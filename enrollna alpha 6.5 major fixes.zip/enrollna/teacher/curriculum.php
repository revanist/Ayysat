<?php
require __DIR__.'/teacher_bootstrap.php';

$teacherId = (int)$teacherId;
$selectedAssignmentId = (int)($_GET['assignment_id'] ?? 0);

$q = mysqli_prepare($conn, "
    SELECT a.id AS assignment_id, a.section_id, a.school_year, a.semester,
           sec.section_name, c.course_code, c.course_name,
           sub.subject_code, sub.subject_name, sub.units,
           sub.year_level, sub.sem, sub.schedule_day, sub.schedule_time, sub.room_number
    FROM teaching_assignments a
    INNER JOIN subjects sub ON sub.id=a.subject_id
    INNER JOIN sections sec ON sec.id=a.section_id
    INNER JOIN courses c ON c.id=sec.course_id
    WHERE a.teacher_id=? AND a.school_year=? AND a.semester=? AND a.status='Active'
    ORDER BY c.course_code, sec.section_name, sub.year_level, sub.sem, sub.subject_code
");
mysqli_stmt_bind_param($q,'isi',$teacherId,$schoolYear,$semester);
mysqli_stmt_execute($q);
$assignments = mysqli_stmt_get_result($q);

$rows=[];
while($r=mysqli_fetch_assoc($assignments)) $rows[]=$r;

$selected = null;
if ($selectedAssignmentId > 0) {
    foreach($rows as $r) { if((int)$r['assignment_id'] === $selectedAssignmentId) { $selected=$r; break; } }
}

// If no assignment was selected, group the instructor's current subjects below.
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Curriculum | EYYSAT</title><link rel="stylesheet" href="../css/admin_dashboard.css"><link rel="stylesheet" href="../css/teacher.css"></head><body><?php include 'sidebar_layout.php';?><main class="dashboard-main">
<section class="teacher-hero"><div><div class="teacher-eyebrow">Academic Reference</div><h1>My Teaching Curriculum</h1><p>Your assigned subjects for SY <?=htmlspecialchars($schoolYear)?> · <?=$semester===1?'1st':'2nd'?> Semester.</p></div></section>
<section class="teacher-panel"><div class="teacher-panel-head"><div><h2>Assigned Subjects</h2><div class="teacher-panel-sub">Each row represents a specific subject, section, and professor assignment. There is no section adviser assignment.</div></div></div>
<div class="teacher-table-wrap"><table class="teacher-table"><thead><tr><th>Code</th><th>Subject</th><th>Section</th><th>Units</th><th>Schedule</th><th>Room</th><th></th></tr></thead><tbody><?php if(!$rows):?><tr><td colspan="7" class="teacher-empty">No active teaching assignments for this semester.</td></tr><?php else:foreach($rows as $r):?><tr><td><strong><?=htmlspecialchars($r['subject_code'])?></strong></td><td><?=htmlspecialchars($r['subject_name'])?></td><td><?=htmlspecialchars($r['course_code'].' · '.$r['section_name'])?></td><td><?=intval($r['units'])?></td><td><?=htmlspecialchars(trim(($r['schedule_day']??'').' '.($r['schedule_time']??''))?:'TBA')?></td><td><?=htmlspecialchars($r['room_number']??'TBA')?></td><td><a class="teacher-link" href="class.php?assignment_id=<?=intval($r['assignment_id'])?>">Open class</a></td></tr><?php endforeach;endif;?></tbody></table></div></section>
</main></body></html>
