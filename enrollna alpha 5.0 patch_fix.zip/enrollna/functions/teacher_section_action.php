<?php
require_once __DIR__ . '/teacher_auth.php';
require_teacher_login();
require_once '../db/dbconn.php';
require_once __DIR__ . '/teacher_setup.php';
ensure_teacher_schema($conn);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ../teacher/sections.php'); exit; }
require_teacher_csrf();
$teacherId=(int)$_SESSION['user_id']; $sectionId=(int)($_POST['section_id']??0); $action=$_POST['action']??'';
if($sectionId<=0){header('Location: ../teacher/sections.php?error=section');exit;}
if($action==='claim'){
 $stmt=mysqli_prepare($conn,'INSERT IGNORE INTO teacher_sections (teacher_id,section_id) VALUES (?,?)');mysqli_stmt_bind_param($stmt,'ii',$teacherId,$sectionId);mysqli_stmt_execute($stmt);mysqli_stmt_close($stmt);
} elseif($action==='release'){
 $stmt=mysqli_prepare($conn,'DELETE FROM teacher_sections WHERE teacher_id=? AND section_id=?');mysqli_stmt_bind_param($stmt,'ii',$teacherId,$sectionId);mysqli_stmt_execute($stmt);mysqli_stmt_close($stmt);
}
header('Location: ../teacher/sections.php?updated=1');exit;
