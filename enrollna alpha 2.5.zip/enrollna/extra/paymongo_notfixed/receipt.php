<?php

require_once __DIR__ . '/student_auth.php';
start_student_session();

require '../db/dbconn.php';


/*
 * Student must be logged in.
 */
if (
    ($_SESSION['role'] ?? '') !== 'student'
    ||
    empty($_SESSION['user_id'])
) {

    header(
        'Location: ../auth/login.php?loginredirect=1',
        true,
        303
    );

    exit;
}


$user_id =
    (int) $_SESSION['user_id'];


$enrollment_id =
    (int) ($_GET['enrollment_id'] ?? 0);


if ($enrollment_id < 1) {

    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


/*
 * Get enrollment.
 */
$stmt = mysqli_prepare(
    $conn,
    "
    SELECT
        e.id,
        e.student_id,
        e.course_id,
        e.section_id,
        e.year_level,
        e.school_year,
        e.sem,
        e.status,
        e.created,
        e.payment_status,
        e.paymongo_link_id,
        e.payment_method,
        e.payment_option,
        e.payment_reference,
        e.amount_paid,

        s.student_number,
        s.first_name,
        s.middle_name,
        s.last_name,
        s.sex,
        s.birthdate,
        s.address,
        s.contact,
        s.email,
        s.guardian,
        s.guardian_contact,

        c.course_code,
        c.course_name,

        sec.section_name

    FROM enrollments e

    INNER JOIN students s
        ON s.id = e.student_id

    LEFT JOIN courses c
        ON c.id = e.course_id

    LEFT JOIN sections sec
        ON sec.id = e.section_id

    WHERE e.id = ?
    AND s.user_id = ?

    LIMIT 1
    "
);

mysqli_stmt_bind_param(
    $stmt,
    'ii',
    $enrollment_id,
    $user_id
);

mysqli_stmt_execute($stmt);

$result =
    mysqli_stmt_get_result($stmt);

$enrollment =
    mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);


if (!$enrollment) {

    http_response_code(404);

    exit('Receipt not found.');
}


/*
 * Curriculum subjects selected in THIS enrollment.
 */
$subjectStmt = mysqli_prepare(
    $conn,
    "
    SELECT
        s.subject_code,
        s.subject_name,

        COALESCE(
            cu.units,
            s.units,
            0
        ) AS units,

        s.schedule_day,
        s.schedule_time,
        s.room_number

    FROM enrollment_details ed

    INNER JOIN subjects s
        ON s.id = ed.subject_id

    LEFT JOIN curriculum cu
        ON cu.subject_id = s.id
        AND cu.course_id = ?
        AND cu.year_level = ?
        AND cu.semester = ?

    WHERE ed.enrollment_id = ?

    ORDER BY
        s.subject_code ASC
    "
);

mysqli_stmt_bind_param(
    $subjectStmt,
    'iiii',
    $enrollment['course_id'],
    $enrollment['year_level'],
    $enrollment['sem'],
    $enrollment_id
);

mysqli_stmt_execute(
    $subjectStmt
);

$subjectResult =
    mysqli_stmt_get_result(
        $subjectStmt
    );


$subjects = [];

$totalUnits = 0.0;


while (
    $subject =
    mysqli_fetch_assoc($subjectResult)
) {

    $subject['units'] =
        (float) $subject['units'];

    $totalUnits +=
        $subject['units'];

    $subjects[] =
        $subject;
}

mysqli_stmt_close(
    $subjectStmt
);


/*
 * Payment information.
 */
$totalTuition =
    (float) ENROLLMENT_PAYMENT_AMOUNT;

$amountPaid =
    (float) $enrollment['amount_paid'];

$remainingBalance =
    max(
        0,
        $totalTuition -
            $amountPaid
    );


$semesterName =
    ((int) $enrollment['sem'] === 1)
    ? '1st Semester'
    : '2nd Semester';


$yearName =
    match ((int) $enrollment['year_level']) {

        1 => '1st Year',
        2 => '2nd Year',
        3 => '3rd Year',
        4 => '4th Year',

        default =>
        'Year ' .
            (int) $enrollment['year_level'],
    };


$studentName =
    trim(
        $enrollment['first_name']
            . ' '
            .
            (
                $enrollment['middle_name']
                ?
                $enrollment['middle_name']
                . ' '
                :
                ''
            )
            .
            $enrollment['last_name']
    );


$receiptNumber =
    'ENR-' .
    str_pad(
        (string) $enrollment['id'],
        8,
        '0',
        STR_PAD_LEFT
    );


function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        Enrollment Receipt <?= h($receiptNumber) ?>
    </title>

    <link
        rel="stylesheet"
        href="../css/receipt.css">

</head>

<body>

    <div class="receipt-page">

        <div class="receipt-actions no-print">

            <a
                href="../student/profile.php"
                class="btn btn-secondary">
                ← Back to Profile
            </a>

            <button
                type="button"
                class="btn btn-primary"
                onclick="window.print()">
                Print / Save PDF
            </button>

        </div>


        <main class="receipt">

            <!-- HEADER -->

            <header class="receipt-header">

                <div class="brand">

                    <div class="logo-wrap">

                        <img
                            src="../assets/img/eyysat.png"
                            alt="EYYSAT">

                    </div>

                    <div>

                        <h1>EYYSAT</h1>

                        <p>
                            Enrollment &amp; Admission Portal
                        </p>

                    </div>

                </div>


                <div class="receipt-title">

                    <span>
                        ENROLLMENT RECEIPT
                    </span>

                    <strong>
                        <?= h($receiptNumber) ?>
                    </strong>

                </div>

            </header>


            <!-- PAYMENT STATUS -->

            <section class="status-row">

                <div>

                    <span class="label">
                        Payment Status
                    </span>

                    <strong
                        class="status
                    <?= $enrollment['payment_status'] === 'Paid'
                        ? 'status-paid'
                        : 'status-pending'
                    ?>">
                        <?= h($enrollment['payment_status']) ?>
                    </strong>

                </div>


                <div>

                    <span class="label">
                        Enrollment Status
                    </span>

                    <strong>
                        <?= h($enrollment['status']) ?>
                    </strong>

                </div>


                <div>

                    <span class="label">
                        School Year
                    </span>

                    <strong>
                        <?= h($enrollment['school_year']) ?>
                    </strong>

                </div>

            </section>


            <!-- STUDENT -->

            <section class="section">

                <div class="section-heading">
                    Student Information
                </div>

                <div class="info-grid">

                    <div class="info-item">

                        <span>
                            Student Number
                        </span>

                        <strong>
                            <?= h($enrollment['student_number']) ?>
                        </strong>

                    </div>


                    <div class="info-item">

                        <span>
                            Full Name
                        </span>

                        <strong>
                            <?= h($studentName) ?>
                        </strong>

                    </div>


                    <div class="info-item">

                        <span>
                            Email
                        </span>

                        <strong>
                            <?= h($enrollment['email']) ?>
                        </strong>

                    </div>


                    <div class="info-item">

                        <span>
                            Contact
                        </span>

                        <strong>
                            <?= h($enrollment['contact']) ?>
                        </strong>

                    </div>

                </div>

            </section>


            <!-- PROGRAM -->

            <section class="section">

                <div class="section-heading">
                    Enrollment Information
                </div>

                <div class="info-grid">

                    <div class="info-item wide">

                        <span>
                            Course
                        </span>

                        <strong>
                            <?= h($enrollment['course_code']) ?>
                            —
                            <?= h($enrollment['course_name']) ?>
                        </strong>

                    </div>


                    <div class="info-item">

                        <span>
                            Year Level
                        </span>

                        <strong>
                            <?= h($yearName) ?>
                        </strong>

                    </div>


                    <div class="info-item">

                        <span>
                            Semester
                        </span>

                        <strong>
                            <?= h($semesterName) ?>
                        </strong>

                    </div>


                    <div class="info-item">

                        <span>
                            Section
                        </span>

                        <strong>
                            <?= h(
                                $enrollment['section_name']
                                    ?: 'Not assigned'
                            ) ?>
                        </strong>

                    </div>

                </div>

            </section>


            <!-- CURRICULUM -->

            <section class="section">

                <div class="section-heading">
                    Enrolled Curriculum
                </div>

                <?php if ($subjects): ?>

                    <div class="table-wrapper">

                        <table>

                            <thead>

                                <tr>

                                    <th>
                                        #
                                    </th>

                                    <th>
                                        Subject Code
                                    </th>

                                    <th>
                                        Subject
                                    </th>

                                    <th>
                                        Schedule
                                    </th>

                                    <th>
                                        Room
                                    </th>

                                    <th class="text-right">
                                        Units
                                    </th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php foreach (
                                    $subjects
                                    as $index => $subject
                                ): ?>

                                    <tr>

                                        <td>
                                            <?= $index + 1 ?>
                                        </td>

                                        <td>
                                            <strong>
                                                <?= h(
                                                    $subject['subject_code']
                                                ) ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <?= h(
                                                $subject['subject_name']
                                            ) ?>
                                        </td>

                                        <td>

                                            <?php if (
                                                $subject['schedule_day']
                                                ||
                                                $subject['schedule_time']
                                            ): ?>

                                                <?= h(
                                                    trim(
                                                        $subject['schedule_day']
                                                            . ' '
                                                            .
                                                            $subject['schedule_time']
                                                    )
                                                ) ?>

                                            <?php else: ?>

                                                —

                                            <?php endif; ?>

                                        </td>

                                        <td>
                                            <?= h(
                                                $subject['room_number']
                                                    ?: '—'
                                            ) ?>
                                        </td>

                                        <td class="text-right">

                                            <?= number_format(
                                                $subject['units'],
                                                1
                                            ) ?>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            </tbody>

                            <tfoot>

                                <tr>

                                    <td
                                        colspan="5"
                                        class="text-right">
                                        Total Units
                                    </td>

                                    <td class="text-right">

                                        <strong>
                                            <?= number_format(
                                                $totalUnits,
                                                1
                                            ) ?>
                                        </strong>

                                    </td>

                                </tr>

                            </tfoot>

                        </table>

                    </div>

                <?php else: ?>

                    <div class="empty">

                        No curriculum subjects were recorded
                        for this enrollment.

                    </div>

                <?php endif; ?>

            </section>


            <!-- PAYMENT -->

            <section class="section">

                <div class="section-heading">
                    Payment Details
                </div>

                <div class="payment-box">

                    <div class="payment-row">

                        <span>
                            Total Enrollment Fee
                        </span>

                        <strong>
                            ₱<?= number_format(
                                    $totalTuition,
                                    2
                                ) ?>
                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Amount Paid
                        </span>

                        <strong class="paid-value">

                            ₱<?= number_format(
                                    $amountPaid,
                                    2
                                ) ?>

                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Remaining Balance
                        </span>

                        <strong>
                            ₱<?= number_format(
                                    $remainingBalance,
                                    2
                                ) ?>
                        </strong>

                    </div>


                    <div class="payment-divider"></div>


                    <div class="payment-row">

                        <span>
                            Payment Method
                        </span>

                        <strong>
                            <?= h(
                                $enrollment['payment_method']
                                    ?: '—'
                            ) ?>
                        </strong>

                    </div>


                    <div class="payment-row">

                        <span>
                            Payment Reference
                        </span>

                        <strong>
                            <?= h(
                                $enrollment['payment_reference']
                                    ?: '—'
                            ) ?>
                        </strong>

                    </div>

                </div>

            </section>


            <!-- FOOTER -->

            <footer class="receipt-footer">

                <div>

                    <strong>
                        Thank you for enrolling with EYYSAT.
                    </strong>

                    <p>
                        Please keep this receipt for your records.
                    </p>

                </div>


                <?php if (
                    $enrollment['payment_status']
                    === 'Paid'
                ): ?>

                    <div class="confirmed">

                        ✓ Payment Confirmed

                    </div>

                <?php endif; ?>

            </footer>

        </main>

    </div>

</body>

</html>