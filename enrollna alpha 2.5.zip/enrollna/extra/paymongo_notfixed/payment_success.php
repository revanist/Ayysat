<?php

require_once __DIR__ . '/student_auth.php';
start_student_session();

require '../db/dbconn.php';


$enrollment_id =
    (int) ($_GET['enrollment_id'] ?? 0);


if ($enrollment_id < 1) {

    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


$user_id =
    (int) ($_SESSION['user_id'] ?? 0);


if ($user_id < 1) {

    header(
        'Location: ../auth/login.php?loginredirect=1',
        true,
        303
    );

    exit;
}


/*
 * Check whether the webhook has already marked
 * the payment as paid.
 */
$stmt = mysqli_prepare(
    $conn,
    "
    SELECT
        e.id,
        e.payment_status,
        e.payment_reference,
        e.amount_paid
    FROM enrollments e
    INNER JOIN students s
        ON s.id = e.student_id
    WHERE e.id = ?
    AND s.user_id = ?
    LIMIT 1
    "
);

mysqli_stmt_bind_param(
    $stmt,
    'ii',
    $enrollment_id,
    $user_id
);

mysqli_stmt_execute($stmt);

$result =
    mysqli_stmt_get_result($stmt);

$row =
    mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);


if (!$row) {

    http_response_code(404);

    exit('Enrollment not found.');
}


if (
    $row['payment_status']
    === 'Paid'
) {

    header(
        'Location: receipt.php?enrollment_id=' .
            $enrollment_id,
        true,
        303
    );

    exit;
}


/*
 * Payment has not been confirmed by webhook yet.
 */
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Payment Processing | EYYSAT</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family:
                Arial,
                Helvetica,
                sans-serif;
            background: #f5f7fb;
            color: #182230;
        }

        .card {
            width: min(520px, 92%);
            background: white;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow:
                0 15px 45px rgba(0, 0, 0, .10);
        }

        .spinner {
            width: 55px;
            height: 55px;
            margin: 0 auto 25px;
            border: 5px solid #e8edf4;
            border-top-color: #0d3b66;
            border-radius: 50%;
            animation: spin .9s linear infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        h1 {
            margin: 0 0 12px;
        }

        p {
            color: #64748b;
            line-height: 1.6;
        }

        .button {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 20px;
            border-radius: 10px;
            text-decoration: none;
            background: #0d3b66;
            color: white;
        }
    </style>

</head>

<body>

    <div class="card">

        <div class="spinner"></div>

        <h1>Payment Processing</h1>

        <p>
            Your payment was returned successfully.
            We are waiting for PayMongo to confirm the
            payment with EYYSAT.
        </p>

        <p>
            This page will automatically check again.
        </p>

        <a
            class="button"
            href="payment_success.php?enrollment_id=<?= (int) $enrollment_id ?>">
            Check Payment Status
        </a>

    </div>


    <script>
        setTimeout(function() {

            window.location.reload();

        }, 5000);
    </script>

</body>

</html>