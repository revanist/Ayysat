<?php

require_once __DIR__ . '/student_auth.php';
start_student_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../webhome.php', true, 303);
    exit;
}

require_student_csrf();

/*
 * This endpoint is only for an intentional "Back to Home" action.
 * Validation failures deliberately keep the draft so the applicant does
 * not lose correctly entered information.
 */
unset(
    $_SESSION['enrollment_draft'],
    $_SESSION['enrollment_error'],
    $_SESSION['enrollment_payment_reference']
);

/* Allow a fresh enrollment attempt to receive a new CSRF token. */
unset($_SESSION['student_csrf_token']);

header('Location: ../webhome.php', true, 303);
exit;
