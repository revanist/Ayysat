<?php 
    require __DIR__ . '/teacher_bootstrap.php';

    $q = mysqli_prepare($conn, 
    "SELECT COUNT(*) total 
    FROM teaching_assignments 
    WHERE teacher_id=? 
    AND school_year=? AND semester=? 
    AND status='Active'");

    mysqli_stmt_bind_param($q, 'isi', $teacherId, $schoolYear, $semester);
    mysqli_stmt_execute($q);
    $assignments = (int) mysqli_fetch_assoc(mysqli_stmt_get_result($q))['total'];

    $q = mysqli_prepare($conn, 
    "SELECT COUNT(DISTINCT section_id) total 
    FROM teaching_assignments WHERE teacher_id=? 
    AND school_year=? AND semester=? 
    AND status='Active'");

    mysqli_stmt_bind_param($q, 'isi', $teacherId, $schoolYear, $semester);
    mysqli_stmt_execute($q);
    $sections = (int) mysqli_fetch_assoc(mysqli_stmt_get_result($q))['total'];

    $q = mysqli_prepare($conn, 
    "SELECT COUNT(DISTINCT s.id) total 
    FROM students s JOIN enrollments e ON e.student_id=s.id 
    JOIN teaching_assignments a ON a.section_id=e.section_id WHERE a.teacher_id=? 
    AND e.school_year=? AND e.sem=? AND a.school_year COLLATE utf8mb4_general_ci=e.school_year COLLATE utf8mb4_general_ci AND a.semester=e.sem 
    AND a.status='Active' AND e.STATUS IN ('Approved','Enrolled')");

    mysqli_stmt_bind_param($q, 'isi', $teacherId, $schoolYear, $semester);
    mysqli_stmt_execute($q);
    $students = (int) mysqli_fetch_assoc(mysqli_stmt_get_result($q))['total'];

    $q = mysqli_prepare($conn, 
    "SELECT a.id,a.title,a.body,a.publish_at,sub.subject_code,sec.section_name 
    FROM lms_announcements a JOIN teaching_assignments ta ON ta.id=a.assignment_id 
    JOIN subjects sub ON sub.id=ta.subject_id JOIN sections sec ON sec.id=ta.section_id 
    WHERE a.teacher_id=? ORDER BY a.publish_at DESC LIMIT 5");
    
    mysqli_stmt_bind_param($q, 'i', $teacherId);
    mysqli_stmt_execute($q);
    $ann = mysqli_stmt_get_result($q);
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Teacher Dashboard | EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/teacher.css">
</head>

<body>
    <?php include 'teacher_sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="hero">
            <div class="welcome"><span class="hero-badge">Faculty LMS</span>
                <h1>Good day, <?= htmlspecialchars($_SESSION['fullname'] ?? 'Teacher') ?>.</h1>
                <p>Your teaching assignments are synchronized with the enrollment system.</p>
            </div>
            <div class="hero-stats">
                <div class="mini-stat">
                    <h3>School Year</h3><span><?= htmlspecialchars($schoolYear) ?></span>
                </div>
                <div class="mini-stat">
                    <h3>Semester</h3><span><?= $semester == 1 ? '1st' : '2nd' ?></span>
                </div>
            </div>
        </div>
        <div class="teacher-grid">
            <div class="teacher-card">
                <h3>My Subjects</h3>
                <div class="teacher-stat"><?= $assignments ?></div>
                <p>Active subject assignments</p>
            </div>
            <div class="teacher-card">
                <h3>My Sections</h3>
                <div class="teacher-stat"><?= $sections ?></div>
                <p>Sections you're teaching</p>
            </div>
            <div class="teacher-card">
                <h3>Students</h3>
                <div class="teacher-stat"><?= $students ?></div>
                <p>Enrolled students in your classes</p>
            </div>
        </div>
        <div class="teacher-card">
            <div class="section-header">
                <div>
                    <h3>Recent Announcements</h3>
                    <p class="muted">Messages you've published to your classes.</p>
                </div><a class="teacher-btn" href="announcements.php">Manage announcements</a>
            </div>
            <?php if (mysqli_num_rows($ann) === 0): ?>
                <div class="empty">No announcements yet.</div><?php else: ?>
                <div class="table-wrap">
                    <table class="teacher-table">
                        <thead>
                            <tr>
                                <th>Class</th>
                                <th>Announcement</th>
                                <th>Published</th>
                            </tr>
                        </thead>
                        <tbody><?php while ($r = mysqli_fetch_assoc($ann)): ?>
                                <tr>
                                    <td><span class="badge"><?= htmlspecialchars($r['subject_code']) ?></span>
                                        <?= htmlspecialchars($r['section_name']) ?></td>
                                    <td><strong><?= htmlspecialchars($r['title']) ?></strong><br><span
                                            class="muted"><?= htmlspecialchars(mb_strimwidth($r['body'], 0, 100, '…')) ?></span></td>
                                    <td><?= htmlspecialchars(date('M d, Y g:i A', strtotime($r['publish_at']))) ?></td>
                                </tr><?php endwhile; ?>
                        </tbody>
                    </table>
                </div><?php endif; ?>
        </div>
    </main>
</body>

</html>