<?php
require_once __DIR__ . '/student_auth.php';
require_student_login();
require_once __DIR__ . '/enrollment_setup.php';
require_once __DIR__ . '/../db/dbconn.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../student/profile.php', true, 303);
    exit;
}

$token = (string) ($_POST['csrf_token'] ?? '');
if (!hash_equals((string) student_csrf_token(), $token)) {
    http_response_code(403);
    exit('Invalid security token.');
}

$userId = (int) $_SESSION['user_id'];
ensure_enrollment_schema($conn);

$studentResult = mysqli_query($conn, "SELECT id, remaining_balance FROM students WHERE user_id = $userId LIMIT 1");
$student = mysqli_fetch_assoc($studentResult);
if (!$student) {
    header('Location: ../student/profile.php', true, 303);
    exit;
}

$studentId = (int) $student['id'];
$balance = max(0, (float) ($student['remaining_balance'] ?? 0));

if ($balance <= 0) {
    header('Location: ../student/profile.php#payment', true, 303);
    exit;
}

$paymentMethod = strtolower(trim((string) ($_POST['payment_method'] ?? '')));
$paymentAccount = trim((string) ($_POST['payment_account'] ?? ''));
$paymentReference = trim((string) ($_SESSION['student_payment_reference'] ?? ''));
$requestedAmount = (float) ($_POST['payment_amount'] ?? 0);

if ($paymentMethod !== 'gcash') {
    header('Location: ../student/profile.php?payment=invalid_method#payment', true, 303);
    exit;
}

if ($requestedAmount <= 0) {
    header('Location: ../student/profile.php?payment=invalid_amount#payment', true, 303);
    exit;
}

// Never allow a payment request to exceed the student's current balance.
if ($requestedAmount > $balance + 0.00001) {
    header('Location: ../student/profile.php?payment=exceeds_balance#payment', true, 303);
    exit;
}

if ($paymentAccount === '') {
    header('Location: ../student/profile.php?payment=missing_details#payment', true, 303);
    exit;
}

if ($paymentReference === '') {
    $paymentReference = generate_payment_reference($conn);
}

$enrollment = mysqli_prepare($conn, "
    SELECT id, payment_status FROM enrollments
    WHERE student_id = ?
    ORDER BY id DESC LIMIT 1
");
mysqli_stmt_bind_param($enrollment, 'i', $studentId);
mysqli_stmt_execute($enrollment);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($enrollment));
mysqli_stmt_close($enrollment);

if (!$row || strtolower((string) $row['payment_status']) === 'paid') {
    header('Location: ../student/profile.php#payment', true, 303);
    exit;
}

$enrollmentId = (int) $row['id'];

// Save the payment request and cashier notification together so a successful
// student submission is always visible in the cashier/notifications queue.
mysqli_begin_transaction($conn);

try {
    $update = mysqli_prepare($conn, "
        UPDATE enrollments
        SET cash_amount_requested = ?, payment_status = 'Pending',
            payment_method = ?, payment_account = ?, payment_reference = ?
        WHERE id = ?
    ");
    if (!$update) {
        throw new RuntimeException('Unable to prepare payment request.');
    }
    mysqli_stmt_bind_param($update, 'dsssi', $requestedAmount, $paymentMethod, $paymentAccount, $paymentReference, $enrollmentId);
    if (!mysqli_stmt_execute($update)) {
        mysqli_stmt_close($update);
        throw new RuntimeException('Unable to save payment request.');
    }
    mysqli_stmt_close($update);

    $nameResult = mysqli_query(
        $conn,
        "SELECT first_name, last_name FROM students WHERE id = $studentId LIMIT 1"
    );
    $nameRow = $nameResult ? mysqli_fetch_assoc($nameResult) : null;
    $studentName = trim((string) (($nameRow['first_name'] ?? '') . ' ' . ($nameRow['last_name'] ?? '')));
    if ($studentName === '') {
        $studentName = 'A student';
    }

    $notificationMessage = sprintf(
        '%s submitted a GCash payment request of ₱%s. Reference: %s.',
        $studentName,
        number_format($requestedAmount, 2),
        $paymentReference
    );

    $notificationStmt = mysqli_prepare(
        $conn,
        'INSERT INTO admin_notifications (enrollment_id, message, is_read) VALUES (?, ?, 0)'
    );
    if (!$notificationStmt) {
        throw new RuntimeException('Unable to prepare cashier notification.');
    }
    mysqli_stmt_bind_param($notificationStmt, 'is', $enrollmentId, $notificationMessage);
    if (!mysqli_stmt_execute($notificationStmt)) {
        mysqli_stmt_close($notificationStmt);
        throw new RuntimeException('Unable to notify the cashier.');
    }
    mysqli_stmt_close($notificationStmt);

    mysqli_commit($conn);
    unset($_SESSION['student_payment_reference']);

    header('Location: ../student/payment_receipt.php?enrollment_id=' . $enrollmentId, true, 303);
    exit;
} catch (Throwable $exception) {
    mysqli_rollback($conn);
    header('Location: ../student/profile.php?payment=failed#payment', true, 303);
    exit;
}
