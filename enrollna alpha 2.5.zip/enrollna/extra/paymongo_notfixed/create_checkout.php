<?php

require_once __DIR__ . '/student_auth.php';

start_student_session();


require '../db/dbconn.php';

require_once __DIR__ . '/enrollment_setup.php';

require_once __DIR__ . '/paymongo_config.php';


/*
 * Fallback definition.
 *
 * This prevents the Undefined constant error
 * if the constant has not yet been placed in
 * paymongo_config.php.
 *
 * Recommended long-term location:
 * paymongo_config.php
 */
if (!defined('ENROLLMENT_PAYMENT_AMOUNT')) {

    define(
        'ENROLLMENT_PAYMENT_AMOUNT',
        500.00
    );
}


/*
 * Only logged-in students can create
 * their own checkout session.
 */
if (

    ($_SESSION['role'] ?? '') !==
    'student'

    ||

    empty($_SESSION['user_id'])

) {

    header(
        'Location: ../auth/login.php?loginredirect=1',
        true,
        303
    );

    exit;
}


/*
 * Enrollment ID.
 */
$enrollment_id =
    (int) (
        $_GET['enrollment_id']
        ?? 0
    );


if (
    $enrollment_id < 1
) {

    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


/*
 * Current user.
 */
$user_id =
    (int) $_SESSION['user_id'];


/*
 * Get enrollment and verify ownership.
 */
$stmt =
    mysqli_prepare(
        $conn,
        "
        SELECT

            e.id,

            e.student_id,

            e.course_id,

            e.section_id,

            e.year_level,

            e.school_year,

            e.sem,

            e.status,

            e.payment_status,

            e.payment_method,

            e.payment_option,

            e.payment_reference,

            e.paymongo_link_id,

            e.amount_paid,

            s.student_number,

            s.first_name,

            s.middle_name,

            s.last_name,

            s.email,

            s.contact,

            c.course_code,

            c.course_name,

            sec.section_name

        FROM enrollments e

        INNER JOIN students s
            ON s.id = e.student_id

        LEFT JOIN courses c
            ON c.id = e.course_id

        LEFT JOIN sections sec
            ON sec.id = e.section_id

        WHERE e.id = ?

        AND s.user_id = ?

        LIMIT 1
        "
    );


mysqli_stmt_bind_param(
    $stmt,
    'ii',
    $enrollment_id,
    $user_id
);


mysqli_stmt_execute(
    $stmt
);


$result =
    mysqli_stmt_get_result(
        $stmt
    );


$enrollment =
    mysqli_fetch_assoc(
        $result
    );


mysqli_stmt_close(
    $stmt
);


if (!$enrollment) {

    http_response_code(404);

    exit('Enrollment not found.');
}


/*
 * Don't create another payment if already paid.
 */
if (
    $enrollment['payment_status']
    === 'Paid'
) {

    header(
        'Location: receipt.php?enrollment_id=' .
            $enrollment_id,
        true,
        303
    );

    exit;
}


/*
 * Server-side allowed payment methods.
 */
$allowed_payment_methods = [

    'card',

    'gcash',

    'maya',

    'qrph'

];


$selectedPaymentMethod =
    strtolower(
        trim(
            (string) (
                $enrollment['payment_method']
                ?? ''
            )
        )
    );


/*
 * Never trust the database value blindly.
 */
if (
    !in_array(
        $selectedPaymentMethod,
        $allowed_payment_methods,
        true
    )
) {

    $_SESSION['enrollment_error'] =
        'The selected payment method is invalid. Please return to enrollment and select a valid PayMongo payment method.';


    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


/*
 * If an existing active checkout session
 * exists, reuse it.
 */
if (
    !empty($enrollment['paymongo_link_id'])
) {

    try {

        $existing =
            paymongo_get_checkout_session(
                $enrollment['paymongo_link_id']
            );


        $existingUrl =
            $existing['data']['attributes']['checkout_url']
            ?? '';


        $existingStatus =
            $existing['data']['attributes']['status']
            ?? '';


        if (

            $existingUrl !== ''

            &&

            $existingStatus ===
            'active'

        ) {

            header(
                'Location: ' .
                    $existingUrl,
                true,
                303
            );

            exit;
        }
    } catch (
        Throwable $ignored
    ) {

        /*
         * Existing checkout is unavailable
         * or expired.
         *
         * Create a new checkout below.
         */
    }
}


/*
 * Server-controlled amount.
 *
 * NEVER read the payment amount from GET or POST.
 */
$amount =
    (float) ENROLLMENT_PAYMENT_AMOUNT;


/*
 * Convert PHP pesos to PayMongo centavos.
 *
 * Example:
 *
 * ₱500.00
 *
 * becomes:
 *
 * 50000
 */
$amountCentavos =
    (int) round(
        $amount * 100
    );


if (
    $amountCentavos < 100
) {

    $_SESSION['enrollment_error'] =
        'The enrollment amount is invalid.';


    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


/*
 * Student name.
 */
$studentName =
    trim(

        $enrollment['first_name']

            . ' '

            .

            (
                $enrollment['middle_name']
                ? $enrollment['middle_name']
                . ' '
                : ''
            )

            .

            $enrollment['last_name']

    );


/*
 * Course name.
 */
$courseName =
    $enrollment['course_code']

    ?

    $enrollment['course_code']
    . ' - '
    . $enrollment['course_name']

    :

    'Enrollment';


/*
 * Semester.
 */
$semesterName =
    (
        (int)
        $enrollment['sem']
        === 1
    )

    ?

    '1st Semester'

    :

    '2nd Semester';


/*
 * Stable reference number.
 */
$reference =
    'ENR-' .

    str_pad(
        (string) $enrollment_id,
        8,
        '0',
        STR_PAD_LEFT
    );


/*
 * Application URLs.
 */
$successUrl =
    APP_BASE_URL .
    '/auth/payment_success.php?enrollment_id=' .
    $enrollment_id;


$cancelUrl =
    APP_BASE_URL .
    '/auth/payment_cancel.php?enrollment_id=' .
    $enrollment_id;


/*
 * PayMongo Hosted Checkout.
 *
 * IMPORTANT:
 *
 * Only the selected payment method is supplied.
 *
 * Example:
 *
 * GCash:
 * ["gcash"]
 *
 * Card:
 * ["card"]
 *
 * Maya:
 * ["maya"]
 *
 * QR Ph:
 * ["qrph"]
 */
$payload = [

    'data' => [

        'attributes' => [

            'line_items' => [

                [

                    'name' =>
                    'EYYSAT Enrollment Fee',

                    'amount' =>
                    $amountCentavos,

                    'currency' =>
                    'PHP',

                    'quantity' =>
                    1,

                    'description' =>
                    $courseName .
                        ' - ' .
                        $semesterName

                ]

            ],


            /*
             * This is the important part:
             *
             * The payment method selected
             * during enrollment is carried
             * into PayMongo.
             */
            'payment_method_types' => [

                $selectedPaymentMethod

            ],


            'success_url' =>
            $successUrl,


            'cancel_url' =>
            $cancelUrl,


            'reference_number' =>
            $reference,


            'description' =>
            'EYYSAT enrollment for ' .
                $studentName,


            'send_email_receipt' =>
            true,


            'show_description' =>
            true,


            'show_line_items' =>
            true,


            'billing' => [

                'name' =>
                $studentName,

                'email' =>
                $enrollment['email'],

                'phone' =>
                $enrollment['contact'],

                'address' => [

                    'country' =>
                    'PH'

                ]

            ],


            'metadata' => [

                'enrollment_id' =>
                (string)
                $enrollment_id,

                'student_id' =>
                (string)
                $enrollment['student_id'],

                'student_number' =>
                (string)
                $enrollment['student_number'],

                'payment_method' =>
                $selectedPaymentMethod

            ]

        ]

    ]

];


try {

    $response =
        paymongo_request(
            'POST',
            PAYMONGO_CHECKOUT_URL,
            $payload
        );
} catch (
    Throwable $exception
) {

    /*
     * Do not expose the PayMongo secret/API
     * error to the student.
     */
    $_SESSION['enrollment_error'] =
        'Unable to create the PayMongo checkout. Please make sure the selected payment method is enabled in your PayMongo account and try again.';


    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


/*
 * Checkout Session ID.
 */
$checkoutSessionId =
    $response['data']['id']
    ?? '';


/*
 * Checkout URL.
 */
$checkoutUrl =
    $response['data']['attributes']['checkout_url']
    ?? '';


if (

    $checkoutSessionId === ''

    ||

    $checkoutUrl === ''

) {

    $_SESSION['enrollment_error'] =
        'PayMongo did not return a valid checkout session.';


    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


/*
 * Save the Checkout Session ID.
 *
 * Payment is still Pending.
 */
$update =
    mysqli_prepare(
        $conn,
        "
        UPDATE enrollments

        SET

            paymongo_link_id = ?,

            payment_reference = ?,

            payment_status = 'Pending',

            amount_paid = 0.00

        WHERE id = ?

        AND student_id = ?
        "
    );


mysqli_stmt_bind_param(
    $update,
    'ssii',
    $checkoutSessionId,
    $reference,
    $enrollment_id,
    $enrollment['student_id']
);


mysqli_stmt_execute(
    $update
);


mysqli_stmt_close(
    $update
);


/*
 * Redirect to PayMongo Hosted Checkout.
 */
header(
    'Location: ' .
        $checkoutUrl,
    true,
    303
);


exit;
