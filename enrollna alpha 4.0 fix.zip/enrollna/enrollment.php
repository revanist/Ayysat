<?php

require_once __DIR__ . '/functions/student_auth.php';

start_student_session();

require __DIR__ . '/db/dbconn.php';

require_once __DIR__ . '/functions/enrollment_setup.php';

ensure_enrollment_schema($conn);
seed_course_data($conn);

if (empty($_SESSION['enrollment_payment_reference'])) {
  $_SESSION['enrollment_payment_reference'] = generate_payment_reference($conn);
}
$enrollmentPaymentReference = (string) $_SESSION['enrollment_payment_reference'];


/*
 * Load courses.
 */
$courses = mysqli_query(
  $conn,
  "
    SELECT
        id,
        course_code,
        course_name
    FROM courses
    ORDER BY course_code ASC
    "
);

$course_catalog = [];

while ($course = mysqli_fetch_assoc($courses)) {

  $course_id = (int) $course['id'];


  /*
     * Sections.
     */
  $sections_result = mysqli_query(
    $conn,
    "
        SELECT
            id,
            section_name
        FROM sections
        WHERE course_id = {$course_id}
        ORDER BY section_name ASC
        "
  );

  $sections = [];

  while ($section = mysqli_fetch_assoc($sections_result)) {
    $sections[] = $section;
  }


  /*
     * Curriculum.
     */
  $curriculum_result = mysqli_query(
    $conn,
    "
        SELECT
            s.id,
            s.subject_code,
            s.subject_name,
            c.units,
            c.year_level,
            c.semester,
            s.schedule_day,
            s.schedule_time,
            s.room_number

        FROM curriculum c
        INNER JOIN subjects s ON s.id = c.subject_id

        WHERE c.course_id = {$course_id}
        AND s.is_available = 1

        ORDER BY
            c.year_level ASC,
            c.semester ASC,
            s.subject_code ASC
        "
  );

  $curriculum = [];

  if ($curriculum_result) {

    while ($subject = mysqli_fetch_assoc($curriculum_result)) {
      $curriculum[] = $subject;
    }
  }


  /*
     * Existing subject catalog.
     */
  $subjects_result = mysqli_query(
    $conn,
    "
        SELECT
            id,
            subject_code,
            subject_name,
            schedule_day,
            schedule_time,
            room_number
        FROM subjects
        WHERE course_id = {$course_id}
        AND is_available = 1
        ORDER BY subject_code ASC
        "
  );

  $subjects = [];

  while ($subject = mysqli_fetch_assoc($subjects_result)) {
    $subjects[] = $subject;
  }


  $course_catalog[] = [
    'course' => $course,
    'sections' => $sections,
    'subjects' => $subjects,
    'curriculum' => $curriculum,
  ];
}


$enrollmentError =
  $_SESSION['enrollment_error'] ?? '';

unset($_SESSION['enrollment_error']);


/*
 * Server-side display amount.
 *
 * This is only for displaying the enrollment fee.
 * The backend remains authoritative.
 */
if (!defined('ENROLLMENT_PAYMENT_AMOUNT')) {
  define('ENROLLMENT_PAYMENT_AMOUNT', 2500.00);
}

$enrollmentFee =
  (float) ENROLLMENT_PAYMENT_AMOUNT;

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0">

  <title>
    Student Enrollment & Registration Portal
  </title>

  <link
    href="css/bootstrap.css"
    rel="stylesheet">

  <link
    href="css/enrollment.css"
    rel="stylesheet">

  <style>
    /* ==========================================================
           CURRICULUM
        ========================================================== */

    .curriculum-panel,
    .registration-section {

      border: 1px solid #dfe7f1;
      border-radius: 18px;
      background: #fff;
      overflow: hidden;
      box-shadow:
        0 8px 24px rgba(30, 90, 150, 0.06);
    }

    .curriculum-panel-header,
    .registration-section-header {

      padding: 20px 22px;

      background:
        linear-gradient(135deg,
          #f5f9ff 0%,
          #ffffff 100%);

      border-bottom:
        1px solid #e5ebf3;

      display: flex;
      align-items: center;
      justify-content: space-between;

      gap: 16px;
    }

    .curriculum-panel-header h4,
    .registration-section-header h5 {

      color: #0d3b66;
      font-weight: 700;
    }

    .curriculum-kicker {

      color: #1e5a96;

      font-size: .72rem;

      font-weight: 800;

      letter-spacing: .12em;

      text-transform: uppercase;

      margin-bottom: 4px;
    }

    .curriculum-course-badge {

      background: #0d3b66;

      color: #fff;

      border-radius: 999px;

      padding: 8px 14px;

      font-size: .82rem;

      font-weight: 700;

      white-space: nowrap;
    }

    .curriculum-accordion {

      padding: 16px;

      background: #f8fafc;
    }

    .curriculum-year-item {

      border:
        1px solid #dfe7f1 !important;

      border-radius:
        14px !important;

      overflow: hidden;

      margin-bottom: 12px;

      background: #fff;
    }

    .curriculum-year-item:last-child {

      margin-bottom: 0;
    }

    .curriculum-year-button {

      gap: 14px;

      padding: 15px 18px;

      color: #163b60;

      background: #fff;

      box-shadow: none !important;
    }

    .curriculum-year-button:not(.collapsed) {

      color: #0d3b66;

      background: #eef5ff;
    }

    .curriculum-year-button::after {

      margin-left: auto;
    }

    .year-number {

      width: 38px;
      height: 38px;

      display: inline-flex;

      align-items: center;
      justify-content: center;

      border-radius: 11px;

      background: #0d3b66;

      color: #fff;

      font-weight: 800;

      flex: 0 0 auto;
    }

    .curriculum-year-button span:nth-child(2) {

      display: flex;

      flex-direction: column;

      gap: 2px;
    }

    .curriculum-year-button small,
    .semester-toggle small {

      color: #718096;

      font-size: .78rem;

      font-weight: 500;
    }

    .curriculum-year-button strong {

      font-size: .98rem;
    }

    .curriculum-year-item .accordion-body {

      padding:
        0 14px 14px;

      background: #fff;
    }

    .semester-card {

      border:
        1px solid #e0e7ef;

      border-radius: 12px;

      overflow: hidden;

      margin-top: 12px;

      background: #fff;
    }

    .semester-card.selected-semester {

      border-color: #8fb7df;

      box-shadow:
        0 4px 14px rgba(30, 90, 150, .08);
    }

    .semester-toggle {

      width: 100%;

      border: 0;

      padding: 13px 15px;

      background: #fff;

      display: flex;

      align-items: center;

      justify-content: space-between;

      text-align: left;

      color: #244b70;
    }

    .semester-toggle:hover {

      background: #f7faff;
    }

    .semester-toggle>span:first-child {

      display: flex;

      flex-direction: column;

      gap: 2px;
    }

    .semester-total {

      font-size: .82rem;

      font-weight: 700;

      color: #1e5a96;

      background: #edf5ff;

      border-radius: 999px;

      padding: 6px 10px;
    }

    .semester-card .collapse {

      border-top:
        1px solid #edf1f5;
    }

    .curriculum-table-wrap {

      padding: 8px;
    }

    .curriculum-table {

      font-size: .88rem;
    }

    .curriculum-table thead th {

      background: #f6f9fc;

      color: #61758a;

      font-size: .72rem;

      text-transform: uppercase;

      letter-spacing: .05em;

      border-bottom:
        1px solid #e1e8f0;

      padding: 11px 10px;
    }

    .curriculum-table tbody td {

      padding: 11px 10px;

      border-color: #edf1f5;

      vertical-align: middle;
    }

    .subject-code-pill {

      display: inline-block;

      padding: 5px 8px;

      border-radius: 7px;

      background: #eaf3ff;

      color: #16558d;

      font-weight: 800;

      font-size: .76rem;
    }

    .units-badge {

      display: inline-block;

      padding: 5px 8px;

      border-radius: 999px;

      background: #f1f5f9;

      color: #475569;

      font-size: .74rem;

      font-weight: 700;
    }

    .curriculum-summary {

      display: grid;

      grid-template-columns:
        repeat(3, 1fr);

      gap: 1px;

      background: #e2e8f0;

      border-top:
        1px solid #e2e8f0;
    }

    .curriculum-summary>div {

      padding: 14px 18px;

      background: #fff;

      display: flex;

      flex-direction: column;

      gap: 3px;
    }

    .summary-label {

      color: #718096;

      font-size: .72rem;

      text-transform: uppercase;

      letter-spacing: .05em;

      font-weight: 700;
    }

    .curriculum-summary strong {

      color: #0d3b66;
    }

    .curriculum-empty-state {

      text-align: center;

      padding: 42px 20px;

      color: #64748b;

      background: #fff;

      border:
        1px dashed #ccd7e3;

      border-radius: 12px;
    }

    .curriculum-empty-icon {

      font-size: 2rem;

      margin-bottom: 8px;
    }

    .curriculum-empty-state h5 {

      color: #234b70;

      font-weight: 700;
    }


    /* ==========================================================
           PAYMENT METHOD
        ========================================================== */

    .payment-container {

      border:
        1px solid #dfe7f1;

      border-radius: 18px;

      background: #fff;

      padding: 24px;

      box-shadow:
        0 8px 24px rgba(30, 90, 150, 0.06);
    }

    .payment-fee-card {

      display: flex;

      align-items: center;

      justify-content: space-between;

      gap: 20px;

      padding: 20px;

      border-radius: 14px;

      background:
        linear-gradient(135deg,
          #eef5ff,
          #f8fbff);

      border:
        1px solid #d7e7f8;

      margin-bottom: 24px;
    }

    .payment-fee-label {

      color: #64748b;

      font-size: .78rem;

      font-weight: 700;

      text-transform: uppercase;

      letter-spacing: .06em;
    }

    .payment-fee-amount {

      color: #0d3b66;

      font-size: 1.8rem;

      font-weight: 800;
    }

    .payment-method-grid {

      display: grid;

      grid-template-columns:
        repeat(2, 1fr);

      gap: 14px;
    }

    .pay-method {

      position: relative;

      cursor: pointer;

      border:
        2px solid #e2e8f0;

      border-radius: 14px;

      padding: 18px;

      background: #fff;

      transition:
        border-color .2s ease,
        background .2s ease,
        transform .2s ease;
    }

    .pay-method:hover {

      border-color: #8fb7df;

      background: #f8fbff;

      transform: translateY(-1px);
    }

    .pay-method.selected {

      border-color: #0d3b66;

      background: #eef5ff;
    }

    .pay-method input {

      position: absolute;

      opacity: 0;
    }

    .pay-method-title {

      color: #163b60;

      font-weight: 800;

      display: block;

      margin-bottom: 4px;
    }

    .pay-method-description {

      color: #718096;

      font-size: .82rem;

      margin: 0;
    }

    .pay-method-check {

      position: absolute;

      top: 14px;

      right: 14px;

      width: 22px;

      height: 22px;

      border-radius: 50%;

      border:
        2px solid #cbd5e1;

      display: flex;

      align-items: center;

      justify-content: center;

      font-size: .75rem;

      color: transparent;
    }

    .pay-method.selected .pay-method-check {

      background: #0d3b66;

      border-color: #0d3b66;

      color: #fff;
    }

    .payment-security-note {

      margin-top: 20px;

      padding: 14px;

      border-radius: 10px;

      background: #f8fafc;

      border:
        1px solid #e2e8f0;

      color: #64748b;

      font-size: .82rem;
    }

    .payment-security-note strong {

      color: #0d3b66;
    }

    .payment-modal-backdrop {
      position: fixed;
      inset: 0;
      z-index: 2000;
      display: none;
      align-items: center;
      justify-content: center;
      padding: 20px;
      background: rgba(13, 59, 102, .45);
    }

    .payment-modal-backdrop.is-open {
      display: flex;
    }

    .payment-modal {
      width: min(520px, 100%);
      max-height: 90vh;
      overflow-y: auto;
      padding: 26px;
      border-radius: 18px;
      background: #fff;
      box-shadow: 0 20px 60px rgba(13, 59, 102, .25);
    }

    .payment-modal h4 {
      color: #0d3b66;
      font-weight: 800;
    }

    .payment-modal-actions {
      display: flex;
      justify-content: flex-end;
      gap: 10px;
      margin-top: 20px;
    }


    /* ==========================================================
           MOBILE
        ========================================================== */

    @media (max-width: 767px) {

      .curriculum-panel-header,
      .registration-section-header,
      .payment-fee-card {

        align-items: flex-start;

        flex-direction: column;
      }

      .curriculum-summary {

        grid-template-columns: 1fr;
      }

      .curriculum-table {

        min-width: 650px;
      }

      .payment-method-grid {

        grid-template-columns: 1fr;
      }
    }
  

    .review-account-note{margin:18px 0;padding:14px 16px;border:1px solid #dbe7f2;border-radius:12px;background:#f7fbff;color:#486581;font-size:.88rem}
    .account-created-alert{text-align:left;padding:2px 4px}
    .account-created-lead{text-align:center;color:#486581;margin:0 0 18px;font-size:14px}
    .account-credential-box{border:1px solid #d9e4ef;border-radius:14px;background:#f8fbfe;overflow:hidden;margin-bottom:15px}
    .credential-row{display:flex;justify-content:space-between;gap:16px;padding:14px 16px;border-bottom:1px solid #e5edf5;align-items:center}
    .credential-row:last-child{border-bottom:0}
    .credential-row span{font-size:12px;color:#627d98;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
    .credential-row strong{font-size:14px;color:#102a43;word-break:break-word;text-align:right}
    .account-created-warning{padding:13px 15px;border-radius:12px;background:#fff8e6;color:#7a5b00;font-size:12px;line-height:1.55;margin-bottom:13px}
    .account-created-status{text-align:center;font-size:12px;color:#627d98;margin:0}
</style>

<link rel="stylesheet" href="css/ux-polish.css">
<script src="js/ux-polish.js" defer></script>
</head>


<body>

  <div id="pageLoader">

    <div class="loader-content">

      <div class="spinner-border loader-spinner"></div>

      <p>Loading portal...</p>

    </div>

  </div>


  <div class="navbar-ayysat">

    <h1>EYYSAT</h1>

    <div class="tagline">
      Application & Registration Portal
    </div>

  </div>


  <div class="form-panel">

    <?php if ($enrollmentError !== ''): ?>

      <div
        id="enrollmentError"
        data-message="<?= htmlspecialchars(
                        $enrollmentError,
                        ENT_QUOTES,
                        'UTF-8'
                      ); ?>"
        hidden></div>

    <?php endif; ?>


    <ul class="wizard-steps">

      <li class="active">
        1. Personal Info
      </li>

      <li>
        2. Program Selection
      </li>

      <li>
        3. Emergency Contact
      </li>

      <li>
        4. Payment Method
      </li>

      <li>
        5. Review & Submit
      </li>

    </ul>


    <form
      id="enrollmentForm"
      action="functions/process_application.php"
      method="POST"
      enctype="multipart/form-data"
      novalidate>

      <input
        type="hidden"
        name="csrf_token"
        value="<?= htmlspecialchars(
                  student_csrf_token(),
                  ENT_QUOTES,
                  'UTF-8'
                ); ?>">

      <input
        type="hidden"
        name="school_year"
        value="2026-2027">


      <!-- ==================================================
                 STEP 1
            =================================================== -->

      <div
        class="wizard-pane active"
        data-step="1">

        <h3>
          Step 1: Personal Information
        </h3>


        <div class="row">

          <div class="col-md-4 form-group">

            <label>
              First Name *
            </label>

            <input
              type="text"
              class="form-control"
              name="first_name"
              required>

          </div>


          <div class="col-md-4 form-group">

            <label>
              Middle Initial(s)
            </label>

            <input
              type="text"
              class="form-control"
              name="middle_name"
              maxlength="5"
              pattern="[A-Za-z. ]{1,5}"
              title="Use initials only, for example A. or M. J.">

          </div>


          <div class="col-md-4 form-group">

            <label>
              Last Name *
            </label>

            <input
              type="text"
              class="form-control"
              name="last_name"
              required>

          </div>

        </div>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Email Address *
            </label>

            <input
              type="email"
              class="form-control"
              name="email"
              required>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Contact Number *
            </label>

            <input
              type="tel"
              class="form-control"
              name="contact"
              maxlength="11"
              placeholder="09XXXXXXXXX"
              required>

          </div>

        </div>


        <div class="form-group">

          <label>
            Complete Address *
          </label>

          <textarea
            class="form-control"
            name="address"
            rows="3"
            required></textarea>

        </div>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Date of Birth *
            </label>

            <input
              type="date"
              class="form-control"
              name="birthdate"
              id="birthdate"
              required>

            <div
              id="birthdateError"
              class="invalid-feedback">
              You must be 18 years old to apply.
            </div>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Sex *
            </label>

            <select
              class="form-select"
              name="sex"
              required>

              <option
                value=""
                selected
                disabled>
                Select Sex...
              </option>

              <option value="Male">
                Male
              </option>

              <option value="Female">
                Female
              </option>

            </select>

          </div>

        </div>


        <div class="btn-group-wizard">

          <a
            href="webhome.php"
            class="btn btn-secondary">
            ← Back to Home
          </a>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 2
            =================================================== -->

      <div
        class="wizard-pane"
        data-step="2">

        <h3>
          Step 2: Program Selection
        </h3>

        <p class="step-intro">
          Choose the student's course, year level,
          and semester. The curriculum below will
          automatically show the required subjects.
        </p>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Course *
            </label>

            <select
              class="form-select"
              name="course_id"
              required>

              <option
                value=""
                selected
                disabled>
                Select Course
              </option>

              <?php foreach (
                $course_catalog
                as $entry
              ):

                $course =
                  $entry['course'];

              ?>

                <option
                  value="<?= (int) $course['id']; ?>">

                  <?= htmlspecialchars(
                    $course['course_code']
                  ); ?>

                  -

                  <?= htmlspecialchars(
                    $course['course_name']
                  ); ?>

                </option>

              <?php endforeach; ?>

            </select>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Year Level *
            </label>

            <select
              class="form-select"
              name="year_level"
              id="year_level"
              required>

              <option
                value=""
                selected
                disabled>
                Select Year
              </option>

              <option value="1">
                1st Year
              </option>

              <option value="2">
                2nd Year
              </option>

              <option value="3">
                3rd Year
              </option>

              <option value="4">
                4th Year
              </option>

            </select>

          </div>

        </div>


        <div class="row mt-3">

          <div class="col-md-6 form-group">

            <label>
              Semester *
            </label>

            <select
              class="form-select"
              name="semester"
              id="semester"
              required>

              <option
                value=""
                selected
                disabled>
                Select Semester
              </option>

              <option value="1">
                1st Semester
              </option>

              <option value="2">
                2nd Semester
              </option>

            </select>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Curriculum Status
            </label>

            <div
              id="curriculumStatus"
              class="form-control bg-light text-muted">
              Select course, year and semester.
            </div>

          </div>

        </div>


        <!-- CURRICULUM -->

        <div class="curriculum-panel mt-4">

          <div class="curriculum-panel-header">

            <div>

              <div class="curriculum-kicker">
                ACADEMIC PLAN
              </div>

              <h4 class="mb-1">
                📚 Curriculum
              </h4>

              <p class="mb-0 text-muted small">
                Your required subjects are
                organized by year level and semester.
              </p>

            </div>


            <div
              id="curriculumCourseBadge"
              class="curriculum-course-badge">
              No course selected
            </div>

          </div>


          <div
            id="curriculumAccordion"
            class="accordion curriculum-accordion">

            <div class="curriculum-empty-state">

              <div class="curriculum-empty-icon">
                📖
              </div>

              <h5>
                Select a course
              </h5>

              <p class="mb-0">
                Choose a course, year level,
                and semester above.
              </p>

            </div>

          </div>


          <div
            id="curriculumSummary"
            class="curriculum-summary d-none">

            <div>

              <span class="summary-label">
                Selected Semester
              </span>

              <strong id="selectedSemesterLabel">
                —
              </strong>

            </div>


            <div>

              <span class="summary-label">
                Required Subjects
              </span>

              <strong id="selectedSubjectCount">
                0
              </strong>

            </div>


            <div>

              <span class="summary-label">
                Total Units
              </span>

              <strong id="totalUnits">
                0
              </strong>

            </div>

          </div>


          <div
            id="subjectContainer"
            class="d-none"></div>


          <div
            class="invalid-feedback d-none"
            id="subjectError">
            Please select a curriculum first.
          </div>

        </div>


        <!-- SECTION -->

        <div class="registration-section mt-4">

          <div class="registration-section-header">

            <div>

              <div class="curriculum-kicker">
                REGISTRATION
              </div>

              <h5 class="mb-1">
                Class Section
              </h5>

              <p class="mb-0 text-muted small">
                Select the section where the
                student will register.
              </p>

            </div>

          </div>


          <div class="row mt-3">

            <div class="col-md-6 form-group">

              <label>
                Section *
              </label>

              <select
                id="section_select"
                name="section_id"
                class="form-select"
                required>

                <option value="">
                  Select Course First
                </option>

              </select>

            </div>


            <div class="col-md-6">

              <div class="registration-note">

                <strong>
                  How this works
                </strong>

                <p class="mb-0">
                  The curriculum determines
                  the required subjects.
                  The selected section provides
                  the class grouping.
                </p>

              </div>

            </div>

          </div>

        </div>


        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 3
            =================================================== -->

      <div
        class="wizard-pane"
        data-step="3">

        <h3>
          Step 3: Emergency Contact
        </h3>

        <p class="step-intro">
          Provide a parent, guardian, or emergency
          contact who can be reached if necessary.
        </p>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Guardian Name *
            </label>

            <input
              type="text"
              class="form-control"
              name="guardian"
              required>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Guardian Contact Number *
            </label>

            <input
              type="tel"
              class="form-control"
              name="guardian_contact"
              maxlength="11"
              placeholder="09XXXXXXXXX"
              required>

          </div>

        </div>


        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 4 PAYMENT METHOD
            =================================================== -->

      <div
        class="wizard-pane"
        data-step="4">

        <h3>
          Step 4: Payment Method
        </h3>

        <p class="step-intro">
          Select a method and complete your secure enrollment payment.
        </p>


        <div class="payment-container">

          <div class="payment-fee-card">

            <div>

              <div class="payment-fee-label">
                Minimum Down Payment
              </div>

              <div class="text-muted small">
                You may pay a higher custom amount
              </div>

            </div>


            <div class="payment-fee-amount">

              ₱<?= number_format(
                  $enrollmentFee,
                  2
                ); ?>

            </div>

          </div>


          <label class="fw-bold mb-3">
            Preferred Payment Method *
          </label>


          <div class="payment-method-grid">


            <!-- CARD -->

            <label class="pay-method">

              <input
                type="radio"
                name="payment_method"
                value="cash"
                required>

              <span class="pay-method-check">
                ✓
              </span>

              <span class="pay-method-title">
                💵 Cash / Over-the-counter
              </span>

              <p class="pay-method-description">
                Pay at the school cashier / accounting office.
              </p>

            </label>


            <!-- GCASH -->

            <label class="pay-method">

              <input
                type="radio"
                name="payment_method"
                value="gcash"
                required>

              <span class="pay-method-check">
                ✓
              </span>

              <span class="pay-method-title">
                📱 GCash
              </span>

              <p class="pay-method-description">
                Pay securely using GCash.
              </p>

            </label>





          </div>


        </div>


        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 5 REVIEW
            =================================================== -->

      <div
        id="reviewPane"
        class="wizard-pane"
        data-step="5">

        <h3>
          Step 5: Review Your Application
        </h3>

        <p class="step-intro">
          Please review your information and
          payment method before submitting.
        </p>


        <div id="summaryBox"></div>

        <div class="review-account-note">
          <strong>Student account:</strong> Your portal account will be created automatically after you submit this application.
        </div>

        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>


          <div class="review-actions">

            <button
              type="button"
              class="btn btn-outline-primary"
              id="previewRegistrationFormBtn">
              View Registration Form
            </button>

            <button
              type="submit"
              class="btn btn-primary"
              id="submitApplicationBtn">
              ✓ Submit Enrollment
            </button>

          </div>

        </div>

      </div>

    </form>

  </div>

  <div
    id="paymentModalBackdrop"
    class="payment-modal-backdrop"
    role="dialog"
    aria-modal="true"
    aria-labelledby="paymentModalTitle"
    hidden>

    <div class="payment-modal" role="document">
      <div class="payment-modal-header">
        <div>
          <h4 id="paymentModalTitle">Payment Details</h4>
          <p id="paymentModalDescription" class="text-muted small mb-0"></p>
        </div>
        <button type="button" class="payment-modal-close" id="closePaymentX" aria-label="Close">&times;</button>
      </div>

      <input id="paymentAccount" type="hidden" name="payment_account" form="enrollmentForm">

      <div id="walletPaymentFields">
        <div class="payment-instructions" id="walletInstructions"></div>
        <div class="form-group mb-3">
          <label for="walletMobile">Sender mobile number *</label>
          <input id="walletMobile" name="payment_sender_mobile" form="enrollmentForm" class="form-control" type="tel" inputmode="numeric" autocomplete="tel" maxlength="15" placeholder="e.g. 09171234567">
        </div>
        <div class="form-group mb-3">
          <label for="paymentReference">GCash transaction reference</label>
          <input id="paymentReference" name="payment_reference" form="enrollmentForm" class="form-control" maxlength="100" value="<?= htmlspecialchars($enrollmentPaymentReference) ?>" readonly aria-readonly="true">
          <small class="text-muted">This reference is generated automatically and is unique to your enrollment. Use this reference when making your GCash payment.</small>
        </div>
      </div>

      <div id="cashPaymentFields" class="d-none">
        <div class="payment-instructions">
          <strong>Cash payment</strong><br>
          Select this option if you will pay directly at the school cashier. Your enrollment will remain pending until the cashier records the payment.
        </div>
      </div>

      <div class="form-group mb-3">
        <label for="paymentAmount">Amount to pay *</label>
        <input id="paymentAmount" class="form-control" type="number" name="payment_amount" form="enrollmentForm" value="<?= htmlspecialchars(number_format($enrollmentFee, 2, '.', '')) ?>" min="<?= htmlspecialchars(number_format($enrollmentFee, 2, '.', '')) ?>" step="0.01" inputmode="decimal" required>
        <small class="text-muted">Minimum payment: ₱<?= number_format($enrollmentFee, 2) ?>.</small>
      </div>

      <div class="payment-modal-actions">
        <button type="button" class="btn btn-secondary" id="cancelPaymentBtn">Cancel</button>
        <button type="button" class="btn btn-primary" id="confirmPaymentBtn">Confirm Payment Details</button>
      </div>
    </div>
  </div>

  <div
    id="paymentReceiptBackdrop"
    class="payment-modal-backdrop payment-receipt-backdrop"
    role="dialog"
    aria-modal="true"
    aria-labelledby="paymentReceiptTitle"
    hidden>

    <div class="payment-modal payment-receipt-modal" role="document">
      <div class="payment-modal-header">
        <div>
          <span class="receipt-mini-label">EYYSAT PAYMENT CONFIRMATION</span>
          <h4 id="paymentReceiptTitle">Payment Receipt</h4>
          <p class="text-muted small mb-0">
            Keep this confirmation for your records. The cashier will verify the payment before it is marked paid.
          </p>
        </div>
        <button type="button" class="payment-modal-close" id="closePaymentReceiptX" aria-label="Close">&times;</button>
      </div>

      <div class="payment-receipt-success">
        <div class="payment-receipt-icon">✓</div>
        <div>
          <strong>Payment details recorded</strong>
          <span>Receipt No. <b id="receiptNumber">PAY-00000000</b></span>
        </div>
      </div>

      <div class="payment-receipt-card">
        <div class="payment-receipt-row">
          <span>Student</span>
          <strong id="receiptStudent">—</strong>
        </div>
        <div class="payment-receipt-row">
          <span>Payment method</span>
          <strong id="receiptMethod">—</strong>
        </div>
        <div class="payment-receipt-row">
          <span>Account / payer</span>
          <strong id="receiptAccount">—</strong>
        </div>
        <div class="payment-receipt-row">
          <span>Transaction reference</span>
          <strong id="receiptReference">—</strong>
        </div>
        <div class="payment-receipt-row">
          <span>Amount submitted</span>
          <strong class="receipt-amount" id="receiptAmount">₱0.00</strong>
        </div>
        <div class="payment-receipt-row">
          <span>Payment proof</span>
          <strong id="receiptProof">—</strong>
        </div>
      </div>

      <div class="payment-receipt-status">
        <span class="receipt-status-dot"></span>
        <span id="receiptStatus">Payment submitted — pending cashier verification</span>
      </div>

      <div class="payment-modal-actions">
        <button type="button" class="btn btn-primary" id="continueToReviewBtn">
          Continue to Review →
        </button>
      </div>
    </div>
  </div>

  <script src="js/bootstrap.bundle.js"></script>

  <script src="js/sweetalert2.all.min.js"></script>

  <script>
    const courseCatalog =
      <?= json_encode(
        array_map(
          function ($entry) {

            return [

              'id' =>
              (int) $entry['course']['id'],

              'course_code' =>
              $entry['course']['course_code'],

              'course_name' =>
              $entry['course']['course_name'],

              'sections' =>
              $entry['sections'],

              'subjects' =>
              $entry['subjects'],

              'curriculum' =>
              $entry['curriculum'],

            ];
          },
          $course_catalog
        ),
        JSON_HEX_TAG |
          JSON_HEX_APOS |
          JSON_HEX_AMP |
          JSON_HEX_QUOT
      ); ?>;


    function escapeHtml(value) {

      return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }


    document.addEventListener(
      'DOMContentLoaded',
      function() {


        const errorMessage =
          document.getElementById(
            'enrollmentError'
          )?.dataset.message;


        if (errorMessage) {

          Swal.fire({

            icon: 'error',

            title: 'Enrollment incomplete',

            text: errorMessage,

            confirmButtonColor: '#1e5a96'

          });
        }


        const state = {

          step: 1,

          totalSteps: 5,

          paymentConfirmed: false,

          data: {}

        };


        const form =
          document.getElementById(
            'enrollmentForm'
          );


        const panes =
          document.querySelectorAll(
            '.wizard-pane'
          );


        const stepItems =
          document.querySelectorAll(
            '.wizard-steps li'
          );


        const birthdateInput =
          document.getElementById(
            'birthdate'
          );


        const birthdateError =
          document.getElementById(
            'birthdateError'
          );


        /* ==================================================
           BIRTHDATE
        ================================================== */

        function validateBirthdate() {

          if (!birthdateInput?.value) {
            return;
          }


          const selectedDate =
            new Date(
              birthdateInput.value +
              'T00:00:00'
            );


          const latestAllowed =
            new Date();


          latestAllowed.setHours(
            0,
            0,
            0,
            0
          );


          latestAllowed.setFullYear(
            latestAllowed.getFullYear() - 18
          );


          const isUnderage =
            selectedDate >
            latestAllowed;


          birthdateInput.setCustomValidity(
            isUnderage ?
            'Applicants must be at least 18 years old.' :
            ''
          );


          birthdateInput.classList.toggle(
            'is-invalid',
            isUnderage
          );


          birthdateError?.classList.toggle(
            'd-block',
            isUnderage
          );
        }


        birthdateInput?.addEventListener(
          'change',
          validateBirthdate
        );


        /* ==================================================
           LOADER
        ================================================== */

        const loader =
          document.getElementById(
            'pageLoader'
          );


        setTimeout(
          function() {

            if (loader) {
              loader.classList.add(
                'loaded'
              );
            }

          },
          300
        );


        /* ==================================================
           NAVIGATION
        ================================================== */

        function showStep(number) {

          panes.forEach(
            function(pane) {

              pane.classList.toggle(
                'active',
                parseInt(
                  pane.dataset.step,
                  10
                ) === number
              );

            }
          );


          stepItems.forEach(
            function(item, index) {

              item.classList.remove(
                'active',
                'done'
              );


              if (
                index + 1 <
                number
              ) {

                item.classList.add(
                  'done'
                );
              }


              if (
                index + 1 ===
                number
              ) {

                item.classList.add(
                  'active'
                );
              }

            }
          );


          state.step = number;


          window.scrollTo({

            top: document.querySelector(
              '.form-panel'
            ).offsetTop - 100,

            behavior: 'smooth'

          });


          if (number === 5) {
            collectAllData();
            buildSummary();
          }
        }


        function collectAllData() {

          state.data = {};


          form.querySelectorAll(
            'input, select, textarea'
          ).forEach(
            function(field) {

              if (!field.name) {
                return;
              }


              if (
                field.type ===
                'radio'
              ) {

                if (
                  field.checked
                ) {

                  state.data[
                      field.name
                    ] =
                    field.value;
                }

                return;
              }


              if (
                field.type ===
                'checkbox'
              ) {

                return;
              }


              if (
                field.name ===
                'subject_ids[]'
              ) {

                if (
                  !state.data[
                    'subject_ids[]'
                  ]
                ) {

                  state.data[
                    'subject_ids[]'
                  ] = [];
                }


                state.data[
                  'subject_ids[]'
                ].push(
                  field.value
                );

                return;
              }


              state.data[
                  field.name
                ] =
                field.value;

            }
          );
        }


        function validatePane(pane) {

          let valid = true;


          const fields =
            pane.querySelectorAll(
              'input[required], select[required], textarea[required]'
            );


          fields.forEach(
            function(field) {

              if (
                !field.checkValidity()
              ) {

                valid = false;

                field.classList.add(
                  'is-invalid'
                );

              } else {

                field.classList.remove(
                  'is-invalid'
                );

              }

            }
          );


          if (
            pane.dataset.step ===
            '2'
          ) {

            const subjects =
              pane.querySelectorAll(
                'input[name="subject_ids[]"][data-curriculum-subject="true"]'
              );


            const error =
              document.getElementById(
                'subjectError'
              );


            if (
              subjects.length ===
              0
            ) {

              valid = false;

              if (error) {

                error.classList.remove(
                  'd-none'
                );

                error.style.display =
                  'block';

                error.textContent =
                  'Please select a course, year level, and semester with a configured curriculum.';
              }

            } else if (error) {

              error.classList.add(
                'd-none'
              );

              error.style.display =
                'none';
            }
          }


          return valid;
        }


        document
          .querySelectorAll('.btn-next')
          .forEach(
            function(button) {

              button.addEventListener(
                'click',
                function() {

                  const currentPane =
                    document.querySelector(
                      '.wizard-pane.active'
                    );


                  if (
                    !validatePane(
                      currentPane
                    )
                  ) {

                    return;
                  }


                  collectAllData();


                  if (
                    state.step <
                    state.totalSteps
                  ) {

                    showStep(
                      state.step + 1
                    );
                  }

                }
              );

            }
          );


        document
          .querySelectorAll('.btn-prev')
          .forEach(
            function(button) {

              button.addEventListener(
                'click',
                function() {

                  if (
                    state.step >
                    1
                  ) {

                    showStep(
                      state.step - 1
                    );
                  }

                }
              );

            }
          );


        /* ==================================================
           COURSE / CURRICULUM
        ================================================== */

        const courseSelect =
          document.querySelector(
            'select[name="course_id"]'
          );


        const sectionSelect =
          document.getElementById(
            'section_select'
          );


        const curriculumAccordion =
          document.getElementById(
            'curriculumAccordion'
          );


        const curriculumStatus =
          document.getElementById(
            'curriculumStatus'
          );


        const curriculumCourseBadge =
          document.getElementById(
            'curriculumCourseBadge'
          );


        const curriculumSummary =
          document.getElementById(
            'curriculumSummary'
          );


        const selectedSemesterLabel =
          document.getElementById(
            'selectedSemesterLabel'
          );


        const selectedSubjectCount =
          document.getElementById(
            'selectedSubjectCount'
          );


        const totalUnits =
          document.getElementById(
            'totalUnits'
          );


        const yearLevelSelect =
          document.getElementById(
            'year_level'
          );


        const semesterSelect =
          document.getElementById(
            'semester'
          );


        const subjectError =
          document.getElementById(
            'subjectError'
          );


        function ordinalYear(year) {

          const map = {

            '1': '1st Year',

            '2': '2nd Year',

            '3': '3rd Year',

            '4': '4th Year'

          };


          return (
            map[String(year)] ||
            String(year) + ' Year'
          );
        }


        function semesterLabel(
          semester
        ) {

          return String(
              semester
            ) === '1' ?
            '1st Semester' :
            '2nd Semester';
        }


        function curriculumSubjectsFor(
          course,
          year,
          semester
        ) {

          return (
            course?.curriculum || []
          ).filter(
            function(subject) {

              return (
                String(
                  subject.year_level
                ) === String(year) &&
                String(
                  subject.semester
                ) === String(semester)
              );

            }
          );
        }


        function groupCurriculum(course) {

          const groups = {};


          (
            course?.curriculum || []
          ).forEach(
            function(subject) {

              const year =
                String(
                  subject.year_level
                );


              const semester =
                String(
                  subject.semester
                );


              if (!groups[year]) {
                groups[year] = {};
              }


              if (
                !groups[year][semester]
              ) {

                groups[year][semester] = [];
              }


              groups[year][semester]
                .push(subject);

            }
          );


          return groups;
        }


        function makeSubjectTable(
          subjects,
          isSelectedSemester
        ) {

          const wrapper =
            document.createElement(
              'div'
            );


          wrapper.className =
            'table-responsive curriculum-table-wrap';


          if (!subjects.length) {

            wrapper.innerHTML =
              '<div class="alert alert-light border mb-0">No subjects configured for this semester.</div>';

            return wrapper;
          }


          const table =
            document.createElement(
              'table'
            );


          table.className =
            'table curriculum-table align-middle mb-0';


          table.innerHTML = `

                        <thead>

                            <tr>

                                <th>
                                    Code
                                </th>

                                <th>
                                    Subject
                                </th>

                                <th>
                                    Units
                                </th>

                                <th>
                                    Schedule
                                </th>

                                <th>
                                    Room
                                </th>

                            </tr>

                        </thead>

                        <tbody></tbody>

                    `;


          const tbody =
            table.querySelector(
              'tbody'
            );


          subjects.forEach(
            function(subject) {

              const row =
                document.createElement(
                  'tr'
                );


              row.innerHTML = `

                                <td>
                                    <span class="subject-code-pill">
                                        ${escapeHtml(
                                            subject.subject_code
                                        )}
                                    </span>
                                </td>

                                <td>

                                    <div class="fw-semibold">
                                        ${escapeHtml(
                                            subject.subject_name
                                        )}
                                    </div>

                                    ${
                                        isSelectedSemester
                                            ? '<small class="text-success">Required for this registration</small>'
                                            : ''
                                    }

                                </td>

                                <td>

                                    <span class="units-badge">

                                        ${escapeHtml(
                                            subject.units
                                        )}

                                        unit${
                                            Number(
                                                subject.units
                                            ) === 1
                                                ? ''
                                                : 's'
                                        }

                                    </span>

                                </td>

                                <td>

                                    ${escapeHtml(
                                        subject.schedule_day ||
                                        'TBA'
                                    )}

                                    <br>

                                    <span class="text-muted">

                                        ${escapeHtml(
                                            subject.schedule_time ||
                                            ''
                                        )}

                                    </span>

                                </td>

                                <td>

                                    ${escapeHtml(
                                        subject.room_number ||
                                        'TBA'
                                    )}

                                </td>

                            `;


              tbody.appendChild(
                row
              );


              if (
                isSelectedSemester
              ) {

                const hidden =
                  document.createElement(
                    'input'
                  );


                hidden.type =
                  'hidden';


                hidden.name =
                  'subject_ids[]';


                hidden.value =
                  subject.id;


                hidden.dataset
                  .curriculumSubject =
                  'true';


                wrapper.appendChild(
                  hidden
                );
              }

            }
          );


          wrapper.appendChild(
            table
          );


          return wrapper;
        }


        function renderCourseDetails() {

          const courseId =
            courseSelect?.value ||
            '';


          const year =
            yearLevelSelect?.value ||
            '';


          const semester =
            semesterSelect?.value ||
            '';


          const selectedCourse =
            courseCatalog.find(
              function(course) {

                return String(
                  course.id
                ) === String(
                  courseId
                );

              }
            );


          sectionSelect.innerHTML =
            '<option value="">Select Section</option>';


          curriculumAccordion.innerHTML =
            '';


          curriculumSummary?.classList.add(
            'd-none'
          );


          curriculumStatus.textContent =
            'Select course, year and semester.';


          curriculumCourseBadge.textContent =
            'No course selected';


          selectedSemesterLabel.textContent =
            '—';


          selectedSubjectCount.textContent =
            '0';


          totalUnits.textContent =
            '0';


          subjectError?.classList.add(
            'd-none'
          );


          if (!selectedCourse) {

            curriculumAccordion.innerHTML = `

                            <div class="curriculum-empty-state">

                                <div class="curriculum-empty-icon">
                                    📖
                                </div>

                                <h5>
                                    Select a course
                                </h5>

                                <p class="mb-0">
                                    Choose a course,
                                    year level, and semester.
                                </p>

                            </div>

                        `;

            return;
          }


          curriculumCourseBadge.textContent =
            selectedCourse.course_code;


          if (
            selectedCourse.sections?.length
          ) {

            selectedCourse.sections
              .forEach(
                function(section) {

                  const option =
                    document.createElement(
                      'option'
                    );


                  option.value =
                    section.id;


                  option.textContent =
                    section.section_name;


                  sectionSelect
                    .appendChild(
                      option
                    );

                }
              );

          } else {

            sectionSelect.innerHTML =
              '<option value="">No sections available</option>';
          }


          const groups =
            groupCurriculum(
              selectedCourse
            );


          const years =
            Object.keys(groups)
            .sort(
              function(a, b) {

                return (
                  Number(a) -
                  Number(b)
                );

              }
            );


          if (!years.length) {

            curriculumAccordion.innerHTML = `

                            <div class="alert alert-warning mb-0">

                                <strong>
                                    Curriculum not configured.
                                </strong>

                                <br>

                                No curriculum records exist for
                                ${escapeHtml(
                                    selectedCourse.course_code
                                )}
                                yet.

                            </div>

                        `;

            curriculumStatus.textContent =
              'Curriculum not configured.';

            return;
          }


          let selectedSubjects = [];


          if (
            year &&
            semester
          ) {

            selectedSubjects =
              curriculumSubjectsFor(
                selectedCourse,
                year,
                semester
              );
          }


          years.forEach(
            function(year) {

              const yearId =
                'curriculumYear' +
                year;


              const yearItem =
                document.createElement(
                  'div'
                );


              yearItem.className =
                'accordion-item curriculum-year-item';


              const yearHeader =
                document.createElement(
                  'h2'
                );


              yearHeader.className =
                'accordion-header';


              const yearButton =
                document.createElement(
                  'button'
                );


              yearButton.type =
                'button';


              yearButton.className =
                'accordion-button curriculum-year-button ' +
                (
                  String(year) ===
                  String(year) ?
                  '' :
                  'collapsed'
                );


              yearButton.setAttribute(
                'data-bs-toggle',
                'collapse'
              );


              yearButton.setAttribute(
                'data-bs-target',
                '#' +
                yearId +
                'Body'
              );


              yearButton.innerHTML = `

                                <span class="year-number">
                                    ${escapeHtml(year)}
                                </span>

                                <span>

                                    <strong>
                                        ${ordinalYear(year)}
                                    </strong>

                                    <small>
                                        ${
                                            Object.values(
                                                groups[year]
                                            ).reduce(
                                                function (
                                                    sum,
                                                    list
                                                ) {
                                                    return (
                                                        sum +
                                                        list.length
                                                    );
                                                },
                                                0
                                            )
                                        }
                                        curriculum subject(s)
                                    </small>

                                </span>

                            `;


              yearHeader.appendChild(
                yearButton
              );


              const yearBody =
                document.createElement(
                  'div'
                );


              yearBody.id =
                yearId +
                'Body';


              yearBody.className =
                'accordion-collapse collapse';


              const yearInner =
                document.createElement(
                  'div'
                );


              yearInner.className =
                'accordion-body';


              ['1', '2']
              .forEach(
                function(
                  sem
                ) {

                  if (
                    !groups[
                      year
                    ][
                      sem
                    ]
                  ) {

                    return;
                  }


                  const subjects =
                    groups[
                      year
                    ][
                      sem
                    ];


                  const isSelected =
                    String(year) ===
                    String(
                      yearLevelSelect.value
                    ) &&
                    String(sem) ===
                    String(
                      semesterSelect.value
                    );


                  const semId =
                    yearId +
                    'Semester' +
                    sem;


                  const card =
                    document.createElement(
                      'div'
                    );


                  card.className =
                    'semester-card ' +
                    (
                      isSelected ?
                      'selected-semester' :
                      ''
                    );


                  const toggle =
                    document.createElement(
                      'button'
                    );


                  toggle.type =
                    'button';


                  toggle.className =
                    'semester-toggle';


                  toggle.setAttribute(
                    'data-bs-toggle',
                    'collapse'
                  );


                  toggle.setAttribute(
                    'data-bs-target',
                    '#' +
                    semId +
                    'Body'
                  );


                  toggle.innerHTML = `

                                            <span>

                                                <strong>
                                                    ${semesterLabel(
                                                        sem
                                                    )}
                                                </strong>

                                                <small>
                                                    ${subjects.length}
                                                    subject(s)
                                                </small>

                                            </span>

                                            <span class="semester-total">

                                                ${
                                                    subjects.reduce(
                                                        function (
                                                            sum,
                                                            subject
                                                        ) {

                                                            return (
                                                                sum +
                                                                Number(
                                                                    subject.units ||
                                                                    0
                                                                )
                                                            );

                                                        },
                                                        0
                                                    )
                                                }

                                                units

                                            </span>

                                        `;


                  const body =
                    document.createElement(
                      'div'
                    );


                  body.id =
                    semId +
                    'Body';


                  body.className =
                    'collapse ' +
                    (
                      isSelected ?
                      'show' :
                      ''
                    );


                  body.appendChild(
                    makeSubjectTable(
                      subjects,
                      isSelected
                    )
                  );


                  card.appendChild(
                    toggle
                  );


                  card.appendChild(
                    body
                  );


                  yearInner.appendChild(
                    card
                  );

                }
              );


              yearBody.appendChild(
                yearInner
              );


              yearItem.appendChild(
                yearHeader
              );


              yearItem.appendChild(
                yearBody
              );


              curriculumAccordion.appendChild(
                yearItem
              );

            }
          );


          if (
            !year ||
            !semester
          ) {

            curriculumStatus.textContent =
              'Curriculum loaded. Select a year level and semester.';

            return;
          }


          if (
            !selectedSubjects.length
          ) {

            curriculumStatus.textContent =
              'Curriculum not configured for this year and semester.';

            return;
          }


          const units =
            selectedSubjects.reduce(
              function(
                sum,
                subject
              ) {

                return (
                  sum +
                  Number(
                    subject.units ||
                    0
                  )
                );

              },
              0
            );


          curriculumSummary.classList.remove(
            'd-none'
          );


          selectedSemesterLabel.textContent =
            ordinalYear(year) +
            ' • ' +
            semesterLabel(
              semester
            );


          selectedSubjectCount.textContent =
            selectedSubjects.length;


          totalUnits.textContent =
            units +
            ' units';


          curriculumStatus.textContent =
            'Curriculum loaded successfully.';
        }


        courseSelect?.addEventListener(
          'change',
          renderCourseDetails
        );


        yearLevelSelect?.addEventListener(
          'change',
          renderCourseDetails
        );


        semesterSelect?.addEventListener(
          'change',
          renderCourseDetails
        );


        /* ==================================================
           PAYMENT METHOD
        ================================================== */

        const paymentModal = document.getElementById('paymentModalBackdrop');
        const paymentModalTitle = document.getElementById('paymentModalTitle');
        const paymentModalDescription = document.getElementById('paymentModalDescription');
        const paymentAccount = document.getElementById('paymentAccount');
        const walletPaymentFields = document.getElementById('walletPaymentFields');
        const cashPaymentFields = document.getElementById('cashPaymentFields');
        const walletInstructions = document.getElementById('walletInstructions');
        const walletMobile = document.getElementById('walletMobile');
        const paymentReference = document.getElementById('paymentReference');
                const paymentAmount = document.getElementById('paymentAmount');
        const confirmPaymentButton = document.getElementById('confirmPaymentBtn');

        function formattedPaymentAmount() {
          const amount = Number(paymentAmount?.value || 0);
          return Number.isFinite(amount) ? amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00';
        }

        function closePaymentModal() {
          if (!paymentModal) return;
          paymentModal.classList.remove('is-open');
          paymentModal.hidden = true;
        }

        function openPaymentModal(method) {
          if (!paymentModal) { console.error('Payment modal element not found'); return; }

          const isWallet = method === 'gcash';
          const isCash = method === 'cash';
          if (!isWallet && !isCash) return;

          const label = method === 'gcash' ? 'GCash' : 'Cash / Over-the-counter';
          paymentModalTitle.textContent = label + ' Payment';
          paymentModalDescription.textContent = isCash
            ? 'Submit a cash payment request for the school cashier.'
            : 'Enter your transaction details so the cashier can verify your payment.';

          walletPaymentFields.classList.toggle('d-none', !isWallet);
          cashPaymentFields.classList.toggle('d-none', !isCash);

          if (isWallet) {
            walletInstructions.innerHTML = '<strong>Important:</strong> Send the payment to the school official ' + label + ' account, then enter the transaction reference below. <strong>Never enter your MPIN or password.</strong>';
          }

          paymentModal.hidden = false;
          paymentModal.classList.add('is-open');
          document.body.classList.add('payment-modal-open');

          window.setTimeout(function() {
            if (isWallet) walletMobile?.focus();
            else paymentAmount?.focus();
          }, 50);
        }

        // Clicking a payment card immediately opens its details window.
        document.addEventListener('click', function(event) {
          const card = event.target.closest('.pay-method');
          if (!card) return;

          const radio = card.querySelector('input[type="radio"]');
          if (!radio) return;

          document.querySelectorAll('.pay-method').forEach(function(item) { item.classList.remove('selected'); });
          card.classList.add('selected');
          radio.checked = true;
          state.paymentConfirmed = false;
          openPaymentModal(radio.value);
        });

        document.getElementById('cancelPaymentBtn')?.addEventListener('click', closePaymentModal);
        document.getElementById('closePaymentX')?.addEventListener('click', closePaymentModal);
        paymentModal?.addEventListener('click', function(event) {
          if (event.target === paymentModal) closePaymentModal();
        });

        paymentAmount?.addEventListener('input', function() {
          confirmPaymentButton.textContent = 'Confirm ₱' + formattedPaymentAmount();
        });

        walletMobile?.addEventListener('input', function() {
          this.value = this.value.replace(/\D/g, '').slice(0, 15);
        });

        confirmPaymentButton?.addEventListener('click', function() {
          const method = document.querySelector('input[name="payment_method"]:checked')?.value;
          const amount = Number(paymentAmount?.value || 0);
          const isWallet = method === 'gcash';
          const isCash = method === 'cash';

          if (!method) { closePaymentModal(); return; }
          if (!Number.isFinite(amount) || amount < <?= json_encode($enrollmentFee) ?>) {
            Swal.fire({ icon: 'warning', title: 'Minimum payment required', text: 'Enter ₱<?= number_format($enrollmentFee, 2) ?> or higher.' });
            return;
          }

          if (isWallet) {
            const mobile = walletMobile.value.replace(/\D/g, '');
            if (mobile.length < 10 || mobile.length > 15) {
              Swal.fire({ icon: 'warning', title: 'Invalid mobile number', text: 'Enter the mobile number used for the payment.' });
              return;
            }
            paymentAccount.value = 'GCash mobile ending ' + mobile.slice(-4);
          } else if (isCash) {
            paymentAccount.value = 'Cash / Over-the-counter';
            paymentReference.value = '';
          }

          state.paymentConfirmed = true;
          collectAllData();
          closePaymentModal();
          showPaymentReceipt(method, amount);
        });

        /* ==================================================
           PAYMENT SUBMISSION RECEIPT
        ================================================== */

        const paymentReceiptModal = document.getElementById('paymentReceiptBackdrop');

        function maskMobile(value) {
          const digits = String(value || '').replace(/\D/g, '');
          if (!digits) return '—';
          return '•••• ' + digits.slice(-4);
        }

        function showPaymentReceipt(method, amount) {
          if (!paymentReceiptModal) return;

          const d = state.data || {};
          const methodLabel = labelForPayment(method);
          const reference = paymentReference?.value.trim() || 'Not applicable — cash payment';
          const account = method === 'cash'
            ? 'School Cashier / Over-the-counter'
            : methodLabel + ' • ' + maskMobile(walletMobile?.value);

          const receiptNumber = 'PAY-' + Date.now().toString().slice(-8);

          document.getElementById('receiptNumber').textContent = receiptNumber;
          document.getElementById('receiptStudent').textContent =
            [d.first_name, d.middle_name, d.last_name].filter(Boolean).join(' ') || 'Student';
          document.getElementById('receiptMethod').textContent = methodLabel;
          document.getElementById('receiptAccount').textContent = account;
          document.getElementById('receiptReference').textContent = reference;
          document.getElementById('receiptAmount').textContent =
            '₱' + Number(amount).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
          document.getElementById('receiptStatus').textContent =
            method === 'cash' ? 'Cash payment request — pending cashier' : 'Payment submitted — pending cashier verification';
          document.getElementById('receiptProof').textContent =
            method === 'gcash'
              ? 'GCash reference recorded — no screenshot required'
              : 'No screenshot required for over-the-counter payment';

          paymentReceiptModal.hidden = false;
          paymentReceiptModal.classList.add('is-open');
          document.body.classList.add('payment-modal-open');
        }

        function closePaymentReceipt() {
          if (!paymentReceiptModal) return;
          paymentReceiptModal.classList.remove('is-open');
          paymentReceiptModal.hidden = true;
          document.body.classList.remove('payment-modal-open');
        }

        document.getElementById('closePaymentReceiptX')?.addEventListener('click', closePaymentReceipt);
        document.getElementById('continueToReviewBtn')?.addEventListener('click', function() {
          closePaymentReceipt();
          showStep(5);
        });
        paymentReceiptModal?.addEventListener('click', function(event) {
          if (event.target === paymentReceiptModal) closePaymentReceipt();
        });

        /* ==================================================
           REVIEW
        ================================================== */

        function labelForPayment(
          method
        ) {

          return {

            cash: 'Cash / Over-the-counter',

            gcash: 'GCash'

          } [method] || '—';
        }


        function buildSummary() {

          collectAllData();


          const box =
            document.getElementById(
              'summaryBox'
            );


          if (!box) {
            return;
          }


          const d =
            state.data;


          const selectedCourse =
            courseCatalog.find(
              function(course) {

                return String(
                  course.id
                ) === String(
                  d.course_id
                );

              }
            );


          const courseName =
            selectedCourse ?
            selectedCourse.course_code +
            ' - ' +
            selectedCourse.course_name :
            '—';


          let sectionName =
            '—';


          if (selectedCourse) {

            const section =
              selectedCourse.sections
              .find(
                function(item) {

                  return String(
                    item.id
                  ) === String(
                    d.section_id
                  );

                }
              );


            if (section) {

              sectionName =
                section.section_name;
            }
          }


          const yearLabels = {

            '1': '1st Year',

            '2': '2nd Year',

            '3': '3rd Year',

            '4': '4th Year'

          };


          const rows = [

            [
              'Full Name',
              [
                d.first_name,
                d.middle_name,
                d.last_name
              ]
              .filter(Boolean)
              .join(' ')
            ],

            [
              'Email',
              d.email
            ],

            [
              'Phone',
              d.contact
            ],

            [
              'Address',
              d.address
            ],

            [
              'Course',
              courseName
            ],

            [
              'Year Level',
              yearLabels[
                d.year_level
              ] || '—'
            ],

            [
              'Semester',
              d.semester === '1' ?
              '1st Semester' :
              '2nd Semester'
            ],

            [
              'Section',
              sectionName
            ],

            [
              'Required Subjects',
              (
                d['subject_ids[]'] || []
              ).length +
              ' Subjects'
            ],

            [
              'Guardian',
              d.guardian
            ],

            [
              'Guardian Contact',
              d.guardian_contact
            ],

            [
              'Payment Method',
              labelForPayment(
                d.payment_method
              )
            ],

            [
              'Enrollment Fee',
              '₱<?= number_format(
                  $enrollmentFee,
                  2
                ); ?>'
            ]

          ];


          box.innerHTML =
            rows
            .map(
              function(row) {

                return `

                                        <div class="summary-row">

                                            <span>
                                                ${escapeHtml(
                                                    row[0]
                                                )}
                                            </span>

                                            <span>
                                                ${escapeHtml(
                                                    row[1] ||
                                                    '—'
                                                )}
                                            </span>

                                        </div>

                                    `;

              }
            )
            .join('');
        }


        /* ==================================================
           REGISTRATION FORM PREVIEW
        ================================================== */

        function previewRegistrationForm() {

          collectAllData();

          const d = state.data;

          const selectedCourse =
            courseCatalog.find(
              function(course) {

                return String(course.id) === String(d.course_id);
              }
            );

          if (!selectedCourse) {

            Swal.fire({
              icon: 'warning',
              title: 'Course required',
              text: 'Select a course, year level, and semester before previewing the registration form.',
              confirmButtonColor: '#1e5a96'
            });

            return;
          }

          const selectedIds = new Set(
            (d['subject_ids[]'] || []).map(String)
          );

          const subjects = curriculumSubjectsFor(
            selectedCourse,
            d.year_level,
            d.semester
          ).filter(
            function(subject) {

              return selectedIds.has(String(subject.id));
            }
          );

          const section = selectedCourse.sections.find(
            function(item) {

              return String(item.id) === String(d.section_id);
            }
          );

          const fullName = [
            d.first_name,
            d.middle_name,
            d.last_name
          ].filter(Boolean).join(' ');

          const subjectRows = subjects.map(
            function(subject) {

              return `
                <tr>
                  <td>${escapeHtml(subject.subject_code)}</td>
                  <td>${escapeHtml(subject.subject_name)}</td>
                  <td>${escapeHtml(subject.units || '—')}</td>
                  <td>${escapeHtml(subject.schedule_day || 'TBA')}</td>
                  <td>${escapeHtml(subject.schedule_time || 'TBA')}</td>
                  <td>${escapeHtml(subject.room_number || 'TBA')}</td>
                </tr>`;
            }
          ).join('');

          const preview = window.open('', 'registrationFormPreview');

          if (!preview) {

            Swal.fire({
              icon: 'info',
              title: 'Allow pop-ups to preview',
              text: 'Your browser blocked the registration form preview.',
              confirmButtonColor: '#1e5a96'
            });

            return;
          }

          preview.document.open();
          preview.document.write(`<!doctype html>
            <html lang="en"><head><meta charset="utf-8">
            <title>Registration Form Preview</title>
            <style>
              * { box-sizing: border-box; }
              body { font-family: Arial, sans-serif; color: #172033; margin: 0; background: #f4f7fb; padding: 32px; }
              .form { max-width: 1000px; margin: auto; background: #fff; padding: 36px; border: 1px solid #d6deea; }
              header { text-align: center; border-bottom: 3px solid #123d68; padding-bottom: 18px; margin-bottom: 28px; }
              h1 { margin: 0; font-size: 24px; color: #123d68; } header p { margin: 7px 0 0; }
              h2 { font-size: 15px; color: #123d68; background: #eef5fc; border-left: 5px solid #1e5a96; padding: 10px; margin: 26px 0 14px; }
              .details { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px 30px; }
              .detail { border-bottom: 1px solid #cdd7e4; padding: 5px 0; } .label { font-weight: 700; color: #475569; font-size: 12px; display: block; margin-bottom: 3px; }
              table { width: 100%; border-collapse: collapse; font-size: 13px; } th, td { border: 1px solid #bfcbd9; padding: 9px; text-align: left; vertical-align: top; } th { background: #123d68; color: #fff; }
              .actions { text-align: center; margin-top: 28px; } button { background: #1e5a96; border: 0; color: #fff; border-radius: 4px; padding: 10px 18px; cursor: pointer; font-size: 14px; }
              .note { color: #64748b; font-size: 12px; margin-top: 14px; }
              @media print { body { padding: 0; background: #fff; } .form { border: 0; } .actions { display: none; } }
            </style></head><body><main class="form">
            <header><h1>Official Registration Form</h1><p>EYYSAT Academy</p></header>
            <h2>Student Information</h2>
            <div class="details">
              <div class="detail"><span class="label">Student Name</span>${escapeHtml(fullName || '—')}</div>
              <div class="detail"><span class="label">Student ID</span>Assigned after submission</div>
              <div class="detail"><span class="label">Address</span>${escapeHtml(d.address || '—')}</div>
              <div class="detail"><span class="label">Contact Number</span>${escapeHtml(d.contact || '—')}</div>
              <div class="detail"><span class="label">Course</span>${escapeHtml(selectedCourse.course_code + ' — ' + selectedCourse.course_name)}</div>
              <div class="detail"><span class="label">Section</span>${escapeHtml(section?.section_name || '—')}</div>
              <div class="detail"><span class="label">Year Level</span>${escapeHtml(ordinalYear(d.year_level))}</div>
              <div class="detail"><span class="label">Semester</span>${escapeHtml(semesterLabel(d.semester))}</div>
            </div>
            <h2>Registered Curriculum (${subjects.length} Subjects)</h2>
            <table><thead><tr><th>Subject Code</th><th>Subject Name</th><th>Units</th><th>Day</th><th>Time</th><th>Room</th></tr></thead>
            <tbody>${subjectRows || '<tr><td colspan="6">No curriculum subjects selected.</td></tr>'}</tbody></table>
            <p class="note">This is a preview. The student ID is created when the enrollment is submitted.</p>
            <div class="actions"><button onclick="window.print()">Print Registration Form</button></div>
            </main></body></html>`);
          preview.document.close();
          preview.focus();
        }


        document
          .getElementById('previewRegistrationFormBtn')
          ?.addEventListener('click', previewRegistrationForm);


        /* ==================================================
           FORM SUBMIT
        ================================================== */

        form.addEventListener(
          'submit',
          function(event) {

            collectAllData();

            const activePayment =
              document.querySelector(
                'input[name="payment_method"]:checked'
              );


            if (!activePayment) {

              event.preventDefault();


              showStep(4);


              Swal.fire({

                icon: 'warning',

                title: 'Select a payment method',

                text: 'Please select your preferred payment method before submitting.',

                confirmButtonColor: '#1e5a96'

              });


              return;
            }

            if (!state.paymentConfirmed) {
              event.preventDefault();
              showStep(4);
              openPaymentModal(activePayment.value);
              return;
            }


            const submitButton =
              document.getElementById(
                'submitApplicationBtn'
              );


            if (submitButton) {

              submitButton.disabled =
                true;

              submitButton.innerHTML =
                '<span class="spinner-border spinner-border-sm me-2"></span> Submitting...';
            }

          }
        );


        <?php if (!empty($_SESSION['new_student_account'])): ?>
        const newStudentAccount = <?= json_encode($_SESSION['new_student_account'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>;
        <?php unset($_SESSION['new_student_account']); ?>

        Swal.fire({
          icon: 'success',
          title: 'Enrollment Submitted!',
          html: `
            <div class="account-created-alert">
              <p class="account-created-lead">Your student portal account has been created successfully.</p>
              <div class="account-credential-box">
                <div class="credential-row">
                  <span>Email / Username</span>
                  <strong>${escapeHtml(newStudentAccount.email)}</strong>
                </div>
                <div class="credential-row">
                  <span>Default Password</span>
                  <strong>${escapeHtml(newStudentAccount.password)}</strong>
                </div>
              </div>
              <div class="account-created-warning">
                <strong>Important:</strong> Save these credentials. Your password is based on your surname and <strong>-1234</strong>. You can change it after signing in.
              </div>
              <p class="account-created-status">Your enrollment and payment request are now waiting for cashier/admin verification.</p>
            </div>
          `,
          confirmButtonText: 'Go to Student Login',
          confirmButtonColor: '#1e5a96',
          allowOutsideClick: false,
          allowEscapeKey: false,
          width: 520
        }).then(function(result) {
          if (result.isConfirmed) {
            window.location.href = 'auth/login.php';
          }
        });
        <?php endif; ?>


        showStep(1);

      }
    );
  </script>

</body>

</html>
