<?php
/** Database helpers for the unified instructor/professor portal. */
function ensure_teacher_schema(mysqli $conn): void
{
    // Teachers/professors are stored in the unified users table with role_id = 2.
    // This helper intentionally does not create a separate teachers table.

    mysqli_query($conn, "
        CREATE TABLE IF NOT EXISTS teacher_sections (
            id INT(11) NOT NULL AUTO_INCREMENT,
            teacher_id INT(11) NOT NULL,
            section_id INT(11) NOT NULL,
            created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_teacher_sections_section (section_id),
            KEY idx_teacher_sections_teacher (teacher_id),
            KEY idx_teacher_sections_section (section_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    mysqli_query($conn, "
        CREATE TABLE IF NOT EXISTS teacher_announcements (
            id INT(11) NOT NULL AUTO_INCREMENT,
            teacher_id INT(11) NOT NULL,
            section_id INT(11) DEFAULT NULL,
            title VARCHAR(150) NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_teacher_announcements_teacher (teacher_id),
            KEY idx_teacher_announcements_section (section_id),
            KEY idx_teacher_announcements_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}
