<?php
declare(strict_types=1);

require_once __DIR__ . '/../functions/academic_auth.php';
require_academic_login();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);

$csrf = academic_csrf_token();
$courseId = (int)($_GET['course'] ?? $_POST['course_id'] ?? 0);
$yearLevel = max(1, min(4, (int)($_GET['year_level'] ?? $_POST['year_level'] ?? 1)));
$semester = max(1, min(2, (int)($_GET['semester'] ?? $_POST['semester'] ?? 1)));
$message = '';
$messageType = 'success';

function curriculum_redirect(int $courseId, int $yearLevel, int $semester, string $notice = ''): never
{
    $params = http_build_query([
        'course' => $courseId,
        'year_level' => $yearLevel,
        'semester' => $semester,
        'notice' => $notice,
    ]);
    header('Location: curriculum.php?' . $params, true, 303);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_academic_csrf();
    $action = (string)($_POST['action'] ?? '');
    $courseId = (int)($_POST['course_id'] ?? 0);
    $yearLevel = max(1, min(4, (int)($_POST['year_level'] ?? 1)));
    $semester = max(1, min(2, (int)($_POST['semester'] ?? 1)));

    if ($courseId <= 0) {
        curriculum_redirect(0, $yearLevel, $semester, 'invalid_course');
    }

    // Confirm that the selected course is real before changing curriculum data.
    $courseCheck = mysqli_prepare($conn, 'SELECT id FROM courses WHERE id = ? LIMIT 1');
    mysqli_stmt_bind_param($courseCheck, 'i', $courseId);
    mysqli_stmt_execute($courseCheck);
    mysqli_stmt_store_result($courseCheck);
    $courseExists = mysqli_stmt_num_rows($courseCheck) === 1;
    mysqli_stmt_close($courseCheck);

    if (!$courseExists) {
        curriculum_redirect(0, $yearLevel, $semester, 'invalid_course');
    }

    if ($action === 'add') {
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $units = (float)($_POST['units'] ?? 0);
        if ($units <= 0 || $units > 12) {
            curriculum_redirect($courseId, $yearLevel, $semester, 'invalid_units');
        }

        // A curriculum subject must belong to the same course and must not
        // already exist elsewhere in that course's curriculum.
        $subjectCheck = mysqli_prepare($conn, 'SELECT id FROM subjects WHERE id = ? AND course_id = ? LIMIT 1');
        mysqli_stmt_bind_param($subjectCheck, 'ii', $subjectId, $courseId);
        mysqli_stmt_execute($subjectCheck);
        mysqli_stmt_store_result($subjectCheck);
        $validSubject = mysqli_stmt_num_rows($subjectCheck) === 1;
        mysqli_stmt_close($subjectCheck);

        if (!$validSubject) {
            curriculum_redirect($courseId, $yearLevel, $semester, 'invalid_subject');
        }

        $duplicate = mysqli_prepare($conn, 'SELECT id FROM curriculum WHERE course_id = ? AND subject_id = ? LIMIT 1');
        mysqli_stmt_bind_param($duplicate, 'ii', $courseId, $subjectId);
        mysqli_stmt_execute($duplicate);
        mysqli_stmt_store_result($duplicate);
        $alreadyAssigned = mysqli_stmt_num_rows($duplicate) > 0;
        mysqli_stmt_close($duplicate);

        if ($alreadyAssigned) {
            curriculum_redirect($courseId, $yearLevel, $semester, 'already_assigned');
        }

        $insert = mysqli_prepare($conn, 'INSERT INTO curriculum (course_id, subject_id, year_level, semester, units) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($insert, 'iiiid', $courseId, $subjectId, $yearLevel, $semester, $units);
        $ok = mysqli_stmt_execute($insert);
        mysqli_stmt_close($insert);
        curriculum_redirect($courseId, $yearLevel, $semester, $ok ? 'added' : 'save_failed');
    }

    if ($action === 'update') {
        $curriculumId = (int)($_POST['curriculum_id'] ?? 0);
        $newYear = max(1, min(4, (int)($_POST['new_year_level'] ?? $yearLevel)));
        $newSemester = max(1, min(2, (int)($_POST['new_semester'] ?? $semester)));
        $units = (float)($_POST['units'] ?? 0);
        if ($curriculumId <= 0 || $units <= 0 || $units > 12) {
            curriculum_redirect($courseId, $yearLevel, $semester, 'invalid_update');
        }

        // Update only a row belonging to the selected course. This prevents
        // an admin from moving another course's curriculum row by ID alone.
        $update = mysqli_prepare($conn, 'UPDATE curriculum SET year_level = ?, semester = ?, units = ? WHERE id = ? AND course_id = ?');
        mysqli_stmt_bind_param($update, 'iidii', $newYear, $newSemester, $units, $curriculumId, $courseId);
        $ok = mysqli_stmt_execute($update);
        $error = mysqli_stmt_errno($update);
        mysqli_stmt_close($update);
        curriculum_redirect($courseId, $newYear, $newSemester, $ok && $error === 0 ? 'updated' : 'update_failed');
    }

    if ($action === 'remove') {
        $curriculumId = (int)($_POST['curriculum_id'] ?? 0);
        $delete = mysqli_prepare($conn, 'DELETE FROM curriculum WHERE id = ? AND course_id = ?');
        mysqli_stmt_bind_param($delete, 'ii', $curriculumId, $courseId);
        $ok = mysqli_stmt_execute($delete);
        mysqli_stmt_close($delete);
        curriculum_redirect($courseId, $yearLevel, $semester, $ok ? 'removed' : 'remove_failed');
    }

    curriculum_redirect($courseId, $yearLevel, $semester, 'unknown_action');
}

$notice = (string)($_GET['notice'] ?? '');
$noticeMap = [
    'added' => ['Subject added to the curriculum.', 'success'],
    'updated' => ['Curriculum entry updated.', 'success'],
    'removed' => ['Subject removed from the curriculum.', 'success'],
    'already_assigned' => ['That subject is already assigned somewhere in this course curriculum.', 'warning'],
    'invalid_subject' => ['The selected subject does not belong to this course.', 'danger'],
    'invalid_units' => ['Units must be greater than 0 and no more than 12.', 'warning'],
    'invalid_update' => ['The curriculum entry could not be updated.', 'danger'],
    'save_failed' => ['The curriculum entry could not be saved.', 'danger'],
    'update_failed' => ['The curriculum entry could not be updated. Check for duplicate placement.', 'warning'],
    'remove_failed' => ['The curriculum entry could not be removed.', 'danger'],
    'invalid_course' => ['Please select a valid course.', 'danger'],
    'unknown_action' => ['Unknown curriculum action.', 'danger'],
];
if (isset($noticeMap[$notice])) {
    [$message, $messageType] = $noticeMap[$notice];
}

$courses = [];
$courseResult = mysqli_query($conn, 'SELECT id, course_code, course_name FROM courses ORDER BY course_code ASC');
while ($row = mysqli_fetch_assoc($courseResult)) {
    $courses[] = $row;
}

if ($courseId === 0 && $courses) {
    $courseId = (int)$courses[0]['id'];
}

$selectedCourse = null;
foreach ($courses as $course) {
    if ((int)$course['id'] === $courseId) {
        $selectedCourse = $course;
        break;
    }
}

$curriculumRows = [];
$unassignedSubjects = [];
$summary = [];

if ($selectedCourse) {
    $summaryStmt = mysqli_prepare($conn, '
        SELECT year_level, semester, COUNT(*) AS subject_count, COALESCE(SUM(units), 0) AS total_units
        FROM curriculum
        WHERE course_id = ?
        GROUP BY year_level, semester
        ORDER BY year_level, semester
    ');
    mysqli_stmt_bind_param($summaryStmt, 'i', $courseId);
    mysqli_stmt_execute($summaryStmt);
    $summaryResult = mysqli_stmt_get_result($summaryStmt);
    while ($row = mysqli_fetch_assoc($summaryResult)) {
        $summary[(int)$row['year_level']][(int)$row['semester']] = $row;
    }
    mysqli_stmt_close($summaryStmt);

    $rowsStmt = mysqli_prepare($conn, '
        SELECT c.id AS curriculum_id, c.subject_id, c.year_level, c.semester, c.units,
               s.subject_code, s.subject_name, s.units AS catalog_units,
               s.schedule_day, s.schedule_time, s.room_number
        FROM curriculum c
        INNER JOIN subjects s ON s.id = c.subject_id
        WHERE c.course_id = ? AND c.year_level = ? AND c.semester = ?
        ORDER BY s.subject_code ASC
    ');
    mysqli_stmt_bind_param($rowsStmt, 'iii', $courseId, $yearLevel, $semester);
    mysqli_stmt_execute($rowsStmt);
    $rowsResult = mysqli_stmt_get_result($rowsStmt);
    while ($row = mysqli_fetch_assoc($rowsResult)) {
        $curriculumRows[] = $row;
    }
    mysqli_stmt_close($rowsStmt);

    $availableStmt = mysqli_prepare($conn, '
        SELECT s.id, s.subject_code, s.subject_name, s.units, s.year_level, s.sem
        FROM subjects s
        LEFT JOIN curriculum c ON c.subject_id = s.id AND c.course_id = s.course_id
        WHERE s.course_id = ? AND c.id IS NULL
        ORDER BY COALESCE(s.year_level, 99), COALESCE(s.sem, 99), s.subject_code ASC
    ');
    mysqli_stmt_bind_param($availableStmt, 'i', $courseId);
    mysqli_stmt_execute($availableStmt);
    $availableResult = mysqli_stmt_get_result($availableStmt);
    while ($row = mysqli_fetch_assoc($availableResult)) {
        $unassignedSubjects[] = $row;
    }
    mysqli_stmt_close($availableStmt);
}

$totalAssigned = 0;
foreach ($summary as $years) {
    foreach ($years as $item) {
        $totalAssigned += (int)$item['subject_count'];
    }
}

$studentEnrollmentImpact = 0;
if ($selectedCourse) {
    $impactStmt = mysqli_prepare($conn, "
        SELECT COUNT(*) AS total
        FROM enrollment_details ed
        INNER JOIN enrollments e ON e.id = ed.enrollment_id
        INNER JOIN students st ON st.id = e.student_id
        WHERE st.course_id = ? AND e.STATUS IN ('Pending','Approved','Enrolled')
    ");
    mysqli_stmt_bind_param($impactStmt, 'i', $courseId);
    mysqli_stmt_execute($impactStmt);
    $impactResult = mysqli_stmt_get_result($impactStmt);
    $studentEnrollmentImpact = (int)(mysqli_fetch_assoc($impactResult)['total'] ?? 0);
    mysqli_stmt_close($impactStmt);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Curriculum Management – EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/ux-polish.css">
    <style>
        .curriculum-page { max-width: 1400px; margin: 0 auto; }
        .course-tabs { display:flex; flex-wrap:wrap; gap:10px; margin:18px 0; }
        .course-tab { display:block; padding:11px 16px; border-radius:12px; background:rgba(255,255,255,.06); color:#fff; text-decoration:none; border:1px solid rgba(255,255,255,.09); }
        .course-tab.active { border-color:#d8ff61; background:rgba(216,255,97,.09); color:#d8ff61; }
        .term-tabs { display:flex; gap:8px; margin-bottom:18px; }
        .term-tabs a { text-decoration:none; padding:9px 14px; border-radius:9px; background:#151026; color:#c9c4d7; border:1px solid rgba(255,255,255,.08); }
        .term-tabs a.active { background:#d8ff61; color:#171717; font-weight:800; }
        .curriculum-grid { display:grid; grid-template-columns:minmax(0,1fr) 330px; gap:18px; align-items:start; }
        .curriculum-table { width:100%; border-collapse:collapse; }
        .curriculum-table th { text-align:left; padding:12px; color:#d8ff61; background:#08021b; font-size:.78rem; text-transform:uppercase; letter-spacing:.05em; }
        .curriculum-table td { padding:12px; border-bottom:1px solid rgba(255,255,255,.07); vertical-align:middle; }
        .curriculum-table tr:hover { background:rgba(255,255,255,.025); }
        .curriculum-table input, .curriculum-table select, .add-form select, .add-form input { width:100%; padding:8px 9px; border-radius:8px; border:1px solid rgba(255,255,255,.13); background:#0f0b22; color:#fff; }
        .curriculum-table .units { width:85px; }
        .inline-form { display:inline; }
        .btn-small { border:0; border-radius:8px; padding:8px 11px; cursor:pointer; font-weight:700; }
        .btn-save { background:#d8ff61; color:#171717; }
        .btn-danger { background:#3a1520; color:#ffb7c5; border:1px solid rgba(255,100,130,.25); }
        .add-form { display:grid; gap:12px; }
        .add-form label { display:block; font-size:.8rem; color:#aaa3b7; margin-bottom:5px; }
        .stat-strip { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin:18px 0; }
        .mini-card { background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.08); border-radius:13px; padding:14px; }
        .mini-card span { display:block; color:#9d98a8; font-size:.75rem; text-transform:uppercase; }
        .mini-card strong { display:block; margin-top:4px; font-size:1.35rem; color:#fff; }
        .year-map { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }
        .year-map-item { border:1px solid rgba(255,255,255,.08); border-radius:11px; padding:10px; background:#0f0b22; }
        .year-map-item strong { color:#d8ff61; }
        .year-map-item div { color:#aaa3b7; font-size:.78rem; margin-top:4px; }
        .empty { padding:35px 15px; text-align:center; color:#aaa3b7; }
        .hint { color:#aaa3b7; font-size:.85rem; line-height:1.5; }
        .badge { display:inline-block; border-radius:999px; padding:4px 9px; font-size:.72rem; background:rgba(124,58,237,.25); color:#d9ccff; }
        @media (max-width: 1050px) { .curriculum-grid { grid-template-columns:1fr; } }
        @media (max-width: 760px) { .stat-strip, .year-map { grid-template-columns:1fr 1fr; } .curriculum-table { min-width:850px; } .table-scroll { overflow:auto; } }
    </style>
</head>
<body>
<?php include __DIR__ . '/../sidebar/sidebar.php'; ?>
<main class="dashboard-main">
<div class="curriculum-page">
    <section class="hero">
        <div class="welcome">
            <span class="hero-badge">📚 Academic Structure</span>
            <h1>Curriculum <span class="accent">Management</span></h1>
            <p>Define which subjects belong to each course, year level, and semester. This is the curriculum source used by enrollment and the student curriculum page.</p>
        </div>
        <div class="hero-stats">
            <div class="mini-stat"><h3>Program</h3><span><?= htmlspecialchars($selectedCourse['course_code'] ?? '—') ?></span></div>
            <div class="mini-stat"><h3>Subjects</h3><span><?= $totalAssigned ?></span></div>
            <div class="mini-stat"><h3>Enrollment Links</h3><span><?= $studentEnrollmentImpact ?></span></div>
        </div>
    </section>

    <?php if ($message): ?>
        <div class="alert alert-<?= htmlspecialchars($messageType) ?>" style="margin-top:18px;"> <?= htmlspecialchars($message) ?> </div>
    <?php endif; ?>

    <section class="card" style="margin-top:18px;">
        <h3>Academic Programs</h3>
        <p class="hint">Choose the program whose official subject structure you want to maintain.</p>
        <div class="course-tabs">
            <?php foreach ($courses as $course): ?>
                <a class="course-tab<?= (int)$course['id'] === $courseId ? ' active' : '' ?>" href="curriculum.php?course=<?= (int)$course['id'] ?>&year_level=<?= $yearLevel ?>&semester=<?= $semester ?>">
                    <strong><?= htmlspecialchars($course['course_code']) ?></strong><br>
                    <small><?= htmlspecialchars($course['course_name']) ?></small>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($selectedCourse): ?>
        <section class="card" style="margin-top:18px;">
            <div style="display:flex;justify-content:space-between;gap:15px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="topbar-label">CURRICULUM MAP</span>
                    <h3><?= htmlspecialchars($selectedCourse['course_code']) ?> — <?= htmlspecialchars($selectedCourse['course_name']) ?></h3>
                    <p class="hint">The entries below are the authoritative subject placements used by the enrollment form.</p>
                </div>
                <span class="badge"><?= $totalAssigned ?> subjects configured</span>
            </div>
            <div class="year-map" style="margin-top:16px;">
                <?php for ($y=1; $y<=4; $y++): ?>
                    <div class="year-map-item">
                        <strong>Year <?= $y ?></strong>
                        <?php for ($s=1; $s<=2; $s++): $item = $summary[$y][$s] ?? null; ?>
                            <div>Sem <?= $s ?>: <?= $item ? (int)$item['subject_count'] . ' subjects · ' . number_format((float)$item['total_units'],1) . ' units' : 'Not configured' ?></div>
                        <?php endfor; ?>
                    </div>
                <?php endfor; ?>
            </div>
        </section>

        <div class="term-tabs" style="margin-top:18px;">
            <?php for ($y=1; $y<=4; $y++): ?>
                <?php for ($s=1; $s<=2; $s++): ?>
                    <a class="<?= $yearLevel === $y && $semester === $s ? 'active' : '' ?>" href="curriculum.php?course=<?= $courseId ?>&year_level=<?= $y ?>&semester=<?= $s ?>">Year <?= $y ?> · Sem <?= $s ?></a>
                <?php endfor; ?>
            <?php endfor; ?>
        </div>

        <div class="curriculum-grid">
            <section class="card">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
                    <div><span class="topbar-label">YEAR <?= $yearLevel ?> · SEMESTER <?= $semester ?></span><h3>Curriculum Subjects</h3></div>
                    <span class="badge"><?= count($curriculumRows) ?> subjects · <?= number_format(array_sum(array_map(static fn($r)=>(float)$r['units'], $curriculumRows)),1) ?> units</span>
                </div>
                <div class="table-scroll">
                    <?php if ($curriculumRows): ?>
                        <table class="curriculum-table">
                            <thead><tr><th>Code</th><th>Subject</th><th>Units</th><th>Move To</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php foreach ($curriculumRows as $row): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($row['subject_code'] ?? '') ?></strong></td>
                                    <td><?= htmlspecialchars($row['subject_name'] ?? '') ?></td>
                                    <td>
                                        <form method="post" class="inline-form">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                                            <input type="hidden" name="action" value="update">
                                            <input type="hidden" name="course_id" value="<?= $courseId ?>">
                                            <input type="hidden" name="curriculum_id" value="<?= (int)$row['curriculum_id'] ?>">
                                            <input type="hidden" name="year_level" value="<?= $yearLevel ?>">
                                            <input type="hidden" name="semester" value="<?= $semester ?>">
                                            <input class="units" type="number" name="units" min="0.5" max="12" step="0.5" value="<?= htmlspecialchars((string)$row['units']) ?>" aria-label="Units">
                                    </td>
                                    <td>
                                            <select name="new_year_level" aria-label="Year level">
                                                <?php for ($y=1;$y<=4;$y++): ?><option value="<?= $y ?>" <?= (int)$row['year_level']===$y?'selected':'' ?>>Year <?= $y ?></option><?php endfor; ?>
                                            </select>
                                            <select name="new_semester" aria-label="Semester" style="margin-top:5px;">
                                                <option value="1" <?= (int)$row['semester']===1?'selected':'' ?>>Semester 1</option>
                                                <option value="2" <?= (int)$row['semester']===2?'selected':'' ?>>Semester 2</option>
                                            </select>
                                    </td>
                                    <td style="white-space:nowrap;">
                                            <button class="btn-small btn-save" type="submit">Save</button>
                                        </form>
                                        <form method="post" class="inline-form" onsubmit="return confirm('Remove this subject from the curriculum? Existing student enrollment records will not be deleted.');">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                                            <input type="hidden" name="action" value="remove">
                                            <input type="hidden" name="course_id" value="<?= $courseId ?>">
                                            <input type="hidden" name="curriculum_id" value="<?= (int)$row['curriculum_id'] ?>">
                                            <input type="hidden" name="year_level" value="<?= $yearLevel ?>">
                                            <input type="hidden" name="semester" value="<?= $semester ?>">
                                            <button class="btn-small btn-danger" type="submit">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="empty">No subjects are configured for Year <?= $yearLevel ?>, Semester <?= $semester ?> yet.</div>
                    <?php endif; ?>
                </div>
            </section>

            <aside class="card">
                <span class="topbar-label">ADD SUBJECT</span>
                <h3>Build This Semester</h3>
                <p class="hint">Choose an existing subject from this course. The subject will become part of the curriculum and immediately become available to the enrollment form for this year/semester.</p>
                <?php if ($unassignedSubjects): ?>
                    <form method="post" class="add-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="course_id" value="<?= $courseId ?>">
                        <input type="hidden" name="year_level" value="<?= $yearLevel ?>">
                        <input type="hidden" name="semester" value="<?= $semester ?>">
                        <div><label for="subject_id">Subject</label><select id="subject_id" name="subject_id" required><option value="">Select subject</option><?php foreach ($unassignedSubjects as $subject): ?><option value="<?= (int)$subject['id'] ?>"><?= htmlspecialchars($subject['subject_code'] . ' — ' . $subject['subject_name']) ?> (<?= number_format((float)($subject['units'] ?? 3),1) ?>u)</option><?php endforeach; ?></select></div>
                        <div><label for="units">Curriculum Units</label><input id="units" type="number" name="units" min="0.5" max="12" step="0.5" value="3.0" required></div>
                        <button class="btn-small btn-save" type="submit">Add to Curriculum</button>
                    </form>
                <?php else: ?>
                    <div class="empty" style="padding:20px 0;">All subjects for this course are already assigned to the curriculum.</div>
                <?php endif; ?>
            </aside>
        </div>
    <?php endif; ?>
</div>
</main>
</body>
</html>
