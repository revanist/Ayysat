<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/../functions/system_settings.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php', true, 303);
    exit;
}

require_student_csrf();

/**
 * Keep the submitted form data available after a validation failure.
 */
function enrollment_fail(string $message, array $draft = []): void
{
    if ($draft !== []) {
        unset($draft['csrf_token']);
        $_SESSION['enrollment_draft'] = $draft;
    }

    $_SESSION['enrollment_error'] = $message;
    header('Location: index.php', true, 303);
    exit;
}

function enrollment_post_string(string $key): string
{
    return trim((string) ($_POST[$key] ?? ''));
}

function enrollment_post_int(string $key): int
{
    return filter_var($_POST[$key] ?? 0, FILTER_VALIDATE_INT) ?: 0;
}

function enrollment_post_subjects(): array
{
    $raw = (array) ($_POST['subject_ids'] ?? []);
    $ids = array_map('intval', $raw);
    $ids = array_filter($ids, static fn (int $id): bool => $id > 0);
    return array_values(array_unique($ids));
}

function enrollment_validate_birthdate(string $birthdate): bool
{
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $birthdate);
    if (!$date || $date->format('Y-m-d') !== $birthdate) {
        return false;
    }

    return $date <= (new DateTimeImmutable('today'))->modify('-18 years');
}

function enrollment_validate_contact(string $contact): bool
{
    return preg_match('/^\d{11}$/', $contact) === 1;
}

function enrollment_validate_input(array $input): void
{
    $required = [
        'first_name', 'last_name', 'sex', 'birthdate', 'address',
        'contact', 'email', 'guardian', 'guardian_contact'
    ];

    foreach ($required as $field) {
        if ($input[$field] === '') {
            throw new RuntimeException('Please complete all required personal and guardian details.');
        }
    }

    if (!filter_var($input['email'], FILTER_VALIDATE_EMAIL)) {
        throw new RuntimeException('Please enter a valid email address.');
    }

    if (!in_array($input['sex'], ['Male', 'Female'], true)) {
        throw new RuntimeException('Please select a valid sex.');
    }

    if (!enrollment_validate_birthdate($input['birthdate'])) {
        throw new RuntimeException('Applicants must be at least 18 years old and must enter a valid birthdate.');
    }

    if ($input['middle_name'] !== '' && !preg_match('/^[A-Za-z. ]{1,5}$/', $input['middle_name'])) {
        throw new RuntimeException('Middle name must contain initials only.');
    }

    if (!enrollment_validate_contact($input['contact']) || !enrollment_validate_contact($input['guardian_contact'])) {
        throw new RuntimeException('Contact numbers must contain exactly 11 digits.');
    }

    if (!in_array($input['year_level'], [1, 2, 3, 4], true)) {
        throw new RuntimeException('Please select a valid year level.');
    }

    if (!in_array($input['semester'], [1, 2], true)) {
        throw new RuntimeException('Please select a valid semester.');
    }

    if ($input['course_id'] < 1 || $input['section_id'] < 1 || $input['subject_ids'] === []) {
        throw new RuntimeException('Please select a valid course, section, and curriculum.');
    }
}

function enrollment_find_student_id_by_user(mysqli $conn, int $userId): ?int
{
    $stmt = mysqli_prepare($conn, 'SELECT id FROM students WHERE user_id = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 'i', $userId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    return $row ? (int) $row['id'] : null;
}

function enrollment_find_student_id_by_email(mysqli $conn, string $email): ?int
{
    $stmt = mysqli_prepare($conn, 'SELECT id FROM students WHERE email = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    return $row ? (int) $row['id'] : null;
}

function enrollment_account_exists(mysqli $conn, string $email): bool
{
    $stmt = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE email = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $exists = mysqli_stmt_num_rows($stmt) > 0;
    mysqli_stmt_close($stmt);
    return $exists;
}

function enrollment_validate_course(mysqli $conn, int $courseId): void
{
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id FROM courses WHERE id = ? LIMIT 1"
    );
    mysqli_stmt_bind_param($stmt, 'i', $courseId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $valid = mysqli_stmt_num_rows($stmt) === 1;
    mysqli_stmt_close($stmt);

    if (!$valid) {
        throw new RuntimeException('The selected course is invalid.');
    }
}

function enrollment_validate_section(
    mysqli $conn,
    int $sectionId,
    int $courseId,
    int $yearLevel = 0,
    int $semester = 0
): void {
    $stmt = mysqli_prepare(
        $conn,
        'SELECT s.section_name, c.course_code
         FROM sections s
         INNER JOIN courses c ON c.id = s.course_id
         WHERE s.id = ? AND s.course_id = ?
         LIMIT 1'
    );

    if (!$stmt) {
        throw new RuntimeException('Unable to validate the selected section.');
    }

    mysqli_stmt_bind_param($stmt, 'ii', $sectionId, $courseId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$row) {
        throw new RuntimeException('The selected section does not belong to the selected course.');
    }

    if ($yearLevel >= 1 && $yearLevel <= 4 && $semester >= 1 && $semester <= 2) {
        $courseCode = strtoupper(trim((string) $row['course_code']));
        $sectionName = strtoupper(trim((string) $row['section_name']));
        $pattern = '/^' . preg_quote($courseCode, '/') . '-'
            . $yearLevel . '[A-D]' . $semester . '$/';

        if (!preg_match($pattern, $sectionName)) {
            throw new RuntimeException(
                'The selected section does not match the selected course, year level, and semester.'
            );
        }
    }
}
function enrollment_validate_subjects(mysqli $conn, array $subjectIds, int $courseId, int $yearLevel, int $semester): void
{
    $stmt = mysqli_prepare(
        $conn,
        'SELECT cu.subject_id
         FROM curriculum cu
         INNER JOIN subjects s ON s.id = cu.subject_id
         WHERE cu.course_id = ?
           AND cu.subject_id = ?
           AND cu.year_level = ?
           AND cu.semester = ?
           AND s.course_id = ?
         LIMIT 1'
    );

    foreach ($subjectIds as $subjectId) {
        mysqli_stmt_bind_param($stmt, 'iiiii', $courseId, $subjectId, $yearLevel, $semester, $courseId);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) !== 1) {
            mysqli_stmt_close($stmt);
            throw new RuntimeException('One or more selected subjects do not belong to the selected curriculum.');
        }

        mysqli_stmt_free_result($stmt);
    }

    mysqli_stmt_close($stmt);
}

function enrollment_validate_capacity(mysqli $conn, int $sectionId): void
{
    // Lock the section during this transaction. Approval performs the final
    // capacity check again, so Pending applications do not consume seats.
    $stmt = mysqli_prepare($conn, "SELECT max_slots FROM sections WHERE id = ? FOR UPDATE");
    if (!$stmt) {
        throw new RuntimeException('Unable to check section capacity.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $sectionId);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to check section capacity.');
    }
    $section = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$section) {
        throw new RuntimeException('The selected section no longer exists.');
    }

    $maxSlots = (int) $section['max_slots'];
    if ($maxSlots <= 0) {
        return;
    }

    $countStmt = mysqli_prepare(
        $conn,
        "SELECT COUNT(*) AS active_count
         FROM enrollments
         WHERE section_id = ?
           AND status IN ('Approved', 'Enrolled')"
    );
    if (!$countStmt) {
        throw new RuntimeException('Unable to count section enrollment.');
    }
    mysqli_stmt_bind_param($countStmt, 'i', $sectionId);
    mysqli_stmt_execute($countStmt);
    $countRow = mysqli_fetch_assoc(mysqli_stmt_get_result($countStmt));
    mysqli_stmt_close($countStmt);

    if ((int)($countRow['active_count'] ?? 0) >= $maxSlots) {
        throw new RuntimeException('The selected section is already full. Please choose another section.');
    }
}

function enrollment_has_active_duplicate(mysqli $conn, int $studentId, string $schoolYear, int $semester): bool
{
    // Serialize submissions for the same student so two requests cannot both
    // pass the duplicate check at the same time.
    $lock = mysqli_prepare($conn, 'SELECT id FROM students WHERE id = ? FOR UPDATE');
    if (!$lock) {
        throw new RuntimeException('Unable to lock the student record.');
    }
    mysqli_stmt_bind_param($lock, 'i', $studentId);
    if (!mysqli_stmt_execute($lock)) {
        mysqli_stmt_close($lock);
        throw new RuntimeException('Unable to lock the student record.');
    }
    $student = mysqli_fetch_assoc(mysqli_stmt_get_result($lock));
    mysqli_stmt_close($lock);

    if (!$student) {
        throw new RuntimeException('Student record not found.');
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT id FROM enrollments
         WHERE student_id = ?
           AND school_year = ?
           AND sem = ?
           AND status IN ('Pending', 'Approved', 'Enrolled')
         LIMIT 1"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to check existing enrollment.');
    }
    mysqli_stmt_bind_param($stmt, 'isi', $studentId, $schoolYear, $semester);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $duplicate = mysqli_stmt_num_rows($stmt) > 0;
    mysqli_stmt_close($stmt);
    return $duplicate;
}

function enrollment_create_account(mysqli $conn, string $firstName, string $middleName, string $lastName, string $email): array
{
    $plainPassword = strtoupper(bin2hex(random_bytes(5))) . '-' . random_int(100, 999);
    $passwordHash = password_hash($plainPassword, PASSWORD_DEFAULT);
    $fullName = trim($firstName . ' ' . $middleName . ' ' . $lastName);

    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO users (full_name, email, password_hash, role_id) VALUES (?, ?, ?, 3)'
    );
    mysqli_stmt_bind_param($stmt, 'sss', $fullName, $email, $passwordHash);

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to create the student account.');
    }

    $userId = (int) mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    return [$userId, $plainPassword];
}

function enrollment_save_student(
    mysqli $conn,
    ?int $existingStudentId,
    int $userId,
    array $input
): int {
    if ($existingStudentId !== null) {
        $stmt = mysqli_prepare(
            $conn,
            "UPDATE students SET
                user_id = ?, first_name = ?, middle_name = ?, last_name = ?, sex = ?,
                birthdate = ?, address = ?, contact = ?, email = ?, guardian = ?,
                guardian_contact = ?, course_id = ?, section_id = ?, year_level = ?,
                enrollment_status = 'Pending'
             WHERE id = ?"
        );
        mysqli_stmt_bind_param(
            $stmt,
            'issssssssssiiii',
            $userId,
            $input['first_name'],
            $input['middle_name'],
            $input['last_name'],
            $input['sex'],
            $input['birthdate'],
            $input['address'],
            $input['contact'],
            $input['email'],
            $input['guardian'],
            $input['guardian_contact'],
            $input['course_id'],
            $input['section_id'],
            $input['year_level'],
            $existingStudentId
        );

        if (!mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            throw new RuntimeException('Unable to update the student record.');
        }
        mysqli_stmt_close($stmt);
        return $existingStudentId;
    }

    // Student numbers are assigned only after Registrar approval.
    $studentNumber = null;
    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO students
            (user_id, student_number, first_name, middle_name, last_name, sex, birthdate,
             address, contact, email, guardian, guardian_contact, course_id, section_id,
             year_level, enrollment_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')"
    );
    mysqli_stmt_bind_param(
        $stmt,
        'isssssssssssiii',
        $userId,
        $studentNumber,
        $input['first_name'],
        $input['middle_name'],
        $input['last_name'],
        $input['sex'],
        $input['birthdate'],
        $input['address'],
        $input['contact'],
        $input['email'],
        $input['guardian'],
        $input['guardian_contact'],
        $input['course_id'],
        $input['section_id'],
        $input['year_level']
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to create the student record.');
    }

    $studentId = (int) mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);
    return $studentId;
}

function enrollment_create_record(mysqli $conn, int $studentId, array $input, string $schoolYear): int
{
    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO enrollments
            (student_id, course_id, section_id, year_level, school_year, sem, status)
         VALUES (?, ?, ?, ?, ?, ?, 'Pending')"
    );
    mysqli_stmt_bind_param(
        $stmt,
        'iiiisi',
        $studentId,
        $input['course_id'],
        $input['section_id'],
        $input['year_level'],
        $schoolYear,
        $input['semester']
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to create the enrollment record.');
    }

    $enrollmentId = (int) mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);
    return $enrollmentId;
}

function enrollment_save_subjects(mysqli $conn, int $enrollmentId, array $subjectIds): void
{
    $stmt = mysqli_prepare(
        $conn,
        'INSERT INTO enrollment_details (enrollment_id, subject_id) VALUES (?, ?)'
    );

    foreach ($subjectIds as $subjectId) {
        mysqli_stmt_bind_param($stmt, 'ii', $enrollmentId, $subjectId);
        if (!mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            throw new RuntimeException('Unable to save the selected curriculum.');
        }
    }

    mysqli_stmt_close($stmt);
}

$draft = $_POST;
$transactionStarted = false;

$input = [
    'first_name' => enrollment_post_string('first_name'),
    'middle_name' => enrollment_post_string('middle_name'),
    'last_name' => enrollment_post_string('last_name'),
    'sex' => enrollment_post_string('sex'),
    'birthdate' => enrollment_post_string('birthdate'),
    'address' => enrollment_post_string('address'),
    'contact' => enrollment_post_string('contact'),
    'email' => enrollment_post_string('email'),
    'guardian' => enrollment_post_string('guardian'),
    'guardian_contact' => enrollment_post_string('guardian_contact'),
    'course_id' => enrollment_post_int('course_id'),
    'section_id' => enrollment_post_int('section_id'),
    'year_level' => enrollment_post_int('year_level'),
    'semester' => enrollment_post_int('semester'),
    'subject_ids' => enrollment_post_subjects(),
];

try {
    enrollment_validate_input($input);

    $userId = null;
    if (($_SESSION['role'] ?? '') === 'student' && !empty($_SESSION['user_id'])) {
        $userId = (int) $_SESSION['user_id'];
    }

    $existingStudentId = $userId !== null
        ? enrollment_find_student_id_by_user($conn, $userId)
        : enrollment_find_student_id_by_email($conn, $input['email']);

    if ($userId === null && $existingStudentId !== null) {
        throw new RuntimeException('An application already exists for this email. Please sign in to view your profile.');
    }

    if ($userId === null && enrollment_account_exists($conn, $input['email'])) {
        throw new RuntimeException('An account already exists for this email. Please sign in before submitting enrollment.');
    }

    $schoolYear = system_school_year($conn);

    mysqli_begin_transaction($conn);
    $transactionStarted = true;

    enrollment_validate_course($conn, $input['course_id']);
    enrollment_validate_section($conn, $input['section_id'], $input['course_id'], $input['year_level'], $input['semester']);
    enrollment_validate_subjects(
        $conn,
        $input['subject_ids'],
        $input['course_id'],
        $input['year_level'],
        $input['semester']
    );

    // Lock an existing student's row before checking for duplicates. This
    // keeps concurrent submissions for the same student serialized.
    if ($existingStudentId !== null && enrollment_has_active_duplicate($conn, $existingStudentId, $schoolYear, $input['semester'])) {
        throw new RuntimeException('An active enrollment already exists for this student in the selected semester.');
    }

    // Lock the selected section after the student lock so all enrollment
    // submissions use a consistent lock order and avoid deadlocks.
    enrollment_validate_capacity($conn, $input['section_id']);

    $createdPassword = null;
    if ($userId === null) {
        [$userId, $createdPassword] = enrollment_create_account(
            $conn,
            $input['first_name'],
            $input['middle_name'],
            $input['last_name'],
            $input['email']
        );
    }

    $studentId = enrollment_save_student($conn, $existingStudentId, $userId, $input);
    $enrollmentId = enrollment_create_record($conn, $studentId, $input, $schoolYear);
    enrollment_save_subjects($conn, $enrollmentId, $input['subject_ids']);

    mysqli_commit($conn);
} catch (Throwable $exception) {
    if ($transactionStarted) {
        mysqli_rollback($conn);
    }

    error_log('Enrollment submission failed: ' . $exception->getMessage());
    enrollment_fail($exception->getMessage(), $draft);
}

unset($_SESSION['student_csrf_token'], $_SESSION['enrollment_draft']);

if ($createdPassword !== null) {
    $_SESSION['new_student_account'] = [
        'email' => $input['email'],
        'password' => $createdPassword,
        'enrollment_id' => $enrollmentId,
    ];
}

$_SESSION['enrollment_success'] = 'Enrollment submitted successfully. Your application is now waiting for Registrar review.';
header('Location: index.php', true, 303);
exit;
