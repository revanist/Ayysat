-- ENROLLNA canonical users-table migration
-- Migrates the previous unified users table to the final account schema.
-- IMPORTANT: Back up your database before running this on an existing database.
START TRANSACTION;

-- Rename legacy columns when present.
ALTER TABLE users
  CHANGE COLUMN id user_id INT NOT NULL AUTO_INCREMENT,
  CHANGE COLUMN fullname full_name VARCHAR(120) NOT NULL,
  CHANGE COLUMN password password_hash VARCHAR(255) NOT NULL,
  CHANGE COLUMN created created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Remove obsolete security columns from the previous version.
ALTER TABLE users
  DROP COLUMN IF EXISTS must_change_password,
  DROP COLUMN IF EXISTS password_expires_at;

-- Ensure the canonical email uniqueness and role index.
ALTER TABLE users
  ADD UNIQUE KEY uq_users_email (email);

COMMIT;
