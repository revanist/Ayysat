<?php
require __DIR__.'/db/dbconn.php';

$q = mysqli_query($conn, "SELECT user_id, email, full_name, role FROM users WHERE email = 'rainier@gmail.com'");
while($r = mysqli_fetch_assoc($q)) print_r($r);
