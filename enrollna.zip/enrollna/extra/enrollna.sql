-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 02, 2026 at 06:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollna`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `enrollment_id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `admin_is_read` tinyint(1) NOT NULL DEFAULT 0,
  `cashier_is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_notifications`
--

INSERT INTO `admin_notifications` (`id`, `enrollment_id`, `message`, `is_read`, `admin_is_read`, `cashier_is_read`, `created_at`) VALUES
(18, 31, 'Received Maya payment of ₱6,000.00 from Lionel Messi (2026-001). Ref: PAY-1790874758-878', 0, 0, 1, '2026-10-01 17:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_name`, `created`) VALUES
(1, 'BSIT', 'Bachelor of Science in Information Technology', '2026-07-19 05:21:08'),
(2, 'BSCS', 'Bachelor of Science in Computer Science', '2026-07-19 05:21:08'),
(3, 'BSIS', 'Bachelor of Science in Information Systems', '2026-07-19 05:21:08');

-- --------------------------------------------------------

--
-- Table structure for table `curriculum`
--

CREATE TABLE `curriculum` (
  `id` int(10) UNSIGNED NOT NULL,
  `course_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `year_level` tinyint(3) UNSIGNED NOT NULL,
  `semester` tinyint(3) UNSIGNED NOT NULL,
  `units` decimal(4,1) NOT NULL DEFAULT 3.0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `curriculum`
--

INSERT INTO `curriculum` (`id`, `course_id`, `subject_id`, `year_level`, `semester`, `units`, `created_at`) VALUES
(7, 1, 61, 1, 1, 3.0, '2026-08-23 11:10:46'),
(8, 1, 62, 1, 1, 3.0, '2026-08-23 11:10:46'),
(9, 1, 63, 1, 1, 3.0, '2026-08-23 11:10:46'),
(13, 1, 67, 1, 2, 3.0, '2026-08-23 11:10:46'),
(14, 1, 68, 1, 2, 3.0, '2026-08-23 11:10:46'),
(15, 1, 69, 1, 2, 3.0, '2026-08-23 11:10:46'),
(19, 1, 73, 2, 1, 3.0, '2026-08-23 11:10:46'),
(20, 1, 74, 2, 1, 3.0, '2026-08-23 11:10:46'),
(21, 1, 75, 2, 1, 3.0, '2026-08-23 11:10:46'),
(22, 1, 76, 2, 1, 3.0, '2026-08-23 11:10:46'),
(25, 1, 79, 2, 2, 3.0, '2026-08-23 11:10:46'),
(26, 1, 80, 2, 2, 3.0, '2026-08-23 11:10:46'),
(27, 1, 81, 2, 2, 3.0, '2026-08-23 11:10:46'),
(28, 1, 82, 2, 2, 3.0, '2026-08-23 11:10:46'),
(31, 1, 85, 3, 1, 3.0, '2026-08-23 11:10:46'),
(32, 1, 86, 3, 1, 3.0, '2026-08-23 11:10:46'),
(33, 1, 87, 3, 1, 3.0, '2026-08-23 11:10:46'),
(34, 1, 88, 3, 1, 3.0, '2026-08-23 11:10:46'),
(35, 1, 89, 3, 1, 3.0, '2026-08-23 11:10:46'),
(36, 1, 90, 3, 1, 3.0, '2026-08-23 11:10:46'),
(37, 1, 91, 3, 2, 3.0, '2026-08-23 11:10:46'),
(38, 1, 92, 3, 2, 3.0, '2026-08-23 11:10:46'),
(39, 1, 93, 3, 2, 3.0, '2026-08-23 11:10:46'),
(40, 1, 94, 3, 2, 3.0, '2026-08-23 11:10:46'),
(41, 1, 95, 3, 2, 3.0, '2026-08-23 11:10:46'),
(42, 1, 96, 3, 2, 3.0, '2026-08-23 11:10:46'),
(43, 1, 97, 4, 1, 3.0, '2026-08-23 11:10:46'),
(44, 1, 98, 4, 1, 3.0, '2026-08-23 11:10:46'),
(45, 1, 99, 4, 1, 3.0, '2026-08-23 11:10:46'),
(46, 1, 100, 4, 1, 3.0, '2026-08-23 11:10:46'),
(47, 1, 101, 4, 1, 3.0, '2026-08-23 11:10:46'),
(48, 1, 102, 4, 2, 3.0, '2026-08-23 11:10:46'),
(49, 1, 103, 4, 2, 3.0, '2026-08-23 11:10:46'),
(50, 1, 104, 4, 2, 6.0, '2026-08-23 11:10:46'),
(51, 1, 217, 1, 1, 3.0, '2026-08-23 11:10:46'),
(52, 1, 218, 1, 1, 3.0, '2026-08-23 11:10:46'),
(53, 1, 219, 1, 1, 2.0, '2026-08-23 11:10:46'),
(54, 1, 220, 1, 2, 3.0, '2026-08-23 11:10:46'),
(55, 1, 221, 1, 2, 3.0, '2026-08-23 11:10:46'),
(56, 1, 222, 1, 2, 2.0, '2026-08-23 11:10:46'),
(57, 1, 223, 2, 1, 3.0, '2026-08-23 11:10:46'),
(58, 1, 224, 2, 1, 2.0, '2026-08-23 11:10:46'),
(59, 1, 225, 2, 2, 3.0, '2026-08-23 11:10:46'),
(60, 1, 226, 2, 2, 2.0, '2026-08-23 11:10:46'),
(67, 2, 232, 1, 1, 3.0, '2026-08-23 11:10:46'),
(68, 2, 233, 1, 1, 3.0, '2026-08-23 11:10:46'),
(69, 2, 234, 1, 1, 3.0, '2026-08-23 11:10:46'),
(70, 2, 235, 1, 1, 3.0, '2026-08-23 11:10:46'),
(71, 2, 236, 1, 1, 3.0, '2026-08-23 11:10:46'),
(72, 2, 237, 1, 1, 2.0, '2026-08-23 11:10:46'),
(73, 2, 238, 1, 2, 3.0, '2026-08-23 11:10:46'),
(74, 2, 239, 1, 2, 3.0, '2026-08-23 11:10:46'),
(75, 2, 240, 1, 2, 3.0, '2026-08-23 11:10:46'),
(76, 2, 241, 1, 2, 3.0, '2026-08-23 11:10:46'),
(77, 2, 242, 1, 2, 3.0, '2026-08-23 11:10:46'),
(78, 2, 243, 1, 2, 2.0, '2026-08-23 11:10:46'),
(79, 2, 244, 2, 1, 3.0, '2026-08-23 11:10:46'),
(80, 2, 245, 2, 1, 3.0, '2026-08-23 11:10:46'),
(81, 2, 246, 2, 1, 3.0, '2026-08-23 11:10:46'),
(82, 2, 247, 2, 1, 3.0, '2026-08-23 11:10:46'),
(83, 2, 248, 2, 1, 3.0, '2026-08-23 11:10:46'),
(84, 2, 249, 2, 1, 2.0, '2026-08-23 11:10:46'),
(85, 2, 250, 2, 2, 3.0, '2026-08-23 11:10:46'),
(86, 2, 251, 2, 2, 3.0, '2026-08-23 11:10:46'),
(87, 2, 252, 2, 2, 3.0, '2026-08-23 11:10:46'),
(88, 2, 253, 2, 2, 3.0, '2026-08-23 11:10:46'),
(89, 2, 254, 2, 2, 3.0, '2026-08-23 11:10:46'),
(90, 2, 255, 2, 2, 2.0, '2026-08-23 11:10:46'),
(91, 2, 256, 3, 1, 3.0, '2026-08-23 11:10:46'),
(92, 2, 257, 3, 1, 3.0, '2026-08-23 11:10:46'),
(93, 2, 258, 3, 1, 3.0, '2026-08-23 11:10:46'),
(94, 2, 259, 3, 1, 3.0, '2026-08-23 11:10:46'),
(95, 2, 260, 3, 1, 3.0, '2026-08-23 11:10:46'),
(96, 2, 261, 3, 1, 3.0, '2026-08-23 11:10:46'),
(97, 2, 262, 3, 2, 3.0, '2026-08-23 11:10:46'),
(98, 2, 263, 3, 2, 3.0, '2026-08-23 11:10:46'),
(99, 2, 264, 3, 2, 3.0, '2026-08-23 11:10:46'),
(100, 2, 265, 3, 2, 3.0, '2026-08-23 11:10:46'),
(101, 2, 266, 3, 2, 3.0, '2026-08-23 11:10:46'),
(102, 2, 267, 3, 2, 3.0, '2026-08-23 11:10:46'),
(103, 2, 268, 4, 1, 3.0, '2026-08-23 11:10:46'),
(104, 2, 269, 4, 1, 3.0, '2026-08-23 11:10:46'),
(105, 2, 270, 4, 1, 3.0, '2026-08-23 11:10:46'),
(106, 2, 271, 4, 1, 3.0, '2026-08-23 11:10:46'),
(107, 2, 272, 4, 1, 3.0, '2026-08-23 11:10:46'),
(108, 2, 273, 4, 2, 3.0, '2026-08-23 11:10:46'),
(109, 2, 274, 4, 2, 3.0, '2026-08-23 11:10:46'),
(110, 2, 275, 4, 2, 6.0, '2026-08-23 11:10:46'),
(117, 3, 295, 1, 1, 3.0, '2026-08-23 11:10:46'),
(118, 3, 296, 1, 1, 3.0, '2026-08-23 11:10:46'),
(119, 3, 297, 1, 1, 3.0, '2026-08-23 11:10:46'),
(120, 3, 298, 1, 1, 3.0, '2026-08-23 11:10:46'),
(121, 3, 299, 1, 1, 3.0, '2026-08-23 11:10:46'),
(122, 3, 300, 1, 1, 2.0, '2026-08-23 11:10:46'),
(123, 3, 301, 1, 2, 3.0, '2026-08-23 11:10:46'),
(124, 3, 302, 1, 2, 3.0, '2026-08-23 11:10:46'),
(125, 3, 303, 1, 2, 3.0, '2026-08-23 11:10:46'),
(126, 3, 304, 1, 2, 3.0, '2026-08-23 11:10:46'),
(127, 3, 305, 1, 2, 3.0, '2026-08-23 11:10:46'),
(128, 3, 306, 1, 2, 2.0, '2026-08-23 11:10:46'),
(129, 3, 307, 2, 1, 3.0, '2026-08-23 11:10:46'),
(130, 3, 308, 2, 1, 3.0, '2026-08-23 11:10:46'),
(131, 3, 309, 2, 1, 3.0, '2026-08-23 11:10:46'),
(132, 3, 310, 2, 1, 3.0, '2026-08-23 11:10:46'),
(133, 3, 311, 2, 1, 3.0, '2026-08-23 11:10:46'),
(134, 3, 312, 2, 1, 2.0, '2026-08-23 11:10:46'),
(135, 3, 313, 2, 2, 3.0, '2026-08-23 11:10:46'),
(136, 3, 314, 2, 2, 3.0, '2026-08-23 11:10:46'),
(137, 3, 315, 2, 2, 3.0, '2026-08-23 11:10:46'),
(138, 3, 316, 2, 2, 3.0, '2026-08-23 11:10:46'),
(139, 3, 317, 2, 2, 3.0, '2026-08-23 11:10:46'),
(140, 3, 318, 2, 2, 2.0, '2026-08-23 11:10:46'),
(141, 3, 319, 3, 1, 3.0, '2026-08-23 11:10:46'),
(142, 3, 320, 3, 1, 3.0, '2026-08-23 11:10:46'),
(143, 3, 321, 3, 1, 3.0, '2026-08-23 11:10:46'),
(144, 3, 322, 3, 1, 3.0, '2026-08-23 11:10:46'),
(145, 3, 323, 3, 1, 3.0, '2026-08-23 11:10:46'),
(146, 3, 324, 3, 1, 3.0, '2026-08-23 11:10:46'),
(147, 3, 325, 3, 2, 3.0, '2026-08-23 11:10:46'),
(148, 3, 326, 3, 2, 3.0, '2026-08-23 11:10:46'),
(149, 3, 327, 3, 2, 3.0, '2026-08-23 11:10:46'),
(150, 3, 328, 3, 2, 3.0, '2026-08-23 11:10:46'),
(151, 3, 329, 3, 2, 3.0, '2026-08-23 11:10:46'),
(152, 3, 330, 3, 2, 3.0, '2026-08-23 11:10:46'),
(153, 3, 331, 4, 1, 3.0, '2026-08-23 11:10:46'),
(154, 3, 332, 4, 1, 3.0, '2026-08-23 11:10:46'),
(155, 3, 333, 4, 1, 3.0, '2026-08-23 11:10:46'),
(156, 3, 334, 4, 1, 3.0, '2026-08-23 11:10:46'),
(157, 3, 335, 4, 1, 3.0, '2026-08-23 11:10:46'),
(158, 3, 336, 4, 2, 3.0, '2026-08-23 11:10:46'),
(159, 3, 337, 4, 2, 3.0, '2026-08-23 11:10:46'),
(160, 3, 338, 4, 2, 6.0, '2026-08-23 11:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `STATUS` enum('Pending','Approved','Rejected','Enrolled') NOT NULL DEFAULT 'Pending',
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_status` enum('Paid','Pending','Unpaid','Partial') NOT NULL DEFAULT 'Pending',
  `paymongo_link_id` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_option` varchar(50) DEFAULT NULL,
  `payment_reference` varchar(100) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT 0.00,
  `cash_amount_requested` decimal(10,2) DEFAULT NULL,
  `payment_account` varchar(100) DEFAULT NULL,
  `payment_proof` varchar(255) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `section_id`, `year_level`, `school_year`, `sem`, `STATUS`, `created`, `payment_status`, `paymongo_link_id`, `payment_method`, `payment_option`, `payment_reference`, `amount_paid`, `cash_amount_requested`, `payment_account`, `payment_proof`, `paid_at`) VALUES
(31, 34, 1, 21, 1, '2026-2027', 1, 'Enrolled', '2026-10-01 16:37:57', 'Paid', NULL, 'Cash', NULL, 'POS-1790876356', 20000.00, NULL, NULL, NULL, NULL),
(32, 35, 1, 30, 3, '2026-2027', 1, 'Pending', '2026-10-02 01:57:54', 'Pending', NULL, NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment_details`
--

CREATE TABLE `enrollment_details` (
  `id` int(11) NOT NULL,
  `enrollment_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollment_details`
--

INSERT INTO `enrollment_details` (`id`, `enrollment_id`, `subject_id`) VALUES
(154, 31, 217),
(155, 31, 218),
(156, 31, 61),
(157, 31, 62),
(158, 31, 63),
(159, 31, 219),
(160, 32, 85),
(161, 32, 86),
(162, 32, 87),
(163, 32, 88),
(164, 32, 89),
(165, 32, 90);

-- --------------------------------------------------------

--
-- Table structure for table `lms_activities`
--

CREATE TABLE `lms_activities` (
  `id` int(10) UNSIGNED NOT NULL,
  `assignment_id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(180) NOT NULL,
  `instructions` text DEFAULT NULL,
  `activity_type` enum('Assignment','Quiz','Project','Exam','Other') NOT NULL DEFAULT 'Assignment',
  `grading_period` enum('Prelim','Midterm','Pre-Final','Final','General') NOT NULL DEFAULT 'General',
  `max_score` decimal(6,2) NOT NULL DEFAULT 100.00,
  `due_at` datetime DEFAULT NULL,
  `status` enum('Draft','Published','Closed','Archived') NOT NULL DEFAULT 'Draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lms_activities`
--

INSERT INTO `lms_activities` (`id`, `assignment_id`, `teacher_id`, `title`, `instructions`, `activity_type`, `grading_period`, `max_score`, `due_at`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 29, 'Chapter 1 Quiz', 'Please complete all multiple choice questions based on Chapter 1.', 'Quiz', 'Prelim', 50.00, '0000-00-00 00:00:00', 'Published', '2026-10-02 03:13:25', '2026-10-02 03:13:25'),
(2, 1, 29, 'Introduction to the Subject Essay', 'Write a 500-word essay on the importance of this subject in your future career.', 'Assignment', 'Prelim', 100.00, '0000-00-00 00:00:00', 'Published', '2026-10-02 03:13:25', '2026-10-02 03:13:25'),
(3, 1, 29, 'Midterm Practical Examination', 'Practical exam covering all topics from weeks 1-6. See attached rubric.', 'Exam', 'Midterm', 100.00, '0000-00-00 00:00:00', 'Published', '2026-10-02 03:13:25', '2026-10-02 03:13:25'),
(4, 1, 29, 'Group Project Proposal', 'Submit your group\'s project proposal document in PDF format.', 'Project', 'Midterm', 100.00, '0000-00-00 00:00:00', 'Published', '2026-10-02 03:13:25', '2026-10-02 03:13:25'),
(5, 1, 29, 'Advanced Concepts Quiz', 'Short quiz on advanced topics.', 'Quiz', 'Pre-Final', 50.00, NULL, 'Draft', '2026-10-02 03:13:25', '2026-10-02 03:13:25'),
(6, 1, 29, 'Final Capstone Submission', 'Submit your final capstone project here.', 'Project', 'Final', 200.00, NULL, 'Draft', '2026-10-02 03:13:25', '2026-10-02 03:13:25');

-- --------------------------------------------------------

--
-- Table structure for table `lms_announcements`
--

CREATE TABLE `lms_announcements` (
  `id` int(10) UNSIGNED NOT NULL,
  `assignment_id` int(10) UNSIGNED DEFAULT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(180) NOT NULL,
  `body` text NOT NULL,
  `publish_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lms_materials`
--

CREATE TABLE `lms_materials` (
  `id` int(10) UNSIGNED NOT NULL,
  `assignment_id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(180) NOT NULL,
  `grading_period` enum('Prelim','Midterm','Pre-Final','Final','General') NOT NULL DEFAULT 'General',
  `description` text DEFAULT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `file_size` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lms_notifications`
--

CREATE TABLE `lms_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'general',
  `title` varchar(180) NOT NULL,
  `message` varchar(500) NOT NULL,
  `link` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `read_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lms_submissions`
--

CREATE TABLE `lms_submissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `activity_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `file_size` bigint(20) UNSIGNED DEFAULT NULL,
  `submission_text` text DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('Submitted','Graded','Returned') NOT NULL DEFAULT 'Submitted',
  `score` decimal(6,2) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `graded_by` int(11) DEFAULT NULL,
  `graded_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `enrollment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `reference_number` varchar(100) NOT NULL,
  `status` enum('Successful','Cancelled','Failed') NOT NULL DEFAULT 'Successful',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'Super Admin', 'Full administrative access to the EYYSAT enrollment system'),
(2, 'Instructor / Professor', 'Faculty access to assigned subjects and sections'),
(3, 'Student', 'Student access to enrollment, profile, curriculum and payment records'),
(4, 'Cashier', 'Payment verification, collection and receipt access'),
(5, 'Registrar / Academic Affairs', 'Academic records, curriculum, sections, enrollment and instructor assignment access');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `max_slots` int(11) DEFAULT 40,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `section_id`, `course_id`, `section_name`, `max_slots`, `created`) VALUES
(21, NULL, 1, 'BSIT-1A1', 40, '2026-07-31 00:13:11'),
(22, NULL, 1, 'BSIT-1B1', 40, '2026-07-31 00:13:11'),
(23, NULL, 1, 'BSIT-1C1', 40, '2026-07-31 00:13:11'),
(24, NULL, 1, 'BSIT-1D1', 40, '2026-07-31 00:13:11'),
(25, NULL, 1, 'BSIT-2A1', 40, '2026-07-31 00:13:11'),
(26, NULL, 1, 'BSIT-2B1', 40, '2026-07-31 00:13:11'),
(27, NULL, 1, 'BSIT-2C1', 40, '2026-07-31 00:13:11'),
(28, NULL, 1, 'BSIT-2D1', 40, '2026-07-31 00:13:11'),
(29, NULL, 1, 'BSIT-3A1', 40, '2026-07-31 00:13:11'),
(30, NULL, 1, 'BSIT-3B1', 40, '2026-07-31 00:13:11'),
(31, NULL, 1, 'BSIT-3C1', 40, '2026-07-31 00:13:11'),
(32, NULL, 1, 'BSIT-3D1', 40, '2026-07-31 00:13:11'),
(33, NULL, 1, 'BSIT-4A1', 40, '2026-07-31 00:13:11'),
(34, NULL, 1, 'BSIT-4B1', 40, '2026-07-31 00:13:11'),
(35, NULL, 1, 'BSIT-4C1', 40, '2026-07-31 00:13:11'),
(36, NULL, 1, 'BSIT-4D1', 40, '2026-07-31 00:13:11'),
(37, NULL, 2, 'BSCS-1A1', 40, '2026-07-31 00:13:11'),
(38, NULL, 2, 'BSCS-1B1', 40, '2026-07-31 00:13:11'),
(39, NULL, 2, 'BSCS-1C1', 40, '2026-07-31 00:13:11'),
(40, NULL, 2, 'BSCS-1D1', 40, '2026-07-31 00:13:11'),
(41, NULL, 2, 'BSCS-2A1', 40, '2026-07-31 00:13:11'),
(42, NULL, 2, 'BSCS-2B1', 40, '2026-07-31 00:13:11'),
(43, NULL, 2, 'BSCS-2C1', 40, '2026-07-31 00:13:11'),
(44, NULL, 2, 'BSCS-2D1', 40, '2026-07-31 00:13:11'),
(45, NULL, 2, 'BSCS-3A1', 40, '2026-07-31 00:13:11'),
(46, NULL, 2, 'BSCS-3B1', 40, '2026-07-31 00:13:11'),
(47, NULL, 2, 'BSCS-3C1', 40, '2026-07-31 00:13:11'),
(48, NULL, 2, 'BSCS-3D1', 40, '2026-07-31 00:13:11'),
(49, NULL, 2, 'BSCS-4A1', 40, '2026-07-31 00:13:11'),
(50, NULL, 2, 'BSCS-4B1', 40, '2026-07-31 00:13:11'),
(51, NULL, 2, 'BSCS-4C1', 40, '2026-07-31 00:13:11'),
(52, NULL, 2, 'BSCS-4D1', 40, '2026-07-31 00:13:11'),
(53, NULL, 3, 'BSIS-1A1', 40, '2026-07-31 00:13:11'),
(54, NULL, 3, 'BSIS-1B1', 40, '2026-07-31 00:13:11'),
(55, NULL, 3, 'BSIS-1C1', 40, '2026-07-31 00:13:11'),
(56, NULL, 3, 'BSIS-1D1', 40, '2026-07-31 00:13:11'),
(57, NULL, 3, 'BSIS-2A1', 40, '2026-07-31 00:13:11'),
(58, NULL, 3, 'BSIS-2B1', 40, '2026-07-31 00:13:11'),
(59, NULL, 3, 'BSIS-2C1', 40, '2026-07-31 00:13:11'),
(60, NULL, 3, 'BSIS-2D1', 40, '2026-07-31 00:13:11'),
(61, NULL, 3, 'BSIS-3A1', 40, '2026-07-31 00:13:11'),
(62, NULL, 3, 'BSIS-3B1', 40, '2026-07-31 00:13:11'),
(63, NULL, 3, 'BSIS-3C1', 40, '2026-07-31 00:13:11'),
(64, NULL, 3, 'BSIS-3D1', 40, '2026-07-31 00:13:11'),
(65, NULL, 3, 'BSIS-4A1', 40, '2026-07-31 00:13:11'),
(66, NULL, 3, 'BSIS-4B1', 40, '2026-07-31 00:13:11'),
(67, NULL, 3, 'BSIS-4C1', 40, '2026-07-31 00:13:11'),
(68, NULL, 3, 'BSIS-4D1', 40, '2026-07-31 00:13:11'),
(69, NULL, 1, 'BSIT-1A2', 40, '2026-07-31 00:13:11'),
(70, NULL, 1, 'BSIT-1B2', 40, '2026-07-31 00:13:11'),
(71, NULL, 1, 'BSIT-1C2', 40, '2026-07-31 00:13:11'),
(72, NULL, 1, 'BSIT-1D2', 40, '2026-07-31 00:13:11'),
(73, NULL, 1, 'BSIT-2A2', 40, '2026-07-31 00:13:11'),
(74, NULL, 1, 'BSIT-2B2', 40, '2026-07-31 00:13:11'),
(75, NULL, 1, 'BSIT-2C2', 40, '2026-07-31 00:13:11'),
(76, NULL, 1, 'BSIT-2D2', 40, '2026-07-31 00:13:11'),
(77, NULL, 1, 'BSIT-3A2', 40, '2026-07-31 00:13:11'),
(78, NULL, 1, 'BSIT-3B2', 40, '2026-07-31 00:13:11'),
(79, NULL, 1, 'BSIT-3C2', 40, '2026-07-31 00:13:11'),
(80, NULL, 1, 'BSIT-3D2', 40, '2026-07-31 00:13:11'),
(81, NULL, 1, 'BSIT-4A2', 40, '2026-07-31 00:13:11'),
(82, NULL, 1, 'BSIT-4B2', 40, '2026-07-31 00:13:11'),
(83, NULL, 1, 'BSIT-4C2', 40, '2026-07-31 00:13:11'),
(84, NULL, 1, 'BSIT-4D2', 40, '2026-07-31 00:13:11'),
(85, NULL, 2, 'BSCS-1A2', 40, '2026-07-31 00:13:11'),
(86, NULL, 2, 'BSCS-1B2', 40, '2026-07-31 00:13:11'),
(87, NULL, 2, 'BSCS-1C2', 40, '2026-07-31 00:13:11'),
(88, NULL, 2, 'BSCS-1D2', 40, '2026-07-31 00:13:11'),
(89, NULL, 2, 'BSCS-2A2', 40, '2026-07-31 00:13:11'),
(90, NULL, 2, 'BSCS-2B2', 40, '2026-07-31 00:13:11'),
(91, NULL, 2, 'BSCS-2C2', 40, '2026-07-31 00:13:11'),
(92, NULL, 2, 'BSCS-2D2', 40, '2026-07-31 00:13:11'),
(93, NULL, 2, 'BSCS-3A2', 40, '2026-07-31 00:13:11'),
(94, NULL, 2, 'BSCS-3B2', 40, '2026-07-31 00:13:11'),
(95, NULL, 2, 'BSCS-3C2', 40, '2026-07-31 00:13:11'),
(96, NULL, 2, 'BSCS-3D2', 40, '2026-07-31 00:13:11'),
(97, NULL, 2, 'BSCS-4A2', 40, '2026-07-31 00:13:11'),
(98, NULL, 2, 'BSCS-4B2', 40, '2026-07-31 00:13:11'),
(99, NULL, 2, 'BSCS-4C2', 40, '2026-07-31 00:13:11'),
(100, NULL, 2, 'BSCS-4D2', 40, '2026-07-31 00:13:11'),
(101, NULL, 3, 'BSIS-1A2', 40, '2026-07-31 00:13:11'),
(102, NULL, 3, 'BSIS-1B2', 40, '2026-07-31 00:13:11'),
(103, NULL, 3, 'BSIS-1C2', 40, '2026-07-31 00:13:11'),
(104, NULL, 3, 'BSIS-1D2', 40, '2026-07-31 00:13:11'),
(105, NULL, 3, 'BSIS-2A2', 40, '2026-07-31 00:13:11'),
(106, NULL, 3, 'BSIS-2B2', 40, '2026-07-31 00:13:11'),
(107, NULL, 3, 'BSIS-2C2', 40, '2026-07-31 00:13:11'),
(108, NULL, 3, 'BSIS-2D2', 40, '2026-07-31 00:13:11'),
(109, NULL, 3, 'BSIS-3A2', 40, '2026-07-31 00:13:11'),
(110, NULL, 3, 'BSIS-3B2', 40, '2026-07-31 00:13:11'),
(111, NULL, 3, 'BSIS-3C2', 40, '2026-07-31 00:13:11'),
(112, NULL, 3, 'BSIS-3D2', 40, '2026-07-31 00:13:11'),
(113, NULL, 3, 'BSIS-4A2', 40, '2026-07-31 00:13:11'),
(114, NULL, 3, 'BSIS-4B2', 40, '2026-07-31 00:13:11'),
(115, NULL, 3, 'BSIS-4C2', 40, '2026-07-31 00:13:11'),
(116, NULL, 3, 'BSIS-4D2', 40, '2026-07-31 00:13:11');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_number` varchar(20) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `sex` enum('Male','Female') DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `guardian` varchar(100) DEFAULT NULL,
  `guardian_contact` varchar(100) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `payment_status` enum('Paid','Pending','Unpaid','Partial') NOT NULL DEFAULT 'Pending',
  `enrollment_status` enum('Pending','Approved','Rejected','Enrolled') NOT NULL DEFAULT 'Pending',
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_picture` varchar(255) DEFAULT NULL,
  `remaining_balance` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `student_number`, `first_name`, `middle_name`, `last_name`, `sex`, `birthdate`, `address`, `contact`, `email`, `guardian`, `guardian_contact`, `course_id`, `section_id`, `year_level`, `payment_status`, `enrollment_status`, `created`, `profile_picture`, `remaining_balance`) VALUES
(34, 36, '2026-001', 'Lionel', 't', 'messi', 'Male', '2001-01-22', 'argentina', '09123456789', 'messi@gmail.com', 'Diego maradona', '09678453756', 1, 21, 1, 'Paid', 'Approved', '2026-10-01 16:37:57', NULL, 0.00),
(35, 42, NULL, 'ryan', 'C', 'ancheta', 'Male', '2002-01-22', 'golden', '09762344523', 'ryan@gmail.com', 'mamaa', '09754328574', 1, 30, 3, 'Pending', 'Pending', '2026-10-02 01:57:54', NULL, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `subject_code` varchar(20) DEFAULT NULL,
  `subject_name` varchar(100) DEFAULT NULL,
  `units` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `section_id` int(11) DEFAULT NULL,
  `schedule_day` varchar(20) DEFAULT NULL,
  `schedule_time` varchar(50) DEFAULT NULL,
  `room_number` varchar(20) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `teacher_name` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `course_id`, `subject_code`, `subject_name`, `units`, `sem`, `year_level`, `created`, `section_id`, `schedule_day`, `schedule_time`, `room_number`, `is_available`, `teacher_name`) VALUES
(61, 1, 'IT111', 'Introduction to Computing', 3, 1, 1, '2026-08-21 05:11:54', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 211', 1, NULL),
(62, 1, 'IT112', 'Programming Fundamentals', 3, 1, 1, '2026-08-21 05:11:54', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 211', 1, 'Bryxen Arce'),
(63, 1, 'IT113', 'Computer Organization', 3, 1, 1, '2026-08-21 05:11:54', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 211', 1, NULL),
(67, 1, 'IT121', 'Object-Oriented Programming', 3, 2, 1, '2026-08-21 05:11:54', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 211', 1, NULL),
(68, 1, 'IT122', 'Database Fundamentals', 3, 2, 1, '2026-08-21 05:11:54', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 211', 1, NULL),
(69, 1, 'IT123', 'Web Development Fundamentals', 3, 2, 1, '2026-08-21 05:11:54', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 211', 1, NULL),
(73, 1, 'IT211', 'Data Structures and Algorithms', 3, 1, 2, '2026-08-21 05:11:54', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 212', 1, NULL),
(74, 1, 'IT212', 'Database Management Systems', 3, 1, 2, '2026-08-21 05:11:54', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 212', 1, NULL),
(75, 1, 'IT213', 'Computer Networking 1', 3, 1, 2, '2026-08-21 05:11:54', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 212', 1, NULL),
(76, 1, 'IT214', 'Systems Analysis and Design', 3, 1, 2, '2026-08-21 05:11:54', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 212', 1, NULL),
(79, 1, 'IT221', 'Computer Networking 2', 3, 2, 2, '2026-08-21 05:11:54', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 212', 1, NULL),
(80, 1, 'IT222', 'Information Management', 3, 2, 2, '2026-08-21 05:11:54', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 212', 1, NULL),
(81, 1, 'IT223', 'Human Computer Interaction', 3, 2, 2, '2026-08-21 05:11:54', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 212', 1, NULL),
(82, 1, 'IT224', 'Platform Technologies', 3, 2, 2, '2026-08-21 05:11:54', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 212', 1, NULL),
(85, 1, 'IT311', 'Advanced Database Systems', 3, 1, 3, '2026-08-21 05:11:54', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 213', 1, NULL),
(86, 1, 'IT312', 'Software Engineering', 3, 1, 3, '2026-08-21 05:11:54', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 213', 1, NULL),
(87, 1, 'IT313', 'Information Assurance and Security', 3, 1, 3, '2026-08-21 05:11:54', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 213', 1, NULL),
(88, 1, 'IT314', 'Mobile Application Development', 3, 1, 3, '2026-08-21 05:11:54', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 213', 1, NULL),
(89, 1, 'IT315', 'IT Project Management', 3, 1, 3, '2026-08-21 05:11:54', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 213', 1, NULL),
(90, 1, 'IT316', 'Web Systems and Technologies', 3, 1, 3, '2026-08-21 05:11:54', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 213', 1, NULL),
(91, 1, 'IT321', 'Systems Integration and Architecture', 3, 2, 3, '2026-08-21 05:11:54', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 213', 1, NULL),
(92, 1, 'IT322', 'Cloud Computing', 3, 2, 3, '2026-08-21 05:11:54', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 213', 1, NULL),
(93, 1, 'IT323', 'Network Security', 3, 2, 3, '2026-08-21 05:11:54', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 213', 1, NULL),
(94, 1, 'IT324', 'IT Elective 1', 3, 2, 3, '2026-08-21 05:11:54', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 213', 1, NULL),
(95, 1, 'IT325', 'Research Methods in IT', 3, 2, 3, '2026-08-21 05:11:54', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 213', 1, NULL),
(96, 1, 'IT326', 'Professional Issues in IT', 3, 2, 3, '2026-08-21 05:11:54', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 213', 1, NULL),
(97, 1, 'IT411', 'Capstone Project 1', 3, 1, 4, '2026-08-21 05:11:54', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 214', 1, NULL),
(98, 1, 'IT412', 'IT Governance', 3, 1, 4, '2026-08-21 05:11:54', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 214', 1, NULL),
(99, 1, 'IT413', 'IT Elective 2', 3, 1, 4, '2026-08-21 05:11:54', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 214', 1, NULL),
(100, 1, 'IT414', 'Emerging Technologies', 3, 1, 4, '2026-08-21 05:11:54', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 214', 1, NULL),
(101, 1, 'IT415', 'Internship Preparation', 3, 1, 4, '2026-08-21 05:11:54', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 214', 1, NULL),
(102, 1, 'IT421', 'Capstone Project 2', 3, 2, 4, '2026-08-21 05:11:54', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 214', 1, NULL),
(103, 1, 'IT422', 'IT Elective 3', 3, 2, 4, '2026-08-21 05:11:54', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 214', 1, NULL),
(104, 1, 'IT423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:11:54', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 214', 1, NULL),
(217, 1, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 211', 1, NULL),
(218, 1, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 211', 1, NULL),
(219, 1, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 211', 1, NULL),
(220, 1, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 211', 1, NULL),
(221, 1, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 211', 1, NULL),
(222, 1, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 211', 1, NULL),
(223, 1, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 212', 1, NULL),
(224, 1, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 212', 1, NULL),
(225, 1, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 212', 1, NULL),
(226, 1, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 212', 1, NULL),
(232, 2, 'CS111', 'Introduction to Computer Science', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 221', 1, 'Prof. Navarro'),
(233, 2, 'CS112', 'Programming Fundamentals', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 221', 1, 'Prof. Ramos'),
(234, 2, 'CS113', 'Discrete Mathematics', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 221', 1, 'Prof. Bautista'),
(235, 2, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 221', 1, 'Prof. Flores'),
(236, 2, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 221', 1, 'Prof. Santos'),
(237, 2, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 221', 1, 'Prof. Reyes'),
(238, 2, 'CS121', 'Object-Oriented Programming', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 221', 1, 'Prof. Cruz'),
(239, 2, 'CS122', 'Data Structures', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 221', 1, 'Prof. Garcia'),
(240, 2, 'CS123', 'Computer Organization', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 221', 1, 'Prof. Dela Cruz'),
(241, 2, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 221', 1, 'Prof. Mendoza'),
(242, 2, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 221', 1, 'Prof. Navarro'),
(243, 2, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 221', 1, 'Prof. Ramos'),
(244, 2, 'CS211', 'Algorithms and Complexity', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 222', 1, 'Prof. Bautista'),
(245, 2, 'CS212', 'Database Systems', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 222', 1, 'Prof. Flores'),
(246, 2, 'CS213', 'Computer Architecture', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 222', 1, 'Prof. Santos'),
(247, 2, 'CS214', 'Operating Systems', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 222', 1, 'Prof. Reyes'),
(248, 2, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 222', 1, 'Prof. Cruz'),
(249, 2, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 222', 1, 'Prof. Garcia'),
(250, 2, 'CS221', 'Software Engineering', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 222', 1, 'Prof. Dela Cruz'),
(251, 2, 'CS222', 'Theory of Computation', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 222', 1, 'Prof. Mendoza'),
(252, 2, 'CS223', 'Artificial Intelligence', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 222', 1, 'Prof. Navarro'),
(253, 2, 'CS224', 'Computer Networks', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 222', 1, 'Prof. Ramos'),
(254, 2, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 222', 1, 'Prof. Bautista'),
(255, 2, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 222', 1, 'Prof. Flores'),
(256, 2, 'CS311', 'Artificial Intelligence 2', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 223', 1, 'Prof. Santos'),
(257, 2, 'CS312', 'Machine Learning', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 223', 1, 'Prof. Reyes'),
(258, 2, 'CS313', 'Web Technologies', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 223', 1, 'Prof. Cruz'),
(259, 2, 'CS314', 'Information Security', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 223', 1, 'Prof. Garcia'),
(260, 2, 'CS315', 'Research Methods', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 223', 1, 'Prof. Dela Cruz'),
(261, 2, 'CS316', 'CS Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 223', 1, 'Prof. Mendoza'),
(262, 2, 'CS321', 'Data Mining', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 223', 1, 'Prof. Navarro'),
(263, 2, 'CS322', 'Compiler Design', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 223', 1, 'Prof. Ramos'),
(264, 2, 'CS323', 'Distributed Computing', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 223', 1, 'Prof. Bautista'),
(265, 2, 'CS324', 'CS Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 223', 1, 'Prof. Flores'),
(266, 2, 'CS325', 'Mobile Computing', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 223', 1, 'Prof. Santos'),
(267, 2, 'CS326', 'Software Project Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 223', 1, 'Prof. Reyes'),
(268, 2, 'CS411', 'Thesis 1', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 224', 1, 'Prof. Cruz'),
(269, 2, 'CS412', 'Advanced Algorithms', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 224', 1, 'Prof. Garcia'),
(270, 2, 'CS413', 'CS Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 224', 1, 'Prof. Dela Cruz'),
(271, 2, 'CS414', 'Emerging Computing Technologies', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 224', 1, 'Prof. Mendoza'),
(272, 2, 'CS415', 'Professional Practice', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 224', 1, 'Prof. Navarro'),
(273, 2, 'CS421', 'Thesis 2', 3, 2, 4, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 224', 1, 'Prof. Ramos'),
(274, 2, 'CS422', 'CS Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 224', 1, 'Prof. Bautista'),
(275, 2, 'CS423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 224', 1, 'Prof. Flores'),
(295, 3, 'IS111', 'Information Systems Fundamentals', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 231', 1, 'Prof. Reyes'),
(296, 3, 'IS112', 'Introduction to Programming', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 231', 1, 'Prof. Cruz'),
(297, 3, 'IS113', 'Business Mathematics', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 231', 1, 'Prof. Garcia'),
(298, 3, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 231', 1, 'Prof. Dela Cruz'),
(299, 3, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 231', 1, 'Prof. Mendoza'),
(300, 3, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 231', 1, 'Prof. Navarro'),
(301, 3, 'IS121', 'Programming for Information Systems', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 231', 1, 'Prof. Ramos'),
(302, 3, 'IS122', 'Database Management', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 231', 1, 'Prof. Bautista'),
(303, 3, 'IS123', 'Business Process Management', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 231', 1, 'Prof. Flores'),
(304, 3, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 231', 1, 'Prof. Santos'),
(305, 3, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 231', 1, 'Prof. Reyes'),
(306, 3, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 231', 1, 'Prof. Cruz'),
(307, 3, 'IS211', 'Systems Analysis and Design', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 232', 1, 'Prof. Garcia'),
(308, 3, 'IS212', 'Data Structures', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 232', 1, 'Prof. Dela Cruz'),
(309, 3, 'IS213', 'Enterprise Architecture', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 232', 1, 'Prof. Mendoza'),
(310, 3, 'IS214', 'IT Infrastructure', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 232', 1, 'Prof. Navarro'),
(311, 3, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 232', 1, 'Prof. Ramos'),
(312, 3, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 232', 1, 'Prof. Bautista'),
(313, 3, 'IS221', 'Web Information Systems', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 232', 1, 'Prof. Flores'),
(314, 3, 'IS222', 'Information Security', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 232', 1, 'Prof. Santos'),
(315, 3, 'IS223', 'Systems Integration', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 232', 1, 'Prof. Reyes'),
(316, 3, 'IS224', 'IT Project Management', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 232', 1, 'Prof. Cruz'),
(317, 3, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 232', 1, 'Prof. Garcia'),
(318, 3, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 232', 1, 'Prof. Dela Cruz'),
(319, 3, 'IS311', 'Business Intelligence', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 233', 1, 'Prof. Mendoza'),
(320, 3, 'IS312', 'Data Analytics', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 233', 1, 'Prof. Navarro'),
(321, 3, 'IS313', 'Information Assurance', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 233', 1, 'Prof. Ramos'),
(322, 3, 'IS314', 'Research Methods', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 233', 1, 'Prof. Bautista'),
(323, 3, 'IS315', 'IS Project Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 233', 1, 'Prof. Flores'),
(324, 3, 'IS316', 'IS Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 233', 1, 'Prof. Santos'),
(325, 3, 'IS321', 'Enterprise Systems', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 233', 1, 'Prof. Reyes'),
(326, 3, 'IS322', 'Cloud Information Systems', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 233', 1, 'Prof. Cruz'),
(327, 3, 'IS323', 'IT Governance', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 233', 1, 'Prof. Garcia'),
(328, 3, 'IS324', 'IS Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 233', 1, 'Prof. Dela Cruz'),
(329, 3, 'IS325', 'Digital Transformation', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 233', 1, 'Prof. Mendoza'),
(330, 3, 'IS326', 'Professional Practice', 3, 2, 3, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 233', 1, 'Prof. Navarro'),
(331, 3, 'IS411', 'Capstone Project 1', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 234', 1, 'Prof. Ramos'),
(332, 3, 'IS412', 'Strategic Information Systems', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 234', 1, 'Prof. Bautista'),
(333, 3, 'IS413', 'IS Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Monday/Wednesday', '7:30 AM - 9:00 AM', 'Room 234', 1, 'Prof. Flores'),
(334, 3, 'IS414', 'Emerging Technologies', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Tuesday/Thursday', '9:00 AM - 10:30 AM', 'Room 234', 1, 'Prof. Santos'),
(335, 3, 'IS415', 'Information Systems Audit', 3, 1, 4, '2026-08-21 05:20:23', NULL, 'Wednesday/Friday', '10:30 AM - 12:00 PM', 'Room 234', 1, 'Prof. Reyes'),
(336, 3, 'IS421', 'Capstone Project 2', 3, 2, 4, '2026-08-21 05:20:23', NULL, 'Monday/Thursday', '1:00 PM - 2:30 PM', 'Room 234', 1, 'Prof. Cruz'),
(337, 3, 'IS422', 'IS Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, 'Tuesday/Friday', '2:30 PM - 4:00 PM', 'Room 234', 1, 'Prof. Garcia'),
(338, 3, 'IS423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:20:23', NULL, 'Wednesday/Saturday', '4:00 PM - 5:30 PM', 'Room 234', 1, 'Prof. Dela Cruz');

-- --------------------------------------------------------

--
-- Table structure for table `system_migrations`
--

CREATE TABLE `system_migrations` (
  `migration_key` varchar(100) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_migrations`
--

INSERT INTO `system_migrations` (`migration_key`, `applied_at`) VALUES
('subject_instructor_assignment_v1', '2026-09-15 01:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES
(1, 'school_year', '2026-2027', NULL, '2026-10-01 14:00:05'),
(2, 'enrollment_fee', '20000.00', NULL, '2026-10-01 14:00:05');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_announcements`
--

CREATE TABLE `teacher_announcements` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_attendance`
--

CREATE TABLE `teacher_attendance` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assignment_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('Present','Absent','Late','Excused') NOT NULL DEFAULT 'Present',
  `remarks` varchar(255) DEFAULT NULL,
  `marked_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_grades`
--

CREATE TABLE `teacher_grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assignment_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `grading_period` varchar(40) NOT NULL DEFAULT 'Final',
  `score` decimal(5,2) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `updated_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher_profiles`
--

CREATE TABLE `teacher_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `employee_number` varchar(40) DEFAULT NULL,
  `department` varchar(120) DEFAULT NULL,
  `title` varchar(80) DEFAULT 'Instructor',
  `contact` varchar(30) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher_profiles`
--

INSERT INTO `teacher_profiles` (`id`, `user_id`, `employee_number`, `department`, `title`, `contact`, `bio`, `created_at`, `updated_at`) VALUES
(5, 29, '0001', 'ITD', 'Instructor', NULL, NULL, '2026-09-14 23:39:30', '2026-10-02 03:41:48'),
(12, 44, '0002', 'ITD', 'Instructor', NULL, NULL, '2026-10-02 03:51:42', '2026-10-02 03:51:42');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_sections`
--

CREATE TABLE `teacher_sections` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher_sections`
--

INSERT INTO `teacher_sections` (`id`, `teacher_id`, `section_id`, `created`) VALUES
(1, 29, 21, '2026-09-15 02:05:03');

-- --------------------------------------------------------

--
-- Table structure for table `teaching_assignments`
--

CREATE TABLE `teaching_assignments` (
  `id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `school_year` varchar(20) NOT NULL,
  `semester` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `status` enum('Active','Archived') NOT NULL DEFAULT 'Active',
  `assignment_source` enum('Manual','Legacy') NOT NULL DEFAULT 'Manual',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teaching_assignments`
--

INSERT INTO `teaching_assignments` (`id`, `teacher_id`, `subject_id`, `section_id`, `school_year`, `semester`, `status`, `assignment_source`, `created_at`, `updated_at`) VALUES
(1, 29, 62, 21, '2026-2027', 1, 'Active', 'Manual', '2026-09-15 02:27:16', '2026-10-02 01:46:50'),
(2, 29, 62, 22, '2026-2027', 1, 'Archived', 'Manual', '2026-09-15 02:27:16', '2026-10-02 01:40:18'),
(5, 29, 61, 21, '2026-2027', 1, 'Archived', 'Manual', '2026-09-15 02:40:09', '2026-10-01 11:53:19'),
(6, 29, 61, 22, '2026-2027', 1, 'Archived', 'Manual', '2026-09-15 02:40:09', '2026-10-01 11:53:19'),
(9, 29, 63, 21, '2026-2027', 1, 'Archived', 'Manual', '2026-09-15 02:40:24', '2026-10-01 10:45:03'),
(10, 29, 63, 22, '2026-2027', 1, 'Archived', 'Manual', '2026-09-15 02:40:24', '2026-10-01 10:45:03'),
(13, 29, 61, 23, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(14, 29, 61, 24, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(15, 29, 61, 25, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(16, 29, 61, 26, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(17, 29, 61, 27, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(18, 29, 61, 28, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(19, 29, 61, 29, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(20, 29, 61, 30, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(21, 29, 61, 31, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(22, 29, 61, 32, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(23, 29, 61, 33, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(24, 29, 61, 34, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(25, 29, 61, 35, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(26, 29, 61, 36, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(27, 29, 61, 69, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(28, 29, 61, 70, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(29, 29, 61, 71, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(30, 29, 61, 72, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(31, 29, 61, 73, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(32, 29, 61, 74, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(33, 29, 61, 75, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(34, 29, 61, 76, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(35, 29, 61, 77, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(36, 29, 61, 78, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(37, 29, 61, 79, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(38, 29, 61, 80, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(39, 29, 61, 81, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(40, 29, 61, 82, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(41, 29, 61, 83, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(42, 29, 61, 84, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:51', '2026-10-01 11:53:19'),
(45, 29, 62, 23, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(46, 29, 62, 24, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(47, 29, 62, 25, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(48, 29, 62, 26, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(49, 29, 62, 27, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(50, 29, 62, 28, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(51, 29, 62, 29, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(52, 29, 62, 30, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(53, 29, 62, 31, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(54, 29, 62, 32, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(55, 29, 62, 33, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(56, 29, 62, 34, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(57, 29, 62, 35, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(58, 29, 62, 36, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(59, 29, 62, 69, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(60, 29, 62, 70, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(61, 29, 62, 71, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(62, 29, 62, 72, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(63, 29, 62, 73, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(64, 29, 62, 74, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(65, 29, 62, 75, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(66, 29, 62, 76, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(67, 29, 62, 77, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(68, 29, 62, 78, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(69, 29, 62, 79, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(70, 29, 62, 80, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(71, 29, 62, 81, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(72, 29, 62, 82, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(73, 29, 62, 83, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(74, 29, 62, 84, '2026-2027', 1, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-02 01:40:18'),
(75, 29, 67, 21, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(76, 29, 67, 22, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(77, 29, 67, 23, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(78, 29, 67, 24, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(79, 29, 67, 25, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(80, 29, 67, 26, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(81, 29, 67, 27, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(82, 29, 67, 28, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(83, 29, 67, 29, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(84, 29, 67, 30, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(85, 29, 67, 31, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(86, 29, 67, 32, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(87, 29, 67, 33, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(88, 29, 67, 34, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(89, 29, 67, 35, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(90, 29, 67, 36, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(91, 29, 67, 69, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(92, 29, 67, 70, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(93, 29, 67, 71, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(94, 29, 67, 72, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(95, 29, 67, 73, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(96, 29, 67, 74, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(97, 29, 67, 75, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(98, 29, 67, 76, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(99, 29, 67, 77, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(100, 29, 67, 78, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(101, 29, 67, 79, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(102, 29, 67, 80, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(103, 29, 67, 81, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(104, 29, 67, 82, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(105, 29, 67, 83, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19'),
(106, 29, 67, 84, '2026-2027', 2, 'Archived', 'Manual', '2026-10-01 11:50:52', '2026-10-01 11:53:19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT 3,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(20) GENERATED ALWAYS AS (case `role_id` when 1 then 'admin' when 2 then 'teacher' when 3 then 'student' when 4 then 'cashier' when 5 then 'registrar' else 'unknown' end) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password_hash`, `role_id`, `created_at`) VALUES
(1, 'Rainier Acquisa', 'rainier@gmail.com', '$2y$12$qxo0Q3JSmLQLDujUTh4JQubYr/p2uSdjOtzYdSG/wvIxHkpR/x//y', 1, '2026-09-14 15:19:46'),
(29, 'Bryxen Arce', 'bryx@gmail.com', '$2y$10$UwteYaXHa1Qagchj8XpqiOeXS38gBjGCy/K15b7XOHgy8M1LVghvu', 2, '2026-09-14 23:39:30'),
(30, 'Andre Breis', 'breis@gmail.com', '$2y$10$F60WN2aNXKpQo7lKLQMI5uT66cx65xngu2sdImrbYAkjk5vVDJ1yu', 4, '2026-09-14 23:40:27'),
(35, 'test registrar', 'test01@gmail.com', '$2y$10$RQLpuwh9pbSQdAf0AWgknuWU0oFEUSFv.TPIIBcg/DBv1zjBu4fim', 5, '2026-10-01 12:28:30'),
(36, 'Lionel messi', 'messi@gmail.com', '$2y$10$4B1Z5K2t/iGhSwuoMl.YNOdpkA7qMmo2vDkqPCY.2I6WNJpyJWgPS', 3, '2026-10-01 16:37:57'),
(42, 'ryan ancheta', 'ryan@gmail.com', '$2y$10$bN0h1f4hWAmcl1pLNh.Uu.RsOvs9M0/PE2K8UQBSHmGhSH4oCZyam', 3, '2026-10-02 01:57:54'),
(44, 'juan dela cruz', 'juan@gmail.com', '$2y$10$PQM//TMvxMscsVMSRwRtWug5Jn/aUxt8BVeog9/RkbXmnfUPg/tqu', 2, '2026-10-02 03:51:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_admin_notifications_unread` (`is_read`,`created_at`),
  ADD KEY `idx_admin_notifications_enrollment` (`enrollment_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `curriculum`
--
ALTER TABLE `curriculum`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_curriculum_subject` (`course_id`,`subject_id`,`year_level`,`semester`),
  ADD UNIQUE KEY `uq_curriculum_course_subject` (`course_id`,`subject_id`),
  ADD KEY `idx_curriculum_lookup` (`course_id`,`year_level`,`semester`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `enrollment_details`
--
ALTER TABLE `enrollment_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `enrollment_id` (`enrollment_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `lms_activities`
--
ALTER TABLE `lms_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_activity_assignment` (`assignment_id`,`status`,`due_at`),
  ADD KEY `idx_activity_teacher` (`teacher_id`,`status`);

--
-- Indexes for table `lms_announcements`
--
ALTER TABLE `lms_announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_lms_announcement_assignment` (`assignment_id`,`publish_at`),
  ADD KEY `idx_lms_announcement_teacher` (`teacher_id`);

--
-- Indexes for table `lms_materials`
--
ALTER TABLE `lms_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_lms_material_assignment` (`assignment_id`,`created_at`),
  ADD KEY `fk_lms_materials_user` (`teacher_id`);

--
-- Indexes for table `lms_notifications`
--
ALTER TABLE `lms_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_lms_notification_user` (`user_id`,`read_at`,`created_at`);

--
-- Indexes for table `lms_submissions`
--
ALTER TABLE `lms_submissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_activity_student` (`activity_id`,`student_id`),
  ADD KEY `idx_submission_activity` (`activity_id`,`status`),
  ADD KEY `idx_submission_student` (`student_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_payment_reference` (`reference_number`),
  ADD KEY `idx_payment_enrollment` (`enrollment_id`),
  ADD KEY `idx_payment_student` (`student_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roles_name` (`name`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `fk_students_section` (`section_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_subject_course_code` (`course_id`,`subject_code`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `system_migrations`
--
ALTER TABLE `system_migrations`
  ADD PRIMARY KEY (`migration_key`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_system_settings_key` (`setting_key`),
  ADD KEY `idx_system_settings_updated_by` (`updated_by`);

--
-- Indexes for table `teacher_announcements`
--
ALTER TABLE `teacher_announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_teacher_announcements_teacher` (`teacher_id`),
  ADD KEY `idx_teacher_announcements_section` (`section_id`),
  ADD KEY `idx_teacher_announcements_created` (`created_at`);

--
-- Indexes for table `teacher_attendance`
--
ALTER TABLE `teacher_attendance`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teacher_attendance` (`assignment_id`,`student_id`,`attendance_date`),
  ADD KEY `idx_attendance_assignment_date` (`assignment_id`,`attendance_date`),
  ADD KEY `idx_attendance_student` (`student_id`);

--
-- Indexes for table `teacher_grades`
--
ALTER TABLE `teacher_grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teacher_grade` (`assignment_id`,`student_id`,`grading_period`),
  ADD KEY `idx_grade_assignment_period` (`assignment_id`,`grading_period`),
  ADD KEY `idx_grade_student` (`student_id`);

--
-- Indexes for table `teacher_profiles`
--
ALTER TABLE `teacher_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teacher_user` (`user_id`),
  ADD UNIQUE KEY `uq_teacher_employee` (`employee_number`);

--
-- Indexes for table `teacher_sections`
--
ALTER TABLE `teacher_sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teacher_sections_section` (`section_id`),
  ADD KEY `idx_teacher_sections_teacher` (`teacher_id`),
  ADD KEY `idx_teacher_sections_section` (`section_id`);

--
-- Indexes for table `teaching_assignments`
--
ALTER TABLE `teaching_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teaching_assignment` (`teacher_id`,`subject_id`,`section_id`,`school_year`,`semester`),
  ADD KEY `idx_assignment_teacher` (`teacher_id`,`status`),
  ADD KEY `idx_assignment_section_subject` (`section_id`,`subject_id`,`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `curriculum`
--
ALTER TABLE `curriculum`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=512;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `enrollment_details`
--
ALTER TABLE `enrollment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `lms_activities`
--
ALTER TABLE `lms_activities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lms_announcements`
--
ALTER TABLE `lms_announcements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lms_materials`
--
ALTER TABLE `lms_materials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lms_notifications`
--
ALTER TABLE `lms_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lms_submissions`
--
ALTER TABLE `lms_submissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=341;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=799;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2399;

--
-- AUTO_INCREMENT for table `teacher_announcements`
--
ALTER TABLE `teacher_announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher_attendance`
--
ALTER TABLE `teacher_attendance`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher_grades`
--
ALTER TABLE `teacher_grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher_profiles`
--
ALTER TABLE `teacher_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `teacher_sections`
--
ALTER TABLE `teacher_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teaching_assignments`
--
ALTER TABLE `teaching_assignments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `enrollment_details`
--
ALTER TABLE `enrollment_details`
  ADD CONSTRAINT `enrollment_details_ibfk_1` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`id`),
  ADD CONSTRAINT `enrollment_details_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `lms_announcements`
--
ALTER TABLE `lms_announcements`
  ADD CONSTRAINT `fk_lms_announcements_user` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lms_materials`
--
ALTER TABLE `lms_materials`
  ADD CONSTRAINT `fk_lms_materials_user` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `sections_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `teacher_announcements`
--
ALTER TABLE `teacher_announcements`
  ADD CONSTRAINT `fk_teacher_announcements_user` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teacher_profiles`
--
ALTER TABLE `teacher_profiles`
  ADD CONSTRAINT `fk_teacher_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teacher_sections`
--
ALTER TABLE `teacher_sections`
  ADD CONSTRAINT `fk_teacher_sections_user` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teaching_assignments`
--
ALTER TABLE `teaching_assignments`
  ADD CONSTRAINT `fk_teaching_assignments_user` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
