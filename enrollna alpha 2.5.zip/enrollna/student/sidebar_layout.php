<?php

/** Shared navigation for student portal pages. */
$studentCurrentPage = basename($_SERVER['PHP_SELF']);
$studentName = htmlspecialchars($_SESSION['fullname'] ?? 'Student');
function student_sidebar_active(string $file, string $current): string
{
    return $current === $file ? ' active' : '';
}
?>
<aside class="admin-sidebar student-sidebar" id="studentSidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo"><img src="../img/eyysat.png" alt="EYYSAT Logo"></div>
        <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>STUDENT PORTAL</span></div>
    </div>
    <nav class="sidebar-nav" aria-label="Student navigation">
        <p class="sidebar-label">MY PORTAL</p>
        <a href="student_dashboard.php" class="sidebar-link<?= student_sidebar_active('student_dashboard.php', $studentCurrentPage) ?>"><span class="sidebar-icon">&#127968;</span><span class="sidebar-text">Dashboard</span></a>
        <a href="profile.php" class="sidebar-link<?= student_sidebar_active('profile.php', $studentCurrentPage) ?>"><span class="sidebar-icon">&#128100;</span><span class="sidebar-text">My Profile</span></a>
        <a href="registration_form_view.php" class="sidebar-link registration-form-link<?= student_sidebar_active('registration_form_view.php', $studentCurrentPage) ?>"><span class="sidebar-icon">&#128196;</span><span class="sidebar-text">Registration Form</span></a>
        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="../auth/logout.php" class="sidebar-link sidebar-logout"><span class="sidebar-icon">&#128682;</span><span class="sidebar-text">Logout</span></a>
    </nav>
    <div class="sidebar-profile">
        <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'Student', 0, 1))) ?></div>
        <div class="profile-info"><strong><?= $studentName ?></strong><span>Student</span></div>
    </div>
</aside>
<div class="sidebar-overlay" id="studentSidebarOverlay"></div>
<button class="sidebar-toggle" id="studentSidebarToggle" type="button" aria-label="Toggle sidebar"></button>
<script src="../js/sweetalert2.all.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('studentSidebar'),
            toggle = document.getElementById('studentSidebarToggle'),
            overlay = document.getElementById('studentSidebarOverlay'),
            main = document.querySelector('.dashboard-main');
        if (!sidebar || !toggle || !overlay) return;
        const positionToggle = () => {
            toggle.style.left = window.innerWidth <= 768 ? '18px' : (sidebar.classList.contains('collapsed') ? '68px' : '246px');
        };
        toggle.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('show');
                return;
            }
            const collapsed = sidebar.classList.toggle('collapsed');
            if (main) main.classList.toggle('sidebar-collapsed', collapsed);
            toggle.classList.toggle('collapsed', collapsed);
            positionToggle();
        });
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('show');
        });
        document.querySelectorAll('.student-sidebar .sidebar-link').forEach(link => link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('show');
            }
        }));
        window.addEventListener('resize', positionToggle);
        positionToggle();

        document.querySelectorAll('.student-sidebar .registration-form-link').forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const url = link.href;
                Swal.fire({
                    title: 'Preparing registration form',
                    text: 'Please wait a moment…',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: function() { Swal.showLoading(); }
                });
                window.setTimeout(function() { window.location.href = url; }, 900);
            });
        });
    });
</script>
