<?php
declare(strict_types=1);

/**
 * Central system configuration used by both SIS and LMS.
 * Admin controls these values; Registrar/Cashier/Student only read them.
 */
function ensure_system_settings_schema(mysqli $conn): void
{
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS system_settings (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        setting_key VARCHAR(80) NOT NULL,
        setting_value VARCHAR(255) NOT NULL,
        updated_by INT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_system_settings_key (setting_key),
        KEY idx_system_settings_updated_by (updated_by)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $defaults = [
        'school_year' => '2026-2027',
        'enrollment_fee' => '20000.00',
    ];
    foreach ($defaults as $key => $value) {
        $stmt = mysqli_prepare($conn, 'INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key)');
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'ss', $key, $value);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }
}

function system_setting(mysqli $conn, string $key, string $default = ''): string
{
    $stmt = mysqli_prepare($conn, 'SELECT setting_value FROM system_settings WHERE setting_key = ? LIMIT 1');
    if (!$stmt) return $default;
    mysqli_stmt_bind_param($stmt, 's', $key);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    return $row ? (string)$row['setting_value'] : $default;
}

function system_school_year(mysqli $conn): string
{
    ensure_system_settings_schema($conn);
    return system_setting($conn, 'school_year', '2026-2027');
}

function system_enrollment_fee(mysqli $conn): float
{
    ensure_system_settings_schema($conn);
    return max(0, (float)system_setting($conn, 'enrollment_fee', '20000.00'));
}

function update_system_setting(mysqli $conn, string $key, string $value, ?int $userId = null): bool
{
    $stmt = mysqli_prepare($conn, 'INSERT INTO system_settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP');
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, 'ssi', $key, $value, $userId);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}
