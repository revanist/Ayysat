<?php
require_once __DIR__ . '/cashier_auth.php';
require_cashier_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method Not Allowed');
}

require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/enrollment_setup.php';
ensure_enrollment_schema($conn);

$token = (string)($_POST['csrf_token'] ?? '');
if (!hash_equals((string)($_SESSION['cashier_csrf_token'] ?? ''), $token) || $token === '') {
    http_response_code(403);
    exit('Invalid CSRF token');
}

mysqli_query($conn, 'UPDATE admin_notifications SET cashier_is_read = 1 WHERE cashier_is_read = 0');
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true]);
