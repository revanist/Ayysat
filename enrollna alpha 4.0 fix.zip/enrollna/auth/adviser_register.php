<?php
require_once __DIR__ . '/../functions/teacher_auth.php';
start_teacher_session();
require_once '../db/dbconn.php';
require_once '../functions/teacher_setup.php';
ensure_teacher_schema($conn);

if (!empty($_SESSION['teacher_id'])) {
    header('Location: ../teacher/teacher_dashboard.php', true, 303);
    exit;
}
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adviser Registration | EYYSAT</title>
    <link rel="stylesheet" href="../css/bootstrap.css"><link rel="stylesheet" href="../css/auth.css">
    <script src="../js/sweetalert2.all.min.js"></script>
</head>
<body>
<div class="auth-page auth-page-register">
    <div class="auth-hero">
        <div class="hero-content">
            <span class="hero-badge">Faculty Access</span>
            <h2>Create your adviser account</h2>
            <p>Your adviser account is separate from student and administrator accounts while using the same EYYSAT portal experience.</p>
            <div class="hero-points"><span>Secure faculty access</span><span>Assigned sections</span><span>Responsive dashboard</span></div>
        </div>
    </div>
    <div class="portal-container reg-container">
        <div class="reg-header">
            <a href="../webhome.php"><img src="../img/eyysat.png" alt="EYYSAT Logo" class="portal-logo"></a>
            <h1>EYYSAT</h1><p>Adviser / Professor Registration</p>
        </div>
        <div class="portal-body">
            <form method="POST" action="../functions/adviser_registration.php">
                <div class="form-group"><label>Full Name</label><input type="text" name="fullname" placeholder="e.g. Prof. Juan Dela Cruz" required></div>
                <div class="form-group"><label>Email Address</label><input type="email" name="email" placeholder="professor@eyysat.edu" required></div>
                <div class="form-group"><label>Password</label><input type="password" name="password" placeholder="At least 8 characters" required></div>
                <div class="form-group"><label>Confirm Password</label><input type="password" name="confirm_password" placeholder="Re-enter password" required></div>
                <button class="btn" type="submit">Create Adviser Account</button>
            </form>
            <div class="link">Already have an adviser account? <a href="adviser_login.php">Login Here</a></div>
        </div>
    </div>
</div>
<script>
const errors={empty:'Please fill in all fields.',email:'Please enter a valid email address.',password:'Passwords do not match.',shortpassword:'Password must be at least 8 characters.',exists:'An adviser account with that email already exists.'};
const key=<?=json_encode($error)?>; if(key && errors[key]) Swal.fire({icon:'error',text:errors[key],confirmButtonText:'Try Again'});
</script>
</body></html>
