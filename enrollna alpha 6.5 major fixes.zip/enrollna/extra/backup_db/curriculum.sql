-- ============================================================
-- EYYSAT - COMPLETE SUBJECT DATA
-- FIXED VERSION
--
-- This version fixes:
-- #1060 - Duplicate column name '1'
--
-- It uses explicit aliases in the first SELECT of every
-- UNION ALL block.
--
-- Existing subjects with the same course_id + subject_code
-- will NOT be duplicated.
-- ============================================================

START TRANSACTION;


-- ============================================================
-- 1. BSIT
-- BACHELOR OF SCIENCE IN INFORMATION TECHNOLOGY
-- ============================================================

INSERT INTO subjects
(
    course_id,
    subject_code,
    subject_name,
    units,
    sem,
    year_level,
    section_id,
    schedule_day,
    schedule_time,
    room_number,
    is_available
)
SELECT
    c.id,
    x.code,
    x.name,
    x.units,
    x.sem,
    x.year_level,
    NULL,
    NULL,
    NULL,
    NULL,
    1
FROM courses c
JOIN
(
    SELECT
        'IT111' AS code,
        'Introduction to Information Technology' AS name,
        3 AS units,
        1 AS sem,
        1 AS year_level

    UNION ALL SELECT 'IT112','Computer Programming 1',3,1,1
    UNION ALL SELECT 'IT113','Fundamentals of Computing',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1

    UNION ALL SELECT 'IT121','Computer Programming 2',3,2,1
    UNION ALL SELECT 'IT122','Web Development 1',3,2,1
    UNION ALL SELECT 'IT123','Database Fundamentals',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1

    UNION ALL SELECT 'IT211','Data Structures and Algorithms',3,1,2
    UNION ALL SELECT 'IT212','Database Management Systems',3,1,2
    UNION ALL SELECT 'IT213','Object-Oriented Programming',3,1,2
    UNION ALL SELECT 'IT214','Computer Organization',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2

    UNION ALL SELECT 'IT221','Web Development 2',3,2,2
    UNION ALL SELECT 'IT222','Networking 1',3,2,2
    UNION ALL SELECT 'IT223','Systems Analysis and Design',3,2,2
    UNION ALL SELECT 'IT224','Human Computer Interaction',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2

    UNION ALL SELECT 'IT311','Networking 2',3,1,3
    UNION ALL SELECT 'IT312','Information Assurance and Security',3,1,3
    UNION ALL SELECT 'IT313','Systems Integration and Architecture',3,1,3
    UNION ALL SELECT 'IT314','IT Project Management',3,1,3
    UNION ALL SELECT 'IT315','Research Methods in IT',3,1,3
    UNION ALL SELECT 'IT316','IT Elective 1',3,1,3

    UNION ALL SELECT 'IT321','Mobile Application Development',3,2,3
    UNION ALL SELECT 'IT322','Cloud Computing',3,2,3
    UNION ALL SELECT 'IT323','Information Management',3,2,3
    UNION ALL SELECT 'IT324','IT Elective 2',3,2,3
    UNION ALL SELECT 'IT325','Enterprise Systems',3,2,3
    UNION ALL SELECT 'IT326','Professional Issues in IT',3,2,3

    UNION ALL SELECT 'IT411','Capstone Project 1',3,1,4
    UNION ALL SELECT 'IT412','Advanced Database Systems',3,1,4
    UNION ALL SELECT 'IT413','IT Elective 3',3,1,4
    UNION ALL SELECT 'IT414','Emerging Technologies',3,1,4
    UNION ALL SELECT 'IT415','IT Governance',3,1,4

    UNION ALL SELECT 'IT421','Capstone Project 2',3,2,4
    UNION ALL SELECT 'IT422','IT Elective 4',3,2,4
    UNION ALL SELECT 'IT423','Practicum / Internship',6,2,4

) x
WHERE c.course_code = 'BSIT'
AND NOT EXISTS
(
    SELECT 1
    FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 2. BSCS
-- BACHELOR OF SCIENCE IN COMPUTER SCIENCE
-- ============================================================

INSERT INTO subjects
(
    course_id,
    subject_code,
    subject_name,
    units,
    sem,
    year_level,
    section_id,
    schedule_day,
    schedule_time,
    room_number,
    is_available
)
SELECT
    c.id,
    x.code,
    x.name,
    x.units,
    x.sem,
    x.year_level,
    NULL,
    NULL,
    NULL,
    NULL,
    1
FROM courses c
JOIN
(
    SELECT
        'CS111' AS code,
        'Introduction to Computer Science' AS name,
        3 AS units,
        1 AS sem,
        1 AS year_level

    UNION ALL SELECT 'CS112','Programming Fundamentals',3,1,1
    UNION ALL SELECT 'CS113','Discrete Mathematics',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1

    UNION ALL SELECT 'CS121','Object-Oriented Programming',3,2,1
    UNION ALL SELECT 'CS122','Data Structures',3,2,1
    UNION ALL SELECT 'CS123','Computer Organization',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1

    UNION ALL SELECT 'CS211','Algorithms and Complexity',3,1,2
    UNION ALL SELECT 'CS212','Database Systems',3,1,2
    UNION ALL SELECT 'CS213','Computer Architecture',3,1,2
    UNION ALL SELECT 'CS214','Operating Systems',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2

    UNION ALL SELECT 'CS221','Software Engineering',3,2,2
    UNION ALL SELECT 'CS222','Theory of Computation',3,2,2
    UNION ALL SELECT 'CS223','Artificial Intelligence',3,2,2
    UNION ALL SELECT 'CS224','Computer Networks',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2

    UNION ALL SELECT 'CS311','Artificial Intelligence 2',3,1,3
    UNION ALL SELECT 'CS312','Machine Learning',3,1,3
    UNION ALL SELECT 'CS313','Web Technologies',3,1,3
    UNION ALL SELECT 'CS314','Information Security',3,1,3
    UNION ALL SELECT 'CS315','Research Methods',3,1,3
    UNION ALL SELECT 'CS316','CS Elective 1',3,1,3

    UNION ALL SELECT 'CS321','Data Mining',3,2,3
    UNION ALL SELECT 'CS322','Compiler Design',3,2,3
    UNION ALL SELECT 'CS323','Distributed Computing',3,2,3
    UNION ALL SELECT 'CS324','CS Elective 2',3,2,3
    UNION ALL SELECT 'CS325','Mobile Computing',3,2,3
    UNION ALL SELECT 'CS326','Software Project Management',3,2,3

    UNION ALL SELECT 'CS411','Thesis 1',3,1,4
    UNION ALL SELECT 'CS412','Advanced Algorithms',3,1,4
    UNION ALL SELECT 'CS413','CS Elective 3',3,1,4
    UNION ALL SELECT 'CS414','Emerging Computing Technologies',3,1,4
    UNION ALL SELECT 'CS415','Professional Practice',3,1,4

    UNION ALL SELECT 'CS421','Thesis 2',3,2,4
    UNION ALL SELECT 'CS422','CS Elective 4',3,2,4
    UNION ALL SELECT 'CS423','Practicum / Internship',6,2,4

) x
WHERE c.course_code = 'BSCS'
AND NOT EXISTS
(
    SELECT 1
    FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 3. BSIS
-- BACHELOR OF SCIENCE IN INFORMATION SYSTEMS
-- ============================================================

INSERT INTO subjects
(
    course_id,
    subject_code,
    subject_name,
    units,
    sem,
    year_level,
    section_id,
    schedule_day,
    schedule_time,
    room_number,
    is_available
)
SELECT
    c.id,
    x.code,
    x.name,
    x.units,
    x.sem,
    x.year_level,
    NULL,
    NULL,
    NULL,
    NULL,
    1
FROM courses c
JOIN
(
    SELECT
        'IS111' AS code,
        'Information Systems Fundamentals' AS name,
        3 AS units,
        1 AS sem,
        1 AS year_level

    UNION ALL SELECT 'IS112','Introduction to Programming',3,1,1
    UNION ALL SELECT 'IS113','Business Mathematics',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1

    UNION ALL SELECT 'IS121','Programming for Information Systems',3,2,1
    UNION ALL SELECT 'IS122','Database Management',3,2,1
    UNION ALL SELECT 'IS123','Business Process Management',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1

    UNION ALL SELECT 'IS211','Systems Analysis and Design',3,1,2
    UNION ALL SELECT 'IS212','Data Structures',3,1,2
    UNION ALL SELECT 'IS213','Enterprise Architecture',3,1,2
    UNION ALL SELECT 'IS214','IT Infrastructure',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2

    UNION ALL SELECT 'IS221','Web Information Systems',3,2,2
    UNION ALL SELECT 'IS222','Information Security',3,2,2
    UNION ALL SELECT 'IS223','Systems Integration',3,2,2
    UNION ALL SELECT 'IS224','IT Project Management',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2

    UNION ALL SELECT 'IS311','Business Intelligence',3,1,3
    UNION ALL SELECT 'IS312','Data Analytics',3,1,3
    UNION ALL SELECT 'IS313','Information Assurance',3,1,3
    UNION ALL SELECT 'IS314','Research Methods',3,1,3
    UNION ALL SELECT 'IS315','IS Project Management',3,1,3
    UNION ALL SELECT 'IS316','IS Elective 1',3,1,3

    UNION ALL SELECT 'IS321','Enterprise Systems',3,2,3
    UNION ALL SELECT 'IS322','Cloud Information Systems',3,2,3
    UNION ALL SELECT 'IS323','IT Governance',3,2,3
    UNION ALL SELECT 'IS324','IS Elective 2',3,2,3
    UNION ALL SELECT 'IS325','Digital Transformation',3,2,3
    UNION ALL SELECT 'IS326','Professional Practice',3,2,3

    UNION ALL SELECT 'IS411','Capstone Project 1',3,1,4
    UNION ALL SELECT 'IS412','Strategic Information Systems',3,1,4
    UNION ALL SELECT 'IS413','IS Elective 3',3,1,4
    UNION ALL SELECT 'IS414','Emerging Technologies',3,1,4
    UNION ALL SELECT 'IS415','Information Systems Audit',3,1,4

    UNION ALL SELECT 'IS421','Capstone Project 2',3,2,4
    UNION ALL SELECT 'IS422','IS Elective 4',3,2,4
    UNION ALL SELECT 'IS423','Practicum / Internship',6,2,4

) x
WHERE c.course_code = 'BSIS'
AND NOT EXISTS
(
    SELECT 1
    FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 4. BSBA
-- BACHELOR OF SCIENCE IN BUSINESS ADMINISTRATION
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'BA111' AS code,'Principles of Management' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'BA112','Business Organization',3,1,1
    UNION ALL SELECT 'BA113','Financial Accounting',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'BA121','Marketing Management',3,2,1
    UNION ALL SELECT 'BA122','Business Statistics',3,2,1
    UNION ALL SELECT 'BA123','Microeconomics',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'BA211','Human Resource Management',3,1,2
    UNION ALL SELECT 'BA212','Operations Management',3,1,2
    UNION ALL SELECT 'BA213','Business Finance',3,1,2
    UNION ALL SELECT 'BA214','Business Law',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'BA221','Entrepreneurship',3,2,2
    UNION ALL SELECT 'BA222','Consumer Behavior',3,2,2
    UNION ALL SELECT 'BA223','Management Information Systems',3,2,2
    UNION ALL SELECT 'BA224','Strategic Management',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'BA311','Business Research',3,1,3
    UNION ALL SELECT 'BA312','Investment Management',3,1,3
    UNION ALL SELECT 'BA313','International Business',3,1,3
    UNION ALL SELECT 'BA314','Organizational Behavior',3,1,3
    UNION ALL SELECT 'BA315','Business Analytics',3,1,3
    UNION ALL SELECT 'BA316','Business Elective 1',3,1,3
    UNION ALL SELECT 'BA321','Strategic Marketing',3,2,3
    UNION ALL SELECT 'BA322','Financial Management',3,2,3
    UNION ALL SELECT 'BA323','Supply Chain Management',3,2,3
    UNION ALL SELECT 'BA324','Business Elective 2',3,2,3
    UNION ALL SELECT 'BA325','Corporate Governance',3,2,3
    UNION ALL SELECT 'BA326','Professional Development',3,2,3
    UNION ALL SELECT 'BA411','Business Strategy',3,1,4
    UNION ALL SELECT 'BA412','Management Consulting',3,1,4
    UNION ALL SELECT 'BA413','Business Elective 3',3,1,4
    UNION ALL SELECT 'BA414','Research Project 1',3,1,4
    UNION ALL SELECT 'BA415','Business Ethics',3,1,4
    UNION ALL SELECT 'BA421','Research Project 2',3,2,4
    UNION ALL SELECT 'BA422','Business Elective 4',3,2,4
    UNION ALL SELECT 'BA423','Practicum / Internship',6,2,4
) x
WHERE c.course_code = 'BSBA'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 5. BSA
-- BACHELOR OF SCIENCE IN ACCOUNTANCY
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'AC111' AS code,'Fundamentals of Accounting' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'AC112','Accounting Principles',3,1,1
    UNION ALL SELECT 'AC113','Business Mathematics',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'AC121','Financial Accounting',3,2,1
    UNION ALL SELECT 'AC122','Managerial Accounting',3,2,1
    UNION ALL SELECT 'AC123','Business Law',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'AC211','Intermediate Accounting 1',3,1,2
    UNION ALL SELECT 'AC212','Cost Accounting',3,1,2
    UNION ALL SELECT 'AC213','Taxation',3,1,2
    UNION ALL SELECT 'AC214','Accounting Information Systems',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'AC221','Intermediate Accounting 2',3,2,2
    UNION ALL SELECT 'AC222','Auditing Principles',3,2,2
    UNION ALL SELECT 'AC223','Advanced Accounting',3,2,2
    UNION ALL SELECT 'AC224','Financial Management',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'AC311','Intermediate Accounting 3',3,1,3
    UNION ALL SELECT 'AC312','Auditing Theory',3,1,3
    UNION ALL SELECT 'AC313','Government Accounting',3,1,3
    UNION ALL SELECT 'AC314','Accounting Research',3,1,3
    UNION ALL SELECT 'AC315','Financial Reporting',3,1,3
    UNION ALL SELECT 'AC316','Accounting Elective 1',3,1,3
    UNION ALL SELECT 'AC321','Advanced Auditing',3,2,3
    UNION ALL SELECT 'AC322','Strategic Cost Management',3,2,3
    UNION ALL SELECT 'AC323','Corporate Accounting',3,2,3
    UNION ALL SELECT 'AC324','Accounting Elective 2',3,2,3
    UNION ALL SELECT 'AC325','Professional Accounting Practice',3,2,3
    UNION ALL SELECT 'AC326','Accounting Ethics',3,2,3
    UNION ALL SELECT 'AC411','Advanced Financial Accounting',3,1,4
    UNION ALL SELECT 'AC412','Advanced Taxation',3,1,4
    UNION ALL SELECT 'AC413','Accounting Elective 3',3,1,4
    UNION ALL SELECT 'AC414','Auditing Applications',3,1,4
    UNION ALL SELECT 'AC415','Accounting Research Project',3,1,4
    UNION ALL SELECT 'AC421','Accounting Practicum',6,2,4
    UNION ALL SELECT 'AC422','Accounting Elective 4',3,2,4
    UNION ALL SELECT 'AC423','Professional Practice',3,2,4
) x
WHERE c.course_code = 'BSA'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 6. BSHM
-- BACHELOR OF SCIENCE IN HOSPITALITY MANAGEMENT
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'HM111' AS code,'Introduction to Hospitality Management' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'HM112','Food and Beverage Service',3,1,1
    UNION ALL SELECT 'HM113','Kitchen Fundamentals',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'HM121','Housekeeping Operations',3,2,1
    UNION ALL SELECT 'HM122','Front Office Operations',3,2,1
    UNION ALL SELECT 'HM123','Hospitality Accounting',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'HM211','Culinary Arts',3,1,2
    UNION ALL SELECT 'HM212','Beverage Management',3,1,2
    UNION ALL SELECT 'HM213','Hotel Operations',3,1,2
    UNION ALL SELECT 'HM214','Hospitality Marketing',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'HM221','Event Management',3,2,2
    UNION ALL SELECT 'HM222','Resort Management',3,2,2
    UNION ALL SELECT 'HM223','Hospitality Technology',3,2,2
    UNION ALL SELECT 'HM224','Food Safety and Sanitation',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'HM311','Hospitality Research',3,1,3
    UNION ALL SELECT 'HM312','Restaurant Management',3,1,3
    UNION ALL SELECT 'HM313','Rooms Division Management',3,1,3
    UNION ALL SELECT 'HM314','Hospitality Entrepreneurship',3,1,3
    UNION ALL SELECT 'HM315','Revenue Management',3,1,3
    UNION ALL SELECT 'HM316','HM Elective 1',3,1,3
    UNION ALL SELECT 'HM321','International Hospitality',3,2,3
    UNION ALL SELECT 'HM322','Quality Management in Hospitality',3,2,3
    UNION ALL SELECT 'HM323','Sustainable Hospitality',3,2,3
    UNION ALL SELECT 'HM324','HM Elective 2',3,2,3
    UNION ALL SELECT 'HM325','Hospitality Leadership',3,2,3
    UNION ALL SELECT 'HM326','Professional Development',3,2,3
    UNION ALL SELECT 'HM411','Hospitality Strategic Management',3,1,4
    UNION ALL SELECT 'HM412','Hospitality Research Project',3,1,4
    UNION ALL SELECT 'HM413','HM Elective 3',3,1,4
    UNION ALL SELECT 'HM414','Advanced Culinary Management',3,1,4
    UNION ALL SELECT 'HM415','Hospitality Law',3,1,4
    UNION ALL SELECT 'HM421','HM Elective 4',3,2,4
    UNION ALL SELECT 'HM422','Hospitality Practicum',6,2,4
    UNION ALL SELECT 'HM423','Professional Practice',3,2,4
) x
WHERE c.course_code = 'BSHM'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 7. BSTM
-- BACHELOR OF SCIENCE IN TOURISM MANAGEMENT
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'TM111' AS code,'Introduction to Tourism' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'TM112','Tourism Industry',3,1,1
    UNION ALL SELECT 'TM113','Travel Geography',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'TM121','Tour Operations',3,2,1
    UNION ALL SELECT 'TM122','Travel Agency Management',3,2,1
    UNION ALL SELECT 'TM123','Tourism Marketing',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'TM211','Destination Management',3,1,2
    UNION ALL SELECT 'TM212','Tourism Planning',3,1,2
    UNION ALL SELECT 'TM213','Tourism Economics',3,1,2
    UNION ALL SELECT 'TM214','Transportation Management',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'TM221','Event Tourism',3,2,2
    UNION ALL SELECT 'TM222','Cultural Heritage Tourism',3,2,2
    UNION ALL SELECT 'TM223','Sustainable Tourism',3,2,2
    UNION ALL SELECT 'TM224','Tourism Technology',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'TM311','Tourism Research',3,1,3
    UNION ALL SELECT 'TM312','Ecotourism',3,1,3
    UNION ALL SELECT 'TM313','Hospitality and Tourism Management',3,1,3
    UNION ALL SELECT 'TM314','Tourism Entrepreneurship',3,1,3
    UNION ALL SELECT 'TM315','Tourism Policy and Planning',3,1,3
    UNION ALL SELECT 'TM316','Tourism Elective 1',3,1,3
    UNION ALL SELECT 'TM321','International Tourism',3,2,3
    UNION ALL SELECT 'TM322','Cruise Tourism',3,2,3
    UNION ALL SELECT 'TM323','Adventure Tourism',3,2,3
    UNION ALL SELECT 'TM324','Tourism Elective 2',3,2,3
    UNION ALL SELECT 'TM325','Tourism Event Management',3,2,3
    UNION ALL SELECT 'TM326','Professional Development',3,2,3
    UNION ALL SELECT 'TM411','Tourism Strategic Management',3,1,4
    UNION ALL SELECT 'TM412','Tourism Research Project',3,1,4
    UNION ALL SELECT 'TM413','Tourism Elective 3',3,1,4
    UNION ALL SELECT 'TM414','Destination Marketing',3,1,4
    UNION ALL SELECT 'TM415','Tourism Law',3,1,4
    UNION ALL SELECT 'TM421','Tourism Elective 4',3,2,4
    UNION ALL SELECT 'TM422','Tourism Practicum',6,2,4
    UNION ALL SELECT 'TM423','Professional Practice',3,2,4
) x
WHERE c.course_code = 'BSTM'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 8. BSCRIM
-- BACHELOR OF SCIENCE IN CRIMINOLOGY
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'CR111' AS code,'Introduction to Criminology' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'CR112','Criminal Law',3,1,1
    UNION ALL SELECT 'CR113','Philippine Criminal Justice System',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'CR121','Criminal Investigation',3,2,1
    UNION ALL SELECT 'CR122','Forensic Science',3,2,1
    UNION ALL SELECT 'CR123','Police Organization',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'CR211','Criminal Procedure',3,1,2
    UNION ALL SELECT 'CR212','Correctional Administration',3,1,2
    UNION ALL SELECT 'CR213','Criminal Sociology',3,1,2
    UNION ALL SELECT 'CR214','Juvenile Delinquency',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'CR221','Crime Detection',3,2,2
    UNION ALL SELECT 'CR222','Criminal Psychology',3,2,2
    UNION ALL SELECT 'CR223','Victimology',3,2,2
    UNION ALL SELECT 'CR224','Community-Based Corrections',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'CR311','Criminalistics',3,1,3
    UNION ALL SELECT 'CR312','Questioned Documents',3,1,3
    UNION ALL SELECT 'CR313','Forensic Photography',3,1,3
    UNION ALL SELECT 'CR314','Criminological Research',3,1,3
    UNION ALL SELECT 'CR315','Crime Prevention',3,1,3
    UNION ALL SELECT 'CR316','Criminology Elective 1',3,1,3
    UNION ALL SELECT 'CR321','Advanced Criminal Investigation',3,2,3
    UNION ALL SELECT 'CR322','Cybercrime Investigation',3,2,3
    UNION ALL SELECT 'CR323','Organized Crime',3,2,3
    UNION ALL SELECT 'CR324','Criminology Elective 2',3,2,3
    UNION ALL SELECT 'CR325','Security Management',3,2,3
    UNION ALL SELECT 'CR326','Professional Practice',3,2,3
    UNION ALL SELECT 'CR411','Criminological Research Project 1',3,1,4
    UNION ALL SELECT 'CR412','Advanced Forensic Science',3,1,4
    UNION ALL SELECT 'CR413','Criminology Elective 3',3,1,4
    UNION ALL SELECT 'CR414','Criminal Justice Administration',3,1,4
    UNION ALL SELECT 'CR415','Professional Ethics',3,1,4
    UNION ALL SELECT 'CR421','Criminological Research Project 2',3,2,4
    UNION ALL SELECT 'CR422','Criminology Elective 4',3,2,4
    UNION ALL SELECT 'CR423','Criminology Practicum',6,2,4
) x
WHERE c.course_code = 'BSCRIM'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 9. BSN
-- BACHELOR OF SCIENCE IN NURSING
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'NURS111' AS code,'Fundamentals of Nursing' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'NURS112','Health Assessment',3,1,1
    UNION ALL SELECT 'NURS113','Anatomy and Physiology',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'NURS121','Community Health Nursing',3,2,1
    UNION ALL SELECT 'NURS122','Nutrition and Diet Therapy',3,2,1
    UNION ALL SELECT 'NURS123','Pharmacology',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'NURS211','Medical Surgical Nursing 1',3,1,2
    UNION ALL SELECT 'NURS212','Maternal and Child Nursing',3,1,2
    UNION ALL SELECT 'NURS213','Pathophysiology',3,1,2
    UNION ALL SELECT 'NURS214','Nursing Informatics',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'NURS221','Medical Surgical Nursing 2',3,2,2
    UNION ALL SELECT 'NURS222','Mental Health Nursing',3,2,2
    UNION ALL SELECT 'NURS223','Pediatric Nursing',3,2,2
    UNION ALL SELECT 'NURS224','Nursing Research',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'NURS311','Medical Surgical Nursing 3',3,1,3
    UNION ALL SELECT 'NURS312','Critical Care Nursing',3,1,3
    UNION ALL SELECT 'NURS313','Community Health Nursing 2',3,1,3
    UNION ALL SELECT 'NURS314','Nursing Leadership',3,1,3
    UNION ALL SELECT 'NURS315','Nursing Research 2',3,1,3
    UNION ALL SELECT 'NURS316','Nursing Elective 1',3,1,3
    UNION ALL SELECT 'NURS321','Emergency Nursing',3,2,3
    UNION ALL SELECT 'NURS322','Gerontological Nursing',3,2,3
    UNION ALL SELECT 'NURS323','Oncology Nursing',3,2,3
    UNION ALL SELECT 'NURS324','Nursing Elective 2',3,2,3
    UNION ALL SELECT 'NURS325','Nursing Management',3,2,3
    UNION ALL SELECT 'NURS326','Professional Nursing Practice',3,2,3
    UNION ALL SELECT 'NURS411','Advanced Nursing Practice',3,1,4
    UNION ALL SELECT 'NURS412','Nursing Research Project',3,1,4
    UNION ALL SELECT 'NURS413','Nursing Elective 3',3,1,4
    UNION ALL SELECT 'NURS414','Health Policy and Administration',3,1,4
    UNION ALL SELECT 'NURS415','Professional Nursing Ethics',3,1,4
    UNION ALL SELECT 'NURS421','Nursing Elective 4',3,2,4
    UNION ALL SELECT 'NURS422','Clinical Practicum',6,2,4
    UNION ALL SELECT 'NURS423','Professional Practice',3,2,4
) x
WHERE c.course_code = 'BSN'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- 10. BSCE
-- BACHELOR OF SCIENCE IN CIVIL ENGINEERING
-- ============================================================

INSERT INTO subjects
(
    course_id, subject_code, subject_name, units, sem, year_level,
    section_id, schedule_day, schedule_time, room_number, is_available
)
SELECT
    c.id, x.code, x.name, x.units, x.sem, x.year_level,
    NULL, NULL, NULL, NULL, 1
FROM courses c
JOIN
(
    SELECT 'CE111' AS code,'Engineering Mathematics 1' AS name,3 AS units,1 AS sem,1 AS year_level
    UNION ALL SELECT 'CE112','Engineering Drawing',3,1,1
    UNION ALL SELECT 'CE113','Engineering Mechanics',3,1,1
    UNION ALL SELECT 'GE111','Purposive Communication',3,1,1
    UNION ALL SELECT 'GE112','Mathematics in the Modern World',3,1,1
    UNION ALL SELECT 'PE111','Physical Education 1',2,1,1
    UNION ALL SELECT 'CE121','Engineering Mathematics 2',3,2,1
    UNION ALL SELECT 'CE122','Computer Aided Design',3,2,1
    UNION ALL SELECT 'CE123','Surveying',3,2,1
    UNION ALL SELECT 'GE113','Understanding the Self',3,2,1
    UNION ALL SELECT 'GE114','Readings in Philippine History',3,2,1
    UNION ALL SELECT 'PE112','Physical Education 2',2,2,1
    UNION ALL SELECT 'CE211','Structural Theory 1',3,1,2
    UNION ALL SELECT 'CE212','Construction Materials',3,1,2
    UNION ALL SELECT 'CE213','Fluid Mechanics',3,1,2
    UNION ALL SELECT 'CE214','Engineering Statistics',3,1,2
    UNION ALL SELECT 'GE211','Ethics',3,1,2
    UNION ALL SELECT 'PE211','Physical Education 3',2,1,2
    UNION ALL SELECT 'CE221','Structural Theory 2',3,2,2
    UNION ALL SELECT 'CE222','Soil Mechanics',3,2,2
    UNION ALL SELECT 'CE223','Hydraulics',3,2,2
    UNION ALL SELECT 'CE224','Highway Engineering',3,2,2
    UNION ALL SELECT 'GE212','Science, Technology and Society',3,2,2
    UNION ALL SELECT 'PE212','Physical Education 4',2,2,2
    UNION ALL SELECT 'CE311','Reinforced Concrete Design',3,1,3
    UNION ALL SELECT 'CE312','Steel Design',3,1,3
    UNION ALL SELECT 'CE313','Foundation Engineering',3,1,3
    UNION ALL SELECT 'CE314','Construction Management',3,1,3
    UNION ALL SELECT 'CE315','Engineering Research',3,1,3
    UNION ALL SELECT 'CE316','Civil Engineering Elective 1',3,1,3
    UNION ALL SELECT 'CE321','Transportation Engineering',3,2,3
    UNION ALL SELECT 'CE322','Water Resources Engineering',3,2,3
    UNION ALL SELECT 'CE323','Environmental Engineering',3,2,3
    UNION ALL SELECT 'CE324','Civil Engineering Elective 2',3,2,3
    UNION ALL SELECT 'CE325','Project Management',3,2,3
    UNION ALL SELECT 'CE326','Professional Practice',3,2,3
    UNION ALL SELECT 'CE411','Advanced Structural Design',3,1,4
    UNION ALL SELECT 'CE412','Advanced Foundation Engineering',3,1,4
    UNION ALL SELECT 'CE413','Civil Engineering Elective 3',3,1,4
    UNION ALL SELECT 'CE414','Engineering Economics',3,1,4
    UNION ALL SELECT 'CE415','Civil Engineering Research',3,1,4
    UNION ALL SELECT 'CE421','Civil Engineering Elective 4',3,2,4
    UNION ALL SELECT 'CE422','Civil Engineering Practicum',6,2,4
    UNION ALL SELECT 'CE423','Professional Practice',3,2,4
) x
WHERE c.course_code = 'BSCE'
AND NOT EXISTS (
    SELECT 1 FROM subjects s
    WHERE s.course_id = c.id
    AND s.subject_code = x.code
);


-- ============================================================
-- FINISH
-- ============================================================

COMMIT;


-- ============================================================
-- VERIFY THE RESULT
-- ============================================================

SELECT
    c.course_code,
    c.course_name,
    COUNT(s.id) AS subject_count
FROM courses c
LEFT JOIN subjects s
    ON s.course_id = c.id
GROUP BY
    c.id,
    c.course_code,
    c.course_name
ORDER BY c.course_code;


-- Show BSIT subjects specifically
SELECT
    c.course_code,
    s.subject_code,
    s.subject_name,
    s.units,
    s.sem,
    s.year_level
FROM subjects s
JOIN courses c
    ON c.id = s.course_id
WHERE c.course_code = 'BSIT'
ORDER BY
    s.year_level,
    s.sem,
    s.subject_code;