<?php
declare(strict_types=1);
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/system_settings.php';

ensure_system_settings_schema($conn);
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_admin_csrf();
    $schoolYear = trim((string)($_POST['school_year'] ?? ''));
    $feeRaw = trim((string)($_POST['enrollment_fee'] ?? ''));
    $fee = is_numeric($feeRaw) ? (float)$feeRaw : -1;

    if (!preg_match('/^\d{4}-\d{4}$/', $schoolYear)) {
        $error = 'School year must use the format YYYY-YYYY.';
    } elseif ($fee < 0 || $fee > 1000000) {
        $error = 'Enrollment fee must be between ₱0 and ₱1,000,000.';
    } else {
        mysqli_begin_transaction($conn);
        try {
            $uid = (int)$_SESSION['user_id'];
            if (!update_system_setting($conn, 'school_year', $schoolYear, $uid) || !update_system_setting($conn, 'enrollment_fee', number_format($fee, 2, '.', ''), $uid)) {
                throw new RuntimeException('Unable to save system settings.');
            }
            mysqli_commit($conn);
            $message = 'System settings saved. New academic and payment settings will be used by new transactions.';
        } catch (Throwable $e) {
            mysqli_rollback($conn);
            $error = 'Settings were not saved. Please try again.';
        }
    }
}

$schoolYear = system_school_year($conn);
$fee = system_enrollment_fee($conn);
$csrf = admin_csrf_token();
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>System Settings | EYYSAT Admin</title>
<link rel="stylesheet" href="../css/admin_dashboard.css"><link rel="stylesheet" href="../css/ux-polish.css">
<style>
.settings-wrap{max-width:1100px;margin:0 auto}.settings-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;margin-top:20px}.settings-card{background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:24px}.settings-card h2{margin-top:0}.settings-card p{color:#aab3c2}.field{margin:18px 0}.field label{display:block;font-weight:700;margin-bottom:7px;color:#e5e7eb}.field input{width:100%;box-sizing:border-box;padding:12px 13px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:#0c2037;color:#fff}.save-btn{border:0;border-radius:10px;padding:12px 18px;background:#d8ff61;color:#101010;font-weight:800;cursor:pointer}.notice{padding:13px 15px;border-radius:10px;margin-top:18px}.success{background:rgba(34,197,94,.12);color:#86efac}.error{background:rgba(239,68,68,.12);color:#fca5a5}.role-list{display:grid;gap:10px}.role-item{padding:12px;border:1px solid rgba(255,255,255,.08);border-radius:11px}.role-item strong{display:block}.role-item span{font-size:.82rem;color:#aab3c2}@media(max-width:800px){.settings-grid{grid-template-columns:1fr}}
</style></head><body>
<?php include __DIR__ . '/../sidebar/sidebar.php'; ?>
<main class="dashboard-main"><div class="settings-wrap">
<section class="hero"><div class="welcome"><span class="hero-badge">SYSTEM ADMINISTRATION</span><h1>System Settings</h1><p>These are system-wide settings. Academic work stays with the Registrar, payments stay with the Cashier, and teaching stays with Instructors.</p></div></section>
<?php if($message): ?><div class="notice success"><?=htmlspecialchars($message)?></div><?php endif; ?>
<?php if($error): ?><div class="notice error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<div class="settings-grid">
<section class="settings-card"><h2>Core Configuration</h2><p>Change these values once instead of editing PHP files whenever a new school year starts.</p>
<form method="post"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($csrf)?>">
<div class="field"><label for="school_year">Current School Year</label><input id="school_year" name="school_year" value="<?=htmlspecialchars($schoolYear)?>" pattern="\d{4}-\d{4}" required><small>Example: 2026-2027</small></div>
<div class="field"><label for="enrollment_fee">Default Enrollment Fee</label><input id="enrollment_fee" name="enrollment_fee" type="number" min="0" max="1000000" step="0.01" value="<?=htmlspecialchars(number_format($fee,2,'.',''))?>"><small>This is used when calculating remaining student balances.</small></div>
<button class="save-btn" type="submit">Save System Settings</button></form></section>
<section class="settings-card"><h2>Role Boundaries</h2><p>Use this as the quick reference for who should operate each part of the system.</p><div class="role-list">
<div class="role-item"><strong>Admin</strong><span>Accounts, roles, system configuration and technical administration.</span></div>
<div class="role-item"><strong>Registrar</strong><span>Admissions, students, enrollment, courses, curriculum, sections and instructor assignments.</span></div>
<div class="role-item"><strong>Cashier</strong><span>Payment verification, balances, transactions and receipts.</span></div>
<div class="role-item"><strong>Instructor</strong><span>Assigned classes, materials, activities, attendance and grades.</span></div>
<div class="role-item"><strong>Student</strong><span>Application, enrollment, payments, classes, activities, submissions and academic results.</span></div>
</div></section>
</div></div></main></body></html>
