<?php
require __DIR__.'/teacher_bootstrap.php';

$teacherId = (int)$teacherId;
$selectedAssignmentId = (int)($_GET['assignment_id'] ?? 0);

$q = mysqli_prepare($conn, "
    SELECT a.id AS assignment_id, a.section_id, a.school_year, a.semester,
           sec.section_name, c.course_code, c.course_name,
           sub.subject_code, sub.subject_name, sub.units,
           sub.year_level, sub.sem, sub.schedule_day, sub.schedule_time, sub.room_number
    FROM teaching_assignments a
    INNER JOIN subjects sub ON sub.id=a.subject_id
    INNER JOIN sections sec ON sec.id=a.section_id
    INNER JOIN courses c ON c.id=sec.course_id
    WHERE a.teacher_id=? AND a.school_year=? AND a.semester=? AND a.status='Active'
    ORDER BY c.course_code, sec.section_name, sub.year_level, sub.sem, sub.subject_code
");
mysqli_stmt_bind_param($q,'isi',$teacherId,$schoolYear,$semester);
mysqli_stmt_execute($q);
$assignments = mysqli_stmt_get_result($q);

$rows=[];
while($r=mysqli_fetch_assoc($assignments)) $rows[]=$r;

$selected = null;
if ($selectedAssignmentId > 0) {
    foreach($rows as $r) {
        if((int)$r['assignment_id'] === $selectedAssignmentId) {
            $selected=$r;
            break;
        }
    }
}

// Group assignments for a curriculum-style academic view.
$groups = [];
foreach ($rows as $r) {
    $groupKey = $r['course_code'].'|'.$r['section_name'];
    if (!isset($groups[$groupKey])) {
        $groups[$groupKey] = [
            'course_code' => $r['course_code'],
            'course_name' => $r['course_name'],
            'section_name' => $r['section_name'],
            'subjects' => []
        ];
    }
    $groups[$groupKey]['subjects'][] = $r;
}

$subjectCount = count($rows);
$totalUnits = 0;
foreach ($rows as $r) $totalUnits += (int)$r['units'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Curriculum | EYYSAT</title>
<link rel="stylesheet" href="../css/admin_dashboard.css?v=<?=time()?>">
<link rel="stylesheet" href="../css/teacher.css?v=<?=time()?>">
<style>
.teacher-curriculum-card.is-collapsed .teacher-curriculum-subjects {
    display: none;
}
.teacher-curriculum-card.is-collapsed .toggle-icon {
    transform: rotate(180deg);
}
.teacher-curriculum-search input::placeholder {
    color: #6c7785;
}
.teacher-curriculum-subject {
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 20px;
}
.teacher-curriculum-subject-header {
    display: flex;
    gap: 16px;
    align-items: flex-start;
}
.teacher-curriculum-subject-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 5px;
    padding-top: 15px;
    border-top: 1px solid rgba(255,255,255,0.08);
}
.teacher-curriculum-subject-actions .teacher-btn {
    text-decoration: none;
    font-size: 0.85rem;
    padding: 8px 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    border-radius: 8px;
}
.teacher-curriculum-subject-actions .teacher-btn i {
    font-size: 0.9rem;
}
</style>
</head>
<body>
<?php include __DIR__ . '/../sidebar/sidebar.php'; ?>

<main class="dashboard-main teacher-curriculum-page">
    <section class="teacher-curriculum-hero">
        <div class="teacher-curriculum-hero-copy">
            <span class="teacher-curriculum-kicker"><i class="fa-solid fa-book-open"></i> Academic Reference</span>
            <h1>Teaching Curriculum</h1>
            <p>View the subjects assigned to you for <strong>SY <?=htmlspecialchars($schoolYear)?></strong> · <strong><?=$semester===1?'1st':'2nd'?> Semester</strong>.</p>
        </div>
        <div class="teacher-curriculum-hero-icon"><i class="fa-solid fa-graduation-cap"></i></div>
    </section>

    <section class="teacher-curriculum-summary">
        <div class="teacher-curriculum-stat">
            <div class="teacher-curriculum-stat-icon"><i class="fa-solid fa-layer-group"></i></div>
            <div><span>Assigned Subjects</span><strong><?= $subjectCount ?></strong></div>
        </div>
        <div class="teacher-curriculum-stat">
            <div class="teacher-curriculum-stat-icon"><i class="fa-solid fa-calculator"></i></div>
            <div><span>Total Units</span><strong><?= $totalUnits ?></strong></div>
        </div>
        <div class="teacher-curriculum-stat">
            <div class="teacher-curriculum-stat-icon"><i class="fa-solid fa-users-rectangle"></i></div>
            <div><span>Sections</span><strong><?= count($groups) ?></strong></div>
        </div>
    </section>

    <div class="teacher-curriculum-search" style="margin-bottom: 20px;">
        <input type="text" id="curriculumSearch" placeholder="Search for subjects, courses, or rooms..." style="width: 100%; padding: 12px 18px; border-radius: 12px; border: 1px solid var(--teacher-border); background: var(--teacher-card); color: #fff; font-size: 0.95rem; outline: none; box-shadow: 0 4px 12px rgba(0,0,0,0.1); transition: border-color 0.2s;" onfocus="this.style.borderColor='var(--teacher-gold)'" onblur="this.style.borderColor='var(--teacher-border)'">
    </div>

    <?php if(!$rows): ?>
        <section class="teacher-curriculum-empty">
            <div class="teacher-curriculum-empty-icon"><i class="fa-solid fa-book-open"></i></div>
            <h2>No Assigned Subjects</h2>
            <p>You do not have any active teaching assignments for this semester.</p>
        </section>
    <?php else: ?>
        <?php foreach($groups as $group): ?>
            <section class="teacher-curriculum-card">
                <div class="teacher-curriculum-card-head" onclick="this.parentElement.classList.toggle('is-collapsed')" style="cursor: pointer; user-select: none;">
                    <div>
                        <span class="teacher-curriculum-course-code"><?=htmlspecialchars($group['course_code'])?></span>
                        <h2><?=htmlspecialchars($group['course_name'])?></h2>
                        <p><i class="fa-solid fa-users"></i> <?=htmlspecialchars($group['section_name'])?></p>
                    </div>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <span class="teacher-curriculum-count"><?=count($group['subjects'])?> subject<?=count($group['subjects'])===1?'':'s'?></span>
                        <i class="fa-solid fa-chevron-up toggle-icon" style="color: #687686; transition: transform 0.3s; font-size: 1.1rem;"></i>
                    </div>
                </div>

                <div class="teacher-curriculum-subjects">
                    <?php foreach($group['subjects'] as $r):
                        $year = (int)$r['year_level'];
                        $sem = (int)$r['sem'];
                        $yearLabel = $year > 0 ? ($year===1?'1st':($year===2?'2nd':($year===3?'3rd':$year.'th'))) . ' Year' : 'Year not set';
                        $semLabel = $sem===1 ? '1st Semester' : ($sem===2 ? '2nd Semester' : 'Semester not set');
                        $schedule = trim(($r['schedule_day']??'').' '.($r['schedule_time']??''));
                        $schedule = $schedule !== '' ? $schedule : 'Schedule TBA';
                        $room = trim((string)($r['room_number'] ?? '')) ?: 'Room TBA';
                    ?>
                    <article class="teacher-curriculum-subject <?= $selectedAssignmentId === (int)$r['assignment_id'] ? 'is-selected' : '' ?>">
                        <div class="teacher-curriculum-subject-header">
                            <div class="teacher-curriculum-subject-code"><?=htmlspecialchars($r['subject_code'])?></div>
                            <div class="teacher-curriculum-subject-main">
                                <h3 style="margin-bottom: 8px; font-size: 1.15rem; color: #fff;"><?=htmlspecialchars($r['subject_name'])?></h3>
                                <div class="teacher-curriculum-meta" style="flex-wrap: wrap; gap: 12px; margin-bottom: 0;">
                                    <span><i class="fa-regular fa-calendar"></i> <?=htmlspecialchars($yearLabel)?></span>
                                    <span><i class="fa-solid fa-clock"></i> <?=htmlspecialchars($semLabel)?></span>
                                    <span><i class="fa-solid fa-coins"></i> <?=intval($r['units'])?> units</span>
                                    <span><i class="fa-regular fa-calendar-days"></i> <?=htmlspecialchars($schedule)?></span>
                                    <span><i class="fa-solid fa-location-dot"></i> <?=htmlspecialchars($room)?></span>
                                </div>
                            </div>
                        </div>
                        <div class="teacher-curriculum-subject-actions">
                            <a class="teacher-btn primary" href="class.php?assignment_id=<?=intval($r['assignment_id'])?>"><i class="fa-solid fa-chalkboard"></i> Class Overview</a>
                            <a class="teacher-btn" href="activities.php?assignment_id=<?=intval($r['assignment_id'])?>"><i class="fa-solid fa-list-check"></i> Manage Curriculum</a>
                            <a class="teacher-btn" href="class.php?assignment_id=<?=intval($r['assignment_id'])?>#materials"><i class="fa-solid fa-file-powerpoint"></i> PPTs & Materials</a>
                            <a class="teacher-btn" href="grades.php?assignment_id=<?=intval($r['assignment_id'])?>"><i class="fa-solid fa-clipboard-check"></i> Gradebook</a>
                            <a class="teacher-btn" href="class_students.php?assignment_id=<?=intval($r['assignment_id'])?>"><i class="fa-solid fa-users"></i> Student Roster</a>
                        </div>
                    </article>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>
</main>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const searchInput = document.getElementById("curriculumSearch");
    if(searchInput) {
        searchInput.addEventListener("input", function() {
            const query = this.value.toLowerCase().trim();
            const cards = document.querySelectorAll(".teacher-curriculum-card");
            
            cards.forEach(card => {
                let hasVisibleSubject = false;
                const subjects = card.querySelectorAll(".teacher-curriculum-subject");
                
                subjects.forEach(sub => {
                    const text = sub.innerText.toLowerCase();
                    if(text.includes(query)) {
                        sub.style.display = "";
                        hasVisibleSubject = true;
                    } else {
                        sub.style.display = "none";
                    }
                });
                
                const headText = card.querySelector(".teacher-curriculum-card-head").innerText.toLowerCase();
                if(!hasVisibleSubject && headText.includes(query)) {
                    subjects.forEach(sub => sub.style.display = "");
                    hasVisibleSubject = true;
                }
                
                if(hasVisibleSubject) {
                    card.style.display = "";
                    if(query !== "") {
                        card.classList.remove("is-collapsed");
                    }
                } else {
                    card.style.display = "none";
                }
            });
        });
    }
});
</script>
</body>
</html>
