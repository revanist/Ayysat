<?php
require_once __DIR__ . '/../functions/teacher_auth.php';
$teacherCurrentPage = basename($_SERVER['PHP_SELF']);
$teacherName = htmlspecialchars($_SESSION['teacher_name'] ?? 'Adviser');

function teacher_sidebar_active(string $file, string $current): string
{
    return $current === $file ? ' active' : '';
}
?>
<aside class="admin-sidebar teacher-sidebar" id="teacherSidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo"><img src="../img/eyysat.png" alt="EYYSAT Logo"></div>
        <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>ADVISER PORTAL</span></div>
    </div>
    <nav class="sidebar-nav" aria-label="Adviser navigation">
        <p class="sidebar-label">FACULTY PORTAL</p>
        <a href="teacher_dashboard.php" class="sidebar-link<?= teacher_sidebar_active('teacher_dashboard.php', $teacherCurrentPage) ?>"><span class="sidebar-icon">&#127968;</span><span class="sidebar-text">Dashboard</span></a>
        <a href="sections.php" class="sidebar-link<?= teacher_sidebar_active('sections.php', $teacherCurrentPage) ?>"><span class="sidebar-icon">&#127891;</span><span class="sidebar-text">My Sections</span></a>
        <a href="announcements.php" class="sidebar-link<?= teacher_sidebar_active('announcements.php', $teacherCurrentPage) ?>"><span class="sidebar-icon">&#128276;</span><span class="sidebar-text">Announcements</span></a>
        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="../auth/logout.php" class="sidebar-link sidebar-logout"><span class="sidebar-icon">&#128682;</span><span class="sidebar-text">Logout</span></a>
    </nav>
    <div class="sidebar-profile">
        <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['teacher_name'] ?? 'A', 0, 1))) ?></div>
        <div class="profile-info"><strong><?= $teacherName ?></strong><span>Adviser / Professor</span></div>
    </div>
</aside>
<div class="sidebar-overlay" id="teacherSidebarOverlay"></div>
<button class="sidebar-toggle" id="teacherSidebarToggle" type="button" aria-label="Toggle sidebar"></button>
<script>
document.addEventListener('DOMContentLoaded', function(){
 const sidebar=document.getElementById('teacherSidebar'),toggle=document.getElementById('teacherSidebarToggle'),overlay=document.getElementById('teacherSidebarOverlay'),main=document.querySelector('.dashboard-main');
 if(!sidebar||!toggle||!overlay)return;
 function pos(){toggle.style.left=window.innerWidth<=768?'18px':(sidebar.classList.contains('collapsed')?'68px':'246px');}
 toggle.addEventListener('click',function(){if(window.innerWidth<=768){sidebar.classList.toggle('mobile-open');overlay.classList.toggle('show');return;}const c=sidebar.classList.toggle('collapsed');if(main)main.classList.toggle('sidebar-collapsed',c);toggle.classList.toggle('collapsed',c);pos();});
 overlay.addEventListener('click',()=>{sidebar.classList.remove('mobile-open');overlay.classList.remove('show');});
 document.querySelectorAll('.teacher-sidebar .sidebar-link').forEach(l=>l.addEventListener('click',()=>{if(window.innerWidth<=768){sidebar.classList.remove('mobile-open');overlay.classList.remove('show');}}));
 window.addEventListener('resize',pos);pos();
});
</script>
