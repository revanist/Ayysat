# EYYSAT Cleanup Notes

This build is the cleaned role-separated baseline.

## Removed dead code
- Removed obsolete `functions/verify_payment.php`.
- Removed old Admin academic/payment redirect stubs. Academic work is handled by Registrar; payment work is handled by Cashier.
- Removed obsolete student-side JavaScript calls to missing `create_payment_link.php` and `select_cash_payment.php`.
- Removed stale PayMongo payment UI references from the active student/Registrar screens.

## Payment flow
1. Registrar approves the enrollment.
2. Student sees the GCash payment form.
3. Student submits a payment request to `functions/request_payment.php`.
4. Cashier reviews the request in `cashier/index.php`.
5. Cashier confirms it through `functions/confirm_payment.php`.
6. Payment becomes `Partial` or `Paid` and the balance is updated.

The student UI and backend now enforce the same approval prerequisite.

## Student record synchronization
Registrar student edits update both `students` and the linked student `users` account (`full_name` and `email`). Duplicate email addresses are rejected.

## Validation
All PHP files were syntax-checked after cleanup. Full MySQL runtime behavior still requires testing inside XAMPP/MariaDB.
