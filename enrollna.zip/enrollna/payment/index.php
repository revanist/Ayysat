<?php
session_start();
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();

require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/student_data.php';

// Fetch the logged-in student's real data
$user_id = (int) $_SESSION['user_id'];
$student = get_student_profile($conn, $user_id);
if (!$student) {
    die("Student not found.");
}

$studentEmail = $student['email'] ?? '';
$studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$remainingBalance = (float) ($student['remaining_balance'] ?? 0);

$minPayment = min(2500, $remainingBalance);
$maxPayment = min(20000, $remainingBalance); 
if ($maxPayment < $minPayment) $maxPayment = $minPayment;

$paymentReference = 'PAY-' . time() . '-' . random_int(100, 999);

// --- CONFIGURATION ---
$mayaPublicKey = 'pk-Z0OSzLvIcOI2UIvDhdTGVVfRSSeiGStnceqwUE7n0Ah';
$gmail_username = '19rainier@gmail.com'; 
$gmail_app_password = 'jiuu rmqn nrmj hqpa'; 

$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
$errorMessage = '';

function send_smtp_email($to, $subject, $message, $smtp_user, $smtp_pass)
{
    $host = 'ssl://smtp.gmail.com';
    $port = 465;
    $socket = @fsockopen($host, $port, $errno, $errstr, 15);
    if (!$socket) return false;

    fread($socket, 515);
    fwrite($socket, "EHLO localhost\r\n"); fread($socket, 515);
    fwrite($socket, "AUTH LOGIN\r\n"); fread($socket, 515);
    fwrite($socket, base64_encode($smtp_user) . "\r\n"); fread($socket, 515);
    fwrite($socket, base64_encode($smtp_pass) . "\r\n");
    $auth_res = fread($socket, 515);

    if (strpos($auth_res, '235') === false) { 
        fclose($socket);
        return false;
    }

    fwrite($socket, "MAIL FROM: <$smtp_user>\r\n"); fread($socket, 515);
    fwrite($socket, "RCPT TO: <$to>\r\n"); fread($socket, 515);
    fwrite($socket, "DATA\r\n"); fread($socket, 515);

    $headers = "From: EYYSAT Payment <$smtp_user>\r\n";
    $headers .= "To: $to\r\n";
    $headers .= "Subject: $subject\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    fwrite($socket, $headers . "\r\n" . $message . "\r\n.\r\n"); fread($socket, 515);
    fwrite($socket, "QUIT\r\n");
    fclose($socket);
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'process_pay') {
    $paymentAmount = (float) ($_POST['payment_amount'] ?? 0);
    
    if ($paymentAmount < $minPayment || $paymentAmount > $maxPayment) {
        $errorMessage = "Invalid amount. Must be between ₱" . number_format($minPayment, 2) . " and ₱" . number_format($maxPayment, 2);
    } else {
        $email = $studentEmail;
        
        $enrollmentStmt = mysqli_prepare($conn, "SELECT id FROM enrollments WHERE student_id = ? ORDER BY id DESC LIMIT 1");
        mysqli_stmt_bind_param($enrollmentStmt, 'i', $student['id']);
        mysqli_stmt_execute($enrollmentStmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($enrollmentStmt));
        $enrollmentId = $row['id'] ?? 0;
        mysqli_stmt_close($enrollmentStmt);

        // 1. Record the pending payment attempt
        if ($enrollmentId) {
            $insertPayment = mysqli_prepare($conn, "
                INSERT INTO payments (enrollment_id, student_id, amount, payment_method, reference_number, status, created_at) 
                VALUES (?, ?, ?, 'Maya', ?, 'Pending', NOW())
            ");
            mysqli_stmt_bind_param($insertPayment, "iids", $enrollmentId, $student['id'], $paymentAmount, $paymentReference);
            mysqli_stmt_execute($insertPayment);
            mysqli_stmt_close($insertPayment);
        }

        $url = 'https://pg-sandbox.paymaya.com/checkout/v1/checkouts';
        $payload = [
            'totalAmount' => ['value' => number_format($paymentAmount, 2, '.', ''), 'currency' => 'PHP', 'details' => ['discount' => '0.00', 'serviceCharge' => '0.00', 'shippingFee' => '0.00', 'tax' => '0.00', 'subtotal' => number_format($paymentAmount, 2, '.', '')]],
            'buyer' => ['firstName' => $student['first_name'], 'lastName' => $student['last_name'], 'contact' => ['phone' => '+639123456789', 'email' => $email]],
            'items' => [
                ['name' => 'Enrollment Fee Deposit', 'quantity' => '1', 'code' => 'ENROLL-FEE', 'description' => 'Tuition Payment',
                 'amount' => ['value' => number_format($paymentAmount, 2, '.', ''), 'details' => ['discount' => '0.00', 'serviceCharge' => '0.00', 'shippingFee' => '0.00', 'tax' => '0.00', 'subtotal' => number_format($paymentAmount, 2, '.', '')]],
                 'totalAmount' => ['value' => number_format($paymentAmount, 2, '.', ''), 'details' => ['discount' => '0.00', 'serviceCharge' => '0.00', 'shippingFee' => '0.00', 'tax' => '0.00', 'subtotal' => number_format($paymentAmount, 2, '.', '')]]]
            ],
            'redirectUrl' => [
                'success' => $baseUrl . '/success.php?ref=' . $paymentReference . '&method=maya',
                'failure' => $baseUrl . '/cancel.php?status=failure',
                'cancel'  => $baseUrl . '/cancel.php?status=cancelled'
            ],
            'requestReferenceNumber' => $paymentReference
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Basic ' . base64_encode($mayaPublicKey . ':')]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (curl_error($ch)) {
            $errorMessage = "cURL Error: " . curl_error($ch);
        } else {
            $data = json_decode($response, true);
            if ($httpCode === 200 && isset($data['redirectUrl'])) {
                header('Location: ' . $data['redirectUrl']);
                exit;
            } else {
                $errorMessage = "Maya API Error ($httpCode): " . $response;
            }
        }
        curl_close($ch);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maya Secure Checkout</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f4f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; overflow: hidden; }
        .card { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); max-width: 450px; width: 100%; text-align: center; position: relative; z-index: 10; }
        .btn { border: none; padding: 14px 24px; font-size: 16px; font-weight: bold; border-radius: 8px; cursor: pointer; width: 100%; transition: 0.2s; display: block; margin-bottom: 12px; box-sizing: border-box; }
        .btn-maya { background: #000; color: #fff; }
        .btn-maya:hover { background: #333; }
        .error { background: #fee2e2; color: #b91c1c; padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; text-align: left; word-break: break-all; }
        .input-group { text-align: left; margin-bottom: 20px; }
        .input-group label { display: block; margin-bottom: 6px; font-weight: 600; color: #374151; font-size: 14px; }
        .input-group input { width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; box-sizing: border-box; font-size: 20px; outline: none; transition: 0.2s; background: #fff; font-weight: bold;}
        .input-group input:focus { border-color: #000; box-shadow: 0 0 0 2px rgba(0, 0, 0, 0.1); }
        .currency-symbol { position: absolute; padding: 12px 15px; font-size: 20px; color: #6b7280; pointer-events: none;}
        .amount-wrap { position: relative; }
        .amount-wrap input { padding-left: 45px; }
        h2 { margin-top: 0; color: #111827; }
        p { color: #4b5563; margin-bottom: 24px; font-size: 15px; }
        .helper-text { font-size: 13px; color: #6b7280; margin-top: 8px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Maya Payment Setup</h2>
        <p>Your remaining balance is <strong>₱<?= number_format($remainingBalance, 2) ?></strong>.</p>

        <?php if (!empty($errorMessage)): ?>
            <div class="error"><strong>Error:</strong><br><?= htmlspecialchars($errorMessage) ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="action" value="process_pay">
            <div class="input-group">
                <label for="paymentAmount">Amount to Pay</label>
                <div class="amount-wrap">
                    <span class="currency-symbol">₱</span>
                    <input type="number" id="paymentAmount" name="payment_amount" min="<?= $minPayment ?>" max="<?= $maxPayment ?>" step="0.01" value="<?= $maxPayment ?>" required>
                </div>
                <div class="helper-text">Min: ₱<?= number_format($minPayment, 2) ?> — Max: ₱<?= number_format($maxPayment, 2) ?></div>
            </div>

            <button type="submit" class="btn btn-maya">Proceed to Maya Checkout</button>
            <a href="../student/profile.php" style="display:block; margin-top:15px; color:#6b7280; text-decoration:none; font-size:14px;">Cancel and go back</a>
        </form>
    </div>
</body>
</html>