<?php
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();

require_once '../db/dbconn.php';
require_once '../functions/student_data.php';
require_once '../functions/teacher_setup.php';
ensure_teacher_schema($conn);

$userId = (int) $_SESSION['user_id'];
$student = get_student_profile($conn, $userId);

if (!$student) {
    http_response_code(404);
    exit('Student profile not found.');
}

$enrollment = get_student_latest_enrollment($conn, (int) $student['id']) ?: [];

$subjectCount = (int) (mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM enrollment_details ed
    INNER JOIN enrollments e ON e.id = ed.enrollment_id
    WHERE e.student_id = " . (int) $student['id'] . "
"))['total'] ?? 0);

$status = strtolower($enrollment['status'] ?? $student['enrollment_status'] ?? 'Not Submitted');
$paymentStatus = strtolower($enrollment['payment_status'] ?? $student['payment_status'] ?? 'Pending');
$statusLabel = $status === 'approved' && $paymentStatus === 'paid' ? 'Enrolled' : ucfirst($status);
$studentName = htmlspecialchars($_SESSION['fullname'] ?? trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? 'Student')));

$remainingBalance = (float) ($student['remaining_balance'] ?? 0);
$isFullyPaid = $remainingBalance <= 0 || $paymentStatus === 'paid';

$studentAnnouncements = [];
$studentSectionId = (int)($student['section_id'] ?? 0);
if ($studentSectionId > 0) {
    // College model: announcements belong to a specific teaching assignment
    // (subject + section), never to a section ownership/claim record.
    $announcementStmt = mysqli_prepare($conn, "
        SELECT a.title, a.body AS message, a.publish_at AS created_at,
               t.full_name AS teacher_name,
               CONCAT(sub.subject_code, ' · ', sec.section_name) AS audience
        FROM lms_announcements a
        INNER JOIN teaching_assignments ta ON ta.id = a.assignment_id
            AND ta.section_id = ?
            AND ta.school_year = ?
            AND ta.semester = ?
            AND ta.status = 'Active'
        INNER JOIN users t ON t.user_id = ta.teacher_id AND t.role_id = 2
        INNER JOIN subjects sub ON sub.id = ta.subject_id
        INNER JOIN sections sec ON sec.id = ta.section_id
        WHERE a.teacher_id = ta.teacher_id
        ORDER BY a.publish_at DESC
        LIMIT 8
    ");
    $studentSchoolYear = (string)($enrollment['school_year'] ?? '2026-2027');
    $studentSemester = (int)($enrollment['sem'] ?? 1);
    if ($announcementStmt) {
        mysqli_stmt_bind_param($announcementStmt, 'isi', $studentSectionId, $studentSchoolYear, $studentSemester);
        mysqli_stmt_execute($announcementStmt);
        $announcementResult = mysqli_stmt_get_result($announcementStmt);
        while ($row = mysqli_fetch_assoc($announcementResult)) { $studentAnnouncements[] = $row; }
        mysqli_stmt_close($announcementStmt);
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard – EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/student_profile.css">
    <script src="../js/sweetalert2.all.min.js"></script>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>

<body class="profile-page">
    <?php include 'sidebar_layout.php'; ?>
    <main class="dashboard-main">
        <header class="dashboard-topbar">
            <div><span class="topbar-label">STUDENT PORTAL</span>
                <h2>Dashboard</h2>
            </div>
        </header>

        <section class="hero">
            <div class="welcome">
                <span class="hero-badge">&#127891; Student Overview</span>
                <h1>Welcome, <span class="accent"><?= $studentName ?></span></h1>
                <p>Keep track of your enrollment, academic details, and account balance.</p>
                <div class="hero-big-stat">
                    <h2><?= $subjectCount ?></h2><span>Subjects Selected</span>
                </div>
            </div>
            <div class="hero-stats">
                <div class="mini-stat">
                    <h3>Course</h3><span><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></span>
                </div>
                <div class="mini-stat">
                    <h3>Year Level</h3><span><?= htmlspecialchars($student['year_level'] ?? 'N/A') ?></span>
                </div>
                <div class="mini-stat">
                    <h3>Section</h3><span><?= htmlspecialchars($student['section_name'] ?? 'Pending') ?></span>
                </div>
            </div>
        </section>

        <section class="stats-row">
            <div class="stat-card stat-success">
                <div class="stat-icon">&#128203;</div>
                <h3>Enrollment Status</h3><span><?= htmlspecialchars($statusLabel) ?></span>
            </div>
            <div class="stat-card stat-paid">
                <div class="stat-icon">&#128176;</div>
                <h3><?= $isFullyPaid ? 'Payment Status' : 'Remaining Balance' ?></h3>
                <?php if ($isFullyPaid): ?>
                    <span class="fully-paid-label">Fully Paid</span>
                <?php else: ?>
                    <span>&#8369;<?= number_format($remainingBalance, 2) ?></span>
                    <a href="profile.php#payment" class="pay-balance-btn">Pay Now</a>
                <?php endif; ?>
            </div>
            <div class="stat-card stat-warning">
                <div class="stat-icon">&#128179;</div>
                <h3>Payment Status</h3><span><?= htmlspecialchars(ucfirst($paymentStatus)) ?></span>
            </div>
            <div class="stat-card stat-section">
                <div class="stat-icon">&#128197;</div>
                <h3>School Term</h3><span><?= htmlspecialchars(($enrollment['school_year'] ?? 'N/A') . ' / ' . ($enrollment['sem'] ?? 'N/A')) ?></span>
            </div>
        </section>

        <section class="teacher-announcements student-dashboard-announcements">
            <div class="card">
                <div class="announcement-section-header"><div><span class="announcement-eyebrow">FACULTY UPDATES</span><h3>Announcements</h3></div><span class="announcement-count"><?= count($studentAnnouncements) ?></span></div>
                <?php if (!$studentAnnouncements): ?>
                    <div class="announcement-empty">No announcements for your section yet.</div>
                <?php else: ?>
                    <div class="student-announcement-list">
                        <?php foreach ($studentAnnouncements as $announcement): ?>
                            <article class="student-announcement-item">
                                <div class="student-announcement-meta"><strong><?= htmlspecialchars($announcement['teacher_name']) ?></strong><time><?= htmlspecialchars(date('M d, Y · g:i A', strtotime($announcement['created_at']))) ?></time></div>
                                <h4><?= htmlspecialchars($announcement['title']) ?></h4>
                                <span class="announcement-audience"><?= htmlspecialchars($announcement['audience']) ?></span>
                                <p><?= nl2br(htmlspecialchars($announcement['message'])) ?></p>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="analytics-grid">
            <div class="card">
                <h3>Academic Information</h3>
                <dl class="info-list">
                    <div>
                        <dt>Program</dt>
                        <dd><?= htmlspecialchars($student['course_name'] ?? 'Not selected') ?></dd>
                    </div>
                    <div>
                        <dt>Student Number</dt>
                        <dd><?= htmlspecialchars($student['student_number'] ?? 'Pending') ?></dd>
                    </div>
                    <div>
                        <dt>Section</dt>
                        <dd><?= htmlspecialchars($student['section_name'] ?? 'Not assigned') ?></dd>
                    </div>
                </dl>
            </div>
        </section>
    </main>
</body>

</html>