<?php
require_once __DIR__ . '/../functions/teacher_auth.php';
start_teacher_session();
unset($_SESSION['teacher_id'], $_SESSION['teacher_name'], $_SESSION['teacher_email'], $_SESSION['teacher_csrf_token']);
session_regenerate_id(true);
header('Location: adviser_login.php', true, 303);
exit;
