<?php

/**
 * EYYSAT ENROLLMENT SETUP
 *
 * This file makes sure the additional enrollment-related
 * columns exist and provides the initial course/section/subject
 * seed data.
 */

function ensure_enrollment_schema(mysqli $conn): void
{
    $tables = [];

    $tables['students'] = [
        [
            'name' => 'section_id',
            'definition' => 'INT NULL DEFAULT NULL'
        ],
        [
            'name' => 'profile_picture',
            'definition' => 'VARCHAR(255) NULL DEFAULT NULL'
        ],
        [
            'name' => 'remaining_balance',
            'definition' => 'DECIMAL(10,2) NULL DEFAULT 0.00'
        ],
    ];

    $tables['subjects'] = [
        [
            'name' => 'section_id',
            'definition' => 'INT NULL DEFAULT NULL'
        ],
        [
            'name' => 'schedule_day',
            'definition' => 'VARCHAR(20) NULL DEFAULT NULL'
        ],
        [
            'name' => 'schedule_time',
            'definition' => 'VARCHAR(50) NULL DEFAULT NULL'
        ],
        [
            'name' => 'room_number',
            'definition' => 'VARCHAR(20) NULL DEFAULT NULL'
        ],
        [
            'name' => 'is_available',
            'definition' => 'TINYINT(1) NOT NULL DEFAULT 1'
        ],
    ];

    $tables['enrollments'] = [
        [
            'name' => 'paymongo_link_id',
            'definition' => 'VARCHAR(100) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_method',
            'definition' => 'VARCHAR(50) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_option',
            'definition' => 'VARCHAR(50) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_reference',
            'definition' => 'VARCHAR(100) NULL DEFAULT NULL'
        ],
        [
            'name' => 'amount_paid',
            'definition' => 'DECIMAL(10,2) NULL DEFAULT 0.00'
        ],
        [
            'name' => 'cash_amount_requested',
            'definition' => 'DECIMAL(10,2) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_account',
            'definition' => 'VARCHAR(100) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_proof',
            'definition' => 'VARCHAR(255) NULL DEFAULT NULL'
        ],
    ];

    foreach ($tables as $table => $columns) {

        $result = mysqli_query($conn, "SHOW COLUMNS FROM `$table`");

        if (!$result) {
            continue;
        }

        $existing = [];

        while ($row = mysqli_fetch_assoc($result)) {
            $existing[] = $row['Field'];
        }

        foreach ($columns as $column) {

            if (!in_array($column['name'], $existing, true)) {

                mysqli_query(
                    $conn,
                    "ALTER TABLE `$table`
                     ADD COLUMN `{$column['name']}`
                     {$column['definition']}"
                );
            }
        }
    }

    /*
     * Older installations use restrictive ENUM columns.  Cashier-confirmed
     * enrollments and down payments need explicit Enrolled and Partial states.
     */
    mysqli_query(
        $conn,
        "ALTER TABLE enrollments
         MODIFY COLUMN STATUS ENUM('Pending', 'Approved', 'Rejected', 'Enrolled')
         NOT NULL DEFAULT 'Pending'"
    );
    mysqli_query(
        $conn,
        "ALTER TABLE enrollments
         MODIFY COLUMN payment_status ENUM('Paid', 'Pending', 'Unpaid', 'Partial')
         NOT NULL DEFAULT 'Pending'"
    );
    mysqli_query(
        $conn,
        "ALTER TABLE students
         MODIFY COLUMN payment_status ENUM('Paid', 'Pending', 'Unpaid', 'Partial')
         NOT NULL DEFAULT 'Pending'"
    );

    /* Repair empty ENUM values written before the expanded status migration. */
    mysqli_query(
        $conn,
        "UPDATE enrollments
         SET STATUS = 'Enrolled'
         WHERE STATUS = ''
           AND COALESCE(amount_paid, 0) > 0
           AND cash_amount_requested IS NULL"
    );
    mysqli_query(
        $conn,
        "UPDATE students s
         INNER JOIN enrollments e ON e.student_id = s.id
         SET s.payment_status = CASE
                 WHEN COALESCE(e.amount_paid, 0) >= 20000 THEN 'Paid'
                 ELSE 'Partial'
             END,
             s.enrollment_status = 'Enrolled'
         WHERE s.payment_status = ''
           AND e.STATUS = 'Enrolled'
           AND COALESCE(e.amount_paid, 0) > 0
           AND e.cash_amount_requested IS NULL"
    );
    mysqli_query(
        $conn,
        "UPDATE enrollments
         SET payment_status = CASE
             WHEN COALESCE(amount_paid, 0) >= 20000 THEN 'Paid'
             ELSE 'Partial'
         END
         WHERE payment_status = ''
           AND COALESCE(amount_paid, 0) > 0
           AND cash_amount_requested IS NULL"
    );

    /*
     * Cashier alerts are persisted so a payment submitted while no admin is
     * online is still shown the next time the cashier page is opened.
     */
    mysqli_query(
        $conn,
        "
        CREATE TABLE IF NOT EXISTS admin_notifications (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            enrollment_id INT NOT NULL,
            message VARCHAR(255) NOT NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_admin_notifications_unread (is_read, created_at),
            KEY idx_admin_notifications_enrollment (enrollment_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        "
    );

    /*
     * Make sure the curriculum table exists.
     *
     * Your database already contains this table, but this makes
     * the application safe if it is installed on a fresh database.
     */
    mysqli_query(
        $conn,
        "
        CREATE TABLE IF NOT EXISTS curriculum (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            course_id INT NOT NULL,
            subject_id INT NOT NULL,
            year_level TINYINT UNSIGNED NOT NULL,
            semester TINYINT UNSIGNED NOT NULL,
            units DECIMAL(4,1) NOT NULL DEFAULT 3.0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

            PRIMARY KEY (id),

            UNIQUE KEY uq_curriculum_subject
                (course_id, subject_id, year_level, semester),

            KEY idx_curriculum_lookup
                (course_id, year_level, semester)
        )
        ENGINE=InnoDB
        DEFAULT CHARSET=utf8mb4
        COLLATE=utf8mb4_unicode_ci
        "
    );
}


/**
 * Seed courses, sections and subjects only when necessary.
 *
 * Existing records are preserved.
 */
function seed_course_data(mysqli $conn): void
{
    $courseCountResult = mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total FROM courses"
    );

    if (!$courseCountResult) {
        return;
    }

    $courseCount = (int) mysqli_fetch_assoc($courseCountResult)['total'];

    if ($courseCount === 0) {

        $courses = [
            [
                'course_code' => 'BSIT',
                'course_name' => 'Bachelor of Science in Information Technology'
            ],
            [
                'course_code' => 'BEED',
                'course_name' => 'Bachelor of Elementary Education'
            ],
            [
                'course_code' => 'BSED',
                'course_name' => 'Bachelor of Secondary Education'
            ],
        ];

        foreach ($courses as $course) {

            $stmt = mysqli_prepare(
                $conn,
                "
                INSERT INTO courses
                (
                    course_code,
                    course_name
                )
                VALUES (?, ?)
                "
            );

            mysqli_stmt_bind_param(
                $stmt,
                'ss',
                $course['course_code'],
                $course['course_name']
            );

            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }

    $courses = mysqli_query(
        $conn,
        "SELECT id, course_code FROM courses ORDER BY id ASC"
    );

    if (!$courses) {
        return;
    }

    while ($course = mysqli_fetch_assoc($courses)) {

        $courseId = (int) $course['id'];
        $courseCode = (string) $course['course_code'];

        /*
         * SECTIONS
         */
        $sectionStmt = mysqli_prepare(
            $conn,
            "
            SELECT COUNT(*) AS total
            FROM sections
            WHERE course_id = ?
            "
        );

        mysqli_stmt_bind_param(
            $sectionStmt,
            'i',
            $courseId
        );

        mysqli_stmt_execute($sectionStmt);

        $sectionResult = mysqli_stmt_get_result($sectionStmt);
        $sectionCount = (int) mysqli_fetch_assoc($sectionResult)['total'];

        mysqli_stmt_close($sectionStmt);

        if ($sectionCount === 0) {

            $sectionNames = [
                'Section A',
                'Section B'
            ];

            foreach ($sectionNames as $sectionName) {

                $stmt = mysqli_prepare(
                    $conn,
                    "
                    INSERT INTO sections
                    (
                        course_id,
                        section_name,
                        max_slots
                    )
                    VALUES (?, ?, 40)
                    "
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    'is',
                    $courseId,
                    $sectionName
                );

                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
        }

        /*
         * SUBJECTS
         */
        $subjectStmt = mysqli_prepare(
            $conn,
            "
            SELECT COUNT(*) AS total
            FROM subjects
            WHERE course_id = ?
            "
        );

        mysqli_stmt_bind_param(
            $subjectStmt,
            'i',
            $courseId
        );

        mysqli_stmt_execute($subjectStmt);

        $subjectResult = mysqli_stmt_get_result($subjectStmt);
        $subjectCount = (int) mysqli_fetch_assoc($subjectResult)['total'];

        mysqli_stmt_close($subjectStmt);

        if ($subjectCount === 0) {

            $sections = mysqli_prepare(
                $conn,
                "
                SELECT id
                FROM sections
                WHERE course_id = ?
                ORDER BY id ASC
                "
            );

            mysqli_stmt_bind_param(
                $sections,
                'i',
                $courseId
            );

            mysqli_stmt_execute($sections);

            $sectionResult = mysqli_stmt_get_result($sections);

            $sectionIds = [];

            while ($section = mysqli_fetch_assoc($sectionResult)) {
                $sectionIds[] = (int) $section['id'];
            }

            mysqli_stmt_close($sections);

            if ($sectionIds === []) {
                continue;
            }

            $subjectTemplates = [

                'BSIT' => [
                    ['code' => 'IT101', 'name' => 'Programming I', 'day' => 'Mon', 'time' => '8:00 AM', 'room' => 'LAB 1'],
                    ['code' => 'IT102', 'name' => 'Database Systems', 'day' => 'Tue', 'time' => '10:00 AM', 'room' => 'LAB 2'],
                    ['code' => 'IT103', 'name' => 'Networking', 'day' => 'Wed', 'time' => '1:00 PM', 'room' => 'LAB 3'],
                    ['code' => 'IT104', 'name' => 'Web Development', 'day' => 'Thu', 'time' => '3:00 PM', 'room' => 'LAB 4'],
                    ['code' => 'IT105', 'name' => 'Systems Analysis', 'day' => 'Fri', 'time' => '9:00 AM', 'room' => 'RM 101'],
                    ['code' => 'IT106', 'name' => 'Ethics in Computing', 'day' => 'Mon', 'time' => '2:00 PM', 'room' => 'RM 102'],
                ],

                'BEED' => [
                    ['code' => 'ED101', 'name' => 'Child Development', 'day' => 'Mon', 'time' => '8:00 AM', 'room' => 'RM 201'],
                    ['code' => 'ED102', 'name' => 'Teaching Methods', 'day' => 'Tue', 'time' => '10:00 AM', 'room' => 'RM 202'],
                    ['code' => 'ED103', 'name' => 'Educational Psychology', 'day' => 'Wed', 'time' => '1:00 PM', 'room' => 'RM 203'],
                    ['code' => 'ED104', 'name' => 'Assessment in Learning', 'day' => 'Thu', 'time' => '3:00 PM', 'room' => 'RM 204'],
                    ['code' => 'ED105', 'name' => 'Reading Instruction', 'day' => 'Fri', 'time' => '9:00 AM', 'room' => 'RM 205'],
                    ['code' => 'ED106', 'name' => 'Curriculum Planning', 'day' => 'Mon', 'time' => '2:00 PM', 'room' => 'RM 206'],
                ],

                'BSED' => [
                    ['code' => 'SED101', 'name' => 'Principles of Teaching', 'day' => 'Mon', 'time' => '8:00 AM', 'room' => 'RM 301'],
                    ['code' => 'SED102', 'name' => 'Educational Research', 'day' => 'Tue', 'time' => '10:00 AM', 'room' => 'RM 302'],
                    ['code' => 'SED103', 'name' => 'Curriculum Development', 'day' => 'Wed', 'time' => '1:00 PM', 'room' => 'RM 303'],
                    ['code' => 'SED104', 'name' => 'Literature Studies', 'day' => 'Thu', 'time' => '3:00 PM', 'room' => 'RM 304'],
                    ['code' => 'SED105', 'name' => 'Classroom Management', 'day' => 'Fri', 'time' => '9:00 AM', 'room' => 'RM 305'],
                    ['code' => 'SED106', 'name' => 'Special Topics', 'day' => 'Mon', 'time' => '2:00 PM', 'room' => 'RM 306'],
                ],
            ];

            $templates =
                $subjectTemplates[$courseCode]
                ?? $subjectTemplates['BSIT'];

            $index = 0;

            foreach ($templates as $subject) {

                $sectionId =
                    $sectionIds[$index % count($sectionIds)];

                $stmt = mysqli_prepare(
                    $conn,
                    "
                    INSERT INTO subjects
                    (
                        course_id,
                        section_id,
                        subject_code,
                        subject_name,
                        units,
                        sem,
                        year_level,
                        schedule_day,
                        schedule_time,
                        room_number
                    )
                    VALUES (?, ?, ?, ?, 3, 1, 1, ?, ?, ?)
                    "
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    'iisssss',
                    $courseId,
                    $sectionId,
                    $subject['code'],
                    $subject['name'],
                    $subject['day'],
                    $subject['time'],
                    $subject['room']
                );

                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);

                $index++;
            }
        }
    }
}


/**
 * Generate a student number.
 */
function generate_student_number(mysqli $conn, int $course_id): string
{
    $year = date('Y');

    $stmt = mysqli_prepare(
        $conn,
        "
        SELECT MAX(
            CAST(
                SUBSTRING(student_number, 6)
                AS UNSIGNED
            )
        ) AS max_num
        FROM students
        WHERE student_number IS NOT NULL
        AND student_number LIKE ?
        "
    );

    $prefix = $year . '-%';

    mysqli_stmt_bind_param(
        $stmt,
        's',
        $prefix
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    mysqli_stmt_close($stmt);

    $next =
        ((int) ($row['max_num'] ?? 0))
        + 1;

    return
        $year .
        '-' .
        str_pad(
            (string) $next,
            5,
            '0',
            STR_PAD_LEFT
        );
}
