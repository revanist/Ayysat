<?php
require_once '../functions/admin_auth.php';
require_admin_login();

require '../db/dbconn.php';
require_once '../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);
ensure_lms_schema($conn);

function um_password(): string
{
    return strtoupper(bin2hex(random_bytes(5))) . '-' . random_int(10, 99);
}

function um_role(int $roleId): string
{
    return match ($roleId) {
        1 => 'Super Admin',
        2 => 'Instructor / Professor',
        4 => 'Cashier',
        default => 'Unknown',
    };
}

$msg = '';
$err = '';
$issued = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_admin_csrf();
    $action = (string)($_POST['action'] ?? '');

    if ($action === 'create_staff') {
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $password = trim((string)($_POST['password'] ?? ''));
        $roleId = (int)($_POST['role_id'] ?? 0);
        $employeeNumber = trim((string)($_POST['employee_number'] ?? ''));
        $department = trim((string)($_POST['department'] ?? ''));

        if ($fullName === '' || mb_strlen($fullName) > 120) {
            $err = 'Enter a valid full name (maximum 120 characters).';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 150) {
            $err = 'Enter a valid email address.';
        } elseif (!in_array($roleId, [2, 4], true)) {
            $err = 'Only Instructor / Professor and Cashier accounts can be created here.';
        } else {
            if ($password === '') {
                $password = um_password();
            }

            if (strlen($password) < 8) {
                $err = 'Password must be at least 8 characters.';
            } else {
                $stmt = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE email = ? LIMIT 1');
                mysqli_stmt_bind_param($stmt, 's', $email);
                mysqli_stmt_execute($stmt);
                $exists = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
                mysqli_stmt_close($stmt);

                if ($exists) {
                    $err = 'That email is already registered.';
                } else {
                    mysqli_begin_transaction($conn);
                    try {
                        $hash = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = mysqli_prepare($conn, 'INSERT INTO users (full_name, email, password_hash, role_id) VALUES (?, ?, ?, ?)');
                        mysqli_stmt_bind_param($stmt, 'sssi', $fullName, $email, $hash, $roleId);
                        mysqli_stmt_execute($stmt);
                        $userId = mysqli_insert_id($conn);
                        mysqli_stmt_close($stmt);

                        if ($roleId === 2) {
                            $stmt = mysqli_prepare($conn, 'INSERT INTO teacher_profiles (user_id, employee_number, department) VALUES (?, ?, ?)');
                            $employeeValue = $employeeNumber !== '' ? $employeeNumber : null;
                            $departmentValue = $department !== '' ? $department : null;
                            mysqli_stmt_bind_param($stmt, 'iss', $userId, $employeeValue, $departmentValue);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_close($stmt);
                        }

                        mysqli_commit($conn);
                        $issued = um_role($roleId) . " account created successfully.\nEmail: {$email}\nInitial password: {$password}\nGive the password directly to the account owner.";
                    } catch (Throwable $e) {
                        mysqli_rollback($conn);
                        $err = 'Could not create the account. Please check the database configuration and try again.';
                    }
                }
            }
        }
    } elseif ($action === 'delete_user') {
        $userId = (int)($_POST['user_id'] ?? 0);

        if ($userId <= 0) {
            $err = 'Invalid account selected.';
        } else {
            $stmt = mysqli_prepare($conn, 'SELECT user_id, full_name, email, role_id FROM users WHERE user_id = ? LIMIT 1');
            mysqli_stmt_bind_param($stmt, 'i', $userId);
            mysqli_stmt_execute($stmt);
            $target = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            mysqli_stmt_close($stmt);

            if (!$target) {
                $err = 'The account could not be found.';
            } elseif ((int)$target['role_id'] === 1) {
                $err = 'Super Admin accounts are protected and cannot be deleted from User Management.';
            } elseif (!in_array((int)$target['role_id'], [2, 3, 4], true)) {
                $err = 'This account type cannot be deleted here.';
            } else {
                $targetRole = (int)$target['role_id'];
                mysqli_begin_transaction($conn);
                try {
                    if ($targetRole === 3) {
                        /*
                         * Student accounts can have enrollment/payment history.
                         * Delete the dependent records first so a test account
                         * can still be completely removed without leaving
                         * broken foreign-key references.
                         */
                        $stmt = mysqli_prepare($conn, 'DELETE FROM admin_notifications WHERE enrollment_id IN (SELECT id FROM enrollments WHERE student_id IN (SELECT id FROM students WHERE user_id = ?))');
                        mysqli_stmt_bind_param($stmt, 'i', $userId);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);

                        $stmt = mysqli_prepare($conn, 'DELETE FROM enrollment_details WHERE enrollment_id IN (SELECT id FROM enrollments WHERE student_id IN (SELECT id FROM students WHERE user_id = ?))');
                        mysqli_stmt_bind_param($stmt, 'i', $userId);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);

                        $stmt = mysqli_prepare($conn, 'DELETE FROM payments WHERE student_id IN (SELECT id FROM students WHERE user_id = ?)');
                        mysqli_stmt_bind_param($stmt, 'i', $userId);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);

                        $stmt = mysqli_prepare($conn, 'DELETE FROM enrollments WHERE student_id IN (SELECT id FROM students WHERE user_id = ?)');
                        mysqli_stmt_bind_param($stmt, 'i', $userId);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);

                        $stmt = mysqli_prepare($conn, 'DELETE FROM students WHERE user_id = ?');
                        mysqli_stmt_bind_param($stmt, 'i', $userId);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } elseif ($targetRole === 2) {
                        // Teacher-related records use ON DELETE CASCADE for users.user_id.
                        $stmt = mysqli_prepare($conn, 'DELETE FROM teacher_profiles WHERE user_id = ?');
                        mysqli_stmt_bind_param($stmt, 'i', $userId);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }

                    $stmt = mysqli_prepare($conn, 'DELETE FROM users WHERE user_id = ? AND role_id IN (2,3,4)');
                    mysqli_stmt_bind_param($stmt, 'i', $userId);
                    mysqli_stmt_execute($stmt);
                    $deleted = mysqli_stmt_affected_rows($stmt);
                    mysqli_stmt_close($stmt);

                    if ($deleted !== 1) {
                        throw new RuntimeException('Account deletion failed.');
                    }

                    mysqli_commit($conn);
                    $msg = um_role($targetRole) . ' account for ' . $target['full_name'] . ' was permanently deleted.';
                } catch (Throwable $e) {
                    mysqli_rollback($conn);
                    $err = 'The account could not be deleted. No changes were saved.';
                }
            }
        }
    } elseif ($action === 'reset_password') {
        $userId = (int)($_POST['user_id'] ?? 0);
        $newPassword = um_password();
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);

        $stmt = mysqli_prepare($conn, 'UPDATE users SET password_hash = ? WHERE user_id = ? AND role_id IN (2,4)');
        mysqli_stmt_bind_param($stmt, 'si', $hash, $userId);
        mysqli_stmt_execute($stmt);
        $changed = mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);

        if ($changed > 0) {
            $issued = "Password reset successfully.\nNew password: {$newPassword}\nGive the new password directly to the account owner.";
        } else {
            $err = 'The staff account was not found.';
        }
    }
}

$filter = (int)($_GET['role'] ?? 0);
if (!in_array($filter, [0,1,2,3,4], true)) { $filter = 0; }

$where = 'u.role_id IN (1,2,3,4)';
if ($filter !== 0) { $where .= ' AND u.role_id = ' . $filter; }
$result = mysqli_query($conn, "SELECT u.user_id,u.full_name,u.email,u.role_id,u.created_at, tp.employee_number,tp.department, s.student_number,s.year_level,s.enrollment_status,s.payment_status FROM users u LEFT JOIN teacher_profiles tp ON tp.user_id=u.user_id LEFT JOIN students s ON s.user_id=u.user_id WHERE {$where} ORDER BY u.role_id ASC,u.full_name ASC");
$counts = [1=>0,2=>0,3=>0,4=>0];
$cr = mysqli_query($conn, 'SELECT role_id,COUNT(*) total FROM users WHERE role_id IN (1,2,3,4) GROUP BY role_id');
if ($cr) while ($r=mysqli_fetch_assoc($cr)) $counts[(int)$r['role_id']] = (int)$r['total'];
$csrf = admin_csrf_token();
?>

?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Management | EYYSAT Admin</title>
<link rel="stylesheet" href="../css/admin_dashboard.css"><link rel="stylesheet" href="../css/admin_users.css"><link rel="stylesheet" href="../css/ux-polish.css"><script src="../js/sweetalert2.all.min.js"></script>
</head><body><?php include 'navbar_layout.php'; ?>
<main class="dashboard-main user-management-main">
<?php if($msg): ?><div class="user-alert success"><?=htmlspecialchars($msg)?></div><?php endif; ?>
<?php if($err): ?><div class="user-alert error"><?=htmlspecialchars($err)?></div><?php endif; ?>
<?php if($issued): ?><div class="user-alert issued"><strong>Account information</strong><pre><?=htmlspecialchars($issued)?></pre></div><?php endif; ?>

<section class="user-card unified-user-directory">
  <div class="unified-directory-header">
    <div class="unified-heading-copy">
      <span class="section-kicker">ACCOUNT MANAGEMENT</span>
      <h1>User Management</h1>
      <p>Manage system accounts, create staff accounts, reset staff passwords, and remove test accounts.</p>
    </div>
    <button class="primary-user-btn unified-create-btn" type="button" id="openCreateModal">+ Create Staff Account</button>
  </div>

  <div class="unified-controls">
    <div class="filter-tabs" aria-label="Filter accounts">
      <a class="<?= $filter===0?'active':'' ?>" href="users.php">All <span><?=array_sum($counts)?></span></a>
      <a class="<?= $filter===2?'active':'' ?>" href="users.php?role=2">Instructors <span><?=$counts[2]?></span></a>
      <a class="<?= $filter===4?'active':'' ?>" href="users.php?role=4">Cashiers <span><?=$counts[4]?></span></a>
      <a class="<?= $filter===1?'active':'' ?>" href="users.php?role=1">Admins <span><?=$counts[1]?></span></a>
      <a class="<?= $filter===3?'active':'' ?>" href="users.php?role=3">Students <span><?=$counts[3]?></span></a>
    </div>
    <label class="user-search"><span aria-hidden="true">⌕</span><input id="userSearch" type="search" placeholder="Search by name, email, or ID..."></label>
  </div>

  <div class="user-table-wrap unified-table-wrap">
    <table class="user-table responsive-user-table unified-user-table">
      <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Details</th><th>Created</th><th class="actions-col">Actions</th></tr></thead>
      <tbody id="userRows">
      <?php if(!$result || mysqli_num_rows($result)===0): ?><tr><td colspan="6" class="empty-row">No user accounts found.</td></tr>
      <?php else: while($row=mysqli_fetch_assoc($result)): $rid=(int)$row['role_id']; $roleLabel=um_role($rid); ?>
      <tr data-search="<?=htmlspecialchars(strtolower($row['full_name'].' '.$row['email'].' '.$row['user_id'].' '.$roleLabel.' '.($row['student_number']??'').' '.($row['employee_number']??'')),ENT_QUOTES)?>">
        <td data-label="User"><div class="user-cell"><span class="user-avatar"><?=htmlspecialchars(strtoupper(substr(trim($row['full_name']),0,1)))?></span><div><strong><?=htmlspecialchars($row['full_name'])?></strong><small>ID #<?= (int)$row['user_id'] ?></small></div></div></td>
        <td data-label="Email"><?=htmlspecialchars($row['email'])?></td>
        <td data-label="Role"><span class="role-pill role-<?=$rid?>"><?=htmlspecialchars($roleLabel)?></span></td>
        <td data-label="Details">
          <?php if($rid===2): ?><span><?=htmlspecialchars($row['employee_number']?:'No employee number')?></span><small><?=htmlspecialchars($row['department']?:'No department')?></small>
          <?php elseif($rid===3): ?><span><?=htmlspecialchars($row['student_number']?:'Student number not assigned')?></span><small>Year <?=htmlspecialchars($row['year_level']?:'—')?> · <?=htmlspecialchars($row['enrollment_status']?:'Pending')?></small>
          <?php elseif($rid===4): ?><span>Payment &amp; cashier operations</span><small>Cashier dashboard access</small>
          <?php else: ?><span>Full system administration</span><small class="protected-detail">Protected administrator</small><?php endif; ?>
        </td>
        <td data-label="Created"><?=htmlspecialchars(date('M d, Y',strtotime($row['created_at'])))?></td>
        <td data-label="Actions" class="actions-cell">
          <?php if(in_array($rid,[2,4],true)): ?><form method="post" onsubmit="return confirm('Reset this account password? The old password will stop working immediately.');"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="reset_password"><input type="hidden" name="user_id" value="<?=(int)$row['user_id']?>"><button class="table-action" type="submit">Reset Password</button></form><?php endif; ?>
          <?php if(in_array($rid,[2,3,4],true)): ?><form method="post" class="delete-account-form"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?=(int)$row['user_id']?>"><button class="table-action danger-action" type="submit" data-delete-user data-name="<?=htmlspecialchars($row['full_name'],ENT_QUOTES)?>" data-role="<?=htmlspecialchars($roleLabel,ENT_QUOTES)?>">Delete</button></form><?php else: ?><span class="protected-label">Protected</span><?php endif; ?>
        </td>
      </tr>
      <?php endwhile; endif; ?>
      </tbody>
    </table>
  </div>
  <div class="directory-footer"><span>Total: <?=array_sum($counts)?> users</span><span>Super Admin accounts are protected.</span></div>
</section>
</main>

<?php if ($issued): ?>
<script>document.addEventListener('DOMContentLoaded',function(){const raw=<?=json_encode($issued,JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)?>;const lines=raw.split('\n');const emailLine=lines.find(v=>v.indexOf('Email: ')===0)||'';const passLine=lines.find(v=>v.indexOf('Initial password: ')===0)||lines.find(v=>v.indexOf('New password: ')===0)||'';const password=passLine.replace(/^Initial password: |^New password: /,'');Swal.fire({icon:'success',title:'Account Ready',html:`<div class="account-created-popup"><p class="popup-role">${escapeHtml(lines[0]||'Staff account')}</p><div class="popup-detail"><span>Email</span><strong>${escapeHtml(emailLine.replace('Email: ','')||'—')}</strong></div><div class="temporary-password-box"><div><span>Password</span><strong>${escapeHtml(password)}</strong></div><button type="button" id="copyIssuedPassword" class="popup-copy-btn">Copy Password</button></div><p class="popup-warning">Give this password directly to the account owner. It will not be shown again after this message is closed.</p></div>`,confirmButtonText:'Done',confirmButtonColor:'#f4d35e',customClass:{popup:'eyysat-account-popup'}});document.addEventListener('click',function(e){if(e.target.id==='copyIssuedPassword'){navigator.clipboard?.writeText(password).then(()=>{e.target.textContent='Copied!';setTimeout(()=>e.target.textContent='Copy Password',1400);});}});});function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}</script>
<?php endif; ?>

<div class="user-modal" id="createModal" aria-hidden="true">
  <div class="modal-backdrop" data-close-modal></div>
  <section class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="createModalTitle">
    <button class="modal-close" type="button" data-close-modal aria-label="Close">&times;</button>
    <span class="modal-kicker">NEW STAFF ACCOUNT</span><h2 id="createModalTitle">Create Staff Account</h2>
    <p class="modal-description">Create an Instructor / Professor or Cashier account. Passwords are stored securely.</p>
    <form method="post" class="create-user-form">
      <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($csrf)?>"><input type="hidden" name="action" value="create_staff">
      <div class="form-grid">
        <label>Full Name<input type="text" name="full_name" maxlength="120" required autocomplete="name"></label>
        <label>Email<input type="email" name="email" maxlength="150" required autocomplete="email"></label>
        <label>Role<select name="role_id" id="staffRole" required><option value="2">Instructor / Professor</option><option value="4">Cashier</option></select></label>
        <label class="password-field">Password <span id="passwordModeText">(temporary password)</span><div class="password-control"><input type="text" name="password" id="staffPassword" minlength="8" autocomplete="new-password" placeholder="Click Generate Password" readonly><button type="button" class="generate-password-btn" id="generatePasswordBtn">Generate</button></div><span class="manual-password-toggle"><input type="checkbox" id="manualPasswordToggle"> Set password manually</span></label>
        <label class="instructor-field">Employee Number <span>(optional)</span><input type="text" name="employee_number" maxlength="40"></label>
        <label class="instructor-field">Department <span>(optional)</span><input type="text" name="department" maxlength="120"></label>
      </div>
      <div class="modal-actions"><button type="button" class="secondary-user-btn" data-close-modal>Cancel</button><button type="submit" class="primary-user-btn">Create Account</button></div>
    </form>
  </section>
</div>
<script src="../js/ux-polish.js" defer></script>
<script>
function esc(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
document.addEventListener('DOMContentLoaded',function(){
 const search=document.getElementById('userSearch'); const rows=[...document.querySelectorAll('#userRows tr[data-search]')];
 search?.addEventListener('input',function(){const q=this.value.trim().toLowerCase();rows.forEach(r=>r.style.display=!q||r.dataset.search.includes(q)?'':'none');});
 document.querySelectorAll('[data-delete-user]').forEach(function(button){button.closest('form')?.addEventListener('submit',function(e){e.preventDefault();const name=button.dataset.name||'this account',role=button.dataset.role||'account';Swal.fire({icon:'warning',title:'Permanently delete account?',html:'<p style="margin:.35rem 0 .8rem"><strong>'+esc(name)+'</strong> ('+esc(role)+')</p><p style="font-size:.92rem;opacity:.82;margin:0">This cannot be undone.</p>'+(role==='Student'?'<p style="font-size:.9rem;color:#b42332;margin:.7rem 0 0"><strong>Student test data:</strong> linked enrollments, enrollment details, payment records and cashier notifications will also be removed.</p>':''),showCancelButton:true,confirmButtonText:'Yes, Delete Permanently',cancelButtonText:'Cancel',confirmButtonColor:'#c62828',focusCancel:true}).then(r=>{if(r.isConfirmed)this.submit();});});});
 const modal=document.getElementById('createModal'),open=document.getElementById('openCreateModal'),role=document.getElementById('staffRole'),fields=document.querySelectorAll('.instructor-field');
 function setModal(v){modal.classList.toggle('show',v);modal.setAttribute('aria-hidden',v?'false':'true');document.body.classList.toggle('modal-open',v);if(v)setTimeout(()=>document.querySelector('#createModal input[name="full_name"]')?.focus(),80);}
 open?.addEventListener('click',()=>setModal(true));document.querySelectorAll('[data-close-modal]').forEach(el=>el.addEventListener('click',()=>setModal(false)));document.addEventListener('keydown',e=>{if(e.key==='Escape')setModal(false);});
 function update(){const ins=role.value==='2';fields.forEach(f=>{f.style.display=ins?'':'none';const input=f.querySelector('input');if(input)input.disabled=!ins;});} role?.addEventListener('change',update);
 const pi=document.getElementById('staffPassword'),gb=document.getElementById('generatePasswordBtn'),mt=document.getElementById('manualPasswordToggle'),pm=document.getElementById('passwordModeText');
 function randomPassword(){const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*';const values=new Uint32Array(14);crypto.getRandomValues(values);return [...values].map(v=>chars[v%chars.length]).join('');}
 function generate(){pi.value=randomPassword();pi.type='text';} gb?.addEventListener('click',generate);mt?.addEventListener('change',function(){pi.readOnly=!this.checked;pi.placeholder=this.checked?'Enter a password (8+ characters)':'Click Generate Password';pm.textContent=this.checked?'(set manually)':'(temporary password)';if(!this.checked)generate();else pi.value='';});generate();update();
});
</script></body></html>
