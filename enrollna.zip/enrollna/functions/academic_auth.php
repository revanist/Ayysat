<?php
require_once __DIR__ . '/session_security.php';

/** Academic/SIS access: Registrar / Academic Affairs only (role 5). */
function start_academic_session(): void { start_secure_session(); }
function require_academic_login(): void {
    start_academic_session();
    $roleId=(int)($_SESSION['role_id'] ?? 0);
    if (empty($_SESSION['user_id']) || $roleId !== 5) {
        header('Location: ../auth/login.php', true, 303); exit;
    }
}
function academic_csrf_token(): string {
    if (empty($_SESSION['academic_csrf_token'])) $_SESSION['academic_csrf_token']=bin2hex(random_bytes(32));
    return $_SESSION['academic_csrf_token'];
}
function require_academic_csrf(): void {
    $token=$_POST['csrf_token'] ?? '';
    $roleId=(int)($_SESSION['role_id'] ?? 0);
    $valid = is_string($token) && !empty($_SESSION['academic_csrf_token']) && hash_equals($_SESSION['academic_csrf_token'],$token);
    if (!$valid) {
        http_response_code(403); exit('Invalid request. Please go back and try again.');
    }
}
