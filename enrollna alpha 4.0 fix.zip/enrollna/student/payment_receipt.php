<?php
require_once __DIR__ . '/../functions/student_auth.php';
start_student_session();
require __DIR__ . '/../db/dbconn.php';

if (($_SESSION['role'] ?? '') !== 'student' || empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php?loginredirect=1', true, 303);
    exit;
}

$enrollmentId = (int) ($_GET['enrollment_id'] ?? 0);
$stmt = mysqli_prepare($conn, '
    SELECT e.id, e.payment_method, e.payment_reference, e.payment_account,
           e.cash_amount_requested, e.amount_paid, e.payment_status,
           e.status, e.created, s.first_name, s.last_name, s.student_number,
           s.email, c.course_code, c.course_name
    FROM enrollments e
    INNER JOIN students s ON s.id = e.student_id
    LEFT JOIN courses c ON c.id = e.course_id
    WHERE e.id = ? AND s.user_id = ?
    LIMIT 1
');
$userId = (int) $_SESSION['user_id'];
mysqli_stmt_bind_param($stmt, 'ii', $enrollmentId, $userId);
mysqli_stmt_execute($stmt);
$receipt = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$receipt) {
    http_response_code(404);
    exit('Payment receipt not found.');
}

function payment_receipt_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$method = strtolower((string) ($receipt['payment_method'] ?? ''));
$methodLabel = $method === 'gcash' ? 'GCash' : 'Cash / Over-the-counter';
$amountSubmitted = (float) ($receipt['cash_amount_requested'] ?? 0);
$amountPaid = (float) ($receipt['amount_paid'] ?? 0);
$isPaid = strtolower((string) ($receipt['payment_status'] ?? '')) === 'paid';
$receiptNumber = 'PAY-' . str_pad((string) $receipt['id'], 8, '0', STR_PAD_LEFT);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payment Receipt | EYYSAT</title>
<link href="../css/bootstrap.css" rel="stylesheet">
<style>
:root{--navy:#102a43;--blue:#1e5a96;--yellow:#f4d35e;--muted:#627d98;--line:#dbe5ee}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:linear-gradient(135deg,#eaf3fb,#f7f9fc 55%,#fff9e4);font-family:"Segoe UI",system-ui,sans-serif;color:#172033;padding:30px 15px}
.page{width:min(850px,100%);margin:auto}.top-actions{display:flex;justify-content:space-between;gap:10px;margin-bottom:14px}.top-actions a{text-decoration:none}
.receipt{background:#fff;border:1px solid var(--line);border-radius:22px;overflow:hidden;box-shadow:0 24px 70px rgba(16,42,67,.15)}
.brand{display:flex;align-items:center;gap:13px;padding:23px 28px;background:var(--navy);color:#fff}.brand img{width:54px;height:54px;object-fit:contain;background:#fff;border-radius:12px;padding:5px}.brand strong{display:block;font-size:1.3rem}.brand span{display:block;color:#cfe2f5;font-size:.8rem;margin-top:2px}
.receipt-head{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;padding:28px}.eyebrow{font-size:.68rem;font-weight:800;letter-spacing:.13em;color:var(--blue)}h1{margin:4px 0 0;color:var(--navy);font-size:1.8rem}.number{text-align:right}.number span{display:block;color:#718096;font-size:.68rem}.number strong{color:var(--blue);font-size:.95rem}
.status{margin:0 28px 20px;padding:14px 16px;border-radius:13px;display:flex;gap:11px;align-items:center;background:<?= $isPaid ? '#effaf4' : '#fff8e6' ?>;border:1px solid <?= $isPaid ? '#cbe9d8' : '#f5df9e' ?>}.status-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:50%;background:<?= $isPaid ? '#1f9d65' : '#e1aa19' ?>;color:#fff;font-weight:900}.status strong,.status span{display:block}.status strong{color:<?= $isPaid ? '#166534' : '#7b5b00' ?>}.status span{font-size:.77rem;color:#718096;margin-top:2px}
.amount{margin:0 28px 25px;padding:20px;border-radius:15px;background:#f5f9fd;border:1px solid #e1eaf2;display:flex;justify-content:space-between;align-items:center}.amount span{font-size:.7rem;font-weight:800;color:var(--muted);letter-spacing:.08em}.amount strong{font-size:1.75rem;color:var(--blue)}
.section{padding:0 28px 25px}.section-title{font-size:.7rem;color:var(--blue);font-weight:900;letter-spacing:.12em;border-bottom:1px solid #edf1f5;padding-bottom:9px;margin-bottom:2px}.grid{display:grid;grid-template-columns:1fr 1fr}.item{padding:14px 5px;border-bottom:1px solid #edf1f5}.item span{display:block;color:#8190a0;font-size:.7rem;margin-bottom:4px}.item strong{display:block;font-size:.88rem;overflow-wrap:anywhere}.note{margin-top:20px;padding:14px 16px;border-left:4px solid var(--blue);background:#f7fbff;color:#627d98;font-size:.78rem;line-height:1.5}.note strong{color:var(--navy);display:block;margin-bottom:3px}.footer{display:flex;justify-content:space-between;gap:15px;padding:16px 28px;background:#fafcfe;border-top:1px solid #edf1f5;color:#94a3b8;font-size:.7rem}
@media(max-width:600px){body{padding:15px 10px}.receipt-head,.amount{flex-direction:column;align-items:flex-start}.number{text-align:left}.grid{grid-template-columns:1fr}.footer{flex-direction:column}.top-actions{flex-wrap:wrap}.top-actions a{flex:1;text-align:center}}
@media print{body{background:#fff;padding:0}.top-actions{display:none}.receipt{box-shadow:none;border:0}.page{width:100%}}
</style>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>
<body>
<div class="page">
  <div class="top-actions">
    <a href="../webhome.php" class="btn btn-outline-secondary">← Back to Home</a>
    <button type="button" class="btn btn-outline-primary" onclick="window.print()">Print Receipt</button>
  </div>
  <main class="receipt">
    <header class="brand"><img src="../img/eyysat.png" alt="EYYSAT Logo"><div><strong>EYYSAT</strong><span>Enrollment &amp; Registration Portal</span></div></header>
    <div class="receipt-head"><div><div class="eyebrow">OFFICIAL PAYMENT SUBMISSION</div><h1>Enrollment Payment Receipt</h1></div><div class="number"><span>Receipt No.</span><strong><?= payment_receipt_escape($receiptNumber) ?></strong></div></div>
    <div class="status"><div class="status-icon">✓</div><div><strong><?= $isPaid ? 'Payment verified' : 'Payment submitted successfully' ?></strong><span><?= $isPaid ? 'The cashier has confirmed this payment.' : 'This receipt confirms your payment details were submitted. Cashier verification is still required.' ?></span></div></div>
    <div class="amount"><span><?= $isPaid ? 'TOTAL PAID' : 'AMOUNT SUBMITTED' ?></span><strong>₱<?= number_format($isPaid && $amountPaid > 0 ? $amountPaid : $amountSubmitted, 2) ?></strong></div>
    <section class="section"><div class="section-title">STUDENT INFORMATION</div><div class="grid">
      <div class="item"><span>Student Name</span><strong><?= payment_receipt_escape($receipt['first_name'].' '.$receipt['last_name']) ?></strong></div>
      <div class="item"><span>Student Number</span><strong><?= payment_receipt_escape($receipt['student_number'] ?? '—') ?></strong></div>
      <div class="item"><span>Course</span><strong><?= payment_receipt_escape($receipt['course_code'] ?? '—') ?><?= !empty($receipt['course_name']) ? ' — '.payment_receipt_escape($receipt['course_name']) : '' ?></strong></div>
      <div class="item"><span>Email</span><strong><?= payment_receipt_escape($receipt['email'] ?? '—') ?></strong></div>
    </div></section>
    <section class="section"><div class="section-title">PAYMENT INFORMATION</div><div class="grid">
      <div class="item"><span>Payment Method</span><strong><?= payment_receipt_escape($methodLabel) ?></strong></div>
      <div class="item"><span>Payer / Account</span><strong><?= payment_receipt_escape($receipt['payment_account'] ?: 'School Cashier / Over-the-counter') ?></strong></div>
      <div class="item"><span>Transaction Reference</span><strong><?= payment_receipt_escape($receipt['payment_reference'] ?: 'Not applicable — cash payment') ?></strong></div>
      <div class="item"><span>Date Submitted</span><strong><?= payment_receipt_escape(date('M d, Y • h:i A', strtotime($receipt['created']))) ?></strong></div>
      <div class="item"><span>Payment Status</span><strong><?= payment_receipt_escape(ucfirst($receipt['payment_status'] ?? 'Pending')) ?></strong></div>
      <div class="item"><span>Enrollment Status</span><strong><?= payment_receipt_escape(ucfirst($receipt['status'] ?? 'Pending')) ?></strong></div>
    </div>
    <div class="note"><strong>Important</strong><?= $method === 'cash' ? 'Please present this receipt at the school cashier when paying over the counter. The cashier will update the payment status after receiving the cash.' : 'Keep this receipt and your GCash transaction details. The cashier will verify the reference before the payment is marked as paid.' ?></div></section>
    <footer class="footer"><span>Thank you for using EYYSAT Enrollment Portal.</span><span>Enrollment #<?= (int)$receipt['id'] ?></span></footer>
  </main>
</div>
</body></html>
