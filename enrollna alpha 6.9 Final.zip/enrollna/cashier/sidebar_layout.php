<?php
require_once __DIR__ . '/../functions/cashier_auth.php';
start_cashier_session();

$currentPage = basename($_SERVER['PHP_SELF']);
$cashierName = htmlspecialchars($_SESSION['fullname'] ?? 'Cashier');

$unreadPaymentCount = 0;
if (isset($conn)) {
    $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM admin_notifications WHERE cashier_is_read = 0");
    if ($result) {
        $unreadPaymentCount = (int)(mysqli_fetch_assoc($result)['total'] ?? 0);
    }
}

function cashier_sidebar_active(string $file, string $current): string
{
    return $current === $file ? ' active' : '';
}
?>

<aside class="admin-sidebar cashier-sidebar" id="cashierSidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo"><img src="../img/eyysat.png" alt="EYYSAT Logo"></div>
        <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>CASHIER PANEL</span></div>
    </div>

    <nav class="sidebar-nav" aria-label="Cashier navigation">
        <p class="sidebar-label">MAIN MENU</p>
        <a href="index.php" class="sidebar-link<?= cashier_sidebar_active('index.php', $currentPage) ?>">
            <span class="sidebar-icon">&#127968;</span><span class="sidebar-text">Dashboard</span>
        </a>
        <a href="index.php#pending-payments" class="sidebar-link">
            <span class="sidebar-icon">&#128176;</span><span class="sidebar-text">Payment Verification</span>
            <?php if ($unreadPaymentCount > 0): ?><span class="sidebar-notification-badge"><?= $unreadPaymentCount > 99 ? '99+' : $unreadPaymentCount ?></span><?php endif; ?>
        </a>
        <a href="index.php#transactions" class="sidebar-link">
            <span class="sidebar-icon">&#128203;</span><span class="sidebar-text">Transactions</span>
        </a>
        <a href="index.php#receipts" class="sidebar-link">
            <span class="sidebar-icon">&#129534;</span><span class="sidebar-text">Receipts</span>
        </a>

        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="../auth/logout.php" class="sidebar-link sidebar-logout">
            <span class="sidebar-icon">&#128682;</span><span class="sidebar-text">Logout</span>
        </a>
    </nav>

    <div class="sidebar-profile">
        <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'C', 0, 1))) ?></div>
        <div class="profile-info"><strong><?= $cashierName ?></strong><span>Cashier</span></div>
    </div>
</aside>

<div class="sidebar-overlay" id="cashierSidebarOverlay"></div>
<button class="sidebar-toggle" id="cashierSidebarToggle" type="button" aria-label="Toggle sidebar"></button>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('cashierSidebar');
    const toggle = document.getElementById('cashierSidebarToggle');
    const overlay = document.getElementById('cashierSidebarOverlay');
    const main = document.querySelector('.dashboard-main');
    if (!sidebar || !toggle || !overlay) return;

    function updateTogglePosition() {
        toggle.style.left = window.innerWidth <= 768 ? '18px' : (sidebar.classList.contains('collapsed') ? '68px' : '246px');
    }

    toggle.addEventListener('click', function () {
        if (window.innerWidth <= 768) {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('show');
            return;
        }
        const collapsed = sidebar.classList.toggle('collapsed');
        if (main) main.classList.toggle('sidebar-collapsed', collapsed);
        toggle.classList.toggle('collapsed', collapsed);
        updateTogglePosition();
    });

    overlay.addEventListener('click', function () {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('show');
    });

    document.querySelectorAll('.cashier-sidebar .sidebar-link').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('show');
            }
        });
    });

    window.addEventListener('resize', updateTogglePosition);
    updateTogglePosition();
});
</script>
