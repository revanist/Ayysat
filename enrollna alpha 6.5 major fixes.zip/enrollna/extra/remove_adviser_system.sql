-- EYYSAT 6.5 - Remove legacy adviser system
-- The application no longer creates or reads teacher_sections or teacher_announcements.
-- Run this only after confirming those legacy tables are no longer needed.
DROP TABLE IF EXISTS teacher_sections;
DROP TABLE IF EXISTS teacher_announcements;
