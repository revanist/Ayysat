<?php
$current = basename($_SERVER['PHP_SELF']);
$name = htmlspecialchars($_SESSION['fullname'] ?? 'Teacher');
function teacher_active(string $file, string $current): string
{
  return $current === $file ? ' active' : '';
}
?>
<aside class="admin-sidebar" id="teacherSidebar">
  <div class="sidebar-brand">
    <div class="sidebar-logo"><img src="../img/eyysat.png" alt="EYYSAT Logo"></div>
    <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>TEACHER LMS</span></div>
  </div>
  <nav class="sidebar-nav" aria-label="Teacher navigation">
    <p class="sidebar-label">TEACHING</p>
    <a class="sidebar-link<?= teacher_active('teacher_dashboard.php', $current) ?>" href="teacher_dashboard.php"><span
        class="sidebar-icon">⌂</span><span class="sidebar-text">Dashboard</span></a>
    <a class="sidebar-link<?= teacher_active('classes.php', $current) ?>" href="classes.php"><span
        class="sidebar-icon">▦</span><span class="sidebar-text">My Classes</span></a>
    <a class="sidebar-link<?= teacher_active('announcements.php', $current) ?>" href="announcements.php"><span
        class="sidebar-icon">!</span><span class="sidebar-text">Announcements</span></a>
    <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
    <a class="sidebar-link sidebar-logout" href="../auth/logout.php"><span class="sidebar-icon">↪</span><span
        class="sidebar-text">Logout</span></a>
  </nav>
  <div class="sidebar-profile">
    <div class="profile-avatar">
      <?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'T', 0, 1))) ?>
    </div>

    <div class="profile-info">
      <strong><?= $name ?></strong>
      <span>Teacher</span>
    </div>
  </div>
  
</aside>
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Toggle navigation"></button>
<script>
  document.addEventListener('DOMContentLoaded', 
  () => {const s = document.getElementById('teacherSidebar'), 
  t = document.getElementById('sidebarToggle'), 
  o = document.getElementById('sidebarOverlay'), 
  m = document.querySelector('.dashboard-main'); 
  if (!s || !t) 
    return; 
  const pos = () => t.style.left = innerWidth <= 768 ? '18px' : (s.classList.contains('collapsed') ? '68px' : '246px'); 
  t.onclick = () => {if (innerWidth <= 768) {s.classList.toggle('mobile-open'); 
  o.classList.toggle('show'); return } s.classList.toggle('collapsed'); 
  m?.classList.toggle('sidebar-collapsed'); t.classList.toggle('collapsed'); pos()}; 
  o?.addEventListener('click', () => {s.classList.remove('mobile-open'); 
  o.classList.remove('show')}); addEventListener('resize', pos); pos()});
</script>