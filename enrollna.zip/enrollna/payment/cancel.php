<?php
$status = isset($_GET['status']) ? htmlspecialchars($_GET['status']) : 'unknown';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Cancelled</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f4f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .card {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .icon {
            font-size: 60px;
            color: #ef4444;
            margin-bottom: 20px;
        }
        h2 { color: #111827; margin: 0 0 10px; }
        p { color: #4b5563; margin-bottom: 20px; }
        .btn {
            background: #e5e7eb;
            color: #374151;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.2s;
            display: inline-block;
        }
        .btn:hover { background: #d1d5db; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">✕</div>
        <h2>Payment Incomplete</h2>
        <p>The transaction was <strong><?= $status ?></strong> or failed to process.</p>
        <a href="index.php" class="btn">Return to Test Page</a>
    </div>
</body>
</html>
