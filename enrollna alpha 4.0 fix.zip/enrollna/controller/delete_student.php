<?php
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();
require_admin_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/students.php', true, 303);
    exit;
}

require __DIR__ . '/../db/dbconn.php';

$studentId = (int) ($_POST['id'] ?? 0);
if ($studentId < 1) {
    http_response_code(400);
    exit('Invalid student ID.');
}

mysqli_begin_transaction($conn);

try {
    // Capture the linked login account before deleting the student.
    $userId = null;
    $lookup = mysqli_prepare($conn, 'SELECT user_id FROM students WHERE id = ? FOR UPDATE');
    if (!$lookup) { throw new RuntimeException('Unable to prepare student lookup.'); }
    mysqli_stmt_bind_param($lookup, 'i', $studentId);
    mysqli_stmt_execute($lookup);
    mysqli_stmt_bind_result($lookup, $userId);
    mysqli_stmt_fetch($lookup);
    mysqli_stmt_close($lookup);

    // Remove records that reference the student/enrollment first.
    // Payments belong to the student and/or enrollment. Delete both links so
    // paid and unpaid students can be removed without payment records blocking deletion.
    $payments = mysqli_prepare($conn, '
        DELETE p FROM payments AS p
        LEFT JOIN enrollments AS e ON e.id = p.enrollment_id
        WHERE p.student_id = ? OR e.student_id = ?
    ');
    if (!$payments) { throw new RuntimeException('Unable to prepare payment deletion.'); }
    mysqli_stmt_bind_param($payments, 'ii', $studentId, $studentId);
    if (!mysqli_stmt_execute($payments)) { throw new RuntimeException('Unable to delete payment records.'); }
    mysqli_stmt_close($payments);

    // Remove all admin notifications tied to this student's enrollments.
    // Use a multi-table DELETE instead of an IN subquery so this also works
    // reliably on older MySQL/MariaDB versions.
    $notifications = mysqli_prepare($conn, '
        DELETE n FROM admin_notifications AS n
        INNER JOIN enrollments AS e ON e.id = n.enrollment_id
        WHERE e.student_id = ?
    ');
    if (!$notifications) { throw new RuntimeException('Unable to prepare notification deletion.'); }
    mysqli_stmt_bind_param($notifications, 'i', $studentId);
    if (!mysqli_stmt_execute($notifications)) { throw new RuntimeException('Unable to delete notifications.'); }
    mysqli_stmt_close($notifications);

    $details = mysqli_prepare($conn, '
        DELETE enrollment_details
        FROM enrollment_details
        INNER JOIN enrollments ON enrollments.id = enrollment_details.enrollment_id
        WHERE enrollments.student_id = ?
    ');
    if (!$details) { throw new RuntimeException('Unable to prepare enrollment detail deletion.'); }
    mysqli_stmt_bind_param($details, 'i', $studentId);
    if (!mysqli_stmt_execute($details)) { throw new RuntimeException('Unable to delete enrollment details.'); }
    mysqli_stmt_close($details);

    $enrollments = mysqli_prepare($conn, 'DELETE FROM enrollments WHERE student_id = ?');
    if (!$enrollments) { throw new RuntimeException('Unable to prepare enrollment deletion.'); }
    mysqli_stmt_bind_param($enrollments, 'i', $studentId);
    if (!mysqli_stmt_execute($enrollments)) { throw new RuntimeException('Unable to delete enrollments.'); }
    mysqli_stmt_close($enrollments);

    $student = mysqli_prepare($conn, 'DELETE FROM students WHERE id = ?');
    mysqli_stmt_bind_param($student, 'i', $studentId);
    if (!mysqli_stmt_execute($student)) { throw new RuntimeException('Unable to delete student.'); }
    $deleted = mysqli_stmt_affected_rows($student);
    mysqli_stmt_close($student);

    if ($deleted !== 1) {
        throw new RuntimeException('Student not found.');
    }

    // A student login is owned by the student record in this application.
    // Delete it after the student so an orphaned student account is not left behind.
    if ($userId !== null && (int) $userId > 0) {
        $user = mysqli_prepare($conn, "DELETE FROM users WHERE id = ? AND role = 'student'");
        if (!$user) { throw new RuntimeException('Unable to prepare user deletion.'); }
        $userIdInt = (int) $userId;
        mysqli_stmt_bind_param($user, 'i', $userIdInt);
        if (!mysqli_stmt_execute($user)) { throw new RuntimeException('Unable to delete student account.'); }
        mysqli_stmt_close($user);
    }

    mysqli_commit($conn);
    header('Location: ../admin/students.php?deleted=1', true, 303);
    exit;
} catch (Throwable $exception) {
    mysqli_rollback($conn);
    http_response_code(500);
    exit('Unable to delete the student.');
}
