<?php
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();
require __DIR__ . '/../db/dbconn.php';

$userId = (int) $_SESSION['user_id'];
$studentStmt = mysqli_prepare($conn, '
    SELECT st.*, e.id AS enrollment_id, e.year_level AS enrollment_year_level,
           e.sem AS enrollment_semester, e.school_year,
           e.status AS enrollment_status_record, co.course_name, co.course_code,
           se.section_name
    FROM students st
    LEFT JOIN enrollments e ON e.id = (
        SELECT e2.id FROM enrollments e2
        WHERE e2.student_id = st.id
        ORDER BY e2.created DESC, e2.id DESC LIMIT 1
    )
    LEFT JOIN courses co ON co.id = COALESCE(e.course_id, st.course_id)
    LEFT JOIN sections se ON se.id = COALESCE(e.section_id, st.section_id)
    WHERE st.user_id = ? LIMIT 1
');
mysqli_stmt_bind_param($studentStmt, 'i', $userId);
mysqli_stmt_execute($studentStmt);
$student = mysqli_fetch_assoc(mysqli_stmt_get_result($studentStmt));
mysqli_stmt_close($studentStmt);

if (!$student) {
    http_response_code(404);
    exit('Registration details not found. Please enroll first.');
}

$subjects = [];
if (!empty($student['enrollment_id'])) {
    $subjectsStmt = mysqli_prepare($conn, '
        SELECT s.subject_code, s.subject_name, s.units, s.schedule_day,
               s.schedule_time, s.room_number
        FROM enrollment_details ed
        INNER JOIN subjects s ON s.id = ed.subject_id
        WHERE ed.enrollment_id = ?
        ORDER BY s.subject_code ASC
    ');
    $enrollmentId = (int) $student['enrollment_id'];
    mysqli_stmt_bind_param($subjectsStmt, 'i', $enrollmentId);
    mysqli_stmt_execute($subjectsStmt);
    $subjectResult = mysqli_stmt_get_result($subjectsStmt);
    while ($subject = mysqli_fetch_assoc($subjectResult)) {
        $subjects[] = $subject;
    }
    mysqli_stmt_close($subjectsStmt);
}

function registration_value($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

$fullName = trim(implode(' ', array_filter([
    $student['first_name'] ?? '', $student['middle_name'] ?? '', $student['last_name'] ?? '',
])));
$yearLevel = (int) ($student['enrollment_year_level'] ?? $student['year_level'] ?? 0);
$semester = (int) ($student['enrollment_semester'] ?? 0);
$yearLabel = $yearLevel > 0 ? $yearLevel . ($yearLevel === 1 ? 'st' : ($yearLevel === 2 ? 'nd' : ($yearLevel === 3 ? 'rd' : 'th'))) . ' Year' : '—';
$semesterLabel = $semester === 1 ? '1st Semester' : ($semester === 2 ? '2nd Semester' : '—');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Official Registration Form</title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; margin: 0; padding: 32px; background: #f4f7fb; color: #172033; }
        .form-container { background: #fff; border: 1px solid #d6deea; max-width: 1000px; margin: 0 auto; padding: 36px; }
        .header { text-align: center; border-bottom: 3px solid #123d68; padding-bottom: 18px; margin-bottom: 28px; }
        .header h1 { margin: 0; font-size: 24px; color: #123d68; text-transform: uppercase; }
        .header p { margin: 7px 0 0; color: #475569; }
        .section { margin-top: 26px; }
        .section-title { background: #eef5fc; border-left: 5px solid #1e5a96; color: #123d68; font-size: 15px; font-weight: 700; padding: 10px; margin-bottom: 14px; }
        .details { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px 30px; }
        .info-row { border-bottom: 1px solid #cdd7e4; padding: 5px 0; }
        .info-label { display: block; color: #475569; font-size: 12px; font-weight: 700; margin-bottom: 3px; }
        .info-value { min-height: 18px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { border: 1px solid #bfcbd9; padding: 9px; text-align: left; vertical-align: top; }
        th { background: #123d68; color: #fff; }
        .empty { color: #64748b; text-align: center; }
        .print-btn { display: block; margin: 30px auto 0; padding: 10px 18px; background: #1e5a96; color: #fff; border: 0; border-radius: 4px; cursor: pointer; font-size: 14px; }
        @media print { body { background: #fff; padding: 0; } .form-container { border: 0; max-width: 100%; } .print-btn { display: none; } }
        @media (max-width: 650px) { body { padding: 12px; } .form-container { padding: 20px; } .details { grid-template-columns: 1fr; } table { font-size: 11px; } th, td { padding: 6px; } }
    </style>
</head>
<body>
    <main class="form-container">
        <header class="header"><h1>Official Registration Form</h1><p>EYYSAT Academy</p></header>

        <section class="section">
            <div class="section-title">Student Information</div>
            <div class="details">
                <div class="info-row"><span class="info-label">Student Name</span><div class="info-value"><?= registration_value($fullName ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Student ID</span><div class="info-value"><?= registration_value($student['student_number'] ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Address</span><div class="info-value"><?= registration_value($student['address'] ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Contact Number</span><div class="info-value"><?= registration_value($student['contact'] ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Email Address</span><div class="info-value"><?= registration_value($student['email'] ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Enrollment Status</span><div class="info-value"><?= registration_value($student['enrollment_status_record'] ?? $student['enrollment_status'] ?? 'Pending') ?></div></div>
            </div>
        </section>

        <section class="section">
            <div class="section-title">Academic Details</div>
            <div class="details">
                <div class="info-row"><span class="info-label">Course</span><div class="info-value"><?= registration_value(($student['course_code'] ?? '') . (!empty($student['course_name']) ? ' — ' . $student['course_name'] : '')) ?></div></div>
                <div class="info-row"><span class="info-label">Section</span><div class="info-value"><?= registration_value($student['section_name'] ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Year Level</span><div class="info-value"><?= registration_value($yearLabel) ?></div></div>
                <div class="info-row"><span class="info-label">Semester</span><div class="info-value"><?= registration_value($semesterLabel) ?></div></div>
                <div class="info-row"><span class="info-label">School Year</span><div class="info-value"><?= registration_value($student['school_year'] ?: '—') ?></div></div>
                <div class="info-row"><span class="info-label">Subjects Registered</span><div class="info-value"><?= count($subjects) ?></div></div>
            </div>
        </section>

        <section class="section">
            <div class="section-title">Registered Curriculum</div>
            <table>
                <thead><tr><th>Subject Code</th><th>Subject Name</th><th>Units</th><th>Day</th><th>Time</th><th>Room</th></tr></thead>
                <tbody>
                    <?php if ($subjects): ?>
                        <?php foreach ($subjects as $subject): ?>
                            <tr>
                                <td><?= registration_value($subject['subject_code']) ?></td><td><?= registration_value($subject['subject_name']) ?></td><td><?= registration_value($subject['units'] ?? '—') ?></td><td><?= registration_value($subject['schedule_day'] ?: 'TBA') ?></td><td><?= registration_value($subject['schedule_time'] ?: 'TBA') ?></td><td><?= registration_value($subject['room_number'] ?: 'TBA') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td class="empty" colspan="6">No registered curriculum subjects found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>

        <button class="print-btn" type="button" onclick="window.print()">Print Registration Form</button>
    </main>
</body>
</html>
