<?php require __DIR__.'/teacher_bootstrap.php'; require_once __DIR__.'/../functions/teacher_academic.php';
$aid=(int)($_GET['assignment_id']??0);$class=teacher_class_assignment($conn,$aid,$teacherId);if(!$class){http_response_code(404);exit('Class not found or not assigned to you.');}
$roster=teacher_roster($conn,$class);$q=mysqli_prepare($conn,"SELECT * FROM lms_materials WHERE assignment_id=? ORDER BY created_at DESC");mysqli_stmt_bind_param($q,'i',$aid);mysqli_stmt_execute($q);$materials=mysqli_stmt_get_result($q);$q=mysqli_prepare($conn,"SELECT * FROM lms_announcements WHERE assignment_id=? ORDER BY publish_at DESC");mysqli_stmt_bind_param($q,'i',$aid);mysqli_stmt_execute($q);$ann=mysqli_stmt_get_result($q);$q=mysqli_prepare($conn,"SELECT a.*,COUNT(s.id) submission_count,SUM(s.status IN ('Submitted','Graded','Returned')) submitted_count FROM lms_activities a LEFT JOIN lms_submissions s ON s.activity_id=a.id WHERE a.assignment_id=? GROUP BY a.id ORDER BY (a.due_at IS NULL),a.due_at DESC,a.created_at DESC");mysqli_stmt_bind_param($q,'i',$aid);mysqli_stmt_execute($q);$activities=mysqli_stmt_get_result($q);$msg=$_GET['msg']??'';$err=$_GET['error']??'';
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=htmlspecialchars($class['subject_code'])?> | EYYSAT LMS</title><link rel="stylesheet" href="../css/admin_dashboard.css"><link rel="stylesheet" href="../css/teacher.css"></head><body><?php include __DIR__.'/../sidebar/sidebar.php';?><main class="dashboard-main">
<section class="teacher-hero"><div><div class="teacher-eyebrow"><?=htmlspecialchars($class['course_code'])?> · <?=htmlspecialchars($class['section_name'])?></div><h1><?=htmlspecialchars($class['subject_code'])?> — <?=htmlspecialchars($class['subject_name'])?></h1><p><?=htmlspecialchars($class['schedule_day']??'Schedule TBA')?> · <?=htmlspecialchars($class['schedule_time']??'')?> · <?=htmlspecialchars($class['room_number']??'Room TBA')?> · <?=intval($class['units'])?> units</p></div><div class="teacher-hero-meta"><span class="teacher-meta-chip"><?=mysqli_num_rows($roster)?> students</span><span class="teacher-meta-chip">SY <?=htmlspecialchars($class['school_year'])?></span><span class="teacher-meta-chip"><?=$class['semester']==1?'1st':'2nd'?> Semester</span></div></section>
<nav class="teacher-tabs"><a class="teacher-tab active" href="class.php?assignment_id=<?=$aid?>">Overview</a><a class="teacher-tab" href="activities.php?assignment_id=<?=$aid?>">Curriculum</a><a class="teacher-tab" href="attendance.php?assignment_id=<?=$aid?>">Attendance</a><a class="teacher-tab" href="grades.php?assignment_id=<?=$aid?>">Gradebook</a><a class="teacher-tab" href="reports.php?assignment_id=<?=$aid?>">Performance</a><a class="teacher-tab" href="class_students.php?assignment_id=<?=$aid?>">Students</a></nav>
<?php if($msg):?><div class="notice"><?=htmlspecialchars($msg)?></div><?php endif;?><?php if($err):?><div class="notice error"><?=htmlspecialchars($err)?></div><?php endif;?>
<section class="teacher-grid"><div class="teacher-panel"><div class="teacher-panel-head"><div><h2>Class stream</h2><div class="teacher-panel-sub">Announcements and learning updates for this section.</div></div><a class="teacher-btn" href="announcements.php">Manage announcements</a></div><form method="post" action="post_announcement.php"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(teacher_csrf_token())?>"><input type="hidden" name="assignment_id" value="<?=$aid?>"><div class="field"><label>Title</label><input name="title" maxlength="180" required></div><div class="field" style="margin-top:10px"><label>Message</label><textarea name="body" rows="4" required></textarea></div><button class="teacher-btn primary" type="submit" style="margin-top:10px">Publish announcement</button></form><div class="stream-list"><?php while($a=mysqli_fetch_assoc($ann)):?><article class="stream-item"><strong><?=htmlspecialchars($a['title'])?></strong><small><?=htmlspecialchars(date('M d, Y g:i A',strtotime($a['publish_at'])))?></small><p><?=nl2br(htmlspecialchars($a['body']))?></p></article><?php endwhile;if(mysqli_num_rows($ann)===0):?><div class="teacher-empty">No announcements yet.</div><?php endif;?></div></div>
<div class="teacher-panel"><div class="teacher-panel-head"><div><h2>Quick actions</h2><div class="teacher-panel-sub">Common tasks for this class.</div></div></div><div class="quick-action-grid"><a href="activities.php?assignment_id=<?=$aid?>" class="quick-action"><strong>+ Activity</strong><small>Create assignment, quiz, project, or exam</small></a><a href="attendance.php?assignment_id=<?=$aid?>" class="quick-action"><strong>✓ Attendance</strong><small>Mark today's attendance</small></a><a href="grades.php?assignment_id=<?=$aid?>" class="quick-action"><strong>▣ Gradebook</strong><small>Record student grades</small></a><a href="class_students.php?assignment_id=<?=$aid?>" class="quick-action"><strong>♙ Students</strong><small>View class roster</small></a></div></div></section>
<section class="teacher-panel"><div class="teacher-panel-head"><div><h2>Activities</h2><div class="teacher-panel-sub">Assessments and student submissions for this class.</div></div><a class="teacher-btn primary" href="activities.php?assignment_id=<?=$aid?>">Manage activities</a></div>
<div class="activity-list">
<?php
$activitiesByPeriod = ['Prelim'=>[],'Midterm'=>[],'Pre-Final'=>[],'Final'=>[],'General'=>[]];
while($a=mysqli_fetch_assoc($activities)) {
    $gp = $a['grading_period'] ?? 'General';
    if (!isset($activitiesByPeriod[$gp])) $activitiesByPeriod[$gp] = [];
    $activitiesByPeriod[$gp][] = $a;
}
$isEmpty = true;
foreach($activitiesByPeriod as $period => $acts):
    if(count($acts)===0) continue;
    $isEmpty = false;
?>
<div style="margin: 24px 0 12px; padding-bottom: 8px; border-bottom: 1px solid var(--teacher-border-soft);">
    <h3 style="color: var(--teacher-gold); margin: 0; font-size: 1.05rem; letter-spacing: 0.03em;"><?=htmlspecialchars($period)?></h3>
</div>
<?php foreach($acts as $a): ?>
<a class="activity-row" href="activity.php?id=<?=$a['id']?>"><div><span class="activity-type"><?=htmlspecialchars($a['activity_type'])?></span><h3 style="margin:6px 0; color:#fff; font-size:1rem; font-weight:700;"><?=htmlspecialchars($a['title'])?></h3><small><?=htmlspecialchars($a['status'])?> · Max <?=number_format((float)$a['max_score'],2)?> points</small></div><div class="activity-meta"><strong><?=intval($a['submission_count'])?></strong><small>submissions</small><span><?= $a['due_at']?htmlspecialchars(date('M d, Y g:i A',strtotime($a['due_at']))):'No due date'?></span></div></a>
<?php endforeach; endforeach; ?>
<?php if($isEmpty):?><div class="teacher-empty">No activities yet. Create your first Prelim or Midterm activity above.</div><?php endif;?>
</div></section>
<section class="teacher-grid"><div class="teacher-panel"><div class="teacher-panel-head"><div><h2>Learning materials</h2><div class="teacher-panel-sub">Resources available to this class.</div></div></div><form method="post" action="upload_material.php" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(teacher_csrf_token())?>"><input type="hidden" name="assignment_id" value="<?=$aid?>"><div class="form-grid"><div class="field"><label>Title</label><input name="title" maxlength="180" required></div><div class="field"><label>Grading Period</label><select name="grading_period"><option>Prelim</option><option>Midterm</option><option>Pre-Final</option><option>Final</option><option selected>General</option></select></div><div class="field full"><label>File</label><input type="file" name="material" required></div><div class="field full"><label>Description</label><textarea name="description" rows="3"></textarea></div></div><button class="teacher-btn primary" type="submit" style="margin-top:12px;">Upload material</button></form>
<div class="material-list">
<?php
$materialsByPeriod = ['Prelim'=>[],'Midterm'=>[],'Pre-Final'=>[],'Final'=>[],'General'=>[]];
while($m=mysqli_fetch_assoc($materials)) {
    $gp = $m['grading_period'] ?? 'General';
    if (!isset($materialsByPeriod[$gp])) $materialsByPeriod[$gp] = [];
    $materialsByPeriod[$gp][] = $m;
}
$isMatEmpty = true;
foreach($materialsByPeriod as $period => $mats):
    if(count($mats)===0) continue;
    $isMatEmpty = false;
?>
<div style="margin: 24px 0 12px; padding-bottom: 8px; border-bottom: 1px solid var(--teacher-border-soft);">
    <h3 style="color: var(--teacher-gold); margin: 0; font-size: 1.05rem; letter-spacing: 0.03em;"><?=htmlspecialchars($period)?></h3>
</div>
<?php foreach($mats as $m): ?>
<div class="material-row"><div><strong><?=htmlspecialchars($m['title'])?></strong><small><?=htmlspecialchars($m['description']??'')?></small></div><a class="teacher-btn" href="download.php?id=<?=$m['id']?>">Download</a></div>
<?php endforeach; endforeach; ?>
<?php if($isMatEmpty):?><div class="teacher-empty">No materials uploaded yet.</div><?php endif;?>
</div></div><div class="teacher-panel"><div class="teacher-panel-head"><div><h2>Class snapshot</h2><div class="teacher-panel-sub">Current academic indicators.</div></div></div><div class="snapshot-grid"><div><strong><?=mysqli_num_rows($roster)?></strong><span>Students</span></div><div><strong><?=mysqli_num_rows($activities)?></strong><span>Activities</span></div><div><strong><?=mysqli_num_rows($materials)?></strong><span>Materials</span></div></div></div></section>
</main></body></html>
