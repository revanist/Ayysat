<?php
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();

include '../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';

ensure_enrollment_schema($conn);


/* =========================================================
   ENROLLMENT RECORDS
========================================================= */

$query = mysqli_query($conn, "
    SELECT 
        enrollments.id, 
        students.student_number, 
        students.first_name, 
        students.last_name, 
        courses.course_code, 
        enrollments.school_year, 
        enrollments.sem, 
        enrollments.STATUS, 
        enrollments.amount_paid, 
        enrollments.created 
    FROM enrollments 
    INNER JOIN students 
        ON enrollments.student_id = students.id 
    LEFT JOIN courses  
        ON students.course_id = courses.id 
    ORDER BY enrollments.created DESC
");


/* =========================================================
   STATUS COUNTS
========================================================= */

$pending = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) total 
         FROM enrollments 
         WHERE STATUS='pending'"
    )
)['total'];


$approved = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) total 
         FROM enrollments 
         WHERE STATUS='approved'"
    )
)['total'];


$rejected = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) total 
         FROM enrollments 
         WHERE STATUS='rejected'"
    )
)['total'];


/* =========================================================
   CSRF
========================================================= */

$csrf = admin_csrf_token();


/* =========================================================
   ADMIN NAME
========================================================= */

$adminName = htmlspecialchars(
    $_SESSION['admin_name'] ?? 'Admin'
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Enrollment Management – EYYSAT</title>

    <link
        rel="stylesheet"
        href="../css/admin_dashboard.css">

    <script
        src="../js/sweetalert2.all.min.js">
    </script>

    <script
        src="../js/swal-confirm.js"
        defer>
    </script>

    <style>
        /* =====================================================
           ENROLLMENT PAGE UX
        ===================================================== */

        .page-header {
            margin-bottom: 26px;
        }

        .page-header .topbar-label {
            display: block;
            margin-bottom: 5px;
        }

        .page-header h1 {
            margin: 0;
            color: #ffffff;
            font-size: clamp(1.8rem, 3vw, 2.4rem);
            font-weight: 900;
            line-height: 1.1;
        }

        .page-header p {
            margin-top: 8px;
            color: var(--text-muted);
            font-size: 0.9rem;
            line-height: 1.5;
        }


        /* =====================================================
           TABLE HEADER
        ===================================================== */

        .table-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 20px;
        }

        .table-header h2 {
            margin: 0;
            color: var(--eyysat-gold);
            font-size: 1.05rem;
            font-weight: 800;
        }


        /* =====================================================
           SEARCH
        ===================================================== */

        .search-box {
            width: 250px;
            max-width: 100%;
            padding: 11px 15px;
            border: 1px solid rgba(244, 211, 94, 0.2);
            border-radius: 10px;
            outline: none;
            background: rgba(4, 18, 33, 0.7);
            color: #ffffff;
            font-family: inherit;
            font-size: 0.82rem;
            transition:
                border-color 0.25s ease,
                box-shadow 0.25s ease,
                background 0.25s ease;
        }

        .search-box::placeholder {
            color: var(--text-dim);
        }

        .search-box:focus {
            border-color: var(--eyysat-gold);
            background: rgba(4, 18, 33, 0.9);
            box-shadow: 0 0 0 3px rgba(244, 211, 94, 0.08);
        }


        /* =====================================================
           MODERN TABLE
        ===================================================== */

        .modern-table {
            width: 100%;
            min-width: 950px;
            border-collapse: separate;
            border-spacing: 0;
        }

        .modern-table thead th {
            padding: 14px 14px;
            background: rgba(6, 26, 48, 0.85);
            color: var(--eyysat-gold);
            text-align: left;
            font-size: 0.72rem;
            font-weight: 800;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            white-space: nowrap;
            border-bottom: 1px solid rgba(244, 211, 94, 0.12);
        }

        .modern-table thead th:first-child {
            border-radius: 10px 0 0 0;
        }

        .modern-table thead th:last-child {
            border-radius: 0 10px 0 0;
        }

        .modern-table tbody td {
            padding: 14px;
            color: var(--text-secondary);
            font-size: 0.84rem;
            border-bottom: 1px solid rgba(244, 211, 94, 0.07);
            white-space: nowrap;
        }

        .modern-table tbody tr {
            transition:
                background 0.2s ease,
                transform 0.2s ease;
        }

        .modern-table tbody tr:hover {
            background: rgba(244, 211, 94, 0.055);
        }


        /* =====================================================
           ACTION BUTTONS
        ===================================================== */

        .action-buttons {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 7px;
        }

        .action-buttons form {
            margin: 0;
        }

        .btn-view,
        .btn-edit,
        .btn-delete {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 34px;
            padding: 7px 12px;
            border-radius: 8px;
            border: 1px solid transparent;
            font-family: inherit;
            font-size: 0.74rem;
            font-weight: 800;
            text-decoration: none;
            cursor: pointer;
            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease,
                background 0.2s ease;
        }

        .btn-view {
            color: #ffffff;
            background: rgba(30, 90, 150, 0.75);
            border-color: rgba(96, 165, 250, 0.25);
        }

        .btn-view:hover {
            color: #ffffff;
            background: #1e5a96;
            transform: translateY(-1px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.25);
        }

        .btn-edit {
            color: #071d34;
            background: linear-gradient(135deg,
                    var(--eyysat-orange),
                    var(--eyysat-gold));
        }

        .btn-edit:hover {
            transform: translateY(-1px);
            box-shadow: 0 5px 14px rgba(244, 211, 94, 0.2);
        }

        .btn-delete {
            color: #ffffff;
            background: rgba(127, 29, 29, 0.75);
            border-color: rgba(248, 113, 113, 0.25);
        }

        .btn-delete:hover {
            background: rgba(185, 28, 28, 0.9);
            transform: translateY(-1px);
            box-shadow: 0 5px 12px rgba(0, 0, 0, 0.25);
        }

        .completed-text {
            color: var(--text-dim);
            font-size: 0.74rem;
            font-weight: 700;
        }


        /* =====================================================
           STATUS BADGES
        ===================================================== */

        .status-approved,
        .status-pending,
        .status-rejected {
            display: inline-flex;
            align-items: center;
            min-height: 25px;
            padding: 4px 9px;
            border-radius: 999px;
            font-size: 0.7rem;
            font-weight: 800;
        }

        .status-approved {
            color: var(--success);
            background: rgba(74, 222, 128, 0.08);
        }

        .status-pending {
            color: var(--warning);
            background: rgba(250, 204, 21, 0.08);
        }

        .status-rejected {
            color: var(--danger);
            background: rgba(248, 113, 113, 0.08);
        }


        /* =====================================================
           TABLE SCROLL
        ===================================================== */

        .table-scroll {
            width: 100%;
            overflow-x: auto;
            scrollbar-width: thin;
        }


        /* =====================================================
           EMPTY TABLE
        ===================================================== */

        .empty-enrollments {
            padding: 45px 20px !important;
            text-align: center;
            color: var(--text-dim) !important;
        }


        /* =====================================================
           MOBILE PAGE HEADER
        ===================================================== */

        @media (max-width: 768px) {

            .page-header {
                padding-left: 54px;
            }

            .table-header {
                align-items: stretch;
                flex-direction: column;
            }

            .search-box {
                width: 100%;
            }

            .modern-table {
                min-width: 950px;
            }

        }


        @media (max-width: 480px) {

            .page-header {
                padding-left: 54px;
            }

            .page-header h1 {
                font-size: 1.6rem;
            }

            .page-header p {
                font-size: 0.8rem;
            }

        }
    </style>

<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>


<body>


    <!-- =========================================================
     SIDEBAR
========================================================= -->

    <aside
        class="admin-sidebar"
        id="adminSidebar">


        <!-- BRAND -->

        <div class="sidebar-brand">

            <div class="sidebar-logo">

                <a href="admin_dashboard.php">

                    <img
                        src="../img/eyysat.png"
                        alt="EYYSAT Logo">

                </a>

            </div>


            <div class="sidebar-brand-text">

                <strong>
                    EYYSAT
                </strong>

                <span>
                    ADMIN PANEL
                </span>

            </div>

        </div>


        <!-- =====================================================
         NAVIGATION
    ====================================================== -->

        <?php
$sidebarUnreadCount = 0;
if (isset($conn)) {
    $sidebarNotifResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM admin_notifications WHERE is_read = 0");
    if ($sidebarNotifResult) { $sidebarUnreadCount = (int) (mysqli_fetch_assoc($sidebarNotifResult)['total'] ?? 0); }
}
?>
        <nav class="sidebar-nav">


            <p class="sidebar-label">
                MAIN MENU
            </p>


            <a
                href="admin_dashboard.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#127968;
                </span>

                <span class="sidebar-text">
                    Dashboard
                </span>

            </a>


            <a
                href="students.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#127891;
                </span>

                <span class="sidebar-text">
                    Students
                </span>

            </a>


            <a
                href="courses.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128218;
                </span>

                <span class="sidebar-text">
                    Courses
                </span>

            </a>


            <!-- ACTIVE ENROLLMENTS -->

            <a
                href="enrollments.php"
                class="sidebar-link active">

                <span class="sidebar-icon">
                    &#128214;
                </span>

                <span class="sidebar-text">
                    Enrollments
                </span>

            </a>


            <!-- CASHIER -->

            <a
                href="cashier.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128176;
                </span>

                <span class="sidebar-text">
                    Cashier
                </span>

            </a>
            <a href="notifications.php" class="sidebar-link"><span class="sidebar-icon">&#128276;</span><span class="sidebar-text">Notifications</span><?php if (($sidebarUnreadCount ?? 0) > 0): ?><span class="sidebar-notification-badge"><?= ($sidebarUnreadCount ?? 0) > 99 ? '99+' : ($sidebarUnreadCount ?? 0) ?></span><?php endif; ?></a>


            <p class="sidebar-label sidebar-label-bottom">
                ACCOUNT
            </p>


            <a
                href="../auth/admin_logout.php"
                class="sidebar-link sidebar-logout">

                <span class="sidebar-icon">
                    &#128682;
                </span>

                <span class="sidebar-text">
                    Logout
                </span>

            </a>


        </nav>


        <!-- =====================================================
         PROFILE
    ====================================================== -->

        <div class="sidebar-profile">

            <div class="profile-avatar">

                <?= strtoupper(
                    substr($adminName, 0, 1)
                ) ?>

            </div>


            <div class="profile-info">

                <strong>
                    <?= $adminName ?>
                </strong>

                <span>
                    Administrator
                </span>

            </div>

        </div>


    </aside>


    <!-- =========================================================
     MOBILE OVERLAY
========================================================= -->

    <div
        class="sidebar-overlay"
        id="sidebarOverlay">
    </div>


    <!-- =========================================================
     MAIN DASHBOARD
========================================================= -->

    <main
        class="dashboard-main"
        id="dashboardMain">


        <!-- =====================================================
         SIDEBAR TOGGLE
    ====================================================== -->

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
            aria-label="Toggle sidebar">
        </button>


        <!-- =====================================================
         PAGE HEADER
    ====================================================== -->

        <header class="page-header">

            <span class="topbar-label">
                ENROLLMENT MANAGEMENT
            </span>

            <h1>
                Enrollment Management
            </h1>

            <p>
                Review enrollment records and payment progress.
            </p>

        </header>


        <!-- =====================================================
         STATUS STATS
    ====================================================== -->

        <section class="stats-row">


            <!-- PENDING -->

            <div class="stat-card stat-warning">

                <div class="stat-icon">
                    ⏳
                </div>

                <h3>
                    Pending
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $pending ?>">

                    <?= $pending ?>

                </span>

            </div>


            <!-- APPROVED -->

            <div class="stat-card stat-success">

                <div class="stat-icon">
                    ✅
                </div>

                <h3>
                    Approved
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $approved ?>">

                    <?= $approved ?>

                </span>

            </div>


            <!-- REJECTED -->

            <div
                class="stat-card"
                style="border-top-color:#ef4444;">

                <div class="stat-icon">
                    ❌
                </div>

                <h3>
                    Rejected
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $rejected ?>">

                    <?= $rejected ?>

                </span>

            </div>


        </section>


        <!-- =====================================================
         ENROLLMENT RECORDS
    ====================================================== -->

        <section class="card">


            <!-- TABLE HEADER -->

            <div class="table-header">

                <h2>
                    Enrollment Records
                </h2>


                <input
                    type="text"
                    id="searchInput"
                    class="search-box"
                    placeholder="🔍 Search student…"
                    autocomplete="off">

            </div>


            <!-- TABLE -->

            <div class="table-scroll">

                <table
                    class="modern-table"
                    id="enrollTable">


                    <thead>

                        <tr>

                            <th>
                                ID
                            </th>

                            <th>
                                Student No.
                            </th>

                            <th>
                                Name
                            </th>

                            <th>
                                Course
                            </th>

                            <th>
                                School Year
                            </th>

                            <th>
                                Sem
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                        <?php

                        $hasRows = false;

                        while ($row = mysqli_fetch_assoc($query)) {

                            $hasRows = true;

                            $status = strtolower(
                                $row['STATUS']
                            );

                            $isEnrolled = $status === 'enrolled';

                        ?>

                            <tr>


                                <!-- ID -->

                                <td>

                                    <?= (int) $row['id'] ?>

                                </td>


                                <!-- STUDENT NUMBER -->

                                <td>

                                    <?= htmlspecialchars(
                                        $row['student_number']
                                    ) ?>

                                </td>


                                <!-- NAME -->

                                <td>

                                    <?= htmlspecialchars(
                                        $row['first_name']
                                            . ' '
                                            . $row['last_name']
                                    ) ?>

                                </td>


                                <!-- COURSE -->

                                <td>

                                    <?= htmlspecialchars(
                                        $row['course_code']
                                    ) ?>

                                </td>


                                <!-- SCHOOL YEAR -->

                                <td>

                                    <?= htmlspecialchars(
                                        $row['school_year']
                                    ) ?>

                                </td>


                                <!-- SEMESTER -->

                                <td>

                                    <?= htmlspecialchars(
                                        $row['sem']
                                    ) ?>

                                </td>


                                <!-- STATUS -->

                                <td>


                                    <?php if ($isEnrolled): ?>

                                        <span
                                            class="status-approved">

                                            Enrolled

                                        </span>


                                    <?php elseif ($status === 'approved'): ?>

                                        <span
                                            class="status-approved">

                                            Approved

                                        </span>


                                    <?php elseif ($status === 'pending'): ?>

                                        <span
                                            class="status-pending">

                                            Pending

                                        </span>


                                    <?php elseif ($status === 'rejected'): ?>

                                        <span
                                            class="status-rejected">

                                            Rejected

                                        </span>

                                    <?php else: ?>

                                        <span class="status-pending">
                                            Pending
                                        </span>

                                    <?php endif; ?>


                                </td>


                                <!-- DATE -->

                                <td>

                                    <?= htmlspecialchars(
                                        date(
                                            'M d, Y',
                                            strtotime(
                                                $row['created']
                                            )
                                        )
                                    ) ?>

                                </td>


                                <!-- ACTIONS -->

                                <td>

                                    <div class="action-buttons">


                                        <!-- VIEW -->

                                        <a
                                            href="student_info.php?id=<?= (int) $row['id'] ?>"
                                            class="btn-view">

                                            View

                                        </a>


                                        <span class="completed-text">
                                            Payment status is managed by the cashier.
                                        </span>


                                    </div>

                                </td>


                            </tr>


                        <?php } ?>


                        <?php if (!$hasRows): ?>

                            <tr>

                                <td
                                    colspan="9"
                                    class="empty-enrollments">

                                    No enrollment records found.

                                </td>

                            </tr>

                        <?php endif; ?>


                    </tbody>


                </table>

            </div>


        </section>


    </main>


    <!-- =========================================================
     SCROLL TO TOP
========================================================= -->

    <button
        class="scroll-top"
        id="scrollTop"
        type="button"
        aria-label="Scroll to top">

        ↑

    </button>


    <script>
        /* =========================================================
   SIDEBAR ELEMENTS
========================================================= */

        const sidebar =
            document.getElementById(
                'adminSidebar'
            );

        const sidebarToggle =
            document.getElementById(
                'sidebarToggle'
            );

        const sidebarOverlay =
            document.getElementById(
                'sidebarOverlay'
            );

        const dashboardMain =
            document.getElementById(
                'dashboardMain'
            );


        let sidebarCollapsed = false;


        /* =========================================================
           UPDATE SIDEBAR TOGGLE POSITION
        ========================================================= */

        function updateTogglePosition() {

            if (window.innerWidth <= 768) {

                sidebarToggle.style.left =
                    '18px';

                return;

            }


            if (sidebarCollapsed) {

                sidebarToggle.style.left =
                    '68px';

            } else {

                sidebarToggle.style.left =
                    '246px';

            }

        }


        /* =========================================================
           SIDEBAR TOGGLE
        ========================================================= */

        sidebarToggle.addEventListener(
            'click',
            function() {


                /* MOBILE */

                if (
                    window.innerWidth <= 768
                ) {

                    sidebar.classList.toggle(
                        'mobile-open'
                    );

                    sidebarOverlay.classList.toggle(
                        'show'
                    );

                    return;

                }


                /* DESKTOP */

                sidebarCollapsed = !sidebarCollapsed;


                sidebar.classList.toggle(
                    'collapsed',
                    sidebarCollapsed
                );


                dashboardMain.classList.toggle(
                    'sidebar-collapsed',
                    sidebarCollapsed
                );


                sidebarToggle.classList.toggle(
                    'collapsed',
                    sidebarCollapsed
                );


                updateTogglePosition();

            }
        );


        /* =========================================================
           MOBILE OVERLAY
        ========================================================= */

        sidebarOverlay.addEventListener(
            'click',
            function() {

                sidebar.classList.remove(
                    'mobile-open'
                );

                sidebarOverlay.classList.remove(
                    'show'
                );

            }
        );


        /* =========================================================
           MOBILE NAVIGATION
        ========================================================= */

        document
            .querySelectorAll(
                '.sidebar-link'
            )
            .forEach(
                function(link) {

                    link.addEventListener(
                        'click',
                        function() {

                            if (
                                window.innerWidth <= 768
                            ) {

                                sidebar.classList.remove(
                                    'mobile-open'
                                );

                                sidebarOverlay.classList.remove(
                                    'show'
                                );

                            }

                        }
                    );

                }
            );


        /* =========================================================
           RESPONSIVE
        ========================================================= */

        window.addEventListener(
            'resize',
            function() {

                updateTogglePosition();

            }
        );


        updateTogglePosition();


        /* =========================================================
           COUNT UP
        ========================================================= */

        document
            .querySelectorAll(
                '.count-up'
            )
            .forEach(
                function(el) {

                    const target =
                        Number(
                            el.dataset.target
                        );

                    const duration = 1000;

                    const step =
                        target /
                        (duration / 16);

                    let current = 0;


                    const timer =
                        setInterval(
                            function() {

                                current =
                                    Math.min(
                                        current + step,
                                        target
                                    );


                                el.textContent =
                                    Math.floor(
                                        current
                                    ).toLocaleString();


                                if (
                                    current >= target
                                ) {

                                    clearInterval(
                                        timer
                                    );

                                }

                            },
                            16
                        );

                }
            );


        /* =========================================================
           SEARCH
        ========================================================= */

        const searchInput =
            document.getElementById(
                'searchInput'
            );


        searchInput.addEventListener(
            'keyup',
            function() {

                const val =
                    this.value
                    .toLowerCase()
                    .trim();


                document
                    .querySelectorAll(
                        '#enrollTable tbody tr'
                    )
                    .forEach(
                        function(row) {

                            const text =
                                row.innerText
                                .toLowerCase();


                            row.style.display =
                                text.includes(val) ?
                                '' :
                                'none';

                        }
                    );

            }
        );


        /* =========================================================
           SCROLL TO TOP
        ========================================================= */

        const scrollTopButton =
            document.getElementById(
                'scrollTop'
            );


        window.addEventListener(
            'scroll',
            function() {

                if (
                    window.scrollY > 300
                ) {

                    scrollTopButton.classList.add(
                        'show'
                    );

                } else {

                    scrollTopButton.classList.remove(
                        'show'
                    );

                }

            }
        );


        /* =========================================================
           SCROLL TO TOP CLICK
        ========================================================= */

        scrollTopButton.addEventListener(
            'click',
            function() {

                window.scrollTo({

                    top: 0,

                    behavior: 'smooth'

                });

            }
        );


        /* =========================================================
           KEYBOARD SHORTCUT
           ESC = CLOSE MOBILE SIDEBAR
        ========================================================= */

        document.addEventListener(
            'keydown',
            function(e) {

                if (
                    e.key === 'Escape' &&
                    window.innerWidth <= 768
                ) {

                    sidebar.classList.remove(
                        'mobile-open'
                    );

                    sidebarOverlay.classList.remove(
                        'show'
                    );

                }

            }
        );


        /* =========================================================
           PREVENT CACHED PAGE AFTER LOGOUT
        ========================================================= */

        window.addEventListener(
            'pageshow',
            function(e) {

                if (e.persisted) {

                    window.location.reload();

                }

            }
        );
    </script>


</body>

</html>
