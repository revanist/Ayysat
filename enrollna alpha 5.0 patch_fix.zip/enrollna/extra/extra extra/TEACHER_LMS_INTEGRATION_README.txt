EYYSAT Teacher/LMS Integration
==============================

Base application:
- enrollna_curriculum_faculty_assignment

Integrated teacher/LMS implementation:
- modern teacher portal from enrollna(1)
- teacher accounts using users.role='teacher'
- teaching assignments by subject + section + school year + semester
- curriculum view driven by teacher assignments
- LMS announcements
- LMS learning materials and secure downloads
- student My LMS
- admin Teachers & Faculty management
- temporary teacher password/change-password flow

Database:
1. Keep your existing curriculum/faculty database.
2. For an existing installation, run:
   extra/backup_db/EYYSAT_teacher_lms_integration.sql
3. The application also performs upgrade-safe LMS schema checks when relevant pages load.

Security:
- Students cannot access teacher pages.
- Teachers cannot use student pages as teachers.
- Legacy adviser portal authentication remains compatible.
- Temporary teacher accounts must change their password.
- Teacher assignments are term-specific.

Important:
- Do not delete the legacy teacher portal tables (teachers, teacher_sections,
  teacher_announcements) if you still use the adviser portal.
- The modern LMS uses separate tables: teacher_profiles,
  teaching_assignments, lms_announcements, lms_materials.
