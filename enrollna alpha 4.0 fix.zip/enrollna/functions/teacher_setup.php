<?php
/** Database helpers for the adviser/teacher portal. */
function ensure_teacher_schema(mysqli $conn): void
{
    mysqli_query($conn, "
        CREATE TABLE IF NOT EXISTS teachers (
            id INT(11) NOT NULL AUTO_INCREMENT,
            fullname VARCHAR(120) NOT NULL,
            email VARCHAR(100) NOT NULL,
            password VARCHAR(255) NOT NULL,
            created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_teachers_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    mysqli_query($conn, "
        CREATE TABLE IF NOT EXISTS teacher_sections (
            id INT(11) NOT NULL AUTO_INCREMENT,
            teacher_id INT(11) NOT NULL,
            section_id INT(11) NOT NULL,
            created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_teacher_sections_section (section_id),
            KEY idx_teacher_sections_teacher (teacher_id),
            KEY idx_teacher_sections_section (section_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");

    mysqli_query($conn, "
        CREATE TABLE IF NOT EXISTS teacher_announcements (
            id INT(11) NOT NULL AUTO_INCREMENT,
            teacher_id INT(11) NOT NULL,
            section_id INT(11) DEFAULT NULL,
            title VARCHAR(150) NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_teacher_announcements_teacher (teacher_id),
            KEY idx_teacher_announcements_section (section_id),
            KEY idx_teacher_announcements_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ");
}
