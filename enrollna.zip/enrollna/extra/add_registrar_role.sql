-- Run this on an existing enrollna database without re-importing the full dump.
START TRANSACTION;
INSERT INTO roles (id,name,description) VALUES (5,'Registrar / Academic Affairs','Academic records, curriculum, sections, enrollment and instructor assignment access') ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description);
ALTER TABLE users DROP COLUMN role;
ALTER TABLE users ADD COLUMN role varchar(20) GENERATED ALWAYS AS (case role_id when 1 then 'admin' when 2 then 'teacher' when 3 then 'student' when 4 then 'cashier' when 5 then 'registrar' else 'unknown' end) STORED;
COMMIT;
