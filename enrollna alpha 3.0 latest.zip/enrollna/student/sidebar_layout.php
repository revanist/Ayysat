<?php

/** Shared navigation for student portal pages. */
$studentCurrentPage = basename($_SERVER['PHP_SELF']);
$studentName = htmlspecialchars($_SESSION['fullname'] ?? 'Student');

if (!isset($conn)) {
    require_once __DIR__ . '/../db/dbconn.php';
}

$studentSidebarProfile = [
    'first_name' => '',
    'middle_name' => '',
    'last_name' => '',
    'email' => '',
    'contact' => '',
    'address' => '',
];

$userSidebarId = (int) ($_SESSION['user_id'] ?? 0);
if ($userSidebarId > 0) {
    $sidebarProfileResult = mysqli_query($conn, "
        SELECT first_name, middle_name, last_name, email, contact, address
        FROM students
        WHERE user_id = $userSidebarId
        LIMIT 1
    ");
    if ($sidebarProfileResult && mysqli_num_rows($sidebarProfileResult) > 0) {
        $studentSidebarProfile = mysqli_fetch_assoc($sidebarProfileResult) ?: $studentSidebarProfile;
    }
}

function student_sidebar_active(string $file, string $current): string
{
    return $current === $file ? ' active' : '';
}
?>
<aside class="admin-sidebar student-sidebar" id="studentSidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo"><img src="../img/eyysat.png" alt="EYYSAT Logo"></div>
        <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>STUDENT PORTAL</span></div>
    </div>
    <nav class="sidebar-nav" aria-label="Student navigation">
        <p class="sidebar-label">MY PORTAL</p>
        <a href="student_dashboard.php" class="sidebar-link<?= student_sidebar_active('student_dashboard.php', $studentCurrentPage) ?>"><span class="sidebar-icon">&#127968;</span><span class="sidebar-text">Dashboard</span></a>
        <a href="profile.php" class="sidebar-link<?= student_sidebar_active('profile.php', $studentCurrentPage) ?>"><span class="sidebar-icon">&#128100;</span><span class="sidebar-text">My Profile</span></a>
        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="../auth/logout.php" class="sidebar-link sidebar-logout"><span class="sidebar-icon">&#128682;</span><span class="sidebar-text">Logout</span></a>
    </nav>
    <button type="button" class="sidebar-profile-trigger" id="studentProfileTrigger" aria-label="Open student account settings">
        <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'Student', 0, 1))) ?></div>
        <div class="profile-info"><strong><?= $studentName ?></strong><span>Student</span></div>
    </button>
</aside>
<div class="sidebar-overlay" id="studentSidebarOverlay"></div>
<button class="sidebar-toggle" id="studentSidebarToggle" type="button" aria-label="Toggle sidebar"></button>
<script src="../js/sweetalert2.all.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.getElementById('studentSidebar'),
            toggle = document.getElementById('studentSidebarToggle'),
            overlay = document.getElementById('studentSidebarOverlay'),
            main = document.querySelector('.dashboard-main'),
            profileTrigger = document.getElementById('studentProfileTrigger');
        if (!sidebar || !toggle || !overlay) return;
        const positionToggle = () => {
            toggle.style.left = window.innerWidth <= 768 ? '18px' : (sidebar.classList.contains('collapsed') ? '68px' : '246px');
        };
        toggle.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.toggle('mobile-open');
                overlay.classList.toggle('show');
                return;
            }
            const collapsed = sidebar.classList.toggle('collapsed');
            if (main) main.classList.toggle('sidebar-collapsed', collapsed);
            toggle.classList.toggle('collapsed', collapsed);
            positionToggle();
        });
        overlay.addEventListener('click', () => {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('show');
        });
        document.querySelectorAll('.student-sidebar .sidebar-link').forEach(link => link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('show');
            }
        }));

        if (profileTrigger) {
            profileTrigger.addEventListener('click', function() {
                Swal.fire({
                    title: 'Loading account settings',
                    text: 'Preparing your information...',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: function() {
                        Swal.showLoading();
                    }
                });

                window.setTimeout(function() {
                    Swal.close();
                    Swal.fire({
                        title: 'Student Account Settings',
                        html: `
                            <form method="POST" action="../functions/student_update_profile.php" class="student-settings-form">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(student_csrf_token()) ?>">
                                <div class="student-settings-grid">
                                    <div class="student-settings-panel">
                                        <h4>Personal Information</h4>
                                        <div class="student-settings-row">
                                            <label>First Name</label>
                                            <input type="text" name="first_name" value="<?= htmlspecialchars($studentSidebarProfile['first_name'] ?? '') ?>" required>
                                        </div>
                                        <div class="student-settings-row">
                                            <label>Middle Name</label>
                                            <input type="text" name="middle_name" value="<?= htmlspecialchars($studentSidebarProfile['middle_name'] ?? '') ?>">
                                        </div>
                                        <div class="student-settings-row">
                                            <label>Last Name</label>
                                            <input type="text" name="last_name" value="<?= htmlspecialchars($studentSidebarProfile['last_name'] ?? '') ?>" required>
                                        </div>
                                        <div class="student-settings-row">
                                            <label>Email</label>
                                            <input type="email" name="email" value="<?= htmlspecialchars($studentSidebarProfile['email'] ?? '') ?>" required>
                                        </div>
                                        <div class="student-settings-row">
                                            <label>Contact Number</label>
                                            <input type="text" name="contact" value="<?= htmlspecialchars($studentSidebarProfile['contact'] ?? '') ?>" required>
                                        </div>
                                        <div class="student-settings-row">
                                            <label>Address</label>
                                            <textarea name="address" rows="3" required><?= htmlspecialchars($studentSidebarProfile['address'] ?? '') ?></textarea>
                                        </div>
                                    </div>
                                    <div class="student-settings-panel">
                                        <h4>Change Password</h4>
                                        <div class="student-settings-row">
                                            <label>Current Password</label>
                                            <input type="password" name="current_password" placeholder="Enter current password">
                                        </div>
                                        <div class="student-settings-row">
                                            <label>New Password</label>
                                            <input type="password" name="new_password" placeholder="At least 8 characters">
                                        </div>
                                        <div class="student-settings-row">
                                            <label>Confirm New Password</label>
                                            <input type="password" name="confirm_password" placeholder="Re-enter new password">
                                        </div>
                                    </div>
                                </div>
                                <div class="student-settings-actions">
                                    <button type="submit" class="btn student-settings-submit">Save Changes</button>
                                </div>
                            </form>
                        `,
                        width: '900px',
                        customClass: {
                            popup: 'student-settings-modal',
                            title: 'student-settings-title'
                        },
                        showCloseButton: true,
                        showConfirmButton: false,
                        allowOutsideClick: true,
                        focusConfirm: false,
                        padding: '1.5rem'
                    });
                }, 450);
            });
        }

        window.addEventListener('resize', positionToggle);
        positionToggle();
    });
</script>