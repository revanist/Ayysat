<?php header('Location: teacher_dashboard.php', true, 303); 
exit; 
?>