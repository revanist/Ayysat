<?php
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();

require_once '../db/dbconn.php';

$userId = (int) $_SESSION['user_id'];
$studentQuery = mysqli_query($conn, "
    SELECT s.*, c.course_code, c.course_name, sec.section_name
    FROM students s
    LEFT JOIN courses c ON c.id = s.course_id
    LEFT JOIN sections sec ON sec.id = s.section_id
    WHERE s.user_id = $userId
    LIMIT 1
");
$student = mysqli_fetch_assoc($studentQuery);

if (!$student) {
    http_response_code(404);
    exit('Student profile not found.');
}

$enrollmentQuery = mysqli_query($conn, "
    SELECT status, payment_status, school_year, sem
    FROM enrollments
    WHERE student_id = " . (int) $student['id'] . "
    ORDER BY id DESC
    LIMIT 1
");
$enrollment = mysqli_fetch_assoc($enrollmentQuery) ?: [];

$subjectCount = (int) (mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM enrollment_details ed
    INNER JOIN enrollments e ON e.id = ed.enrollment_id
    WHERE e.student_id = " . (int) $student['id'] . "
"))['total'] ?? 0);

$status = strtolower($enrollment['status'] ?? $student['enrollment_status'] ?? 'Not Submitted');
$paymentStatus = strtolower($enrollment['payment_status'] ?? $student['payment_status'] ?? 'Pending');
$statusLabel = $status === 'approved' && $paymentStatus === 'paid' ? 'Enrolled' : ucfirst($status);
$studentName = htmlspecialchars($_SESSION['fullname'] ?? trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? 'Student')));
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard – EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/student_profile.css">
    <script src="../js/sweetalert2.all.min.js"></script>
</head>

<body class="profile-page">
    <?php include 'sidebar_layout.php'; ?>
    <main class="dashboard-main">
        <header class="dashboard-topbar">
            <div><span class="topbar-label">STUDENT PORTAL</span>
                <h2>Dashboard</h2>
            </div>
        </header>

        <section class="hero">
            <div class="welcome">
                <span class="hero-badge">&#127891; Student Overview</span>
                <h1>Welcome, <span class="accent"><?= $studentName ?></span></h1>
                <p>Keep track of your enrollment, academic details, and account balance.</p>
                <div class="hero-big-stat">
                    <h2><?= $subjectCount ?></h2><span>Subjects Selected</span>
                </div>
            </div>
            <div class="hero-stats">
                <div class="mini-stat">
                    <h3>Course</h3><span><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></span>
                </div>
                <div class="mini-stat">
                    <h3>Year Level</h3><span><?= htmlspecialchars($student['year_level'] ?? 'N/A') ?></span>
                </div>
                <div class="mini-stat">
                    <h3>Section</h3><span><?= htmlspecialchars($student['section_name'] ?? 'Pending') ?></span>
                </div>
            </div>
        </section>

        <section class="stats-row">
            <div class="stat-card stat-success">
                <div class="stat-icon">&#128203;</div>
                <h3>Enrollment Status</h3><span><?= htmlspecialchars($statusLabel) ?></span>
            </div>
            <div class="stat-card stat-paid">
                <div class="stat-icon">&#128176;</div>
                <h3>Remaining Balance</h3><span>&#8369;<?= number_format((float) ($student['remaining_balance'] ?? 0), 2) ?></span>
            </div>
            <div class="stat-card stat-warning">
                <div class="stat-icon">&#128179;</div>
                <h3>Payment Status</h3><span><?= htmlspecialchars(ucfirst($paymentStatus)) ?></span>
            </div>
            <div class="stat-card stat-section">
                <div class="stat-icon">&#128197;</div>
                <h3>School Term</h3><span><?= htmlspecialchars(($enrollment['school_year'] ?? 'N/A') . ' / ' . ($enrollment['sem'] ?? 'N/A')) ?></span>
            </div>
        </section>

        <section class="analytics-grid">
            <div class="card">
                <h3>Quick Actions</h3>
                <p style="color:var(--text-muted); margin-bottom:20px;">Manage your personal details, track your enrollment, or view your registration form.</p>
                <div style="display:flex; flex-wrap:wrap; gap:12px;"><a class="btn" href="profile.php">My Profile</a><a class="btn" href="profile.php#enrollment">Enrollment Status</a><a class="btn registration-form-link" href="registration_form_view.php">Registration Form</a></div>
            </div>
            <div class="card">
                <h3>Academic Information</h3>
                <dl class="info-list">
                    <div>
                        <dt>Program</dt>
                        <dd><?= htmlspecialchars($student['course_name'] ?? 'Not selected') ?></dd>
                    </div>
                    <div>
                        <dt>Student Number</dt>
                        <dd><?= htmlspecialchars($student['student_number'] ?? 'Pending') ?></dd>
                    </div>
                    <div>
                        <dt>Section</dt>
                        <dd><?= htmlspecialchars($student['section_name'] ?? 'Not assigned') ?></dd>
                    </div>
                </dl>
            </div>
        </section>
    </main>
    <script>
        document.querySelectorAll('.registration-form-link').forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const url = link.href;
                Swal.fire({
                    title: 'Preparing registration form',
                    text: 'Please wait a moment…',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: function() { Swal.showLoading(); }
                });
                window.setTimeout(function() { window.location.href = url; }, 900);
            });
        });
    </script>
</body>

</html>
