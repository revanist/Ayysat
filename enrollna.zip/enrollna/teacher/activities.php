<?php
require __DIR__.'/teacher_bootstrap.php';
require_once __DIR__.'/../functions/teacher_academic.php';
$aid = (int)($_GET['assignment_id'] ?? 0);
$class = $aid ? teacher_class_assignment($conn, $aid, $teacherId) : null;
if($aid && !$class){ http_response_code(404); exit('Class not found or not assigned to you.'); }
$msg = $_GET['msg'] ?? '';
$err = $_GET['error'] ?? '';

if($aid){
    $q = mysqli_prepare($conn, "SELECT a.*, COUNT(s.id) submission_count FROM lms_activities a LEFT JOIN lms_submissions s ON s.activity_id = a.id WHERE a.assignment_id = ? GROUP BY a.id ORDER BY a.created_at DESC");
    mysqli_stmt_bind_param($q, 'i', $aid);
} else {
    $q = mysqli_prepare($conn, "SELECT a.*, COUNT(s.id) submission_count, sub.subject_code, sec.section_name FROM lms_activities a JOIN teaching_assignments ta ON ta.id = a.assignment_id AND ta.teacher_id = ? AND ta.school_year = ? AND ta.semester = ? AND ta.status = 'Active' JOIN subjects sub ON sub.id = ta.subject_id JOIN sections sec ON sec.id = ta.section_id LEFT JOIN lms_submissions s ON s.activity_id = a.id GROUP BY a.id ORDER BY (a.due_at IS NULL), a.due_at");
    mysqli_stmt_bind_param($q, 'isi', $teacherId, $schoolYear, $semester);
}
mysqli_stmt_execute($q);
$rows = mysqli_stmt_get_result($q);

$activitiesByPeriod = ['Prelim'=>[],'Midterm'=>[],'Pre-Final'=>[],'Final'=>[],'General'=>[]];
while($a = mysqli_fetch_assoc($rows)) {
    $gp = $a['grading_period'] ?? 'General';
    if (!isset($activitiesByPeriod[$gp])) $activitiesByPeriod[$gp] = [];
    $activitiesByPeriod[$gp][] = $a;
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Activities | EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css?v=<?=time()?>">
    <link rel="stylesheet" href="../css/teacher.css?v=<?=time()?>">
    <style>
        .lms-module {
            background: var(--teacher-card);
            border: 1px solid var(--teacher-border-soft);
            border-radius: 14px;
            margin-bottom: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            overflow: hidden;
        }
        .lms-module-header {
            background: rgba(4,18,33,0.4);
            padding: 18px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            border-bottom: 1px solid var(--teacher-border-soft);
            user-select: none;
            transition: background 0.2s;
        }
        .lms-module-header:hover {
            background: rgba(255,255,255,0.04);
        }
        .lms-module-title {
            font-size: 1.15rem;
            color: #fff;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
            letter-spacing: 0.03em;
        }
        .lms-module-title i {
            color: var(--teacher-gold);
            font-size: 1.3rem;
        }
        .lms-activity-row {
            display: flex;
            align-items: center;
            padding: 20px 24px;
            border-bottom: 1px solid rgba(255,255,255,0.04);
            text-decoration: none;
            transition: all 0.2s ease;
            gap: 20px;
            background: transparent;
        }
        .lms-activity-row:last-child {
            border-bottom: none;
        }
        .lms-activity-row:hover {
            background: rgba(255,255,255,0.03);
            padding-left: 28px; /* interactive hover indent */
        }
        .lms-activity-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: rgba(244,211,94,0.1);
            color: var(--teacher-gold);
            display: grid;
            place-items: center;
            font-size: 1.4rem;
            flex-shrink: 0;
            transition: transform 0.2s;
        }
        .lms-activity-row:hover .lms-activity-icon {
            transform: scale(1.08);
            background: var(--teacher-gold);
            color: var(--teacher-card);
        }
        .lms-activity-details {
            flex: 1;
            min-width: 0;
        }
        .lms-activity-title {
            color: #fff;
            font-size: 1.05rem;
            font-weight: 700;
            margin: 0 0 6px 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .lms-activity-meta {
            color: var(--teacher-muted);
            font-size: 0.82rem;
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
        }
        .lms-activity-meta span {
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .lms-activity-meta i {
            color: rgba(255,255,255,0.3);
        }
        .lms-activity-status {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 0.72rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .status-published { background: rgba(74,222,128,0.15); color: #4ade80; }
        .status-draft { background: rgba(255,255,255,0.1); color: #b0cceb; }
        
        .lms-create-panel {
            background: linear-gradient(145deg, var(--teacher-card-2), var(--teacher-card));
            border: 1px solid var(--teacher-border-soft);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            animation: slideDown 0.3s ease-out;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .lms-empty-state {
            padding: 40px 20px;
            text-align: center;
            color: var(--teacher-muted);
        }
        .lms-empty-state i {
            font-size: 3rem;
            color: rgba(255,255,255,0.1);
            margin-bottom: 16px;
            display: block;
        }
    </style>
</head>
<body>
<?php include __DIR__.'/../sidebar/sidebar.php'; ?>

<main class="dashboard-main">
    <section class="teacher-hero">
        <div>
            <div class="teacher-eyebrow"><?= $class ? htmlspecialchars($class['subject_code'].' · '.$class['section_name']) : 'Current Teaching Load' ?></div>
            <h1>Activities & Assessments</h1>
            <p><?= $class ? 'Manage and grade coursework organized by academic term.' : 'Review activities across your current teaching assignments.' ?></p>
        </div>
        <div class="teacher-hero-meta">
            <?php if($class): ?>
            <button class="teacher-btn primary" onclick="document.getElementById('createActivityForm').style.display='block'; window.scrollTo({top: 0, behavior: 'smooth'});" style="padding: 10px 20px; font-size: 0.9rem;">
                <i class="fa-solid fa-plus"></i> New Activity
            </button>
            <?php endif; ?>
        </div>
    </section>

    <?php if($class): ?>
    <nav class="teacher-tabs">
        <a class="teacher-tab" href="class.php?assignment_id=<?=$aid?>">Overview</a>
        <a class="teacher-tab active" href="activities.php?assignment_id=<?=$aid?>">Curriculum</a>
        <a class="teacher-tab" href="attendance.php?assignment_id=<?=$aid?>">Attendance</a>
        <a class="teacher-tab" href="grades.php?assignment_id=<?=$aid?>">Gradebook</a>
        <a class="teacher-tab" href="reports.php?assignment_id=<?=$aid?>">Performance</a>
        <a class="teacher-tab" href="class_students.php?assignment_id=<?=$aid?>">Students</a>
    </nav>
    <?php endif; ?>

    <?php if($msg): ?><div class="notice"><i class="fa-solid fa-check-circle"></i> <?=htmlspecialchars($msg)?></div><?php endif; ?>
    <?php if($err): ?><div class="notice error"><i class="fa-solid fa-triangle-exclamation"></i> <?=htmlspecialchars($err)?></div><?php endif; ?>

    <?php if($class): ?>
    <div id="createActivityForm" style="display: none;">
        <div class="lms-create-panel">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="color: #fff; margin: 0; font-size: 1.25rem;"><i class="fa-solid fa-pen-to-square" style="color: var(--teacher-gold); margin-right: 8px;"></i> Create New Activity</h2>
                <button type="button" class="teacher-btn" onclick="document.getElementById('createActivityForm').style.display='none';">
                    <i class="fa-solid fa-times"></i> Close
                </button>
            </div>
            
            <form method="post" action="save_activity.php">
                <input type="hidden" name="csrf_token" value="<?=htmlspecialchars(teacher_csrf_token())?>">
                <input type="hidden" name="assignment_id" value="<?=$aid?>">
                <div class="form-grid">
                    <div class="field full"><label>Activity Title</label><input name="title" maxlength="180" placeholder="e.g. Chapter 1 Quiz" required></div>
                    <div class="field"><label>Activity Type</label><select name="activity_type"><option>Assignment</option><option>Quiz</option><option>Project</option><option>Exam</option><option>Other</option></select></div>
                    <div class="field"><label>Grading Period</label><select name="grading_period"><option>Prelim</option><option>Midterm</option><option>Pre-Final</option><option>Final</option><option selected>General</option></select></div>
                    <div class="field"><label>Maximum Score</label><input type="number" name="max_score" min="1" max="9999" step="0.01" value="100" required></div>
                    <div class="field"><label>Due Date & Time</label><input type="datetime-local" name="due_at"></div>
                    <div class="field full"><label>Instructions (Optional)</label><textarea name="instructions" rows="4" placeholder="Provide guidelines for students..."></textarea></div>
                    <div class="field"><label>Status</label><select name="status"><option>Draft</option><option>Published</option></select></div>
                </div>
                <div style="margin-top: 20px; display: flex; gap: 12px; justify-content: flex-end;">
                    <button type="button" class="teacher-btn" onclick="document.getElementById('createActivityForm').style.display='none';">Cancel</button>
                    <button class="teacher-btn primary" type="submit"><i class="fa-solid fa-paper-plane"></i> Save & Publish</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <?php 
    $totalActs = 0;
    foreach($activitiesByPeriod as $period => $acts) {
        if (count($acts) > 0) $totalActs += count($acts);
    }
    
    if ($totalActs === 0): 
    ?>
    <div class="teacher-panel lms-empty-state">
        <i class="fa-solid fa-box-open"></i>
        <h2 style="color: #fff; margin-bottom: 8px;">Your curriculum is empty</h2>
        <p>You haven't added any activities or assessments for this class yet.<br>Click the <strong>New Activity</strong> button to get started.</p>
    </div>
    <?php 
    else:
        foreach($activitiesByPeriod as $period => $acts):
            if(count($acts)===0) continue;
    ?>
    <div class="lms-module">
        <div class="lms-module-header" onclick="const b = this.nextElementSibling; b.style.display = b.style.display === 'none' ? 'block' : 'none'; const i = this.querySelector('.toggle-icon'); i.style.transform = b.style.display === 'none' ? 'rotate(0deg)' : 'rotate(180deg)';">
            <div class="lms-module-title">
                <i class="fa-solid fa-folder-open"></i> <?=htmlspecialchars($period)?> Term
            </div>
            <div style="display: flex; align-items: center; gap: 16px;">
                <span style="color: var(--teacher-muted); font-size: 0.85rem; font-weight: 600;"><?=count($acts)?> item<?=count($acts)>1?'s':''?></span>
                <i class="fa-solid fa-chevron-down toggle-icon" style="color: rgba(255,255,255,0.4); transition: transform 0.3s; transform: rotate(180deg);"></i>
            </div>
        </div>
        <div class="lms-module-body" style="display: block;">
            <?php 
            foreach($acts as $a): 
                $icon = 'fa-file-lines'; // default Assignment
                if ($a['activity_type'] === 'Quiz') $icon = 'fa-bolt';
                if ($a['activity_type'] === 'Project') $icon = 'fa-lightbulb';
                if ($a['activity_type'] === 'Exam') $icon = 'fa-file-signature';
            ?>
            <a class="lms-activity-row" href="activity.php?id=<?=$a['id']?>">
                <div class="lms-activity-icon">
                    <i class="fa-solid <?=$icon?>"></i>
                </div>
                <div class="lms-activity-details">
                    <h3 class="lms-activity-title"><?=htmlspecialchars($a['title'])?></h3>
                    <div class="lms-activity-meta">
                        <span><i class="fa-solid fa-layer-group"></i> <?=htmlspecialchars($a['activity_type'])?></span>
                        <span><i class="fa-solid fa-star"></i> <?=number_format((float)$a['max_score'],2)?> pts</span>
                        <span><i class="fa-solid fa-calendar-check"></i> <?= $a['due_at'] ? htmlspecialchars(date('M d, Y g:i A',strtotime($a['due_at']))) : 'No due date' ?></span>
                        <?php if(!$class && isset($a['subject_code'])): ?>
                        <span><i class="fa-solid fa-book"></i> <?=htmlspecialchars($a['subject_code'].' · '.$a['section_name'])?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="display: flex; align-items: center; gap: 20px;">
                    <div style="text-align: right;">
                        <span style="display: block; color: #fff; font-size: 1.1rem; font-weight: 800;"><?=intval($a['submission_count'])?></span>
                        <span style="color: var(--teacher-muted); font-size: 0.7rem; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em;">Submissions</span>
                    </div>
                    <span class="lms-activity-status <?= $a['status']==='Published' ? 'status-published' : 'status-draft' ?>">
                        <?=htmlspecialchars($a['status'])?>
                    </span>
                    <i class="fa-solid fa-chevron-right" style="color: rgba(255,255,255,0.2);"></i>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php 
        endforeach; 
    endif;
    ?>
</main>
</body>
</html>
