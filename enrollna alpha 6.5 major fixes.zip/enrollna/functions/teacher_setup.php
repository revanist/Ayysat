<?php
/** Database helpers for the modern instructor/faculty portal. */
function ensure_teacher_schema(mysqli $conn): void
{
    // The college model uses subject-level teaching_assignments.
    // No section-level ownership/claim table is created or used here.
    if (function_exists('lms_table_exists') && lms_table_exists($conn, 'teaching_assignments')) {
        $col = mysqli_query($conn, "SHOW COLUMNS FROM teaching_assignments LIKE 'assignment_source'");
        if ($col && mysqli_num_rows($col) === 0) {
            mysqli_query($conn, "ALTER TABLE teaching_assignments ADD COLUMN assignment_source ENUM('Manual','Legacy') NOT NULL DEFAULT 'Manual' AFTER status");
            mysqli_query($conn, "UPDATE teaching_assignments SET assignment_source='Legacy'");
        }
        // One-time archive of assignments created by the old automatic assignment model.
        mysqli_query($conn, "CREATE TABLE IF NOT EXISTS system_migrations (migration_key VARCHAR(100) PRIMARY KEY, applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $key = 'subject_instructor_assignment_v1';
        $stmt = mysqli_prepare($conn, "SELECT migration_key FROM system_migrations WHERE migration_key=? LIMIT 1");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 's', $key); mysqli_stmt_execute($stmt);
            $done = mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0; mysqli_stmt_close($stmt);
            if (!$done) {
                mysqli_query($conn, "UPDATE teaching_assignments SET status='Archived', assignment_source='Legacy' WHERE assignment_source='Legacy'");
                $ins = mysqli_prepare($conn, "INSERT IGNORE INTO system_migrations (migration_key) VALUES (?)");
                if ($ins) { mysqli_stmt_bind_param($ins, 's', $key); mysqli_stmt_execute($ins); mysqli_stmt_close($ins); }
            }
        }
    }
}
