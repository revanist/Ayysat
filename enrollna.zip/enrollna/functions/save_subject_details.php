<?php
require_once __DIR__ . '/academic_auth.php';
require_academic_login();
require_academic_csrf();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/enrollment_setup.php';
require_once __DIR__ . '/teacher_setup.php';
ensure_enrollment_schema($conn);
ensure_teacher_schema($conn);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $targetBase = '../registrar/courses.php';
    header('Location: ' . $targetBase, true, 303);
    exit;
}

$courseId = (int)($_POST['course_id'] ?? 0);
$action = (string)($_POST['action'] ?? '');
$subjects = $_POST['subjects'] ?? [];

if ($courseId <= 0 || $action !== 'bulk_save' || !is_array($subjects)) {
    $targetBase = '../registrar/courses.php';
    header('Location: ' . $targetBase . '?course=' . $courseId, true, 303);
    exit;
}

$allowedDays = [];
$allowedTimes = [];
$allowedRooms = [];
$result = mysqli_query($conn, "SELECT DISTINCT schedule_day, schedule_time, room_number FROM subjects WHERE schedule_day IS NOT NULL OR schedule_time IS NOT NULL OR room_number IS NOT NULL");
while ($row = mysqli_fetch_assoc($result)) {
    if (trim((string)$row['schedule_day']) !== '') $allowedDays[] = trim((string)$row['schedule_day']);
    if (trim((string)$row['schedule_time']) !== '') $allowedTimes[] = trim((string)$row['schedule_time']);
    if (trim((string)$row['room_number']) !== '') $allowedRooms[] = trim((string)$row['room_number']);
}
$allowedDays = array_unique($allowedDays);
$allowedTimes = array_unique($allowedTimes);
$allowedRooms = array_unique($allowedRooms);

mysqli_begin_transaction($conn);

try {
    foreach ($subjects as $subjectIdRaw => $data) {
        $subjectId = (int)$subjectIdRaw;
        if ($subjectId <= 0 || !is_array($data)) continue;

        $teacherId = (int)($data['teacher_id'] ?? 0);
        $day = trim((string)($data['schedule_day'] ?? ''));
        $time = trim((string)($data['schedule_time'] ?? ''));
        $room = trim((string)($data['room_number'] ?? ''));

        if ($day !== '' && !in_array($day, $allowedDays, true)) throw new RuntimeException('Invalid schedule day selected.');
        if ($time !== '' && !in_array($time, $allowedTimes, true)) throw new RuntimeException('Invalid schedule time selected.');
        if ($room !== '' && !in_array($room, $allowedRooms, true)) throw new RuntimeException('Invalid room selected.');

        $subjectStmt = mysqli_prepare($conn, 'SELECT id, section_id, sem FROM subjects WHERE id=? AND course_id=? LIMIT 1');
        mysqli_stmt_bind_param($subjectStmt, 'ii', $subjectId, $courseId);
        mysqli_stmt_execute($subjectStmt);
        $subject = mysqli_fetch_assoc(mysqli_stmt_get_result($subjectStmt));
        mysqli_stmt_close($subjectStmt);
        if (!$subject) continue;

        if ($teacherId > 0) {
            $teacherStmt = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE user_id=? AND role_id=2 AND TRIM(full_name) <> \'\' LIMIT 1');
            mysqli_stmt_bind_param($teacherStmt, 'i', $teacherId);
            mysqli_stmt_execute($teacherStmt);
            $valid = mysqli_num_rows(mysqli_stmt_get_result($teacherStmt)) === 1;
            mysqli_stmt_close($teacherStmt);
            if (!$valid) throw new RuntimeException('Invalid instructor selected.');
        }

        $teacherName = '';
        if ($teacherId > 0) {
            $nameStmt = mysqli_prepare($conn, 'SELECT full_name FROM users WHERE user_id=? AND role_id=2 LIMIT 1');
            mysqli_stmt_bind_param($nameStmt, 'i', $teacherId);
            mysqli_stmt_execute($nameStmt);
            $teacherRow = mysqli_fetch_assoc(mysqli_stmt_get_result($nameStmt));
            mysqli_stmt_close($nameStmt);
            $teacherName = trim((string)($teacherRow['full_name'] ?? ''));
        }

        $stmt = mysqli_prepare($conn, "UPDATE subjects SET teacher_name=NULLIF(?, ''), schedule_day=NULLIF(?, ''), schedule_time=NULLIF(?, ''), room_number=NULLIF(?, '') WHERE id=? AND course_id=?");
        mysqli_stmt_bind_param($stmt, 'ssssii', $teacherName, $day, $time, $room, $subjectId, $courseId);
        if (!mysqli_stmt_execute($stmt)) { mysqli_stmt_close($stmt); throw new RuntimeException('Unable to save subject schedule.'); }
        mysqli_stmt_close($stmt);

        $schoolYear = system_school_year($conn);
        $semester = max(1, (int)($subject['sem'] ?? 1));
        $archive = mysqli_prepare($conn, "UPDATE teaching_assignments SET status='Archived' WHERE subject_id=? AND school_year=? AND status='Active'");
        mysqli_stmt_bind_param($archive, 'is', $subjectId, $schoolYear);
        if (!mysqli_stmt_execute($archive)) { mysqli_stmt_close($archive); throw new RuntimeException('Unable to update teaching assignment state.'); }
        mysqli_stmt_close($archive);

        if ($teacherId > 0) {
            $targetSections = [];
            $actualSectionId = (int)($subject['section_id'] ?? 0);
            if ($actualSectionId > 0) {
                $targetSections[] = $actualSectionId;
            } else {
                $sectionStmt = mysqli_prepare($conn, 'SELECT id FROM sections WHERE course_id=? ORDER BY id');
                mysqli_stmt_bind_param($sectionStmt, 'i', $courseId);
                mysqli_stmt_execute($sectionStmt);
                $sectionResult = mysqli_stmt_get_result($sectionStmt);
                while ($sectionRow = mysqli_fetch_assoc($sectionResult)) $targetSections[] = (int)$sectionRow['id'];
                mysqli_stmt_close($sectionStmt);
            }

            foreach ($targetSections as $targetSectionId) {
                $assign = mysqli_prepare($conn, "INSERT INTO teaching_assignments (teacher_id, subject_id, section_id, school_year, semester, status, assignment_source) VALUES (?, ?, ?, ?, ?, 'Active', 'Manual') ON DUPLICATE KEY UPDATE teacher_id=VALUES(teacher_id), status='Active', assignment_source='Manual', updated_at=CURRENT_TIMESTAMP");
                mysqli_stmt_bind_param($assign, 'iiisi', $teacherId, $subjectId, $targetSectionId, $schoolYear, $semester);
                if (!mysqli_stmt_execute($assign)) { mysqli_stmt_close($assign); throw new RuntimeException('Unable to save teaching assignment.'); }
                mysqli_stmt_close($assign);
            }
        }
    }

    mysqli_commit($conn);
    $targetBase = '../registrar/courses.php';
    header('Location: ' . $targetBase . '?course=' . $courseId . '&saved=1', true, 303);
    exit;
} catch (Throwable $e) {
    mysqli_rollback($conn);
    $targetBase = '../registrar/courses.php';
    header('Location: ' . $targetBase . '?course=' . $courseId . '&saved=0', true, 303);
    exit;
}
