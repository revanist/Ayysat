(() => {
    'use strict';

    const catalog = Array.isArray(window.ENROLLMENT_CATALOG)
        ? window.ENROLLMENT_CATALOG
        : [];
    const draft = window.ENROLLMENT_DRAFT && typeof window.ENROLLMENT_DRAFT === 'object'
        ? window.ENROLLMENT_DRAFT
        : {};

    const state = { step: 1, totalSteps: 4 };
    const form = document.getElementById('enrollmentForm');
    const panes = [...document.querySelectorAll('.wizard-pane')];
    const stepItems = [...document.querySelectorAll('.wizard-steps li')];

    const $ = (id) => document.getElementById(id);
    const escapeHtml = (value) => String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');

    const ordinalYear = (year) => {
        const value = Number(year);
        const suffix = value === 1 ? 'st' : value === 2 ? 'nd' : value === 3 ? 'rd' : 'th';
        return `${value}${suffix} Year`;
    };

    const semesterLabel = (semester) => Number(semester) === 1 ? '1st Semester' : '2nd Semester';

    function selectedCourse() {
        const id = Number(document.querySelector('[name="course_id"]')?.value || 0);
        return catalog.find((course) => Number(course.id) === id) || null;
    }

    function selectedCurriculum(course) {
        const year = Number($('year_level')?.value || 0);
        const semester = Number($('semester')?.value || 0);
        return (course?.curriculum || []).filter((subject) =>
            Number(subject.year_level) === year && Number(subject.semester) === semester
        );
    }

    function collectFormData() {
        const data = {};
        if (!form) return data;

        form.querySelectorAll('input, select, textarea').forEach((field) => {
            if (!field.name || field.type === 'submit' || field.type === 'button') return;

            if (field.name === 'subject_ids[]') {
                data.subject_ids ??= [];
                data.subject_ids.push(field.value);
                return;
            }

            if ((field.type === 'checkbox' || field.type === 'radio') && !field.checked) return;
            data[field.name] = field.value;
        });

        return data;
    }

    function showStep(step) {
        state.step = Math.max(1, Math.min(state.totalSteps, step));

        panes.forEach((pane) => {
            pane.classList.toggle('active', Number(pane.dataset.step) === state.step);
        });

        stepItems.forEach((item, index) => {
            item.classList.toggle('active', index + 1 === state.step);
            item.classList.toggle('done', index + 1 < state.step);
        });

        const panel = document.querySelector('.form-panel');
        if (panel) {
            window.scrollTo({ top: panel.offsetTop - 80, behavior: 'smooth' });
        }

        if (state.step === 4) buildSummary();
    }

    function validateBirthdate() {
        const input = $('birthdate');
        const error = $('birthdateError');
        if (!input) return true;

        if (!input.value) {
            input.setCustomValidity('');
            error?.classList.remove('d-block');
            return false;
        }

        const birthdate = new Date(`${input.value}T00:00:00`);
        const latestAllowed = new Date();
        latestAllowed.setHours(0, 0, 0, 0);
        latestAllowed.setFullYear(latestAllowed.getFullYear() - 18);

        const valid = birthdate <= latestAllowed;
        input.setCustomValidity(valid ? '' : 'Applicants must be at least 18 years old.');
        input.classList.toggle('is-invalid', !valid);
        error?.classList.toggle('d-block', !valid);
        return valid;
    }

    function validatePane(pane) {
        if (!pane) return false;

        let valid = true;
        pane.querySelectorAll('input[required], select[required], textarea[required]').forEach((field) => {
            if (!field.checkValidity()) {
                field.classList.add('is-invalid');
                valid = false;
            } else {
                field.classList.remove('is-invalid');
            }
        });

        if (pane.dataset.step === '1') valid = validateBirthdate() && valid;

        if (pane.dataset.step === '2') {
            const subjects = pane.querySelectorAll('input[name="subject_ids[]"][data-curriculum-subject="true"]');
            const error = $('subjectError');
            const hasSubjects = subjects.length > 0;

            error?.classList.toggle('d-none', hasSubjects);
            if (!hasSubjects) {
                valid = false;
                if (error) error.textContent = 'Please select a course, year level, and semester with a configured curriculum.';
            }
        }

        return valid;
    }

    function renderSections(course) {
        const sectionSelect = $('section_select');
        if (!sectionSelect) return;

        sectionSelect.innerHTML = '';
        const selectedYear = Number($('year_level')?.value || 0);
        const selectedSemester = Number($('semester')?.value || 0);
        const courseCode = String(course?.course_code || '').trim().toUpperCase();

        /*
         * Section format:
         *   COURSE-YEARLETTERSEMESTER
         *   Example: BSIT-1A1 = BSIT, 1st Year, Section A, 1st Semester.
         */
        const sections = (course?.sections || []).filter((section) => {
            const name = String(section.section_name || '').trim().toUpperCase();

            // Prefer normalized metadata supplied by PHP.
            if (Number(section.year_level) > 0 && Number(section.semester) > 0) {
                return Number(section.year_level) === selectedYear
                    && Number(section.semester) === selectedSemester;
            }

            // Backward-compatible fallback for older cached/catalog data.
            const match = name.match(/^(.+)-(1|2|3|4)([A-D])(1|2)$/);
            return !!match
                && match[1] === courseCode
                && Number(match[2]) === selectedYear
                && Number(match[4]) === selectedSemester;
        });

        if (!selectedYear || !selectedSemester || !courseCode) {
            sectionSelect.add(new Option('Select Course, Year and Semester', ''));
        } else if (!sections.length) {
            sectionSelect.add(new Option('No sections available for this semester', ''));
        } else {
            sectionSelect.add(new Option('Select Section', ''));
            sections.forEach((section) => {
                sectionSelect.add(new Option(section.section_name, section.id));
            });
        }

        const draftSection = String(draft.section_id || '');
        if (draftSection) sectionSelect.value = draftSection;
    }

    function makeSubjectTable(subjects, isSelected) {
        const wrapper = document.createElement('div');
        wrapper.className = 'table-responsive curriculum-table-wrap';

        if (!subjects.length) {
            wrapper.innerHTML = '<div class="alert alert-light border mb-0">No subjects configured for this semester.</div>';
            return wrapper;
        }

        const table = document.createElement('table');
        table.className = 'table curriculum-table align-middle mb-0';
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Subject</th>
                    <th>Units</th>
                    <th>Schedule</th>
                    <th>Room</th>
                </tr>
            </thead>
            <tbody></tbody>`;

        const tbody = table.querySelector('tbody');
        subjects.forEach((subject) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><span class="subject-code-pill">${escapeHtml(subject.subject_code)}</span></td>
                <td>
                    <div class="fw-semibold">${escapeHtml(subject.subject_name)}</div>
                    ${isSelected ? '<small class="text-success">Required for this registration</small>' : ''}
                </td>
                <td><span class="units-badge">${escapeHtml(subject.units)} unit${Number(subject.units) === 1 ? '' : 's'}</span></td>
                <td>${escapeHtml(subject.schedule_day || 'TBA')}<br><span class="text-muted">${escapeHtml(subject.schedule_time || '')}</span></td>
                <td>${escapeHtml(subject.room_number || 'TBA')}</td>`;
            tbody.appendChild(row);

            if (isSelected) {
                const hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'subject_ids[]';
                hidden.value = subject.id;
                hidden.dataset.curriculumSubject = 'true';
                wrapper.appendChild(hidden);
            }
        });

        wrapper.appendChild(table);
        return wrapper;
    }

    function renderCurriculum(course) {
        const accordion = $('curriculumAccordion');
        const status = $('curriculumStatus');
        const badge = $('curriculumCourseBadge');
        const summary = $('curriculumSummary');
        const error = $('subjectError');
        const year = Number($('year_level')?.value || 0);
        const semester = Number($('semester')?.value || 0);

        if (!accordion) return;

        accordion.innerHTML = '';
        summary?.classList.add('d-none');
        error?.classList.add('d-none');
        badge.textContent = course ? course.course_code : 'No course selected';

        if (!course) {
            accordion.innerHTML = `<div class="curriculum-empty-state"><div class="curriculum-empty-icon">📖</div><h5>Select a course</h5><p class="mb-0">Choose a course, year level, and semester above.</p></div>`;
            status.textContent = 'Select course, year and semester.';
            return;
        }

        const curriculum = course.curriculum || [];
        const years = [...new Set(curriculum.map((item) => Number(item.year_level)))].sort((a, b) => a - b);

        if (!years.length) {
            accordion.innerHTML = '<div class="curriculum-empty-state"><div class="curriculum-empty-icon">📖</div><h5>No curriculum configured</h5><p class="mb-0">This course does not have curriculum records yet.</p></div>';
            status.textContent = 'No curriculum configured for this course.';
            return;
        }

        years.forEach((yearNumber, index) => {
            const yearSubjects = curriculum.filter((item) => Number(item.year_level) === yearNumber);
            const yearId = `curriculumYear${yearNumber}`;
            const yearItem = document.createElement('div');
            yearItem.className = 'accordion-item curriculum-year-item';

            const header = document.createElement('h2');
            header.className = 'accordion-header';
            header.innerHTML = `
                <button class="accordion-button curriculum-year-button ${index === 0 ? '' : 'collapsed'}" type="button"
                        data-bs-toggle="collapse" data-bs-target="#${yearId}Body">
                    <span class="year-number">${yearNumber}</span>
                    <span><strong>${ordinalYear(yearNumber)}</strong><small>${yearSubjects.length} curriculum subject(s)</small></span>
                </button>`;

            const body = document.createElement('div');
            body.id = `${yearId}Body`;
            body.className = `accordion-collapse collapse ${index === 0 ? 'show' : ''}`;

            const inner = document.createElement('div');
            inner.className = 'accordion-body';

            [1, 2].forEach((sem) => {
                const subjects = yearSubjects.filter((item) => Number(item.semester) === sem);
                if (!subjects.length) return;

                const selected = Number(year) === yearNumber && sem === semester;
                const card = document.createElement('div');
                card.className = `semester-card ${selected ? 'selected-semester' : ''}`;
                const semId = `${yearId}Semester${sem}`;

                const toggle = document.createElement('button');
                toggle.type = 'button';
                toggle.className = 'semester-toggle';
                toggle.setAttribute('data-bs-toggle', 'collapse');
                toggle.setAttribute('data-bs-target', `#${semId}Body`);
                const units = subjects.reduce((sum, item) => sum + Number(item.units || 0), 0);
                toggle.innerHTML = `<span><strong>${semesterLabel(sem)}</strong><small>${subjects.length} subject(s)</small></span><span class="semester-total">${units} units</span>`;

                const semBody = document.createElement('div');
                semBody.id = `${semId}Body`;
                semBody.className = `collapse ${selected ? 'show' : ''}`;
                semBody.appendChild(makeSubjectTable(subjects, selected));

                card.append(toggle, semBody);
                inner.appendChild(card);
            });

            body.appendChild(inner);
            yearItem.append(header, body);
            accordion.appendChild(yearItem);
        });

        const selectedSubjects = selectedCurriculum(course);
        if (!year || !semester) {
            status.textContent = 'Curriculum loaded. Select a year level and semester.';
            return;
        }

        if (!selectedSubjects.length) {
            status.textContent = 'Curriculum not configured for this year and semester.';
            return;
        }

        const units = selectedSubjects.reduce((sum, item) => sum + Number(item.units || 0), 0);
        summary?.classList.remove('d-none');
        $('selectedSemesterLabel').textContent = `${ordinalYear(year)} • ${semesterLabel(semester)}`;
        $('selectedSubjectCount').textContent = selectedSubjects.length;
        $('totalUnits').textContent = `${units} units`;
        status.textContent = 'Curriculum loaded successfully.';
    }

    function renderAcademicDetails() {
        const course = selectedCourse();
        renderSections(course);
        renderCurriculum(course);
    }

    function buildSummary() {
        const data = collectFormData();
        const course = selectedCourse();
        const section = course?.sections?.find((item) => String(item.id) === String(data.section_id));
        const rows = [
            ['Name', [data.first_name, data.middle_name, data.last_name].filter(Boolean).join(' ')],
            ['Email', data.email],
            ['Contact', data.contact],
            ['Sex', data.sex],
            ['Birthdate', data.birthdate],
            ['Address', data.address],
            ['Course', course ? `${course.course_code} — ${course.course_name}` : '—'],
            ['Year Level', data.year_level ? ordinalYear(data.year_level) : '—'],
            ['Semester', data.semester ? semesterLabel(data.semester) : '—'],
            ['Section', section?.section_name || '—'],
            ['Guardian', data.guardian],
            ['Guardian Contact', data.guardian_contact],
            ['Subjects', `${(data.subject_ids || []).length} curriculum subject(s)`]
        ];

        const box = $('summaryBox');
        if (!box) return;
        box.innerHTML = rows.map(([label, value]) => `
            <div class="summary-row"><span>${escapeHtml(label)}</span><span>${escapeHtml(value || '—')}</span></div>
        `).join('');
    }

    function showAccountResult() {
        if (window.ENROLLMENT_ERROR && window.Swal) {
            Swal.fire({ icon: 'error', title: 'Enrollment incomplete', text: window.ENROLLMENT_ERROR, confirmButtonColor: '#1e5a96' });
        }

        if (!window.NEW_STUDENT_ACCOUNT || !window.Swal) return;

        const account = window.NEW_STUDENT_ACCOUNT;
        Swal.fire({
            icon: 'success',
            title: 'Enrollment submitted',
            confirmButtonColor: '#1e5a96',
            html: `
                <div class="account-created-alert">
                    <p class="account-created-lead">Your application is waiting for admin verification. Save these portal credentials now.</p>
                    <div class="account-credential-box">
                        <div class="credential-row"><span>Email</span><strong>${escapeHtml(account.email)}</strong></div>
                        <div class="credential-row"><span>Temporary Password</span><strong>${escapeHtml(account.password)}</strong></div>
                    </div>
                    <div class="account-created-warning">For security, change this password after signing in.</div>
                    <p class="account-created-status">Your account is ready. Use the login page to access your student portal.</p>
                </div>`
        });
    }

    function init() {
        if (!form) return;

        $('birthdate')?.addEventListener('change', validateBirthdate);
        $('birthdate')?.addEventListener('input', validateBirthdate);
        $('course_id')?.addEventListener('change', renderAcademicDetails);
        $('year_level')?.addEventListener('change', renderAcademicDetails);
        $('semester')?.addEventListener('change', renderAcademicDetails);

        document.querySelectorAll('.btn-next').forEach((button) => {
            button.addEventListener('click', () => {
                const current = document.querySelector('.wizard-pane.active');
                if (validatePane(current)) showStep(state.step + 1);
            });
        });

        document.querySelectorAll('.btn-prev').forEach((button) => {
            button.addEventListener('click', () => showStep(state.step - 1));
        });

        $('backToHomeBtn')?.addEventListener('click', () => {
            window.location.href = '../webhome.php';
        });

        $('previewRegistrationFormBtn')?.addEventListener('click', () => {
            buildSummary();
            if (window.Swal) {
                Swal.fire({
                    title: 'Application Review',
                    html: $('summaryBox')?.innerHTML || '',
                    width: 760,
                    confirmButtonColor: '#1e5a96'
                });
            }
        });

        form.querySelectorAll('input, select, textarea').forEach((field) => {
            field.addEventListener('input', () => field.classList.remove('is-invalid'));
            field.addEventListener('change', () => field.classList.remove('is-invalid'));
        });

        form.addEventListener('submit', (event) => {
            const current = document.querySelector('.wizard-pane.active');
            if (!validatePane(current)) {
                event.preventDefault();
                return;
            }

            const submitButton = $('submitApplicationBtn');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = 'Submitting…';
            }
        });

        renderAcademicDetails();
        showStep(1);

        const loader = $('pageLoader');
        window.setTimeout(() => loader?.classList.add('loaded'), 250);
        showAccountResult();
    }

    document.addEventListener('DOMContentLoaded', init);
})();
