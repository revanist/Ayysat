<?php
declare(strict_types=1);
require_once __DIR__ . '/../functions/academic_auth.php';
require_academic_login();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);
require_once __DIR__ . '/../functions/system_settings.php';
$schoolYear = system_school_year($conn);

function registrar_count(mysqli $conn, string $sql): int {
    $r = mysqli_query($conn, $sql);
    return $r ? (int)(mysqli_fetch_assoc($r)['total'] ?? 0) : 0;
}

$stats = [
    'students' => registrar_count($conn, "SELECT COUNT(DISTINCT student_id) total FROM enrollments WHERE status IN ('Approved', 'Enrolled')"),
    'pending' => registrar_count($conn, "SELECT COUNT(*) total FROM enrollments WHERE STATUS='Pending'"),
    'programs' => registrar_count($conn, "SELECT COUNT(*) total FROM courses WHERE course_code IN ('BSIT','BSCS','BSIS')"),
    'sections' => registrar_count($conn, "SELECT COUNT(*) total FROM sections s INNER JOIN courses c ON c.id=s.course_id WHERE c.course_code IN ('BSIT','BSCS','BSIS')"),
    'instructors' => registrar_count($conn, "SELECT COUNT(*) total FROM users WHERE role_id=2"),
];

$pending = [];
$q = mysqli_query($conn, "SELECT e.id enrollment_id, e.created, s.id student_id, s.first_name, s.middle_name, s.last_name, s.email, c.course_code, sec.section_name FROM enrollments e INNER JOIN students s ON s.id=e.student_id LEFT JOIN courses c ON c.id=e.course_id LEFT JOIN sections sec ON sec.id=e.section_id WHERE e.STATUS='Pending' ORDER BY e.created ASC LIMIT 6");
while ($q && ($row = mysqli_fetch_assoc($q))) $pending[] = $row;

$recentStudents = [];
$q = mysqli_query($conn, "SELECT s.id, s.student_number, s.first_name, s.middle_name, s.last_name, e.status AS enrollment_status, c.course_code FROM enrollments e JOIN students s ON s.id=e.student_id LEFT JOIN courses c ON c.id=e.course_id ORDER BY e.id DESC LIMIT 6");
while ($q && ($row = mysqli_fetch_assoc($q))) $recentStudents[] = $row;

$sections = [];
$q = mysqli_query($conn, "SELECT s.id, s.section_name, s.max_slots, c.course_code, (SELECT COUNT(*) FROM enrollments e WHERE e.section_id=s.id AND e.status IN ('Approved','Enrolled') AND e.school_year='" . mysqli_real_escape_string($conn, $schoolYear) . "') student_count FROM sections s INNER JOIN courses c ON c.id=s.course_id WHERE c.course_code IN ('BSIT','BSCS','BSIS') ORDER BY c.course_code, s.section_name LIMIT 10");
while ($q && ($row = mysqli_fetch_assoc($q))) $sections[] = $row;

$unassignedSubjects = registrar_count($conn, "SELECT COUNT(*) total FROM subjects sub INNER JOIN sections sec ON sec.id=sub.section_id LEFT JOIN teaching_assignments ta ON ta.subject_id=sub.id AND ta.section_id=sub.section_id AND ta.school_year='" . mysqli_real_escape_string($conn, $schoolYear) . "' AND ta.status='Active' WHERE sub.section_id IS NOT NULL AND ta.id IS NULL");

$csrf = academic_csrf_token();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Registrar Dashboard | EYYSAT</title>
<link rel="stylesheet" href="../css/admin_dashboard.css">
<link rel="stylesheet" href="../css/ux-polish.css">
<link rel="stylesheet" href="../css/all.min.css">
<style>
:root {
    --primary: #d8ff61;
    --primary-dim: rgba(216, 255, 97, 0.1);
    --bg-card: rgba(255, 255, 255, 0.04);
    --border: rgba(255, 255, 255, 0.08);
    --text-muted: #a1a1aa;
    --danger: #f87171;
    --danger-dim: rgba(248, 113, 113, 0.1);
}
.reg-wrap { max-width: 1400px; margin: 0 auto; padding-bottom: 40px; }
.hero-header { margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 15px; }
.hero-badge { display: inline-block; padding: 6px 12px; background: var(--primary-dim); color: var(--primary); border-radius: 20px; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 12px; }
.hero-title { font-size: 2rem; margin: 0 0 8px; font-weight: 800; }
.hero-subtitle { color: var(--text-muted); margin: 0; font-size: 1rem; }
.term-indicator { background: var(--bg-card); border: 1px solid var(--border); padding: 12px 20px; border-radius: 12px; display: flex; flex-direction: column; align-items: flex-end; }
.term-label { font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; }
.term-value { font-size: 1.1rem; font-weight: 700; color: #fff; }

.stats-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.stat-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; padding: 20px; display: flex; align-items: center; gap: 16px; transition: transform 0.2s; }
.stat-card:hover { transform: translateY(-3px); border-color: rgba(255, 255, 255, 0.15); }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; background: rgba(255,255,255,0.05); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; color: var(--text-muted); }
.stat-card.primary .stat-icon { background: var(--primary-dim); color: var(--primary); }
.stat-info { display: flex; flex-direction: column; }
.stat-value { font-size: 1.5rem; font-weight: 800; line-height: 1.2; }
.stat-label { font-size: 0.8rem; color: var(--text-muted); font-weight: 500; }

.alerts-container { margin-bottom: 24px; }
.alert-box { display: flex; align-items: center; gap: 15px; padding: 16px 20px; border-radius: 12px; background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.2); margin-bottom: 12px; }
.alert-box i { font-size: 1.5rem; color: #fbbf24; }
.alert-content h4 { margin: 0 0 4px; color: #fde68a; font-size: 1rem; }
.alert-content p { margin: 0; color: #d1d5db; font-size: 0.85rem; }

.grid-layout { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 24px; }
@media (max-width: 992px) { .grid-layout { grid-template-columns: 1fr; } }

.panel { background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; display: flex; flex-direction: column; overflow: hidden; }
.panel-header { padding: 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
.panel-title { margin: 0; font-size: 1.1rem; font-weight: 700; display: flex; align-items: center; gap: 10px; }
.panel-title i { color: var(--primary); }
.panel-action { font-size: 0.8rem; font-weight: 700; color: var(--primary); text-decoration: none; padding: 6px 12px; background: var(--primary-dim); border-radius: 8px; transition: 0.2s; }
.panel-action:hover { background: var(--primary); color: #000; }

.data-table { width: 100%; border-collapse: collapse; }
.data-table th, .data-table td { padding: 14px 20px; text-align: left; border-bottom: 1px solid var(--border); font-size: 0.85rem; }
.data-table th { font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); font-weight: 600; letter-spacing: 0.5px; background: rgba(0,0,0,0.2); }
.data-table tr:last-child td { border-bottom: none; }
.data-table tbody tr:hover { background: rgba(255,255,255,0.02); }

.user-cell { display: flex; flex-direction: column; }
.user-name { font-weight: 600; color: #fff; font-size: 0.9rem; }
.user-sub { color: var(--text-muted); font-size: 0.75rem; margin-top: 2px; }

.status-badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 0.7rem; font-weight: 700; }
.status-pending { background: rgba(245, 158, 11, 0.15); color: #fbbf24; }
.status-enrolled { background: rgba(34, 197, 94, 0.15); color: #4ade80; }
.status-full { background: var(--danger-dim); color: var(--danger); }

.quick-links { display: flex; flex-direction: column; padding: 10px; }
.q-link { display: flex; align-items: center; gap: 15px; padding: 15px; text-decoration: none; color: #fff; border-radius: 10px; transition: 0.2s; }
.q-link:hover { background: rgba(255,255,255,0.05); }
.q-icon { width: 40px; height: 40px; border-radius: 10px; background: rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: center; color: var(--primary); font-size: 1.1rem; }
.q-text h5 { margin: 0 0 3px; font-size: 0.95rem; }
.q-text p { margin: 0; font-size: 0.75rem; color: var(--text-muted); }

.progress-bar-bg { width: 100%; height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; overflow: hidden; margin-top: 8px; }
.progress-bar-fill { height: 100%; background: var(--primary); border-radius: 3px; }
.progress-bar-fill.danger { background: var(--danger); }

.empty-state { padding: 40px 20px; text-align: center; color: var(--text-muted); }
.empty-state i { font-size: 2.5rem; margin-bottom: 15px; opacity: 0.5; }
</style>
</head>
<body>
<?php include __DIR__ . '/../sidebar/sidebar.php'; ?>
<main class="dashboard-main">
    <div class="reg-wrap">
        
        <div class="hero-header">
            <div>
                <span class="hero-badge">REGISTRAR / ACADEMIC AFFAIRS</span>
                <h1 class="hero-title">Registrar Workspace</h1>
                <p class="hero-subtitle">Manage admissions, academic structures, and faculty assignments.</p>
            </div>
            <div class="term-indicator">
                <span class="term-label">Active Academic Year</span>
                <span class="term-value">SY <?= htmlspecialchars($schoolYear) ?></span>
            </div>
        </div>

        <?php if ($stats['pending'] > 0 || $unassignedSubjects > 0): ?>
        <div class="alerts-container">
            <?php if ($stats['pending'] > 0): ?>
            <div class="alert-box">
                <i class="fa-solid fa-users-viewfinder"></i>
                <div class="alert-content">
                    <h4>Action Required: Pending Enrollments</h4>
                    <p>There are <strong><?= $stats['pending'] ?></strong> student applications waiting for your review and approval.</p>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($unassignedSubjects > 0): ?>
            <div class="alert-box" style="background: rgba(248, 113, 113, 0.1); border-color: rgba(248, 113, 113, 0.2);">
                <i class="fa-solid fa-triangle-exclamation" style="color: #f87171;"></i>
                <div class="alert-content">
                    <h4 style="color: #fca5a5;">Missing Faculty Assignments</h4>
                    <p>There are <strong><?= $unassignedSubjects ?></strong> subjects in active sections without an assigned instructor.</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="stats-container">
            <div class="stat-card primary">
                <div class="stat-icon"><i class="fa-solid fa-user-graduate"></i></div>
                <div class="stat-info">
                    <span class="stat-value"><?= number_format($stats['students']) ?></span>
                    <span class="stat-label">Enrolled Students</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-book-open"></i></div>
                <div class="stat-info">
                    <span class="stat-value"><?= number_format($stats['programs']) ?></span>
                    <span class="stat-label">Programs</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-chalkboard-user"></i></div>
                <div class="stat-info">
                    <span class="stat-value"><?= number_format($stats['sections']) ?></span>
                    <span class="stat-label">Active Sections</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-user-tie"></i></div>
                <div class="stat-info">
                    <span class="stat-value"><?= number_format($stats['instructors']) ?></span>
                    <span class="stat-label">Faculty Members</span>
                </div>
            </div>
        </div>

        <div class="grid-layout">
            <!-- Left Column -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                
                <!-- Pending Applications -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title"><i class="fa-solid fa-user-clock"></i> Pending Admissions</h3>
                        <a href="pending_enrollments.php" class="panel-action">Review All</a>
                    </div>
                    <?php if ($pending): ?>
                    <div style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Applicant</th>
                                    <th>Program & Section</th>
                                    <th>Date Applied</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($pending as $row): ?>
                                <tr>
                                    <td>
                                        <div class="user-cell">
                                            <span class="user-name"><?= htmlspecialchars(trim($row['first_name'].' '.($row['middle_name']??'').' '.$row['last_name'])) ?></span>
                                            <span class="user-sub"><?= htmlspecialchars($row['email']??'') ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span style="font-weight: 600;"><?= htmlspecialchars($row['course_code']??'—') ?></span><br>
                                        <span style="color: var(--text-muted); font-size: 0.75rem;"><?= htmlspecialchars($row['section_name']??'—') ?></span>
                                    </td>
                                    <td style="color: var(--text-muted);"><?= date('M d, Y', strtotime($row['created'])) ?></td>
                                    <td>
                                        <a href="student_info.php?id=<?= (int)$row['student_id'] ?>" style="color: var(--primary); text-decoration: none; font-weight: 600; font-size: 0.8rem;">Review →</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="empty-state">
                        <i class="fa-solid fa-check-circle" style="color: #4ade80;"></i>
                        <p>All caught up! No pending applications.</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Recent Students -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title"><i class="fa-solid fa-users"></i> Recently Enrolled</h3>
                        <a href="students.php" class="panel-action">View Directory</a>
                    </div>
                    <?php if ($recentStudents): ?>
                    <div style="overflow-x: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Student No.</th>
                                    <th>Program</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recentStudents as $row): ?>
                                <tr>
                                    <td>
                                        <span class="user-name"><?= htmlspecialchars(trim($row['first_name'].' '.($row['middle_name']??'').' '.$row['last_name'])) ?></span>
                                    </td>
                                    <td style="font-family: monospace; color: var(--text-muted);"><?= htmlspecialchars($row['student_number']??'Pending') ?></td>
                                    <td><?= htmlspecialchars($row['course_code']??'—') ?></td>
                                    <td>
                                        <?php if(in_array($row['enrollment_status'], ['Approved', 'Enrolled'])): ?>
                                            <span class="status-badge status-enrolled">Enrolled</span>
                                        <?php else: ?>
                                            <span class="status-badge status-pending"><?= htmlspecialchars($row['enrollment_status']??'—') ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="empty-state">
                        <i class="fa-solid fa-folder-open"></i>
                        <p>No student records found.</p>
                    </div>
                    <?php endif; ?>
                </div>

            </div>

            <!-- Right Column -->
            <div style="display: flex; flex-direction: column; gap: 20px;">
                
                <!-- Academic Setup Workflow -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title"><i class="fa-solid fa-sliders"></i> Academic Setup</h3>
                    </div>
                    <div class="quick-links">
                        <a href="courses.php" class="q-link">
                            <div class="q-icon"><i class="fa-solid fa-graduation-cap"></i></div>
                            <div class="q-text">
                                <h5>Programs & Courses</h5>
                                <p>Manage available degrees.</p>
                            </div>
                        </a>
                        <a href="curriculum.php" class="q-link">
                            <div class="q-icon"><i class="fa-solid fa-list-check"></i></div>
                            <div class="q-text">
                                <h5>Curriculum Design</h5>
                                <p>Define subject prerequisites.</p>
                            </div>
                        </a>
                        <a href="sections.php" class="q-link">
                            <div class="q-icon"><i class="fa-solid fa-layer-group"></i></div>
                            <div class="q-text">
                                <h5>Class Sections</h5>
                                <p>Create sections and capacity.</p>
                            </div>
                        </a>
                        <a href="assign_subjects.php" class="q-link">
                            <div class="q-icon"><i class="fa-solid fa-person-chalkboard"></i></div>
                            <div class="q-text">
                                <h5>Faculty Assignment</h5>
                                <p>Allocate instructors to classes.</p>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Section Utilization -->
                <div class="panel">
                    <div class="panel-header">
                        <h3 class="panel-title"><i class="fa-solid fa-chart-pie"></i> Section Capacity</h3>
                        <a href="sections.php" class="panel-action">Manage</a>
                    </div>
                    <div style="padding: 15px 20px;">
                        <?php if ($sections): ?>
                            <div style="display: flex; flex-direction: column; gap: 16px;">
                                <?php foreach($sections as $row): 
                                    $count=(int)$row['student_count']; 
                                    $cap=max(1,(int)$row['max_slots']); 
                                    $pct=min(100, round(($count/$cap)*100));
                                    $full=$count >= $cap; 
                                ?>
                                <div>
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                                        <span style="font-weight: 600; font-size: 0.85rem;"><?= htmlspecialchars($row['section_name']) ?> <span style="color:var(--text-muted); font-weight:normal;">(<?= htmlspecialchars($row['course_code']) ?>)</span></span>
                                        <span style="font-size: 0.8rem; color: <?= $full ? 'var(--danger)' : 'var(--text-muted)' ?>; font-weight: <?= $full ? '700' : 'normal' ?>;">
                                            <?= $count ?> / <?= $cap ?>
                                        </span>
                                    </div>
                                    <div class="progress-bar-bg">
                                        <div class="progress-bar-fill <?= $pct > 90 ? 'danger' : '' ?>" style="width: <?= $pct ?>%;"></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state" style="padding: 20px;">
                                <p>No active sections.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>

    </div>
</main>
</body>
</html>
