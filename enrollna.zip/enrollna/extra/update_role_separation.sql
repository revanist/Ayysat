-- EYYSAT role separation migration
-- Run this on an existing v10 database. The application also performs these
-- checks at runtime, but this migration makes the database ready immediately.

INSERT INTO roles (id, name, description) VALUES
(5, 'Registrar / Academic Affairs', 'Academic records, curriculum, sections, enrollment and instructor assignment access')
ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description);

CREATE TABLE IF NOT EXISTS system_settings (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  setting_key VARCHAR(80) NOT NULL,
  setting_value VARCHAR(255) NOT NULL,
  updated_by INT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_system_settings_key (setting_key),
  KEY idx_system_settings_updated_by (updated_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO system_settings (setting_key, setting_value, updated_by) VALUES
('school_year', '2026-2027', NULL),
('enrollment_fee', '20000.00', NULL)
ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key);

-- If users.role is a generated column, add/update it manually only if your
-- existing database uses that column. The application repairs it at runtime.
