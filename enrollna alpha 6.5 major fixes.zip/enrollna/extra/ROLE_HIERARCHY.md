# EYYSAT Unified User Hierarchy

The semi-final database now uses one account table: `users`.

| role_id | Role | Access |
|---:|---|---|
| 1 | Super Admin | Full administrative access |
| 2 | Instructor / Professor | Teacher portal, assigned subjects/sections, announcements and LMS functions |
| 3 | Student | Student enrollment, profile, curriculum and payment records |
| 4 | Cashier | Payment verification, collection and receipt access |

There are no separate `admins` or `teachers` tables in the new database. Instructor/professor records use `users.user_id`, and instructor-related tables such as `teacher_profiles` and `teaching_assignments`, `lms_announcements`, and `lms_materials` use that same user ID as `teacher_id`.

`email` is the login email for all four roles. Passwords remain hashed with PHP `password_hash()`.
