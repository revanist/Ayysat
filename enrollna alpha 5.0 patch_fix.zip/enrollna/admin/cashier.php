<?php

require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();

include '../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);


/* =========================================================
   PAYMENT DATA
========================================================= */

$query = mysqli_query(
    $conn,
    "
    SELECT
        enrollments.id,
        students.student_number,
        students.first_name,
        students.last_name,
        courses.course_code,
        enrollments.payment_status,
        enrollments.payment_method,
        enrollments.cash_amount_requested,
        enrollments.payment_account,
        enrollments.payment_reference,
        enrollments.payment_proof,
        enrollments.amount_paid,
        enrollments.STATUS,
        enrollments.created

    FROM enrollments

    INNER JOIN students
        ON enrollments.student_id = students.id

    LEFT JOIN courses
        ON students.course_id = courses.id

        WHERE enrollments.payment_status = 'pending'

    ORDER BY enrollments.created DESC
    "
);


/* =========================================================
   COUNTS
========================================================= */

$totalPending = (int) (
    mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "
            SELECT COUNT(*) total
            FROM enrollments
            WHERE payment_status = 'pending'
            "
        )
    )['total'] ?? 0
);


$totalPaid = (int) (
    mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "
            SELECT COUNT(*) total
            FROM enrollments
            WHERE payment_status = 'paid'
            "
        )
    )['total'] ?? 0
);


/* =========================================================
   ADMIN NAME
========================================================= */

$adminName = htmlspecialchars(
    $_SESSION['admin_name'] ?? 'Admin'
);

function cashier_payment_method(?string $method): string
{
    return match (strtolower(trim((string) $method))) {
        'gcash' => 'GCash',
        'cash' => 'Cash',
        'card' => 'Card',
        default => '—',
    };
}


/* =========================================================
   CSRF
========================================================= */

$csrf = admin_csrf_token();

$reviewId = (int) ($_GET['review'] ?? $_GET['confirmed'] ?? $_GET['receipt'] ?? 0);
$receiptMode = isset($_GET['receipt']) || isset($_GET['confirmed']);
$reviewData = null;

if ($reviewId > 0) {
    $reviewStmt = mysqli_prepare($conn, '
        SELECT e.id, e.status, e.payment_status, e.payment_method,
               e.payment_option, e.payment_reference, e.payment_account,
               e.payment_proof, e.amount_paid, e.cash_amount_requested, e.created,
               s.id AS student_id, s.student_number, s.first_name,
               s.last_name, s.email, c.course_code
        FROM enrollments e
        INNER JOIN students s ON s.id = e.student_id
        LEFT JOIN courses c ON c.id = e.course_id
        WHERE e.id = ?
        LIMIT 1
    ');
    mysqli_stmt_bind_param($reviewStmt, 'i', $reviewId);
    mysqli_stmt_execute($reviewStmt);
    $reviewData = mysqli_fetch_assoc(mysqli_stmt_get_result($reviewStmt));
    mysqli_stmt_close($reviewStmt);
}

$confirmedId = (int) ($_GET['confirmed'] ?? 0);

/* Show submitted payments to the cashier even if they arrive while offline. */
$paymentAlerts = [];
$alertQuery = mysqli_query(
    $conn,
    "SELECT n.id, n.enrollment_id, s.first_name, s.last_name,
            e.payment_method, e.payment_reference, e.cash_amount_requested
      FROM admin_notifications n
      INNER JOIN enrollments e ON e.id = n.enrollment_id
      INNER JOIN students s ON s.id = e.student_id
      WHERE n.is_read = 0
      ORDER BY n.created_at ASC
      LIMIT 10"
);

if ($alertQuery) {
    $notificationIds = [];
    while ($alert = mysqli_fetch_assoc($alertQuery)) {
        $paymentAlerts[] = [
            'id' => (int) $alert['enrollment_id'],
            'student' => trim($alert['first_name'] . ' ' . $alert['last_name']),
            'method' => cashier_payment_method($alert['payment_method']),
            'reference' => (string) $alert['payment_reference'],
            'amount' => number_format((float) $alert['cash_amount_requested'], 2),
        ];
        $notificationIds[] = (int) $alert['id'];
    }

    if ($notificationIds !== []) {
        mysqli_query(
            $conn,
            'UPDATE admin_notifications SET is_read = 1 WHERE id IN (' .
            implode(',', $notificationIds) . ')'
        );
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Cashier – EYYSAT</title>


    <!-- SAME ADMIN DASHBOARD CSS -->

    <link
        rel="stylesheet"
        href="../css/admin_dashboard.css">


    <!-- SWEET ALERT -->

    <script
        src="../js/sweetalert2.all.min.js">
    </script>

    <script
        src="../js/swal-confirm.js"
        defer>
    </script>

<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>


<body>


    <!-- =====================================================
         SIDEBAR
    ===================================================== -->

    <aside
        class="admin-sidebar"
        id="adminSidebar">


        <!-- =================================================
             BRAND / LOGO
        ================================================= -->

        <div class="sidebar-brand">


            <div class="sidebar-logo">

                <a href="admin_dashboard.php">

                    <img
                        src="../img/eyysat.png"
                        alt="EYYSAT Logo">

                </a>

            </div>


            <div class="sidebar-brand-text">

                <strong>
                    EYYSAT
                </strong>

                <span>
                    ADMIN PANEL
                </span>

            </div>

        </div>


        <!-- =================================================
             NAVIGATION
        ================================================= -->

        <?php
$sidebarUnreadCount = 0;
if (isset($conn)) {
    $sidebarNotifResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM admin_notifications WHERE is_read = 0");
    if ($sidebarNotifResult) { $sidebarUnreadCount = (int) (mysqli_fetch_assoc($sidebarNotifResult)['total'] ?? 0); }
}
?>
        <nav class="sidebar-nav">


            <p class="sidebar-label">
                MAIN MENU
            </p>


            <!-- DASHBOARD -->

            <a
                href="admin_dashboard.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#127968;
                </span>

                <span class="sidebar-text">
                    Dashboard
                </span>

            </a>


            <!-- STUDENTS -->

            <a
                href="students.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#127891;
                </span>

                <span class="sidebar-text">
                    Students
                </span>

            </a>


            <!-- COURSES -->

            <a
                href="courses.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128218;
                </span>

                <span class="sidebar-text">
                    Courses
                </span>

            </a>


            <!-- ENROLLMENTS -->

            <a
                href="enrollments.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128214;
                </span>

                <span class="sidebar-text">
                    Enrollments
                </span>

            </a>


            <!-- CASHIER -->

            <a
                href="cashier.php"
                class="sidebar-link active">

                <span class="sidebar-icon">
                    &#128176;
                </span>

                <span class="sidebar-text">
                    Cashier
                </span>

            </a>
            <a href="notifications.php" class="sidebar-link"><span class="sidebar-icon">&#128276;</span><span class="sidebar-text">Notifications</span><?php if (($sidebarUnreadCount ?? 0) > 0): ?><span class="sidebar-notification-badge"><?= ($sidebarUnreadCount ?? 0) > 99 ? '99+' : ($sidebarUnreadCount ?? 0) ?></span><?php endif; ?></a>


            <p class="sidebar-label sidebar-label-bottom">
                ACCOUNT
            </p>


            <!-- LOGOUT -->

            <a
                href="../auth/logout.php"
                class="sidebar-link sidebar-logout">

                <span class="sidebar-icon">
                    &#128682;
                </span>

                <span class="sidebar-text">
                    Logout
                </span>

            </a>


        </nav>


        <!-- =================================================
             PROFILE
        ================================================= -->

        <div class="sidebar-profile">


            <div class="profile-avatar">

                <?= strtoupper(
                    substr($adminName, 0, 1)
                ) ?>

            </div>


            <div class="profile-info">

                <strong>
                    <?= $adminName ?>
                </strong>

                <span>
                    Administrator
                </span>

            </div>


        </div>


    </aside>


    <!-- =====================================================
         MOBILE OVERLAY
    ===================================================== -->

    <div
        class="sidebar-overlay"
        id="sidebarOverlay">
    </div>


    <!-- =====================================================
         MAIN DASHBOARD
    ===================================================== -->

    <main
        class="dashboard-main"
        id="dashboardMain">


        <!-- =================================================
             SIDEBAR TOGGLE
        ================================================= -->

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
            aria-label="Toggle sidebar">
        </button>


        <!-- =================================================
             TOPBAR
        ================================================= -->

        <header class="dashboard-topbar">


            <div>

                <span class="topbar-label">
                    ADMINISTRATION
                </span>

                <h2>
                    Cashier
                </h2>

            </div>

        </header>


        <!-- =================================================
             PAGE HEADER
        ================================================= -->

        <section class="page-header">

            <span class="topbar-label">
                PAYMENT MANAGEMENT
            </span>

            <h1>
                Cashier
            </h1>

            <p>
                Review and confirm student payments.
            </p>

        </section>


        <!-- =================================================
             STATISTICS
        ================================================= -->

        <section class="stats-row">


            <!-- PENDING -->

            <div class="stat-card stat-warning">

                <div class="stat-icon">
                    ⏳
                </div>

                <h3>
                    Pending Payments
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $totalPending ?>">

                    <?= $totalPending ?>

                </span>

            </div>


            <!-- VERIFIED -->

            <div class="stat-card stat-paid">

                <div class="stat-icon">
                    ✅
                </div>

                <h3>
                    Verified Payments
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $totalPaid ?>">

                    <?= $totalPaid ?>

                </span>

            </div>


        </section>


        <!-- =================================================
             PAYMENT VERIFICATION
        ================================================= -->

        <section class="card recent-card">


            <!-- CARD HEADER -->

            <div class="table-header">


                <div>

                    <span class="topbar-label">
                        PAYMENT VERIFICATION
                    </span>

                    <h2>
                        Student Payments
                    </h2>

                </div>


                <input
                    type="text"
                    id="searchInput"
                    class="search-box"
                    placeholder="Search student...">


            </div>


            <!-- TABLE -->

            <div class="table-wrapper">


                <table
                    class="modern-table"
                    id="cashierTable">


                    <thead>

                        <tr>

                            <th>
                                Student No.
                            </th>

                            <th>
                                Name
                            </th>

                            <th>
                                Course
                            </th>

                            <th>
                                Enrollment
                            </th>

                            <th>
                                Payment
                            </th>

                            <th>
                                Payment Method
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Action
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                        <?php if (mysqli_num_rows($query) === 0): ?>


                            <tr>

                                <td
                                    colspan="8"
                                    class="empty-state">

                                    <div>
                                        💰
                                    </div>

                                    <strong>
                                        No pending payments
                                    </strong>

                                    <span>
                                        There are currently no submitted payments waiting for verification.
                                    </span>

                                </td>

                            </tr>


                        <?php else: ?>


                            <?php while ($row = mysqli_fetch_assoc($query)): ?>


                                <tr>


                                    <!-- STUDENT NUMBER -->

                                    <td>

                                        <strong class="table-primary">

                                            <?= htmlspecialchars(
                                                $row['student_number']
                                            ) ?>

                                        </strong>

                                    </td>


                                    <!-- NAME -->

                                    <td>

                                        <?= htmlspecialchars(
                                            $row['first_name']
                                                . ' '
                                                . $row['last_name']
                                        ) ?>

                                    </td>


                                    <!-- COURSE -->

                                    <td>

                                        <?= htmlspecialchars(
                                            $row['course_code'] ?? '—'
                                        ) ?>

                                    </td>


                                    <!-- ENROLLMENT -->

                                    <td>

                                        <span class="status-approved">

                                            <?= htmlspecialchars(
                                                ucfirst(
                                                    $row['STATUS']
                                                )
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- PAYMENT -->

                                    <td>

                                        <span class="status-pending">

                                            <?= htmlspecialchars(
                                                ucfirst(
                                                    $row['payment_status']
                                                )
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- PAYMENT METHOD -->

                                    <td>
                                        <span class="payment-badge cash">
                                            <?= htmlspecialchars(cashier_payment_method($row['payment_method'] ?? null)) ?>
                                        </span>
                                    </td>


                                    <!-- DATE -->

                                    <td>

                                        <?= htmlspecialchars(
                                            date(
                                                'M d, Y',
                                                strtotime(
                                                    $row['created']
                                                )
                                            )
                                        ) ?>

                                    </td>


                                    <!-- ACTION -->

                                    <td>


                                        <a
                                            href="cashier.php?review=<?= (int) $row['id'] ?>"
                                            class="btn-edit">
                                            Review
                                        </a>


                                    </td>


                                </tr>


                            <?php endwhile; ?>


                        <?php endif; ?>


                    </tbody>


                </table>


            </div>


        </section>


    </main>

    <?php if ($reviewData): ?>
        <div class="cashier-review-backdrop" role="dialog" aria-modal="true">
            <div class="cashier-review-modal <?= $receiptMode ? 'receipt-mode' : '' ?>">
                <div class="cashier-modal-topbar">
                    <div>
                        <span class="cashier-eyebrow"><?= $receiptMode ? 'OFFICIAL PAYMENT RECEIPT' : 'CASHIER VERIFICATION' ?></span>
                        <h2><?= $receiptMode ? 'Payment Receipt' : 'Review Payment' ?></h2>
                        <p><?= $receiptMode ? 'A complete record of the payment submitted for this enrollment.' : 'Verify the payment information before approving the student payment.' ?></p>
                    </div>
                    <a class="cashier-close-btn" href="cashier.php" aria-label="Back to cashier">&times;</a>
                </div>

                <?php if ($receiptMode): ?>
                    <div class="official-receipt">
                        <div class="receipt-brand-row">
                            <div class="receipt-brand">
                                <img src="../img/eyysat.png" alt="EYYSAT">
                                <div><strong>EYYSAT</strong><span>Enrollment &amp; Registration Portal</span></div>
                            </div>
                            <div class="receipt-status-stamp <?= strtolower($reviewData['payment_status']) === 'paid' ? 'paid' : 'pending' ?>">
                                <?= htmlspecialchars(strtoupper($reviewData['payment_status'] ?? 'PENDING')) ?>
                            </div>
                        </div>
                        <div class="receipt-title-row">
                            <div><span>PAYMENT RECEIPT</span><h3>Enrollment Payment</h3></div>
                            <div class="receipt-number"><span>Receipt No.</span><strong>PAY-<?= str_pad((string)$reviewData['id'], 8, '0', STR_PAD_LEFT) ?></strong></div>
                        </div>
                        <div class="receipt-amount-box">
                            <span>AMOUNT <?= strtolower($reviewData['payment_status']) === 'paid' ? 'PAID' : 'SUBMITTED' ?></span>
                            <strong>₱<?= number_format((float) ($reviewData['amount_paid'] ?: $reviewData['cash_amount_requested'] ?: 0), 2) ?></strong>
                        </div>
                        <div class="receipt-grid">
                            <div><span>Student Name</span><strong><?= htmlspecialchars($reviewData['first_name'].' '.$reviewData['last_name']) ?></strong></div>
                            <div><span>Student Number</span><strong><?= htmlspecialchars($reviewData['student_number']) ?></strong></div>
                            <div><span>Course</span><strong><?= htmlspecialchars($reviewData['course_code'] ?? '—') ?></strong></div>
                            <div><span>Email</span><strong><?= htmlspecialchars($reviewData['email'] ?? '—') ?></strong></div>
                            <div><span>Payment Method</span><strong><?= htmlspecialchars(cashier_payment_method($reviewData['payment_method'] ?? null)) ?></strong></div>
                            <div><span>Payer / Account</span><strong><?= htmlspecialchars($reviewData['payment_account'] ?? '—') ?></strong></div>
                            <div><span>Transaction Reference</span><strong><?= htmlspecialchars($reviewData['payment_reference'] ?: 'Not applicable — cash payment') ?></strong></div>
                            <div><span>Date Submitted</span><strong><?= htmlspecialchars(date('M d, Y • h:i A', strtotime($reviewData['created']))) ?></strong></div>
                        </div>
                        <div class="receipt-note">
                            <strong><?= strtolower($reviewData['payment_status']) === 'paid' ? 'Payment verified' : 'Verification status' ?></strong>
                            <span><?= strtolower($reviewData['payment_status']) === 'paid' ? 'This payment has been confirmed by the cashier.' : 'This receipt confirms that the payment details were submitted. Cashier verification is still required.' ?></span>
                        </div>
                        <div class="receipt-footer"><span>Thank you for using EYYSAT Enrollment Portal.</span><span>Enrollment #<?= (int)$reviewData['id'] ?></span></div>
                    </div>
                    <div class="cashier-modal-actions">
                        <a href="cashier.php?review=<?= (int)$reviewData['id'] ?>" class="btn btn-secondary">← Back to Review</a>
                        <a href="cashier.php" class="btn btn-primary">Back to Payments</a>
                    </div>
                <?php else: ?>
                    <div class="review-status-banner">
                        <span class="review-status-icon">₱</span>
                        <div><strong>Payment awaiting verification</strong><span>Compare the student's details and transaction information with the actual payment record.</span></div>
                    </div>
                    <div class="review-student-card">
                        <div><span>Student</span><strong><?= htmlspecialchars($reviewData['first_name'].' '.$reviewData['last_name']) ?></strong><small><?= htmlspecialchars($reviewData['student_number']) ?></small></div>
                        <div><span>Course</span><strong><?= htmlspecialchars($reviewData['course_code'] ?? '—') ?></strong><small><?= htmlspecialchars($reviewData['email'] ?? '—') ?></small></div>
                    </div>
                    <div class="review-payment-card">
                        <div class="review-card-heading"><span>PAYMENT DETAILS</span><strong>Submitted Payment</strong></div>
                        <div class="review-payment-grid">
                            <div><span>Method</span><strong><?= htmlspecialchars(cashier_payment_method($reviewData['payment_method'] ?? null)) ?></strong></div>
                            <div><span>Amount</span><strong class="money">₱<?= number_format((float) ($reviewData['cash_amount_requested'] ?? 0), 2) ?></strong></div>
                            <div><span>Payer / Account</span><strong><?= htmlspecialchars($reviewData['payment_account'] ?: '—') ?></strong></div>
                            <div><span>Transaction Reference</span><strong><?= htmlspecialchars($reviewData['payment_reference'] ?: 'Not applicable — cash payment') ?></strong></div>
                            <div><span>Enrollment Status</span><strong><?= htmlspecialchars(ucfirst($reviewData['status'] ?? 'Pending')) ?></strong></div>
                            <div><span>Submitted</span><strong><?= htmlspecialchars(date('M d, Y • h:i A', strtotime($reviewData['created']))) ?></strong></div>
                        </div>
                    </div>
                    <div class="cashier-modal-actions">
                        <a href="cashier.php" class="btn btn-secondary">← Back to Payments</a>
                        <a href="cashier.php?receipt=<?= (int)$reviewData['id'] ?>" class="btn btn-outline-primary">View Receipt</a>
                        <?php if (strtolower($reviewData['payment_status'] ?? '') !== 'paid'): ?>
                            <form method="POST" action="../functions/confirm_payment.php">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                                <input type="hidden" name="enrollment_id" value="<?= (int) $reviewData['id'] ?>">
                                <button type="submit" class="btn btn-success confirm-payment-button">✓ Confirm Payment</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>


    <!-- =====================================================
         SCROLL TO TOP
    ===================================================== -->

    <button
        class="scroll-top"
        id="scrollTop"
        type="button"
        aria-label="Scroll to top">

        ↑

    </button>


    <!-- =====================================================
         JAVASCRIPT
    ===================================================== -->

    <script>
        const paymentAlerts = <?= json_encode(
            $paymentAlerts,
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        ) ?>;

        if (paymentAlerts.length) {
            const escapeAlertHtml = function(value) {
                const element = document.createElement('span');
                element.textContent = String(value);
                return element.innerHTML;
            };
            const alertItems = paymentAlerts.map(function(payment) {
                const receiptUrl = 'cashier.php?receipt=' + encodeURIComponent(payment.user_id);
                return '<div style="text-align:left;margin:0 0 12px">' +
                    '<strong>' + escapeAlertHtml(payment.student) + '</strong> paid <strong>₱' + escapeAlertHtml(payment.amount) + '</strong> via ' + escapeAlertHtml(payment.method) +
                    '<br><small>Reference: ' + escapeAlertHtml(payment.reference) + '</small>' +
                    '<br><a href="' + receiptUrl + '">View payment receipt</a></div>';
            }).join('');

            Swal.fire({
                icon: 'info',
                title: paymentAlerts.length === 1 ? 'New student payment' : 'New student payments',
                html: alertItems,
                confirmButtonText: 'Review payments',
                confirmButtonColor: '#1e5a96'
            });
        }

        /* =====================================================
           SIDEBAR
        ===================================================== */

        const sidebar =
            document.getElementById(
                'adminSidebar'
            );


        const sidebarToggle =
            document.getElementById(
                'sidebarToggle'
            );


        const sidebarOverlay =
            document.getElementById(
                'sidebarOverlay'
            );


        const dashboardMain =
            document.getElementById(
                'dashboardMain'
            );


        let sidebarCollapsed = false;


        /* =====================================================
           TOGGLE POSITION
        ===================================================== */

        function updateTogglePosition() {


            if (
                window.innerWidth <= 768
            ) {

                sidebarToggle.style.left =
                    '18px';

                return;

            }


            if (sidebarCollapsed) {

                sidebarToggle.style.left =
                    '68px';

            } else {

                sidebarToggle.style.left =
                    '246px';

            }

        }


        /* =====================================================
           SIDEBAR TOGGLE
        ===================================================== */

        sidebarToggle.addEventListener(
            'click',
            function() {


                /* MOBILE */

                if (
                    window.innerWidth <= 768
                ) {

                    sidebar.classList.toggle(
                        'mobile-open'
                    );


                    sidebarOverlay.classList.toggle(
                        'show'
                    );


                    return;

                }


                /* DESKTOP */

                sidebarCollapsed = !sidebarCollapsed;


                sidebar.classList.toggle(
                    'collapsed',
                    sidebarCollapsed
                );


                dashboardMain.classList.toggle(
                    'sidebar-collapsed',
                    sidebarCollapsed
                );


                sidebarToggle.classList.toggle(
                    'collapsed',
                    sidebarCollapsed
                );


                updateTogglePosition();

            }
        );


        /* =====================================================
           MOBILE OVERLAY
        ===================================================== */

        sidebarOverlay.addEventListener(
            'click',
            function() {


                sidebar.classList.remove(
                    'mobile-open'
                );


                sidebarOverlay.classList.remove(
                    'show'
                );

            }
        );


        /* =====================================================
           MOBILE NAVIGATION
        ===================================================== */

        document
            .querySelectorAll(
                '.sidebar-link'
            )
            .forEach(
                function(link) {


                    link.addEventListener(
                        'click',
                        function() {


                            if (
                                window.innerWidth <= 768
                            ) {

                                sidebar.classList.remove(
                                    'mobile-open'
                                );


                                sidebarOverlay.classList.remove(
                                    'show'
                                );

                            }

                        }
                    );

                }
            );


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        window.addEventListener(
            'resize',
            function() {

                updateTogglePosition();

            }
        );


        updateTogglePosition();


        /* =====================================================
           COUNT UP
        ===================================================== */

        document
            .querySelectorAll(
                '.count-up'
            )
            .forEach(
                function(el) {


                    const target =
                        Number(
                            el.dataset.target
                        );


                    const duration = 1200;


                    const step =
                        target /
                        (duration / 16);


                    let current = 0;


                    const timer =
                        setInterval(
                            function() {


                                current =
                                    Math.min(
                                        current + step,
                                        target
                                    );


                                el.textContent =
                                    Math.floor(
                                        current
                                    ).toLocaleString();


                                if (
                                    current >= target
                                ) {

                                    clearInterval(
                                        timer
                                    );

                                }

                            },
                            16
                        );

                }
            );


        /* =====================================================
           SEARCH
        ===================================================== */

        const searchInput =
            document.getElementById(
                'searchInput'
            );


        searchInput.addEventListener(
            'keyup',
            function() {


                const value =
                    this.value
                    .toLowerCase()
                    .trim();


                document
                    .querySelectorAll(
                        '#cashierTable tbody tr'
                    )
                    .forEach(
                        function(row) {


                            const text =
                                row.innerText
                                .toLowerCase();


                            if (
                                row.querySelector(
                                    '.empty-state'
                                )
                            ) {

                                return;

                            }


                            row.style.display =
                                text.includes(
                                    value
                                ) ?
                                '' :
                                'none';

                        }
                    );

            }
        );


        /* =====================================================
           SCROLL TO TOP
        ===================================================== */

        const scrollTopButton =
            document.getElementById(
                'scrollTop'
            );


        window.addEventListener(
            'scroll',
            function() {


                if (
                    window.scrollY > 300
                ) {

                    scrollTopButton.classList.add(
                        'show'
                    );

                } else {

                    scrollTopButton.classList.remove(
                        'show'
                    );

                }

            }
        );


        /* =====================================================
           SCROLL TO TOP CLICK
        ===================================================== */

        scrollTopButton.addEventListener(
            'click',
            function() {


                window.scrollTo({

                    top: 0,

                    behavior: 'smooth'

                });

            }
        );


        /* =====================================================
           PREVENT CACHED PAGE AFTER LOGOUT
        ===================================================== */

        window.addEventListener(
            'pageshow',
            function(e) {


                if (e.persisted) {

                    window.location.reload();

                }

            }
        );
    </script>


</body>

</html>
