<?php
require_once __DIR__ . '/admin_auth.php';
require_admin_login();
require_admin_csrf();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/enrollment_setup.php';
ensure_enrollment_schema($conn);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/courses.php', true, 303);
    exit;
}

$subjectId = (int) ($_POST['subject_id'] ?? 0);
$courseId = (int) ($_POST['course_id'] ?? 0);
$teacher = trim((string) ($_POST['teacher_name'] ?? ''));
$day = trim((string) ($_POST['schedule_day'] ?? ''));
$time = trim((string) ($_POST['schedule_time'] ?? ''));
$room = trim((string) ($_POST['room_number'] ?? ''));

if ($subjectId <= 0 || $courseId <= 0) {
    header('Location: ../admin/courses.php', true, 303);
    exit;
}

$teacher = mb_substr($teacher, 0, 120);
$day = mb_substr($day, 0, 20);
$time = mb_substr($time, 0, 50);
$room = mb_substr($room, 0, 20);

$stmt = mysqli_prepare($conn, "
    UPDATE subjects
    SET teacher_name = NULLIF(?, ''),
        schedule_day = NULLIF(?, ''),
        schedule_time = NULLIF(?, ''),
        room_number = NULLIF(?, '')
    WHERE id = ? AND course_id = ?
");
mysqli_stmt_bind_param($stmt, 'ssssii', $teacher, $day, $time, $room, $subjectId, $courseId);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

header('Location: ../admin/courses.php?course=' . $courseId . '&saved=1', true, 303);
exit;
