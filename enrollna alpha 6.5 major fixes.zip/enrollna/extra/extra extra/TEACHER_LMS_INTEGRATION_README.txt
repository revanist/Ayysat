EYYSAT 6.5 - Instructor/LMS Integration

This version uses the unified users table (role_id=2) for instructor/professor accounts.
Teaching access is determined exclusively by teaching_assignments, which identifies the
professor, subject, section, school year, and semester.

The legacy section-claim/ownership workflow is no longer part of the application.
Instructor classes, rosters, schedules, curriculum, attendance, grades, and announcements
are driven by the professor's subject assignments.

If an old database still contains legacy section-claim tables, they are ignored by the
application. See extra/remove_adviser_system.sql if you want to remove those unused tables.
