<?php
require_once __DIR__ . '/../functions/academic_auth.php';
require_academic_login();

include '../db/dbconn.php';
require_once '../functions/enrollment_setup.php';
require_once '../functions/teacher_setup.php';
ensure_teacher_schema($conn);

ensure_enrollment_schema($conn);
$schoolYear = system_school_year($conn);

$selected_course = isset($_GET['course']) ? (int) $_GET['course'] : 0;

$coursesQuery = mysqli_query($conn, "
    SELECT
        courses.id,
        courses.course_code,
        courses.course_name,
        COUNT(sections.id) AS total_sections
    FROM courses
    LEFT JOIN sections ON courses.id = sections.course_id
    WHERE courses.course_code IN ('BSIT','BSCS','BSIS')
    GROUP BY courses.id
    ORDER BY courses.course_code
");

$totalCourses  = mysqli_num_rows($coursesQuery);
$totalSections = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) total FROM sections INNER JOIN courses ON courses.id = sections.course_id WHERE courses.course_code IN ('BSIT','BSCS','BSIS')"))['total'];
$totalSubjects = (int) mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) total FROM subjects INNER JOIN courses ON courses.id = subjects.course_id WHERE courses.course_code IN ('BSIT','BSCS','BSIS')"))['total'];

mysqli_data_seek($coursesQuery, 0);

$csrf = academic_csrf_token();
$teacherOptions = [];
// Only real Instructor accounts from the users table are available for assignment.
$teacherResult = mysqli_query($conn, "SELECT user_id, full_name, email FROM users WHERE role_id = 2 AND user_id IS NOT NULL AND TRIM(full_name) <> '' ORDER BY full_name");
while ($teacherRow = mysqli_fetch_assoc($teacherResult)) { $teacherOptions[] = $teacherRow; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courses – EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <style>
        /* ── Course card tweaks ────────────────────────────── */
        .course-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(210px,1fr)); gap:16px; margin-top:16px; }
        .course-card { background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.1); border-radius:16px; padding:20px; text-decoration:none; color:#fff; transition:.25s; }
        .course-card:hover { background:rgba(216,255,97,.08); border-color:#d8ff61; transform:translateY(-4px); }
        .course-card h2 { font-size:1.5rem; color:#d8ff61; margin-bottom:4px; }
        .course-card p  { font-size:.85rem; color:#a1a1aa; margin-bottom:10px; }
        .course-card span { display:inline-block; background:rgba(124,58,237,.4); color:#e0d4ff; font-size:.78rem; padding:4px 12px; border-radius:999px; }

        /* ── Subjects table ────────────────────────────────── */
        .subjects-table { width:100%; border-collapse:collapse; }
        .subjects-table thead th { background:#08021b; color:#d8ff61; padding:12px 14px; text-align:left; font-size:.82rem; letter-spacing:.05em; text-transform:uppercase; }
        .subjects-table tbody tr { border-bottom:1px solid rgba(255,255,255,.06); transition:.2s; }
        .subjects-table tbody tr:hover { background:rgba(255,255,255,.04); }
        .subjects-table td { padding:12px 14px; font-size:.92rem; vertical-align:middle; }


        .section-pill { display:inline-block; background:#1c056e; border:1px solid rgba(124,58,237,.4); border-radius:999px; padding:5px 14px; font-size:.85rem; color:#c4b5fd; }
        .subject-detail-input { width:130px; max-width:100%; padding:7px 9px; border-radius:8px; border:1px solid rgba(255,255,255,.14); background:#0f0b22; color:#fff; font-size:.82rem; }
        .subject-detail-input.teacher { width:210px; }
        .faculty-select { cursor:pointer; }
        .faculty-select option { background:#0f0b22; color:#fff; }
        .bulk-save-wrap { display:flex; justify-content:flex-end; margin-top:18px; }
        .bulk-save-btn { border:0; border-radius:10px; padding:11px 18px; background:#d8ff61; color:#171717; font-weight:800; cursor:pointer; }
        .bulk-save-btn:hover { filter:brightness(.92); }
        .subject-detail-input { min-width:145px; }
        .subject-detail-input.teacher { min-width:210px; }
    </style>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/../sidebar/sidebar.php'; ?>

<main class="dashboard-main">

    <!-- HERO -->
    <div class="hero">
        <div class="welcome">
            <span class="hero-badge">📚 Academic Programs</span>
            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;"><h1 style="margin:0;">Courses</h1><a href="curriculum.php" style="display:inline-block;padding:8px 13px;border-radius:9px;background:#d8ff61;color:#171717;text-decoration:none;font-weight:800;">Manage Curriculum</a></div>
            <p>Manage academic programs, subjects, professor assignments, schedules, and rooms.</p>
        </div>

        <div class="hero-stats">
            <div class="mini-stat">
                <h3>Courses</h3>
                <span><?= $totalCourses ?></span>
            </div>
            <div class="mini-stat">
                <h3>Sections</h3>
                <span><?= $totalSections ?></span>
            </div>
            <div class="mini-stat">
                <h3>Subjects</h3>
                <span><?= $totalSubjects ?></span>
            </div>
        </div>
    </div>

    <div class="analytics-grid" style="grid-template-columns:1fr;">

        <!-- COURSE CARDS -->
        <div class="card">
            <h3>Available Courses</h3>
            <div class="course-grid">
                <?php while ($course = mysqli_fetch_assoc($coursesQuery)) { ?>
                    <a href="courses.php?course=<?= (int) $course['id'] ?>" class="course-card">
                        <h2><?= htmlspecialchars($course['course_code']) ?></h2>
                        <p><?= htmlspecialchars($course['course_name']) ?></p>
                        <span><?= (int) $course['total_sections'] ?> Sections</span>
                    </a>
                <?php } ?>
            </div>
        </div>

        <?php if ($selected_course > 0):
            $courseInfo = mysqli_fetch_assoc(mysqli_query($conn,
                "SELECT * FROM courses WHERE id = " . $selected_course . " AND course_code IN ('BSIT','BSCS','BSIS')"));
            if ($courseInfo):
        ?>

        <!-- COURSE DETAIL -->
        <div class="card">
            <h3><?= htmlspecialchars($courseInfo['course_code']) ?>
                <span style="font-size:.75em;color:#a1a1aa;font-weight:400;">
                    — <?= htmlspecialchars($courseInfo['course_name']) ?>
                </span>
            </h3>

            <hr style="border-color:rgba(255,255,255,.08);margin:20px 0;">

            <!-- Subjects, professor assignments, schedules, and rooms -->
        <h4 style="color:#d8ff61;margin-bottom:14px;">Subjects</h4>

        <?php
        $scheduleDays = [];
        $scheduleTimes = [];
        $rooms = [];
        $optionResult = mysqli_query($conn, "SELECT DISTINCT schedule_day, schedule_time, room_number FROM subjects WHERE schedule_day IS NOT NULL OR schedule_time IS NOT NULL OR room_number IS NOT NULL ORDER BY schedule_day, schedule_time, room_number");
        while ($optionRow = mysqli_fetch_assoc($optionResult)) {
            if (trim((string)$optionRow['schedule_day']) !== '') $scheduleDays[] = trim((string)$optionRow['schedule_day']);
            if (trim((string)$optionRow['schedule_time']) !== '') $scheduleTimes[] = trim((string)$optionRow['schedule_time']);
            if (trim((string)$optionRow['room_number']) !== '') $rooms[] = trim((string)$optionRow['room_number']);
        }
        $scheduleDays = array_values(array_unique($scheduleDays));
        $scheduleTimes = array_values(array_unique($scheduleTimes));
        $rooms = array_values(array_unique($rooms));
        natcasesort($scheduleDays); $scheduleDays = array_values($scheduleDays);
        natcasesort($scheduleTimes); $scheduleTimes = array_values($scheduleTimes);
        natcasesort($rooms); $rooms = array_values($rooms);
        ?>

        <form method="POST" action="../functions/save_subject_details.php" id="bulkSubjectForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
            <input type="hidden" name="action" value="bulk_save">
            <input type="hidden" name="course_id" value="<?= $selected_course ?>">
            <div style="overflow-x:auto;">
                <table class="subjects-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Subject Name</th>
                            <th>Units</th>
                            <th>Year</th>
                            <th>Sem</th>
                            <th>Professor</th>
                            <th>Day</th>
                            <th>Time</th>
                            <th>Room</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $subjects = mysqli_query($conn,
                            'SELECT * FROM subjects WHERE course_id = ' . $selected_course . ' ORDER BY year_level, sem, subject_code');
                        while ($subj = mysqli_fetch_assoc($subjects)):
                            $subjectId = (int)$subj['id'];
                            $assignedTeacherId = 0;
                            if (!empty($subj['section_id'])) {
                                $taStmt = mysqli_prepare($conn, "SELECT teacher_id FROM teaching_assignments WHERE subject_id=? AND section_id=? AND school_year=? AND status='Active' ORDER BY id DESC LIMIT 1");
                                if ($taStmt) {
                                    mysqli_stmt_bind_param($taStmt, 'iis', $subjectId, $subj['section_id'], $schoolYear);
                                    mysqli_stmt_execute($taStmt);
                                    $taRow = mysqli_fetch_assoc(mysqli_stmt_get_result($taStmt));
                                    $assignedTeacherId = (int)($taRow['teacher_id'] ?? 0);
                                    mysqli_stmt_close($taStmt);
                                }
                            } else {
                                $taStmt = mysqli_prepare($conn, "
                                    SELECT MIN(teacher_id) AS teacher_id, COUNT(DISTINCT teacher_id) AS teacher_count
                                    FROM teaching_assignments ta
                                    INNER JOIN sections s ON s.id = ta.section_id AND s.course_id = ?
                                    WHERE ta.subject_id=? AND ta.school_year=? AND ta.status='Active'
                                ");
                                if ($taStmt) {
                                    mysqli_stmt_bind_param($taStmt, 'iis', $selected_course, $subjectId, $schoolYear);
                                    mysqli_stmt_execute($taStmt);
                                    $taRow = mysqli_fetch_assoc(mysqli_stmt_get_result($taStmt));
                                    if ((int)($taRow['teacher_count'] ?? 0) === 1) $assignedTeacherId = (int)($taRow['teacher_id'] ?? 0);
                                    mysqli_stmt_close($taStmt);
                                }
                            }
                            if ($assignedTeacherId === 0 && !empty($subj['teacher_name'])) {
                                foreach ($teacherOptions as $teacherOption) {
                                    if (strcasecmp(trim((string)$teacherOption['full_name']), trim((string)$subj['teacher_name'])) === 0) {
                                        $assignedTeacherId = (int)$teacherOption['user_id'];
                                        break;
                                    }
                                }
                            }
                            $prefix = 'subjects[' . $subjectId . ']';
                        ?>
                        <tr>
                            <td><strong style="color:#d8ff61;"><?= htmlspecialchars($subj['subject_code']) ?></strong></td>
                            <td><?= htmlspecialchars($subj['subject_name']) ?></td>
                            <td style="text-align:center;"><?= (int)$subj['units'] ?></td>
                            <td style="text-align:center;"><?= (int)$subj['year_level'] ?></td>
                            <td style="text-align:center;"><?= (int)$subj['sem'] ?></td>
                            <td>
                                <select class="subject-detail-input teacher faculty-select" name="<?= $prefix ?>[teacher_id]" aria-label="Professor for <?= htmlspecialchars($subj['subject_code']) ?>">
                                    <option value="0" <?= $assignedTeacherId === 0 ? 'selected' : '' ?>>Faculty</option>
                                    <?php foreach ($teacherOptions as $teacher): ?>
                                        <option value="<?= (int)$teacher['user_id'] ?>" <?= $assignedTeacherId === (int)$teacher['user_id'] ? 'selected' : '' ?>><?= htmlspecialchars($teacher['full_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select class="subject-detail-input" name="<?= $prefix ?>[schedule_day]" aria-label="Day for <?= htmlspecialchars($subj['subject_code']) ?>">
                                    <option value="">Select day</option>
                                    <?php foreach ($scheduleDays as $day): ?>
                                        <option value="<?= htmlspecialchars($day) ?>" <?= trim((string)$subj['schedule_day']) === $day ? 'selected' : '' ?>><?= htmlspecialchars($day) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select class="subject-detail-input" name="<?= $prefix ?>[schedule_time]" aria-label="Time for <?= htmlspecialchars($subj['subject_code']) ?>">
                                    <option value="">Select time</option>
                                    <?php foreach ($scheduleTimes as $time): ?>
                                        <option value="<?= htmlspecialchars($time) ?>" <?= trim((string)$subj['schedule_time']) === $time ? 'selected' : '' ?>><?= htmlspecialchars($time) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select class="subject-detail-input" name="<?= $prefix ?>[room_number]" aria-label="Room for <?= htmlspecialchars($subj['subject_code']) ?>">
                                    <option value="">Select room</option>
                                    <?php foreach ($rooms as $room): ?>
                                        <option value="<?= htmlspecialchars($room) ?>" <?= trim((string)$subj['room_number']) === $room ? 'selected' : '' ?>><?= htmlspecialchars($room) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <div class="bulk-save-wrap">
                <button type="submit" class="bulk-save-btn">Save All Changes</button>
            </div>
        </form>

        <?php endif; endif; ?>

    </div>
 </main>

<script>
window.addEventListener('pageshow', e => { if (e.persisted) window.location.reload(); });
</script>
</body>
</html>
