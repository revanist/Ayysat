-- EYYSAT Cashier Role Migration
-- Adds the dedicated Cashier role (role_id = 4) and updates the generated role label.

INSERT INTO roles (id, name, description)
VALUES (4, 'Cashier', 'Payment verification, collection and receipt access')
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    description = VALUES(description);

ALTER TABLE users
MODIFY COLUMN role VARCHAR(20)
GENERATED ALWAYS AS (
    CASE role_id
        WHEN 1 THEN 'admin'
        WHEN 2 THEN 'teacher'
        WHEN 3 THEN 'student'
        WHEN 4 THEN 'cashier'
        ELSE 'unknown'
    END
) STORED;
