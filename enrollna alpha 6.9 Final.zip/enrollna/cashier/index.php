<?php
require_once __DIR__ . '/../functions/cashier_auth.php';
require_cashier_login();

require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);
ensure_account_security_schema($conn);

function cashier_payment_method(?string $method): string
{
    return match (strtolower(trim((string)$method))) {
        'gcash' => 'GCash',
        'cash' => 'Cash',
        'card' => 'Card',
        'bank', 'bank transfer' => 'Bank Transfer',
        default => '—',
    };
}

$cashierName = htmlspecialchars($_SESSION['fullname'] ?? 'Cashier');
$csrf = cashier_csrf_token();

/* Dashboard statistics */
$totalPending = 0;
$totalPaid = 0;
$collectedToday = 0.0;
$unpaidBalance = 0.0;
$transactionCount = 0;

$r = mysqli_query($conn, "SELECT COUNT(*) AS total FROM enrollments WHERE LOWER(payment_status)='pending' AND COALESCE(cash_amount_requested,0) > 0");
if ($r) $totalPending = (int)(mysqli_fetch_assoc($r)['total'] ?? 0);

$r = mysqli_query($conn, "SELECT COUNT(*) AS total FROM enrollments WHERE LOWER(payment_status)='paid'");
if ($r) $totalPaid = (int)(mysqli_fetch_assoc($r)['total'] ?? 0);

$r = mysqli_query($conn, "SELECT COALESCE(SUM(amount_paid),0) AS total FROM enrollments WHERE LOWER(payment_status) IN ('paid','partial') AND DATE(created)=CURDATE()");
if ($r) $collectedToday = (float)(mysqli_fetch_assoc($r)['total'] ?? 0);

$r = mysqli_query($conn, "SELECT COALESCE(SUM(remaining_balance),0) AS total FROM students WHERE COALESCE(remaining_balance,0) > 0");
if ($r) $unpaidBalance = (float)(mysqli_fetch_assoc($r)['total'] ?? 0);

$r = mysqli_query($conn, "SELECT COUNT(*) AS total FROM enrollments WHERE COALESCE(amount_paid,0) > 0");
if ($r) $transactionCount = (int)(mysqli_fetch_assoc($r)['total'] ?? 0);

/* Pending payments waiting for cashier action */
$pendingQuery = mysqli_query($conn, "
    SELECT e.id, s.student_number, s.first_name, s.last_name, s.email,
           c.course_code, e.payment_status, e.payment_method,
           e.payment_account, e.payment_reference, e.cash_amount_requested,
           e.amount_paid, e.status, e.created
    FROM enrollments e
    INNER JOIN students s ON s.id=e.student_id
    LEFT JOIN courses c ON c.id=e.course_id
    WHERE LOWER(e.payment_status)='pending'
      AND COALESCE(e.cash_amount_requested,0) > 0
    ORDER BY e.created DESC
");

/* Recent verified / submitted transactions */
$recentQuery = mysqli_query($conn, "
    SELECT e.id, s.student_number, s.first_name, s.last_name,
           c.course_code, e.payment_status, e.payment_method,
           e.amount_paid, e.cash_amount_requested, e.created
    FROM enrollments e
    INNER JOIN students s ON s.id=e.student_id
    LEFT JOIN courses c ON c.id=e.course_id
    WHERE COALESCE(e.amount_paid,0) > 0 OR COALESCE(e.cash_amount_requested,0) > 0
    ORDER BY e.created DESC
    LIMIT 12
");

/* Persistent payment notifications */
$paymentAlerts = [];
$alertQuery = mysqli_query($conn, "
    SELECT n.id, n.enrollment_id, n.message, n.created_at,
           e.payment_method, e.payment_reference, e.cash_amount_requested,
           s.first_name, s.last_name
    FROM admin_notifications n
    INNER JOIN enrollments e ON e.id=n.enrollment_id
    INNER JOIN students s ON s.id=e.student_id
    WHERE n.cashier_is_read=0
    ORDER BY n.created_at ASC
    LIMIT 10
");
if ($alertQuery) {
    while ($a=mysqli_fetch_assoc($alertQuery)) {
        $paymentAlerts[] = [
            'id'=>(int)$a['id'],
            'enrollment_id'=>(int)$a['enrollment_id'],
            'student'=>trim($a['first_name'].' '.$a['last_name']),
            'method'=>cashier_payment_method($a['payment_method']),
            'amount'=>number_format((float)$a['cash_amount_requested'],2),
            'reference'=>(string)($a['payment_reference'] ?? '')
        ];
    }
}

/* Review / receipt modal */
$reviewId = (int)($_GET['review'] ?? $_GET['receipt'] ?? 0);
$receiptMode = isset($_GET['receipt']);
$reviewData = null;
if ($reviewId > 0) {
    $stmt = mysqli_prepare($conn, "
        SELECT e.id,e.status,e.payment_status,e.payment_method,e.payment_option,
               e.payment_reference,e.payment_account,e.payment_proof,
               e.amount_paid,e.cash_amount_requested,e.created,
               s.id AS student_id,s.student_number,s.first_name,s.last_name,s.email,
               c.course_code
        FROM enrollments e
        INNER JOIN students s ON s.id=e.student_id
        LEFT JOIN courses c ON c.id=e.course_id
        WHERE e.id=? LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt,'i',$reviewId);
    mysqli_stmt_execute($stmt);
    $reviewData=mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
}

$confirmed = isset($_GET['confirmed']);
$paymentStatus = strtolower(trim((string)($reviewData['payment_status'] ?? '')));
$cashRequestPending = isset($reviewData['cash_amount_requested']) && (float)$reviewData['cash_amount_requested'] > 0;
$paymentConfirmed = in_array($paymentStatus, ['paid', 'partial'], true) && !$cashRequestPending;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cashier Dashboard – EYYSAT</title>
<link rel="stylesheet" href="../css/admin_dashboard.css">
<link rel="stylesheet" href="../css/cashier_dashboard.css">
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/sweetalert2.all.min.js"></script>
<script src="../js/ux-polish.js" defer></script>
</head>
<body>

<?php include __DIR__ . '/sidebar_layout.php'; ?>

<main class="dashboard-main cashier-main">
    <header class="dashboard-topbar">
        <div class="cashier-topbar-copy">
            <span class="topbar-label">CASHIER PORTAL</span>
            <h2>Dashboard</h2>
        </div>
    </header>

    <section class="page-header cashier-page-header">
        <span class="topbar-label">PAYMENT MANAGEMENT</span>
        <h1>Welcome, <?= $cashierName ?></h1>
        <p>Review student payment submissions, verify transactions, and issue payment receipts.</p>
    </section>

    <section class="stats-row cashier-stats">
        <div class="stat-card stat-paid">
            <div class="stat-icon">₱</div>
            <h3>Collected Today</h3>
            <span>₱<?= number_format($collectedToday,2) ?></span>
            <small class="cashier-stat-note">Recorded payment activity</small>
        </div>
        <div class="stat-card stat-warning">
            <div class="stat-icon">⏳</div>
            <h3>Pending Verification</h3>
            <span><?= $totalPending ?></span>
            <small class="cashier-stat-note">Needs cashier action</small>
        </div>
        <div class="stat-card">
            <div class="stat-icon">₱</div>
            <h3>Unpaid Balances</h3>
            <span>₱<?= number_format($unpaidBalance,2) ?></span>
            <small class="cashier-stat-note">Across student records</small>
        </div>
        <div class="stat-card stat-success">
            <div class="stat-icon">✓</div>
            <h3>Transactions</h3>
            <span><?= $transactionCount ?></span>
            <small class="cashier-stat-note">Payments with recorded amounts</small>
        </div>
    </section>

    <section class="card cashier-table-card" id="pending-payments">
        <div class="table-header">
            <div>
                <span class="topbar-label">PAYMENT VERIFICATION</span>
                <h2>Pending Student Payments</h2>
            </div>
            <input type="text" id="pendingSearch" class="search-box" placeholder="Search student, number or reference..." aria-label="Search pending payments">
        </div>
        <div class="table-wrapper cashier-table-wrap">
            <table class="modern-table" id="pendingTable">
                <thead><tr>
                    <th>Student No.</th><th>Student</th><th>Course</th><th>Amount</th><th>Method</th><th>Reference</th><th>Date</th><th>Action</th>
                </tr></thead>
                <tbody>
                <?php if (!$pendingQuery || mysqli_num_rows($pendingQuery)===0): ?>
                    <tr><td colspan="8" class="empty-state"><div>✓</div><strong>No pending payments</strong><span>All submitted payments have been processed.</span></td></tr>
                <?php else: while($row=mysqli_fetch_assoc($pendingQuery)): ?>
                    <tr>
                        <td><strong class="table-primary"><?= htmlspecialchars($row['student_number']) ?></strong></td>
                        <td><?= htmlspecialchars(trim($row['first_name'].' '.$row['last_name'])) ?></td>
                        <td><?= htmlspecialchars($row['course_code'] ?? '—') ?></td>
                        <td><strong>₱<?= number_format((float)$row['cash_amount_requested'],2) ?></strong></td>
                        <td><span class="cashier-method <?= strtolower($row['payment_method'] ?? '')==='cash'?'cash':'gcash' ?>"><?= htmlspecialchars(cashier_payment_method($row['payment_method'])) ?></span></td>
                        <td><?= htmlspecialchars($row['payment_reference'] ?: 'Cash payment') ?></td>
                        <td><?= htmlspecialchars(date('M d, Y h:i A',strtotime($row['created']))) ?></td>
                        <td><a class="cashier-action" href="index.php?review=<?= (int)$row['id'] ?>">Review</a></td>
                    </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="card cashier-table-card" id="transactions" style="margin-top:22px">
        <div class="table-header">
            <div>
                <span class="topbar-label">TRANSACTION HISTORY</span>
                <h2>Recent Transactions</h2>
            </div>
            <input type="text" id="transactionSearch" class="search-box" placeholder="Search transactions..." aria-label="Search transactions">
        </div>
        <div class="table-wrapper cashier-table-wrap">
            <table class="modern-table" id="transactionTable">
                <thead><tr><th>Enrollment</th><th>Student</th><th>Course</th><th>Method</th><th>Amount</th><th>Status</th><th>Date</th><th>Receipt</th></tr></thead>
                <tbody>
                <?php if (!$recentQuery || mysqli_num_rows($recentQuery)===0): ?>
                    <tr><td colspan="8" class="empty-state"><div>₱</div><strong>No transactions yet</strong><span>Processed student payments will appear here.</span></td></tr>
                <?php else: while($row=mysqli_fetch_assoc($recentQuery)): ?>
                    <?php $displayAmount=(float)($row['amount_paid'] ?? 0); if($displayAmount<=0) $displayAmount=(float)($row['cash_amount_requested'] ?? 0); ?>
                    <tr>
                        <td><strong>#<?= (int)$row['id'] ?></strong></td>
                        <td><?= htmlspecialchars(trim($row['first_name'].' '.$row['last_name'])) ?><br><small><?= htmlspecialchars($row['student_number']) ?></small></td>
                        <td><?= htmlspecialchars($row['course_code'] ?? '—') ?></td>
                        <td><span class="cashier-method <?= strtolower($row['payment_method'] ?? '')==='cash'?'cash':'gcash' ?>"><?= htmlspecialchars(cashier_payment_method($row['payment_method'])) ?></span></td>
                        <td><strong>₱<?= number_format($displayAmount,2) ?></strong></td>
                        <td><span class="status-<?= strtolower($row['payment_status'])==='paid'?'approved':'pending' ?>"><?= htmlspecialchars(ucfirst($row['payment_status'])) ?></span></td>
                        <td><?= htmlspecialchars(date('M d, Y h:i A',strtotime($row['created']))) ?></td>
                        <td><a class="cashier-action" href="index.php?receipt=<?= (int)$row['id'] ?>">View Receipt</a></td>
                    </tr>
                <?php endwhile; endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="card" id="receipts" style="margin-top:22px;padding:20px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:14px;flex-wrap:wrap">
            <div><span class="topbar-label">RECEIPTS</span><h2 style="margin:4px 0">Payment receipts</h2><p style="margin:0;color:#718096">Open a transaction above to review or view its receipt.</p></div>
            <span class="cashier-stat-note">Verified payments: <?= $totalPaid ?></span>
        </div>
    </section>
</main>

<?php if ($reviewData): ?>
<div class="cashier-review-backdrop" role="dialog" aria-modal="true" aria-label="Payment review">
    <div class="cashier-review-modal">
        <div class="cashier-modal-topbar">
            <div><span class="cashier-eyebrow"><?= $receiptMode ? 'OFFICIAL PAYMENT RECEIPT' : 'CASHIER VERIFICATION' ?></span><h2><?= $receiptMode ? 'Payment Receipt' : 'Review Payment' ?></h2><p><?= $receiptMode ? 'A complete record of the payment submitted for this enrollment.' : 'Check the student and transaction information before confirming the payment.' ?></p></div>
            <a class="cashier-close-btn" href="index.php" aria-label="Back to dashboard">&times;</a>
        </div>

        <?php if ($receiptMode): ?>
        <div class="official-receipt improved-main-receipt">
            <div class="receipt-brand-bar">
                <div class="receipt-brand-logo"><img src="../img/eyysat-circle.png" alt="EYYSAT Logo"><div>EYYSAT<span>Enrollment &amp; Registration Portal</span></div></div>
            </div>
            <div class="receipt-title-row improved-receipt-title">
                <div><h3>Enrollment Payment</h3><p>Payment Receipt</p></div>
                <div class="receipt-number"><span>Receipt No.</span><strong>PAY-<?= str_pad((string)$reviewData['id'],8,'0',STR_PAD_LEFT) ?></strong></div>
            </div>
            <?php $receiptIsPaid = $paymentConfirmed || $paymentStatus === 'paid'; ?>
            <div class="receipt-status-alert <?= $receiptIsPaid ? 'paid' : 'pending' ?>">
                <h4><?= $receiptIsPaid ? '✓ PAYMENT VERIFIED' : '⚠️ PENDING VERIFICATION' ?></h4>
                <p><?= $receiptIsPaid ? 'The cashier has confirmed this payment and it is considered final.' : 'Cashier verification is still required before this payment is considered final.' ?></p>
            </div>
            <div class="receipt-amount-main"><span><?= $receiptIsPaid ? 'Amount Paid' : 'Amount Submitted' ?></span><strong>₱<?= number_format((float)($receiptIsPaid && (float)$reviewData['amount_paid'] > 0 ? $reviewData['amount_paid'] : ($reviewData['cash_amount_requested'] ?: $reviewData['amount_paid'] ?: 0)),2) ?></strong></div>
            <div class="receipt-section-title">Student Information</div>
            <div class="receipt-details-list">
                <div><span>Student Name</span><strong><?= htmlspecialchars($reviewData['first_name'].' '.$reviewData['last_name']) ?></strong></div>
                <div><span>Student Number</span><strong><?= htmlspecialchars($reviewData['student_number'] ?? '—') ?></strong></div>
                <div><span>Course</span><strong><?= htmlspecialchars($reviewData['course_code'] ?? '—') ?></strong></div>
                <div><span>Email</span><strong><?= htmlspecialchars($reviewData['email'] ?? '—') ?></strong></div>
            </div>
            <div class="receipt-section-title">Payment Information</div>
            <div class="receipt-details-list">
                <div><span>Payment Method</span><strong><?= htmlspecialchars(cashier_payment_method($reviewData['payment_method'])) ?></strong></div>
                <div><span>Payer / Account</span><strong><?= htmlspecialchars($reviewData['payment_account'] ?: 'School Cashier / Over-the-counter') ?></strong></div>
                <div><span>Transaction Reference</span><strong><?= htmlspecialchars($reviewData['payment_reference'] ?: 'Not applicable — cash payment') ?></strong></div>
                <div><span>Date Submitted</span><strong><?= htmlspecialchars(date('M d, Y • h:i A',strtotime($reviewData['created']))) ?></strong></div>
                <div><span>Payment Status</span><strong><?= htmlspecialchars(ucfirst($reviewData['payment_status'] ?? 'Pending')) ?></strong></div>
                <div><span>Enrollment Status</span><strong><?= htmlspecialchars(ucfirst($reviewData['status'] ?? 'Pending')) ?></strong></div>
            </div>
            <div class="receipt-footer-main">Thank you for using EYYSAT Enrollment Portal.<br>Enrollment #<?= (int)$reviewData['id'] ?></div>
        </div>
        <div class="cashier-modal-actions improved-receipt-actions"><button type="button" class="btn btn-secondary" onclick="window.print()">🖨️ Print Receipt</button><?php if (!$paymentConfirmed): ?><a href="index.php?review=<?= (int)$reviewData['id'] ?>" class="btn btn-secondary">← Back to Review</a><?php endif; ?><a href="index.php" class="btn btn-primary">Back to Dashboard</a></div>
        <?php else: ?>
        <div class="cashier-review-content improved-payment-review">
            <div class="review-action-alert">
                <span class="review-alert-icon">⚠️</span>
                <div><strong>Action Required:</strong><span>Compare the submitted details with the actual payment record before confirming.</span></div>
            </div>

            <div class="review-info-grid review-student-info">
                <div class="info-block"><label>Student</label><div><?= htmlspecialchars($reviewData['first_name'].' '.$reviewData['last_name']) ?></div><small><?= htmlspecialchars($reviewData['student_number']) ?></small></div>
                <div class="info-block"><label>Course</label><div><?= htmlspecialchars($reviewData['course_code'] ?? '—') ?></div><small><?= htmlspecialchars($reviewData['email'] ?? '—') ?></small></div>
            </div>

            <div class="review-section-title">Payment Details</div>

            <div class="review-info-grid">
                <div class="info-block"><label>Method</label><div><?= htmlspecialchars(cashier_payment_method($reviewData['payment_method'])) ?></div></div>
                <div class="info-block"><label>Amount</label><div class="review-amount-value">₱<?= number_format((float)($reviewData['cash_amount_requested'] ?: $reviewData['amount_paid'] ?: 0),2) ?></div></div>
                <div class="info-block"><label>Payer / Account</label><div><?= htmlspecialchars($reviewData['payment_account'] ?: 'School Cashier / Over-the-counter') ?></div></div>
                <div class="info-block"><label>Enrollment Status</label><div class="review-status-value"><?= htmlspecialchars($reviewData['status'] ?? 'Pending') === 'Enrolled' ? 'Enrolled' : 'Pending Payment Verification' ?></div></div>
                <div class="info-block"><label>Transaction Reference</label><div class="reference-wrap"><span class="reference-value"><?= htmlspecialchars($reviewData['payment_reference'] ?: 'Not applicable — cash payment') ?></span><?php if (!empty($reviewData['payment_reference'])): ?><button type="button" class="copy-reference" data-reference="<?= htmlspecialchars($reviewData['payment_reference'], ENT_QUOTES) ?>">Copy</button><?php endif; ?></div></div>
                <div class="info-block"><label>Submitted</label><div><?= htmlspecialchars(date('M d, Y • h:i A',strtotime($reviewData['created']))) ?></div></div>
            </div>
        </div>

        <div class="cashier-review-footer improved-review-footer">
            <?php if (!$paymentConfirmed && $cashRequestPending): ?>
            <label class="verification-checkbox"><input type="checkbox" id="verifyCheck"><span>I have verified this transaction against the payment record.</span></label>
            <?php else: ?><span class="already-verified">✓ Payment already verified</span><?php endif; ?>

            <div class="review-footer-buttons">
                <a href="index.php" class="review-btn review-btn-link">← Back</a>
                <a href="index.php?receipt=<?= (int)$reviewData['id'] ?>" class="review-btn review-btn-secondary">View Receipt</a>
                <?php if (!$paymentConfirmed && $cashRequestPending): ?>
                <form method="POST" action="../functions/confirm_payment.php" id="confirmPaymentForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                    <input type="hidden" name="enrollment_id" value="<?= (int)$reviewData['id'] ?>">
                    <button type="submit" class="review-btn review-btn-primary" id="confirmBtn" disabled>Confirm Payment</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const verifyCheck = document.getElementById('verifyCheck');
    const confirmBtn = document.getElementById('confirmBtn');
    if (verifyCheck && confirmBtn) {
        verifyCheck.addEventListener('change', function () {
            confirmBtn.disabled = !this.checked;
        });
    }

    document.querySelectorAll('.copy-reference').forEach(function (button) {
        button.addEventListener('click', function () {
            const reference = this.getAttribute('data-reference') || '';
            if (!reference) return;
            navigator.clipboard.writeText(reference).then(() => {
                const original = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => this.textContent = original, 1200);
            }).catch(() => {
                window.prompt('Copy transaction reference:', reference);
            });
        });
    });
});

function filterTable(inputId, tableId) {
    const input=document.getElementById(inputId), table=document.getElementById(tableId);
    if(!input||!table)return;
    input.addEventListener('input',function(){
        const q=this.value.trim().toLowerCase();
        table.querySelectorAll('tbody tr').forEach(function(row){ row.style.display=row.textContent.toLowerCase().includes(q)?'':'none'; });
    });
}
filterTable('pendingSearch','pendingTable');
filterTable('transactionSearch','transactionTable');

const paymentAlerts=<?= json_encode($paymentAlerts,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
<?php if ($confirmed): ?>
Swal.fire({icon:'success',title:'Payment confirmed',text:'The payment has been recorded successfully.',confirmButtonText:'OK'});
<?php elseif ($paymentAlerts && !$reviewData): ?>
Swal.fire({icon:'info',title:paymentAlerts.length===1?'New student payment':'New student payments',text:paymentAlerts.length+' payment submission'+(paymentAlerts.length===1?'':'s')+' waiting for verification.',confirmButtonText:'View Pending Payments'}).then(function(result){
  if(result.isConfirmed){
    fetch('../functions/mark_cashier_notifications_read.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'csrf_token='+encodeURIComponent(<?= json_encode($csrf) ?>)})
      .finally(function(){document.getElementById('pending-payments')?.scrollIntoView({behavior:'smooth',block:'start'});});
  }
});
<?php endif; ?>
</script>
</body>
</html>
