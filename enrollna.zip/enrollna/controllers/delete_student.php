<?php
http_response_code(410);
exit('Student deletion is disabled.');
