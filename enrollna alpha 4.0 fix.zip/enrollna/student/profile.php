<?php
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();

include '../db/dbconn.php';
require_once '../functions/enrollment_setup.php';

ensure_enrollment_schema($conn);
seed_course_data($conn);

$user_id = (int) $_SESSION['user_id'];

$query = mysqli_query($conn, "
    SELECT
        students.*,
        courses.course_name,
        courses.course_code,
        sections.section_name
    FROM students
    LEFT JOIN courses  ON students.course_id  = courses.id
    LEFT JOIN sections ON students.section_id = sections.id
    WHERE students.user_id = $user_id
");

$student = mysqli_fetch_assoc($query);

if (!$student) {
    http_response_code(404);
    exit('Student profile not found.');
}

$enrollment_query = mysqli_query($conn, "
    SELECT status, payment_status, school_year, sem
    FROM enrollments
    WHERE student_id = " . (int) $student['id'] . "
    ORDER BY id DESC
    LIMIT 1
");
$enrollment = mysqli_fetch_assoc($enrollment_query) ?: [];

$subject_query = mysqli_query($conn, "
    SELECT
        subjects.subject_code,
        subjects.subject_name,
        subjects.schedule_day,
        subjects.schedule_time,
        subjects.room_number
    FROM enrollment_details
    LEFT JOIN enrollments ON enrollments.id = enrollment_details.enrollment_id
    LEFT JOIN subjects    ON subjects.id    = enrollment_details.subject_id
    WHERE enrollments.student_id = " . (int) $student['id'] . "
    ORDER BY subjects.subject_code ASC
");

$selected_subjects = [];
while ($subject = mysqli_fetch_assoc($subject_query)) {
    $selected_subjects[] = $subject;
}

// Determine if Pay Now button should show
$canPay = (
    in_array(strtolower($enrollment['status'] ?? ''), ['approved', 'enrolled'], true) &&
    strtolower($enrollment['payment_status'] ?? '') !== 'paid' &&
    ((float) ($student['remaining_balance'] ?? 0)) > 0
);
$storedEnrollmentStatus = trim((string) ($enrollment['status'] ?? ''));
$displayEnrollmentStatus = (
    in_array(strtolower($enrollment['status'] ?? ''), ['approved', 'enrolled'], true) &&
    strtolower($enrollment['payment_status'] ?? '') === 'paid'
) ? 'Enrolled' : ($storedEnrollmentStatus !== '' ? $storedEnrollmentStatus : ($student['enrollment_status'] ?? 'Not Submitted'));

$csrf = student_csrf_token();

$remainingBalance = (float) ($student['remaining_balance'] ?? 0);
$isFullyPaid = $remainingBalance <= 0 || strtolower($enrollment['payment_status'] ?? '') === 'paid';

if (!$isFullyPaid && $canPay) {
    if (empty($_SESSION['student_payment_reference'])) {
        $_SESSION['student_payment_reference'] = generate_payment_reference($conn);
    }
    $studentPaymentReference = (string) $_SESSION['student_payment_reference'];
} else {
    $studentPaymentReference = '';
}

// Payment notification from redirect
$paymentMsg = '';
if (isset($_GET['payment'])) {
    if ($_GET['payment'] === 'success') {
        $paymentMsg = 'success';
    } elseif ($_GET['payment'] === 'failed') {
        $paymentMsg = 'failed';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>My Profile – Eyysat</title>
    <link rel="stylesheet" href="../css/all.min.css">
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/student_profile.css">
    <script src="../js/sweetalert2.all.min.js"></script>
    <style>
        /* Profile payment UI */
        .pay-balance-btn, .btn-payment {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 18px;
            border-radius: 10px;
            background: var(--academy-blue, #0d3b66);
            color: #fff !important;
            text-decoration: none;
            font-weight: 700;
            font-size: .9rem;
            border: 0;
            cursor: pointer;
            transition: transform .18s ease, opacity .18s ease, box-shadow .18s ease;
        }
        .pay-balance-btn:hover, .btn-payment:hover { opacity: .92; transform: translateY(-1px); }
        .fully-paid-label { color: #16803c; font-weight: 800; }
        .payment-card-content { display:flex; align-items:center; justify-content:space-between; gap:24px; flex-wrap:wrap; }
        .payment-card-content p { margin: 5px 0 0; color:#667085; }
        .payment-help { display:block; margin-top:6px; color:#667085; }

        /* Centered payment panel — clean EYYSAT palette */
        .payment-window {
            width: min(700px, calc(100% - 32px));
            margin: 24px auto 12px;
            border: 1px solid #d7e2ea;
            border-radius: 18px;
            box-shadow: 0 18px 50px rgba(13, 59, 102, .14);
            background: #ffffff;
            overflow: hidden;
            box-sizing: border-box;
        }
        .payment-window[hidden] { display:none !important; }
        .payment-window-form {
            width: 100%;
            box-sizing: border-box;
            padding: clamp(22px, 4vw, 34px);
            color: #183247 !important;
            background: #ffffff !important;
            font-family: Arial, Helvetica, sans-serif !important;
            font-size: 15px;
            line-height: 1.5;
        }
        .payment-window-form * { box-sizing: border-box; }
        .payment-modal-header {
            display:flex; justify-content:space-between; gap:16px; align-items:flex-start;
            margin: -34px -34px 24px;
            padding: 26px 34px 22px;
            background: linear-gradient(135deg, #eef6fb 0%, #f8fbfd 100%);
            border-bottom: 1px solid #dce8ef;
        }
        .payment-modal-header h3 { margin:5px 0 4px; color:#12344d !important; font-size:clamp(1.3rem, 3vw, 1.6rem); }
        .payment-modal-header p { margin:0; color:#526779 !important; }
        .payment-modal-header p strong { color:#0d3b66 !important; }
        .payment-kicker { font-size:.72rem; font-weight:800; letter-spacing:.12em; color:#0d3b66 !important; }
        .payment-close {
            flex:0 0 auto; width:40px; height:40px; border:1px solid #d5e0e8; border-radius:10px;
            background:#ffffff; font-size:26px; line-height:1; cursor:pointer; color:#344054 !important;
        }
        .payment-close:hover { background:#edf3f7; border-color:#b9cbd7; }
        .payment-method-grid { display:grid; grid-template-columns:1fr; gap:10px; margin-bottom:22px; }
        .payment-method {
            text-align:left; padding:14px 16px; border:1px solid #9bc6dd;
            background:#f0f8fc; border-radius:12px; color:#183247 !important;
            box-shadow: inset 3px 0 0 #0d3b66;
        }
        .payment-method strong { display:block; color:#12344d !important; }
        .payment-method small { display:block; color:#607789 !important; margin-top:3px; }
        .payment-method .method-icon { display:block; font-size:20px; margin-bottom:5px; }
        .payment-field { margin-bottom:18px; }
        .payment-field label { display:block; font-weight:700; margin-bottom:7px; color:#183247 !important; }
        .payment-field input {
            display:block;
            width:100% !important;
            min-height:48px;
            padding:11px 13px;
            border:1.5px solid #b8c8d3 !important;
            border-radius:10px !important;
            font-size:15px;
            font-family:Arial, Helvetica, sans-serif !important;
            color:#111827 !important;
            background:#ffffff !important;
            outline:none;
            font-weight:600;
            -webkit-text-fill-color:#111827 !important;
            opacity:1 !important;
            box-shadow:none !important;
        }
        .payment-field input:hover { border-color:#8fa9b9 !important; }
        .payment-field input:focus {
            border-color:#0d3b66 !important;
            box-shadow:0 0 0 3px rgba(13,59,102,.13) !important;
        }
        /* Simple enrollment-style amount input */
        .payment-field input.form-control {
            width:100% !important;
            min-height:48px;
            padding:10px 12px;
            border:1px solid #ced4da !important;
            border-radius:6px !important;
            background:#ffffff !important;
            color:#212529 !important;
            -webkit-text-fill-color:#212529 !important;
            font-size:16px;
            font-weight:400;
            box-shadow:none !important;
        }
        .payment-field input.form-control:focus {
            border-color:#86b7fe !important;
            box-shadow:0 0 0 .2rem rgba(13,110,253,.15) !important;
            outline:0;
        }
        .payment-field input.form-control:hover { border-color:#adb5bd !important; }
        .payment-field input.form-control::placeholder { color:#6c757d !important; }
        .payment-field input::placeholder { color:#718096 !important; opacity:1 !important; -webkit-text-fill-color:#718096 !important; }
        .payment-field input::selection { background:#cfe5f2; color:#111827; }
        .payment-window-form input[type='number'] { appearance:auto; }
        .payment-window-form input[type='number']::-webkit-inner-spin-button,
        .payment-window-form input[type='number']::-webkit-outer-spin-button { opacity:1; }
        .payment-field input[readonly] {
            background:#f3f6f8 !important;
            color:#0d3b66 !important;
            -webkit-text-fill-color:#0d3b66 !important;
            font-weight:800;
            letter-spacing:.03em;
            border-color:#c5d5df !important;
        }
        .payment-field small { display:block; margin-top:6px; color:#657887 !important; }
        .amount-input-wrap {
            display:flex;
            align-items:stretch;
            width:100%;
            min-height:48px;
            border:1.5px solid #b8c8d3;
            border-radius:10px;
            overflow:hidden;
            background:#ffffff;
        }
        .amount-input-wrap:focus-within { border-color:#0d3b66; box-shadow:0 0 0 3px rgba(13,59,102,.13); }
        .amount-input-wrap span {
            display:flex;
            align-items:center;
            padding:0 0 0 14px;
            font-size:16px;
            font-weight:800;
            color:#0d3b66 !important;
            background:#f7fafc;
        }
        .amount-input-wrap input {
            flex:1 1 auto;
            min-width:0;
            width:100% !important;
            min-height:46px;
            border:0 !important;
            border-radius:0 !important;
            box-shadow:none !important;
            color:#111827 !important;
            -webkit-text-fill-color:#111827 !important;
            font-weight:700;
            background:#ffffff !important;
        }
        .amount-input-wrap input:focus { box-shadow:none !important; border:0 !important; }
        .payment-modal-actions { display:flex; justify-content:flex-end; gap:10px; margin-top:24px; padding-top:20px; border-top:1px solid #e4ebef; }
        .payment-modal-actions .btn { min-height:44px; padding:10px 18px; border-radius:10px; cursor:pointer; font-weight:700; }
        .payment-modal-actions .btn-secondary { background:#f3f6f8; color:#344054 !important; border:1px solid #d0d9df; }
        .payment-modal-actions .btn-secondary:hover { background:#e7edf1; }
        .payment-modal-actions .btn-payment { background:#0d3b66 !important; color:#ffffff !important; border:1px solid #0d3b66 !important; }
        .payment-modal-actions .btn-payment:hover { background:#092f52 !important; }
        @media (max-width: 700px) {
            .payment-card-content { align-items:stretch; }
            .payment-card-content .btn-payment { width:100%; }
            .payment-window { width:calc(100% - 20px); margin-top:18px; border-radius:16px; }
            .payment-window-form { padding:20px 16px; }
            .payment-modal-header { margin:-20px -16px 20px; padding:20px 16px 18px; gap:10px; }
            .payment-close { width:36px; height:36px; font-size:23px; }
            .payment-modal-actions { flex-direction:column-reverse; }
            .payment-modal-actions .btn { width:100%; }
        }
        @media (max-width: 420px) {
            .payment-window { width:calc(100% - 12px); }
            .payment-window-form { padding:18px 13px; font-size:14px; }
            .payment-modal-header { margin:-18px -13px 18px; padding:18px 13px 16px; }
            .payment-field input { min-height:46px; font-size:16px; }
        }
    </style>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>

<body class="profile-page">

    <?php include 'sidebar_layout.php'; ?>

    <main class="dashboard-main">

        <!-- HERO -->
        <div class="hero">
            <div class="welcome">
                <span class="eyebrow">🎓 Student Portal</span>
                <h1>Student Profile</h1>
                <p>Your complete student record, enrollment progress, and account details.</p>

                <div class="student-id">
                    <?php if (!empty($student['profile_picture'])): ?>
                        <div class="student-avatar">
                            <img src="../uploads/<?= htmlspecialchars($student['profile_picture']) ?>"
                                alt="Profile Picture">
                        </div>
                    <?php else: ?>
                        <div class="student-avatar">
                            <i class="fa-solid fa-user"></i>
                        </div>
                    <?php endif; ?>
                    <div>
                        <strong><?= htmlspecialchars($student['student_number'] ?? 'Pending') ?></strong>
                        <span>Student Number</span>
                    </div>
                </div>
            </div>

            <div class="hero-stats">
                <div class="mini-stat">
                    <h3>Course</h3>
                    <span><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></span>
                </div>

                <div class="mini-stat balance-mini-stat">
                    <h3><?= $isFullyPaid ? 'Payment Status' : 'Balance' ?></h3>
                    <?php if ($isFullyPaid): ?>
                        <span class="fully-paid-label">Fully Paid</span>
                    <?php else: ?>
                        <span>₱<?= number_format($remainingBalance, 2) ?></span>
                    <?php endif; ?>
                </div>

                <div class="mini-stat">
                    <h3>Status</h3>
                    <span><?= htmlspecialchars($displayEnrollmentStatus) ?></span>
                </div>
            </div>
        </div>

        <!-- PAYMENT NOTIFICATION -->
        <?php if ($paymentMsg === 'success'): ?>
            <div class="alert-banner alert-success">
                🎉 <strong>Payment successful!</strong> Your enrollment fee has been received.
                Your account will be updated shortly.
            </div>
        <?php elseif ($paymentMsg === 'failed'): ?>
            <div class="alert-banner alert-danger">
                ⚠️ <strong>Payment was not completed.</strong> Please try again or contact the cashier.
            </div>
        <?php endif; ?>

        <!-- CARDS GRID -->
        <div class="analytics-grid">

            <!-- Academic Information -->
            <div class="card">
                <h3>Academic Information</h3>

                <dl class="info-list">
                    <div>
                        <dt>Student No.</dt>
                        <dd><?= htmlspecialchars($student['student_number'] ?? 'Pending') ?></dd>
                    </div>
                    <div>
                        <dt>Course</dt>
                        <dd><?= htmlspecialchars($student['course_name'] ?? 'Not selected') ?></dd>
                    </div>
                    <div>
                        <dt>Course Code</dt>
                        <dd><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Year Level</dt>
                        <dd><?= htmlspecialchars($student['year_level'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Birthdate</dt>
                        <dd><?= htmlspecialchars($student['birthdate'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Sex</dt>
                        <dd><?= htmlspecialchars($student['sex'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Section</dt>
                        <dd><?= htmlspecialchars($student['section_name'] ?? 'Not assigned yet') ?></dd>
                    </div>
                </dl>

                <div style="margin-top:1.5rem;">
                    <h3>Registration Form</h3>
                    <p style="color:#666;margin-bottom:.75rem;">View your official submitted registration details.</p>
                    <a id="viewRegistrationFormBtn" href="registration_form_view.php" class="btn btn-doc">
                        📄 View Registration Form
                    </a>
                </div>
            </div>

            <!-- Payment -->
            <?php if (!$isFullyPaid && $canPay): ?>
                <div class="card payment-card" id="payment" style="grid-column: 1 / -1;">
                    <div class="payment-card-content">
                        <div>
                            <h3>Payment</h3>
                            <p>Your remaining balance is <strong>₱<?= number_format($remainingBalance, 2) ?></strong>.</p>
                            <small class="payment-help">Choose GCash and enter the amount you want to pay.</small>
                        </div>
                        <button type="button" class="btn btn-payment" onclick="openPaymentModal()">💳 Pay Now</button>
                    </div>
                </div>

                <div id="paymentWindow" class="payment-window" style="grid-column:1 / -1;" hidden>
                    <form method="POST" action="../functions/request_payment.php" id="customPaymentForm" class="payment-window-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf) ?>">
                        <input type="hidden" name="payment_method" value="gcash">

                        <div class="payment-modal-header">
                            <div>
                                <span class="payment-kicker">SECURE PAYMENT</span>
                                <h3>Make a Payment</h3>
                                <p>Remaining balance: <strong>₱<?= number_format($remainingBalance, 2) ?></strong></p>
                            </div>
                            <button type="button" class="payment-close" onclick="closePaymentModal()" aria-label="Close">&times;</button>
                        </div>

                        <div class="payment-method-grid">
                            <div class="payment-method active" aria-label="GCash payment">
                                <span class="method-icon">📱</span>
                                <strong>GCash</strong>
                                <small>Pay using GCash</small>
                            </div>
                        </div>

                        <div class="payment-field">
                            <label for="paymentAmount">Amount to pay *</label>
                            <input id="paymentAmount" class="form-control" name="payment_amount" type="number" min="0" max="<?= htmlspecialchars(number_format($remainingBalance, 2, '.', '')) ?>" step="0.01" value="0" placeholder="0" inputmode="decimal" required>
                            <small>Enter any amount up to your remaining balance. Maximum: ₱<?= number_format($remainingBalance, 2) ?></small>
                        </div>

                        <div class="payment-field">
                            <label for="paymentAccount">GCash Account</label>
                            <input id="paymentAccount" name="payment_account" type="text" maxlength="100" placeholder="e.g. GCash mobile ending 1234" required>
                        </div>

                        <div class="payment-field">
                            <label for="paymentReference">Transaction Reference</label>
                            <input id="paymentReference" name="payment_reference" type="text" maxlength="100" value="<?= htmlspecialchars($studentPaymentReference) ?>" readonly aria-readonly="true">
                            <small>Your transaction reference is generated automatically and is unique to this payment request.</small>
                        </div>

                        <div class="payment-modal-actions">
                            <button type="button" class="btn btn-secondary" onclick="closePaymentModal()">Cancel</button>
                            <button type="submit" class="btn btn-payment" id="submitPaymentBtn">Submit Payment</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <!-- Enrollment Status -->
            <div class="card" id="enrollment" style="grid-column: 1 / -1;">
                <h3>Enrollment Status</h3>

                <div class="status-summary">
                    <div class="status-item">
                        <span>Application</span>
                        <strong class="<?= in_array(strtolower($displayEnrollmentStatus), ['approved', 'enrolled'], true) ? 'text-success' : (strtolower($displayEnrollmentStatus) === 'rejected' ? 'text-danger' : 'text-warning') ?>">
                            <?= htmlspecialchars($displayEnrollmentStatus) ?>
                        </strong>
                    </div>
                    <div class="status-item">
                        <span>Payment</span>
                        <strong class="<?= strtolower($enrollment['payment_status'] ?? '') === 'paid' ? 'text-success' : 'text-warning' ?>">
                            <?= htmlspecialchars($enrollment['payment_status'] ?? $student['payment_status'] ?? 'Pending') ?>
                        </strong>
                    </div>
                    <div class="status-item">
                        <span>School Year</span>
                        <strong><?= htmlspecialchars($enrollment['school_year'] ?? 'N/A') ?></strong>
                    </div>
                    <div class="status-item">
                        <span>Semester</span>
                        <strong><?= htmlspecialchars($enrollment['sem'] ?? 'N/A') ?></strong>
                    </div>
                </div>

            </div>

        </div>

    </main>

    <!-- PAYMENT ERROR TOAST -->
    <div id="payErrorToast" style="
        display:none; position:fixed; bottom:24px; right:24px;
        background:#ef4444; color:#fff; padding:14px 20px;
        border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,.25);
        font-weight:600; z-index:9999; max-width:340px;">
    </div>

    <script>
        /* ── Back-button / tab security ─────────────────────────── */
        window.addEventListener('pageshow', function(e) {
            if (e.persisted) window.location.reload();
        });

        document.querySelectorAll('#viewRegistrationFormBtn').forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const url = link.href;
                Swal.fire({
                    title: 'Preparing registration form',
                    text: 'Please wait a moment…',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: function() {
                        Swal.showLoading();
                    }
                });
                window.setTimeout(function() {
                    window.location.href = url;
                }, 900);
            });
        });

        /* ── PayMongo Pay Now ───────────────────────────────────── */
        async function initiatePayment() {
            const btn = document.getElementById('payNowBtn');
            const txtEl = document.getElementById('payBtnText');
            const spinEl = document.getElementById('payBtnSpinner');
            const csrf = document.getElementById('paycsrf')?.value || '';

            btn.disabled = true;
            txtEl.style.display = 'none';
            spinEl.style.display = 'inline';

            try {
                const res = await fetch('../functions/create_payment_link.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'csrf_token=' + encodeURIComponent(csrf),
                });

                const data = await res.json();

                if (data.url) {
                    window.location.href = data.url;
                } else {
                    showPayError(data.error || 'Could not create a payment link. Try again.');
                    btn.disabled = false;
                    txtEl.style.display = 'inline';
                    spinEl.style.display = 'none';
                }
            } catch (err) {
                showPayError('Network error. Please check your connection and try again.');
                btn.disabled = false;
                txtEl.style.display = 'inline';
                spinEl.style.display = 'none';
            }
        }

        function openCashKiosk() {
            const kiosk = document.getElementById('cashPaymentKiosk');
            if (kiosk?.showModal) kiosk.showModal();
        }

        function closeCashKiosk() {
            document.getElementById('cashPaymentKiosk')?.close();
        }

        function submitCustomCashPayment() {
            const amount = Number(document.getElementById('customCashAmount')?.value || 0);
            if (amount <= 0) {
                showPayError('Enter a valid cash amount.');
                return;
            }
            selectCashPayment(amount);
        }

        async function selectCashPayment(amount) {
            const btn = document.getElementById('cashPaymentBtn');
            const csrf = document.getElementById('paycsrf')?.value || '';
            btn.disabled = true;

            try {
                const res = await fetch('../functions/select_cash_payment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'csrf_token=' + encodeURIComponent(csrf) + '&cash_amount=' + encodeURIComponent(amount),
                });
                const data = await res.json();

                if (res.ok) {
                    closeCashKiosk();
                    Swal.fire({
                        icon: 'info',
                        title: 'Cash payment requested',
                        text: 'Please wait for the cashier to verify your payment after you pay.',
                        confirmButtonText: 'OK'
                    });
                } else {
                    showPayError(data.error || 'Could not select cash payment. Try again.');
                }
            } catch (err) {
                showPayError('Network error. Please check your connection and try again.');
            } finally {
                btn.disabled = false;
            }
        }

        function showPayError(msg) {
            const toast = document.getElementById('payErrorToast');
            toast.textContent = msg;
            toast.style.display = 'block';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 5000);
        }

        function openPaymentModal() {
            const windowEl = document.getElementById('paymentWindow');
            const amount = document.getElementById('paymentAmount');
            const reference = document.getElementById('paymentReference');
            const max = <?= json_encode($remainingBalance) ?>;

            if (!windowEl) return;
            if (amount) {
                amount.max = max.toFixed(2);
                if (!amount.value || Number(amount.value) > max) amount.value = '0';
            }
            if (reference) reference.value = '<?= htmlspecialchars($studentPaymentReference, ENT_QUOTES) ?>';
            windowEl.hidden = false;
            windowEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        function closePaymentModal() {
            const windowEl = document.getElementById('paymentWindow');
            if (windowEl) windowEl.hidden = true;
        }

        const paymentAmountInput = document.getElementById('paymentAmount');
        paymentAmountInput?.addEventListener('focus', function() {
            if (this.value === '0') this.value = '';
        });
        paymentAmountInput?.addEventListener('blur', function() {
            if (this.value.trim() === '') this.value = '0';
        });

        document.getElementById('customPaymentForm')?.addEventListener('submit', function(event) {
            const amountInput = document.getElementById('paymentAmount');
            const amount = Number(amountInput?.value || 0);
            const max = Number(amountInput?.max || 0);
            const reference = document.getElementById('paymentReference');
            const account = document.getElementById('paymentAccount');

            if (!Number.isFinite(amount) || amount <= 0) {
                event.preventDefault();
                showPayError('Enter a valid payment amount.');
                return;
            }
            if (amount > max + 0.00001) {
                event.preventDefault();
                amountInput.value = max.toFixed(2);
                showPayError('Payment cannot exceed your remaining balance of ₱' + max.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2}) + '.');
                return;
            }
            if (!account?.value.trim()) {
                event.preventDefault();
                showPayError('Enter your GCash account details.');
                return;
            }
            if (reference) reference.readOnly = true;
        });

        /* ── Profile Image Preview ──────────────────────────────── */
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('pic_preview');
                    const placeholder = document.getElementById('pic_placeholder');
                    if (preview) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    }
                    if (placeholder) {
                        placeholder.style.display = 'none';
                    }
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>

</html>