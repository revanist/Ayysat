<?php

require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();

include '../db/dbconn.php';

/* =========================================================
   SEARCH
========================================================= */

$search = trim((string) ($_GET['search'] ?? ''));
$like = '%' . $search . '%';


/* =========================================================
   TOTAL STUDENTS
========================================================= */

$totalStudentsResult = mysqli_query(
    $conn,
    'SELECT COUNT(*) total FROM students'
);

$totalStudents = (int) (
    mysqli_fetch_assoc($totalStudentsResult)['total'] ?? 0
);


/* =========================================================
   CSRF
========================================================= */

$csrf = admin_csrf_token();


/* =========================================================
   STUDENT QUERY
========================================================= */

$stmt = mysqli_prepare(
    $conn,
    "
    SELECT
        students.id,
        students.student_number,
        students.first_name,
        students.last_name,
        students.email,
        students.year_level,
        students.payment_status,
        courses.course_code,
        sections.section_name

    FROM students

    LEFT JOIN courses
        ON students.course_id = courses.id

    LEFT JOIN sections
        ON students.section_id = sections.id

    WHERE
        students.student_number LIKE ?
        OR students.last_name LIKE ?
        OR students.email LIKE ?

    ORDER BY students.id DESC
    "
);

mysqli_stmt_bind_param(
    $stmt,
    'sss',
    $like,
    $like,
    $like
);

mysqli_stmt_execute($stmt);

$query = mysqli_stmt_get_result($stmt);

$shownStudents = mysqli_num_rows($query);


/* =========================================================
   ADMIN NAME
========================================================= */

$adminName = htmlspecialchars(
    $_SESSION['admin_name'] ?? 'Admin'
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Students – EYYSAT</title>


    <!-- =====================================================
         ADMIN CSS
    ====================================================== -->

    <link
        rel="stylesheet"
        href="../css/admin_dashboard.css">


    <!-- =====================================================
         SWEETALERT
    ====================================================== -->

    <script
        src="../js/sweetalert2.all.min.js">
    </script>

    <script
        src="../js/swal-confirm.js"
        defer>
    </script>

<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>


<body>


    <!-- =========================================================
     SIDEBAR
========================================================= -->

    <?php include 'navbar_layout.php'; ?>

    <main
        class="dashboard-main"
        id="dashboardMain">


        <!-- =====================================================
         SIDEBAR TOGGLE
    ====================================================== -->

        


        <!-- =====================================================
         TOPBAR
    ====================================================== -->

        <header class="dashboard-topbar">


            <div>

                <span class="topbar-label">
                    ADMINISTRATION
                </span>

                <h2>
                    Students
                </h2>

            </div>

        </header>


        <!-- =====================================================
         PAGE HEADER
    ====================================================== -->

        <section class="page-header">

            <span class="hero-badge">
                👨‍🎓 Student Management
            </span>

            <h1>
                Students
            </h1>

            <p>
                Manage registered students, their courses,
                sections, year levels, and payment status.
            </p>

        </section>


        <!-- =====================================================
         STATS
    ====================================================== -->

        <section class="stats-row">


            <!-- TOTAL -->

            <div class="stat-card stat-success">

                <div class="stat-icon">
                    🎓
                </div>

                <h3>
                    Total Students
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $totalStudents ?>">
                    <?= $totalStudents ?>
                </span>

            </div>


            <!-- SHOWN -->

            <div class="stat-card stat-section">

                <div class="stat-icon">
                    📋
                </div>

                <h3>
                    Shown in Table
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $shownStudents ?>">
                    <?= $shownStudents ?>
                </span>

            </div>

        </section>


        <!-- =====================================================
         STUDENT LIST CARD
    ====================================================== -->

        <section class="card student-list-card">


            <!-- TABLE HEADER -->

            <div class="table-header">


                <div>

                    <span class="table-label">
                        STUDENT RECORDS
                    </span>

                    <h2>
                        Student List
                    </h2>

                </div>


                <!-- SEARCH -->

                <div class="student-search">

                    <span class="search-icon">
                        🔎
                    </span>

                    <input
                        type="text"
                        id="searchInput"
                        class="search-box"
                        placeholder="Search student..."
                        value="<?= htmlspecialchars($search) ?>"
                        autocomplete="off">

                </div>

            </div>


            <!-- =================================================
             TABLE
        ================================================== -->

            <div class="table-wrapper">


                <table
                    class="modern-table"
                    id="studentTable">


                    <thead>

                        <tr>

                            <th>
                                ID
                            </th>

                            <th>
                                Student No.
                            </th>

                            <th>
                                Name
                            </th>

                            <th>
                                Course
                            </th>

                            <th>
                                Year
                            </th>

                            <th>
                                Email
                            </th>

                            <th>
                                Section
                            </th>

                            <th>
                                Payment
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                        <?php if ($shownStudents > 0): ?>


                            <?php while (
                                $row = mysqli_fetch_assoc($query)
                            ): ?>


                                <?php

                                $paymentStatus =
                                    strtolower(
                                        trim(
                                            $row['payment_status'] ?? ''
                                        )
                                    );

                                $paymentLabel =
                                    $paymentStatus === 'paid'
                                    ? 'Fully Paid'
                                    : (
                                        $paymentStatus !== ''
                                        ? ucfirst($paymentStatus)
                                        : 'Pending'
                                    );


                                $paymentClass =
                                    $paymentStatus === 'paid'
                                    ? 'payment-paid'
                                    : 'payment-pending';

                                ?>


                                <tr>


                                    <!-- ID -->

                                    <td data-label="ID">

                                        <span class="student-id">
                                            <?= (int) $row['id'] ?>
                                        </span>

                                    </td>


                                    <!-- STUDENT NUMBER -->

                                    <td data-label="Student No.">

                                        <strong class="student-number">

                                            <?= htmlspecialchars(
                                                $row['student_number']
                                            ) ?>

                                        </strong>

                                    </td>


                                    <!-- NAME -->

                                    <td data-label="Name">

                                        <div class="student-name">

                                            <span>

                                                <?= htmlspecialchars(
                                                    $row['first_name']
                                                        . ' '
                                                        . $row['last_name']
                                                ) ?>

                                            </span>

                                        </div>

                                    </td>


                                    <!-- COURSE -->

                                    <td data-label="Course">

                                        <span class="course-badge">

                                            <?= htmlspecialchars(
                                                $row['course_code'] ?? '—'
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- YEAR -->

                                    <td data-label="Year">

                                        <?= htmlspecialchars(
                                            $row['year_level'] ?? '—'
                                        ) ?>

                                    </td>


                                    <!-- EMAIL -->

                                    <td data-label="Email">

                                        <span class="email-text">

                                            <?= htmlspecialchars(
                                                $row['email']
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- SECTION -->

                                    <td data-label="Section">

                                        <?= htmlspecialchars(
                                            $row['section_name'] ?? '—'
                                        ) ?>

                                    </td>


                                    <!-- PAYMENT -->

                                    <td data-label="Payment">

                                        <span
                                            class="payment-status <?= $paymentClass ?>">

                                            <?= htmlspecialchars(
                                                $paymentLabel
                                            ) ?>

                                        </span>

                                    </td>


                                    <!-- ACTIONS -->

                                    <td
                                        data-label="Actions"
                                        class="action-cell">


                                        <a
                                            href="edit_student.php?id=<?= (int) $row['id'] ?>"
                                            class="btn-edit">
                                            Edit
                                        </a>


                                        <form
                                            method="POST"
                                            action="../controller/delete_student.php"
                                            class="delete-form"
                                            data-swal-confirm="Delete this student permanently?"
                                            data-swal-title="Delete student?">

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= htmlspecialchars($csrf) ?>">

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= (int) $row['id'] ?>">

                                            <button
                                                type="submit"
                                                class="btn-delete"
                                                name="delete_student"
                                                value="1">
                                                Delete
                                            </button>

                                        </form>


                                    </td>


                                </tr>


                            <?php endwhile; ?>


                        <?php else: ?>


                            <tr>

                                <td
                                    colspan="9"
                                    class="empty-state">

                                    <div class="empty-icon">
                                        👨‍🎓
                                    </div>

                                    <strong>
                                        No students found
                                    </strong>

                                    <span>
                                        Try changing your search.
                                    </span>

                                </td>

                            </tr>


                        <?php endif; ?>


                    </tbody>

                </table>

            </div>

        </section>


    </main>


    <!-- =========================================================
     SCROLL TO TOP
========================================================= -->

    <button
        class="scroll-top"
        id="scrollTop"
        type="button"
        aria-label="Scroll to top">

        ↑

    </button>


    <!-- =========================================================
     JAVASCRIPT
========================================================= -->

    <script>
        document.addEventListener(
            'DOMContentLoaded',
            function() {


                /* =====================================================
                   SIDEBAR
                ====================================================== */

                const sidebar =
                    document.getElementById(
                        'adminSidebar'
                    );


                const sidebarToggle =
                    document.getElementById(
                        'sidebarToggle'
                    );


                const sidebarOverlay =
                    document.getElementById(
                        'sidebarOverlay'
                    );


                const dashboardMain =
                    document.getElementById(
                        'dashboardMain'
                    );


                let sidebarCollapsed = false;


                /* =====================================================
                   UPDATE TOGGLE POSITION
                ====================================================== */

                function updateTogglePosition() {

                    if (window.innerWidth <= 768) {

                        sidebarToggle.style.left =
                            '18px';

                        return;
                    }


                    if (sidebarCollapsed) {

                        sidebarToggle.style.left =
                            '68px';

                    } else {

                        sidebarToggle.style.left =
                            '246px';

                    }

                }


                /* =====================================================
                   SIDEBAR TOGGLE
                ====================================================== */

                sidebarToggle.addEventListener(
                    'click',
                    function() {


                        /* MOBILE */

                        if (
                            window.innerWidth <= 768
                        ) {

                            sidebar.classList.toggle(
                                'mobile-open'
                            );

                            sidebarOverlay.classList.toggle(
                                'show'
                            );

                            return;

                        }


                        /* DESKTOP */

                        sidebarCollapsed = !sidebarCollapsed;


                        sidebar.classList.toggle(
                            'collapsed',
                            sidebarCollapsed
                        );


                        dashboardMain.classList.toggle(
                            'sidebar-collapsed',
                            sidebarCollapsed
                        );


                        sidebarToggle.classList.toggle(
                            'collapsed',
                            sidebarCollapsed
                        );


                        updateTogglePosition();

                    }
                );


                /* =====================================================
                   MOBILE OVERLAY
                ====================================================== */

                sidebarOverlay.addEventListener(
                    'click',
                    function() {

                        sidebar.classList.remove(
                            'mobile-open'
                        );

                        sidebarOverlay.classList.remove(
                            'show'
                        );

                    }
                );


                /* =====================================================
                   MOBILE NAVIGATION
                ====================================================== */

                document
                    .querySelectorAll(
                        '.sidebar-link'
                    )
                    .forEach(
                        function(link) {

                            link.addEventListener(
                                'click',
                                function() {

                                    if (
                                        window.innerWidth <= 768
                                    ) {

                                        sidebar.classList.remove(
                                            'mobile-open'
                                        );

                                        sidebarOverlay.classList.remove(
                                            'show'
                                        );

                                    }

                                }
                            );

                        }
                    );


                /* =====================================================
                   RESIZE
                ====================================================== */

                window.addEventListener(
                    'resize',
                    function() {

                        updateTogglePosition();

                    }
                );


                updateTogglePosition();


                /* =====================================================
                   COUNT UP
                ====================================================== */

                document
                    .querySelectorAll(
                        '.count-up'
                    )
                    .forEach(
                        function(element) {


                            const target =
                                Number(
                                    element.dataset.target
                                );


                            if (
                                !Number.isFinite(target)
                            ) {
                                return;
                            }


                            const duration = 900;

                            const startTime =
                                performance.now();


                            function animate(
                                currentTime
                            ) {

                                const elapsed =
                                    currentTime -
                                    startTime;


                                const progress =
                                    Math.min(
                                        elapsed / duration,
                                        1
                                    );


                                const eased =
                                    1 -
                                    Math.pow(
                                        1 - progress,
                                        3
                                    );


                                const current =
                                    Math.floor(
                                        target * eased
                                    );


                                element.textContent =
                                    current.toLocaleString();


                                if (
                                    progress < 1
                                ) {

                                    requestAnimationFrame(
                                        animate
                                    );

                                }

                            }


                            requestAnimationFrame(
                                animate
                            );

                        }
                    );


                /* =====================================================
                   LIVE TABLE SEARCH
                ====================================================== */

                const searchInput =
                    document.getElementById(
                        'searchInput'
                    );


                const tableRows =
                    document.querySelectorAll(
                        '#studentTable tbody tr'
                    );


                if (searchInput) {

                    searchInput.addEventListener(
                        'input',
                        function() {


                            const value =
                                this.value
                                .toLowerCase()
                                .trim();


                            tableRows.forEach(
                                function(row) {


                                    if (
                                        row.querySelector(
                                            '.empty-state'
                                        )
                                    ) {

                                        return;

                                    }


                                    const text =
                                        row.innerText
                                        .toLowerCase();


                                    row.style.display =
                                        text.includes(
                                            value
                                        ) ?
                                        '' :
                                        'none';

                                }
                            );

                        }
                    );

                }


                /* =====================================================
                   SCROLL TO TOP
                ====================================================== */

                const scrollTopButton =
                    document.getElementById(
                        'scrollTop'
                    );


                window.addEventListener(
                    'scroll',
                    function() {


                        if (
                            window.scrollY > 300
                        ) {

                            scrollTopButton.classList.add(
                                'show'
                            );

                        } else {

                            scrollTopButton.classList.remove(
                                'show'
                            );

                        }

                    }
                );


                /* =====================================================
                   SCROLL TO TOP CLICK
                ====================================================== */

                scrollTopButton.addEventListener(
                    'click',
                    function() {

                        window.scrollTo({

                            top: 0,

                            behavior: 'smooth'

                        });

                    }
                );


                /* =====================================================
                   PREVENT CACHED PAGE AFTER LOGOUT
                ====================================================== */

                window.addEventListener(
                    'pageshow',
                    function(event) {

                        if (
                            event.persisted
                        ) {

                            window.location.reload();

                        }

                    }
                );


            }
        );
    </script>


</body>

</html>