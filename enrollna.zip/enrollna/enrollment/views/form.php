<?php
function enrollment_old(string $key, string $default = ''): string
{
    $value = $_SESSION['enrollment_draft'][$key] ?? $default;
    return htmlspecialchars(is_scalar($value) ? (string) $value : $default, ENT_QUOTES, 'UTF-8');
}

function enrollment_old_checked(string $key, string $value): string
{
    return ((string) ($_SESSION['enrollment_draft'][$key] ?? '') === $value) ? ' selected' : '';
}

?>


  <div id="pageLoader">

    <div class="loader-content">

      <div class="spinner-border loader-spinner"></div>

      <p>Loading portal...</p>

    </div>

  </div>


  <div class="navbar-ayysat">

    <h1>EYYSAT</h1>

    <div class="tagline">
      Application & Registration Portal
    </div>

  </div>


  <div class="form-panel">

    <?php if ($enrollmentError !== ''): ?>

      <div
        id="enrollmentError"
        data-message="<?= htmlspecialchars(
                        $enrollmentError,
                        ENT_QUOTES,
                        'UTF-8'
                      ); ?>"
        hidden></div>

    <?php endif; ?>


    <ul class="wizard-steps">

      <li class="active">
        1. Personal Info
      </li>

      <li>
        2. Program Selection
      </li>

      <li>
        3. Emergency Contact
      </li>

      <li>
        4. Review & Submit
      </li>

    </ul>


    <form
      id="enrollmentForm"
      action="process.php"
      method="POST"
      enctype="multipart/form-data"
      novalidate>

      <input
        type="hidden"
        name="csrf_token"
        value="<?= htmlspecialchars(
                  student_csrf_token(),
                  ENT_QUOTES,
                  'UTF-8'
                ); ?>">

      <input
        type="hidden"
        name="school_year"
        value="<?= htmlspecialchars(system_school_year($conn)) ?>">


      <!-- ==================================================
                 STEP 1
            =================================================== -->

      <div
        class="wizard-pane active"
        data-step="1">

        <h3>
          Step 1: Personal Information
        </h3>


        <div class="row">

          <div class="col-md-4 form-group">

            <label>
              First Name *
            </label>

            <input
              type="text"
              class="form-control"
              name="first_name"
              value="<?= enrollment_old('first_name'); ?>"
              required>

          </div>


          <div class="col-md-4 form-group">

            <label>
              Middle Initial(s)
            </label>

            <input
              type="text"
              class="form-control"
              name="middle_name"
              value="<?= enrollment_old('middle_name'); ?>"
              maxlength="5"
              pattern="[A-Za-z. ]{1,5}"
              title="Use initials only, for example A. or M. J.">

          </div>


          <div class="col-md-4 form-group">

            <label>
              Last Name *
            </label>

            <input
              type="text"
              class="form-control"
              name="last_name"
              value="<?= enrollment_old('last_name'); ?>"
              required>

          </div>

        </div>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Email Address *
            </label>

            <input
              type="email"
              class="form-control"
              name="email"
              value="<?= enrollment_old('email'); ?>"
              required>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Contact Number *
            </label>

            <input
              type="tel"
              class="form-control"
              name="contact"
              value="<?= enrollment_old('contact'); ?>"
              maxlength="11"
              placeholder="09XXXXXXXXX"
              required>

          </div>

        </div>


        <div class="form-group">

          <label>
            Complete Address *
          </label>

          <textarea
            class="form-control"
            name="address"
            rows="3"
            required><?= enrollment_old('address'); ?></textarea>

        </div>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Date of Birth *
            </label>

            <input
              type="date"
              class="form-control"
              name="birthdate"
              id="birthdate"
              value="<?= enrollment_old('birthdate'); ?>"
              required>

            <div
              id="birthdateError"
              class="invalid-feedback">
              You must be 18 years old to apply.
            </div>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Sex *
            </label>

            <select
              class="form-select"
              name="sex"
              required>

              <option
                value=""
                selected
                disabled>
                Select Sex...
              </option>

              <option value="Male"<?= enrollment_old_checked('sex', 'Male'); ?>>
                Male
              </option>

              <option value="Female"<?= enrollment_old_checked('sex', 'Female'); ?>>
                Female
              </option>

            </select>

          </div>

        </div>


        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary"
            id="backToHomeBtn">
            ← Back to Home
          </button>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 2
            =================================================== -->

      <div
        class="wizard-pane"
        data-step="2">

        <h3>
          Step 2: Program Selection
        </h3>

        <p class="step-intro">
          Choose the student's course, year level,
          and semester. The curriculum below will
          automatically show the required subjects.
        </p>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Course *
            </label>

            <select
              class="form-select"
              id="course_id"
              name="course_id"
              required>

              <option
                value=""
                selected
                disabled>
                Select Course
              </option>

              <?php foreach (
                $courseCatalog
                as $entry
              ):

                $course =
                  $entry['course'];

              ?>

                <option
                  value="<?= (int) $course['id']; ?>"<?= enrollment_old_checked('course_id', (string) $course['id']); ?>>

                  <?= htmlspecialchars(
                    $course['course_code']
                  ); ?>

                  -

                  <?= htmlspecialchars(
                    $course['course_name']
                  ); ?>

                </option>

              <?php endforeach; ?>

            </select>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Year Level *
            </label>

            <select
              class="form-select"
              name="year_level"
              id="year_level"
              required>

              <option
                value=""
                selected
                disabled>
                Select Year
              </option>

              <option value="1"<?= enrollment_old_checked('year_level', '1'); ?>>
                1st Year
              </option>

              <option value="2"<?= enrollment_old_checked('year_level', '2'); ?>>
                2nd Year
              </option>

              <option value="3"<?= enrollment_old_checked('year_level', '3'); ?>>
                3rd Year
              </option>

              <option value="4"<?= enrollment_old_checked('year_level', '4'); ?>>
                4th Year
              </option>

            </select>

          </div>

        </div>


        <div class="row mt-3">

          <div class="col-md-6 form-group">

            <label>
              Semester *
            </label>

            <select
              class="form-select"
              name="semester"
              id="semester"
              required>

              <option
                value=""
                selected
                disabled>
                Select Semester
              </option>

              <option value="1"<?= enrollment_old_checked('semester', '1'); ?>>
                1st Semester
              </option>

              <option value="2"<?= enrollment_old_checked('semester', '2'); ?>>
                2nd Semester
              </option>

            </select>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Curriculum Status
            </label>

            <div
              id="curriculumStatus"
              class="form-control bg-light text-muted">
              Select course, year and semester.
            </div>

          </div>

        </div>


        <!-- CURRICULUM -->

        <div class="curriculum-panel mt-4">

          <div class="curriculum-panel-header">

            <div>

              <div class="curriculum-kicker">
                ACADEMIC PLAN
              </div>

              <h4 class="mb-1">
                📚 Curriculum
              </h4>

              <p class="mb-0 text-muted small">
                Your required subjects are
                organized by year level and semester.
              </p>

            </div>


            <div
              id="curriculumCourseBadge"
              class="curriculum-course-badge">
              No course selected
            </div>

          </div>


          <div
            id="curriculumAccordion"
            class="accordion curriculum-accordion">

            <div class="curriculum-empty-state">

              <div class="curriculum-empty-icon">
                📖
              </div>

              <h5>
                Select a course
              </h5>

              <p class="mb-0">
                Choose a course, year level,
                and semester above.
              </p>

            </div>

          </div>


          <div
            id="curriculumSummary"
            class="curriculum-summary d-none">

            <div>

              <span class="summary-label">
                Selected Semester
              </span>

              <strong id="selectedSemesterLabel">
                —
              </strong>

            </div>


            <div>

              <span class="summary-label">
                Required Subjects
              </span>

              <strong id="selectedSubjectCount">
                0
              </strong>

            </div>


            <div>

              <span class="summary-label">
                Total Units
              </span>

              <strong id="totalUnits">
                0
              </strong>

            </div>

          </div>


          <div
            id="subjectContainer"
            class="d-none"></div>


          <div
            class="invalid-feedback d-none"
            id="subjectError">
            Please select a curriculum first.
          </div>

        </div>


        <!-- SECTION -->

        <div class="registration-section mt-4">

          <div class="registration-section-header">

            <div>

              <div class="curriculum-kicker">
                REGISTRATION
              </div>

              <h5 class="mb-1">
                Class Section
              </h5>

              <p class="mb-0 text-muted small">
                Select the section where the
                student will register.
              </p>

            </div>

          </div>


          <div class="row mt-3">

            <div class="col-md-6 form-group">

              <label>
                Section *
              </label>

              <select
                id="section_select"
                name="section_id"
                class="form-select"
                required>

                <option value="">
                  Select Course First
                </option>

              </select>

            </div>


            <div class="col-md-6">

              <div class="registration-note">

                <strong>
                  How this works
                </strong>

                <p class="mb-0">
                  The curriculum determines
                  the required subjects.
                  The selected section provides
                  the class grouping.
                </p>

              </div>

            </div>

          </div>

        </div>


        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 3
            =================================================== -->

      <div
        class="wizard-pane"
        data-step="3">

        <h3>
          Step 3: Emergency Contact
        </h3>

        <p class="step-intro">
          Provide a parent, guardian, or emergency
          contact who can be reached if necessary.
        </p>


        <div class="row">

          <div class="col-md-6 form-group">

            <label>
              Guardian Name *
            </label>

            <input
              type="text"
              class="form-control"
              name="guardian"
              value="<?= enrollment_old('guardian'); ?>"
              required>

          </div>


          <div class="col-md-6 form-group">

            <label>
              Guardian Contact Number *
            </label>

            <input
              type="tel"
              class="form-control"
              name="guardian_contact"
              value="<?= enrollment_old('guardian_contact'); ?>"
              maxlength="11"
              placeholder="09XXXXXXXXX"
              required>

          </div>

        </div>


        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>

          <button
            type="button"
            class="btn btn-primary btn-next">
            Next →
          </button>

        </div>

      </div>


      <!-- ==================================================
                 STEP 4 REVIEW
            =================================================== -->

      <div
        id="reviewPane"
        class="wizard-pane"
        data-step="4">

        <h3>
          Step 4: Review Your Application
        </h3>

        <p class="step-intro">
          Please review your information before submitting.
        </p>


        <div id="summaryBox"></div>

        <div class="review-account-note">
          <strong>Student account:</strong> Your portal account will be created automatically after you submit this application.
        </div>

        <div class="btn-group-wizard">

          <button
            type="button"
            class="btn btn-secondary btn-prev">
            ← Previous
          </button>


          <div class="review-actions">

            <button
              type="button"
              class="btn btn-outline-primary"
              id="previewRegistrationFormBtn">
              View Registration Form
            </button>

            <button
              type="submit"
              class="btn btn-primary"
              id="submitApplicationBtn">
              ✓ Submit Enrollment
            </button>

          </div>

        </div>

      </div>

    </form>

  </div>

  