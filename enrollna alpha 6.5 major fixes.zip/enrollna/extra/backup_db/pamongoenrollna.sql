-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2026 at 07:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollna`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `fullname`, `email`, `password`, `created`) VALUES
(1, 'rainier acquisa', 'rainier@eyysat.edu.ph', '$2y$10$4DRQN3MzgK6RGzXiPb0Cxem5eVzUBqmKB2DSLQwGoMNxZo3FqUUIS', '2026-07-30 16:27:49');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_name`, `created`) VALUES
(1, 'BSIT', 'Bachelor of Science in Information Technology', '2026-07-19 05:21:08'),
(2, 'BSCS', 'Bachelor of Science in Computer Science', '2026-07-19 05:21:08'),
(3, 'BSIS', 'Bachelor of Science in Information Systems', '2026-07-19 05:21:08'),
(5, 'BSBA', 'Bachelor of Science in Business Administration', '2026-07-19 05:21:08'),
(6, 'BSA', 'Bachelor of Science in Accountancy', '2026-07-19 05:21:08'),
(7, 'BSHM', 'Bachelor of Science in Hospitality Management', '2026-07-19 05:21:08'),
(8, 'BSTM', 'Bachelor of Science in Tourism Management', '2026-07-19 05:21:08'),
(9, 'BSCRIM', 'Bachelor of Science in Criminology', '2026-07-19 05:21:08'),
(10, 'BSN', 'Bachelor of Science in Nursing', '2026-07-19 05:21:08'),
(15, 'BSCE', 'Bachelor of Science in Civil Engineering', '2026-07-19 05:21:08');

-- --------------------------------------------------------

--
-- Table structure for table `curriculum`
--

CREATE TABLE `curriculum` (
  `id` int(10) UNSIGNED NOT NULL,
  `course_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `year_level` tinyint(3) UNSIGNED NOT NULL,
  `semester` tinyint(3) UNSIGNED NOT NULL,
  `units` decimal(4,1) NOT NULL DEFAULT 3.0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ;

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `STATUS` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_status` enum('Paid','Pending','Unpaid') DEFAULT 'Pending',
  `paymongo_link_id` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_option` varchar(50) DEFAULT NULL,
  `payment_reference` varchar(100) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT 0.00,
  `cash_amount_requested` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollment_details`
--

CREATE TABLE `enrollment_details` (
  `id` int(11) NOT NULL,
  `enrollment_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `max_slots` int(11) DEFAULT 40,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `section_id`, `course_id`, `section_name`, `max_slots`, `created`) VALUES
(21, NULL, 1, 'Section A', 40, '2026-07-31 00:13:11'),
(22, NULL, 1, 'Section B', 40, '2026-07-31 00:13:11'),
(23, NULL, 2, 'Section A', 40, '2026-07-31 00:13:11'),
(24, NULL, 2, 'Section B', 40, '2026-07-31 00:13:11'),
(25, NULL, 3, 'Section A', 40, '2026-07-31 00:13:11'),
(26, NULL, 3, 'Section B', 40, '2026-07-31 00:13:11'),
(27, NULL, 5, 'Section A', 40, '2026-07-31 00:13:11'),
(28, NULL, 5, 'Section B', 40, '2026-07-31 00:13:11'),
(29, NULL, 6, 'Section A', 40, '2026-07-31 00:13:11'),
(30, NULL, 6, 'Section B', 40, '2026-07-31 00:13:11'),
(31, NULL, 7, 'Section A', 40, '2026-07-31 00:13:11'),
(32, NULL, 7, 'Section B', 40, '2026-07-31 00:13:11'),
(33, NULL, 8, 'Section A', 40, '2026-07-31 00:13:11'),
(34, NULL, 8, 'Section B', 40, '2026-07-31 00:13:11'),
(35, NULL, 9, 'Section A', 40, '2026-07-31 00:13:11'),
(36, NULL, 9, 'Section B', 40, '2026-07-31 00:13:11'),
(37, NULL, 10, 'Section A', 40, '2026-07-31 00:13:11'),
(38, NULL, 10, 'Section B', 40, '2026-07-31 00:13:11'),
(39, NULL, 15, 'Section A', 40, '2026-07-31 00:13:11'),
(40, NULL, 15, 'Section B', 40, '2026-07-31 00:13:11');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_number` varchar(20) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `sex` enum('Male','Female') DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `guardian` varchar(100) DEFAULT NULL,
  `guardian_contact` varchar(100) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `payment_status` enum('Pending','Paid') DEFAULT 'Pending',
  `enrollment_status` enum('Pending','Enrolled') DEFAULT 'Pending',
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile_picture` varchar(255) DEFAULT NULL,
  `remaining_balance` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `subject_code` varchar(20) DEFAULT NULL,
  `subject_name` varchar(100) DEFAULT NULL,
  `units` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL,
  `year_level` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `section_id` int(11) DEFAULT NULL,
  `schedule_day` varchar(20) DEFAULT NULL,
  `schedule_time` varchar(50) DEFAULT NULL,
  `room_number` varchar(20) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `course_id`, `subject_code`, `subject_name`, `units`, `sem`, `year_level`, `created`, `section_id`, `schedule_day`, `schedule_time`, `room_number`, `is_available`) VALUES
(1, 1, 'IT101', 'Programming I', 3, 1, 1, '2026-07-30 16:24:50', 1, 'Mon', '8:00 AM', 'LAB 1', 1),
(2, 1, 'IT102', 'Database Systems', 3, 1, 1, '2026-07-30 16:24:50', 2, 'Tue', '10:00 AM', 'LAB 2', 1),
(3, 1, 'IT103', 'Networking', 3, 1, 1, '2026-07-30 16:24:50', 1, 'Wed', '1:00 PM', 'LAB 3', 1),
(4, 1, 'IT104', 'Web Development', 3, 1, 1, '2026-07-30 16:24:50', 2, 'Thu', '3:00 PM', 'LAB 4', 1),
(5, 1, 'IT105', 'Systems Analysis', 3, 1, 1, '2026-07-30 16:24:50', 1, 'Fri', '9:00 AM', 'RM 101', 1),
(6, 1, 'IT106', 'Ethics in Computing', 3, 1, 1, '2026-07-30 16:24:50', 2, 'Mon', '2:00 PM', 'RM 102', 1),
(7, 2, 'CS101', 'Programming Fundamentals', 3, 1, 1, '2026-07-30 16:24:50', 3, 'Mon', '8:00 AM', 'LAB 1', 1),
(8, 2, 'CS102', 'Data Structures', 3, 1, 1, '2026-07-30 16:24:50', 4, 'Tue', '10:00 AM', 'LAB 2', 1),
(9, 2, 'CS103', 'Discrete Mathematics', 3, 1, 1, '2026-07-30 16:24:50', 3, 'Wed', '1:00 PM', 'LAB 3', 1),
(10, 2, 'CS104', 'Algorithms', 3, 1, 1, '2026-07-30 16:24:50', 4, 'Thu', '3:00 PM', 'LAB 4', 1),
(11, 2, 'CS105', 'Computer Architecture', 3, 1, 1, '2026-07-30 16:24:50', 3, 'Fri', '9:00 AM', 'RM 101', 1),
(12, 2, 'CS106', 'Operating Systems', 3, 1, 1, '2026-07-30 16:24:50', 4, 'Mon', '2:00 PM', 'RM 102', 1),
(13, 3, 'IS101', 'Information Systems Fundamentals', 3, 1, 1, '2026-07-30 16:24:50', 5, 'Mon', '8:00 AM', 'LAB 1', 1),
(14, 3, 'IS102', 'Business Process Management', 3, 1, 1, '2026-07-30 16:24:50', 6, 'Tue', '10:00 AM', 'LAB 2', 1),
(15, 3, 'IS103', 'Database Management', 3, 1, 1, '2026-07-30 16:24:50', 5, 'Wed', '1:00 PM', 'LAB 3', 1),
(16, 3, 'IS104', 'Systems Analysis and Design', 3, 1, 1, '2026-07-30 16:24:50', 6, 'Thu', '3:00 PM', 'LAB 4', 1),
(17, 3, 'IS105', 'Enterprise Systems', 3, 1, 1, '2026-07-30 16:24:50', 5, 'Fri', '9:00 AM', 'RM 101', 1),
(18, 3, 'IS106', 'IT Governance', 3, 1, 1, '2026-07-30 16:24:50', 6, 'Mon', '2:00 PM', 'RM 102', 1),
(19, 5, 'BA101', 'Principles of Management', 3, 1, 1, '2026-07-30 16:24:50', 7, 'Mon', '8:00 AM', 'LAB 1', 1),
(20, 5, 'BA102', 'Marketing Management', 3, 1, 1, '2026-07-30 16:24:50', 8, 'Tue', '10:00 AM', 'LAB 2', 1),
(21, 5, 'BA103', 'Human Resource Management', 3, 1, 1, '2026-07-30 16:24:50', 7, 'Wed', '1:00 PM', 'LAB 3', 1),
(22, 5, 'BA104', 'Operations Management', 3, 1, 1, '2026-07-30 16:24:50', 8, 'Thu', '3:00 PM', 'LAB 4', 1),
(23, 5, 'BA105', 'Business Finance', 3, 1, 1, '2026-07-30 16:24:50', 7, 'Fri', '9:00 AM', 'RM 101', 1),
(24, 5, 'BA106', 'Entrepreneurship', 3, 1, 1, '2026-07-30 16:24:50', 8, 'Mon', '2:00 PM', 'RM 102', 1),
(25, 6, 'ACCT101', 'Financial Accounting', 3, 1, 1, '2026-07-30 16:24:50', 9, 'Mon', '8:00 AM', 'LAB 1', 1),
(26, 6, 'ACCT102', 'Managerial Accounting', 3, 1, 1, '2026-07-30 16:24:50', 10, 'Tue', '10:00 AM', 'LAB 2', 1),
(27, 6, 'ACCT103', 'Auditing Principles', 3, 1, 1, '2026-07-30 16:24:50', 9, 'Wed', '1:00 PM', 'LAB 3', 1),
(28, 6, 'ACCT104', 'Taxation', 3, 1, 1, '2026-07-30 16:24:50', 10, 'Thu', '3:00 PM', 'LAB 4', 1),
(29, 6, 'ACCT105', 'Accounting Information Systems', 3, 1, 1, '2026-07-30 16:24:50', 9, 'Fri', '9:00 AM', 'RM 101', 1),
(30, 6, 'ACCT106', 'Business Law', 3, 1, 1, '2026-07-30 16:24:50', 10, 'Mon', '2:00 PM', 'RM 102', 1),
(31, 7, 'HM101', 'Introduction to Hospitality', 3, 1, 1, '2026-07-30 16:24:50', 11, 'Mon', '8:00 AM', 'LAB 1', 1),
(32, 7, 'HM102', 'Food and Beverage Service', 3, 1, 1, '2026-07-30 16:24:50', 12, 'Tue', '10:00 AM', 'LAB 2', 1),
(33, 7, 'HM103', 'Housekeeping Operations', 3, 1, 1, '2026-07-30 16:24:50', 11, 'Wed', '1:00 PM', 'LAB 3', 1),
(34, 7, 'HM104', 'Front Office Management', 3, 1, 1, '2026-07-30 16:24:50', 12, 'Thu', '3:00 PM', 'LAB 4', 1),
(35, 7, 'HM105', 'Culinary Fundamentals', 3, 1, 1, '2026-07-30 16:24:50', 11, 'Fri', '9:00 AM', 'RM 101', 1),
(36, 7, 'HM106', 'Events Management', 3, 1, 1, '2026-07-30 16:24:50', 12, 'Mon', '2:00 PM', 'RM 102', 1),
(37, 8, 'TM101', 'Introduction to Tourism', 3, 1, 1, '2026-07-30 16:24:50', 13, 'Mon', '8:00 AM', 'LAB 1', 1),
(38, 8, 'TM102', 'Tour Operations', 3, 1, 1, '2026-07-30 16:24:50', 14, 'Tue', '10:00 AM', 'LAB 2', 1),
(39, 8, 'TM103', 'Travel Management', 3, 1, 1, '2026-07-30 16:24:50', 13, 'Wed', '1:00 PM', 'LAB 3', 1),
(40, 8, 'TM104', 'Tourism Planning', 3, 1, 1, '2026-07-30 16:24:50', 14, 'Thu', '3:00 PM', 'LAB 4', 1),
(41, 8, 'TM105', 'Cultural Heritage Tourism', 3, 1, 1, '2026-07-30 16:24:50', 13, 'Fri', '9:00 AM', 'RM 101', 1),
(42, 8, 'TM106', 'Sustainable Tourism', 3, 1, 1, '2026-07-30 16:24:50', 14, 'Mon', '2:00 PM', 'RM 102', 1),
(43, 9, 'CRIM101', 'Introduction to Criminology', 3, 1, 1, '2026-07-30 16:24:50', 15, 'Mon', '8:00 AM', 'LAB 1', 0),
(44, 9, 'CRIM102', 'Criminal Law', 3, 1, 1, '2026-07-30 16:24:50', 16, 'Tue', '10:00 AM', 'LAB 2', 1),
(45, 9, 'CRIM103', 'Forensic Science', 3, 1, 1, '2026-07-30 16:24:50', 15, 'Wed', '1:00 PM', 'LAB 3', 1),
(46, 9, 'CRIM104', 'Criminal Investigation', 3, 1, 1, '2026-07-30 16:24:50', 16, 'Thu', '3:00 PM', 'LAB 4', 1),
(47, 9, 'CRIM105', 'Police Organization', 3, 1, 1, '2026-07-30 16:24:50', 15, 'Fri', '9:00 AM', 'RM 101', 1),
(48, 9, 'CRIM106', 'Corrections', 3, 1, 1, '2026-07-30 16:24:50', 16, 'Mon', '2:00 PM', 'RM 102', 1),
(49, 10, 'NURS101', 'Fundamentals of Nursing', 3, 1, 1, '2026-07-30 16:24:50', 17, 'Mon', '8:00 AM', 'LAB 1', 1),
(50, 10, 'NURS102', 'Health Assessment', 3, 1, 1, '2026-07-30 16:24:50', 18, 'Tue', '10:00 AM', 'LAB 2', 1),
(51, 10, 'NURS103', 'Community Health Nursing', 3, 1, 1, '2026-07-30 16:24:50', 17, 'Wed', '1:00 PM', 'LAB 3', 1),
(52, 10, 'NURS104', 'Medical Surgical Nursing', 3, 1, 1, '2026-07-30 16:24:50', 18, 'Thu', '3:00 PM', 'LAB 4', 1),
(53, 10, 'NURS105', 'Pharmacology', 3, 1, 1, '2026-07-30 16:24:50', 17, 'Fri', '9:00 AM', 'RM 101', 1),
(54, 10, 'NURS106', 'Anatomy and Physiology', 3, 1, 1, '2026-07-30 16:24:50', 18, 'Mon', '2:00 PM', 'RM 102', 1),
(55, 15, 'CE101', 'Engineering Mechanics', 3, 1, 1, '2026-07-30 16:24:50', 19, 'Mon', '8:00 AM', 'LAB 1', 1),
(56, 15, 'CE102', 'Surveying', 3, 1, 1, '2026-07-30 16:24:50', 20, 'Tue', '10:00 AM', 'LAB 2', 1),
(57, 15, 'CE103', 'Construction Materials', 3, 1, 1, '2026-07-30 16:24:50', 19, 'Wed', '1:00 PM', 'LAB 3', 1),
(58, 15, 'CE104', 'Structural Theory', 3, 1, 1, '2026-07-30 16:24:50', 20, 'Thu', '3:00 PM', 'LAB 4', 1),
(59, 15, 'CE105', 'Hydraulics', 3, 1, 1, '2026-07-30 16:24:50', 19, 'Fri', '9:00 AM', 'RM 101', 1),
(60, 15, 'CE106', 'Construction Management', 3, 1, 1, '2026-07-30 16:24:50', 20, 'Mon', '2:00 PM', 'RM 102', 1),
(61, 1, 'IT111', 'Introduction to Computing', 3, 1, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(62, 1, 'IT112', 'Programming Fundamentals', 3, 1, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(63, 1, 'IT113', 'Computer Organization', 3, 1, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(64, 1, 'GE101', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(65, 1, 'GE102', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(66, 1, 'PE101', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(67, 1, 'IT121', 'Object-Oriented Programming', 3, 2, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(68, 1, 'IT122', 'Database Fundamentals', 3, 2, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(69, 1, 'IT123', 'Web Development Fundamentals', 3, 2, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(70, 1, 'GE103', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(71, 1, 'GE104', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(72, 1, 'PE102', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(73, 1, 'IT211', 'Data Structures and Algorithms', 3, 1, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(74, 1, 'IT212', 'Database Management Systems', 3, 1, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(75, 1, 'IT213', 'Computer Networking 1', 3, 1, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(76, 1, 'IT214', 'Systems Analysis and Design', 3, 1, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(77, 1, 'GE201', 'Ethics', 3, 1, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(78, 1, 'PE201', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(79, 1, 'IT221', 'Computer Networking 2', 3, 2, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(80, 1, 'IT222', 'Information Management', 3, 2, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(81, 1, 'IT223', 'Human Computer Interaction', 3, 2, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(82, 1, 'IT224', 'Platform Technologies', 3, 2, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(83, 1, 'GE202', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(84, 1, 'PE202', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(85, 1, 'IT311', 'Advanced Database Systems', 3, 1, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(86, 1, 'IT312', 'Software Engineering', 3, 1, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(87, 1, 'IT313', 'Information Assurance and Security', 3, 1, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(88, 1, 'IT314', 'Mobile Application Development', 3, 1, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(89, 1, 'IT315', 'IT Project Management', 3, 1, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(90, 1, 'IT316', 'Web Systems and Technologies', 3, 1, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(91, 1, 'IT321', 'Systems Integration and Architecture', 3, 2, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(92, 1, 'IT322', 'Cloud Computing', 3, 2, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(93, 1, 'IT323', 'Network Security', 3, 2, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(94, 1, 'IT324', 'IT Elective 1', 3, 2, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(95, 1, 'IT325', 'Research Methods in IT', 3, 2, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(96, 1, 'IT326', 'Professional Issues in IT', 3, 2, 3, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(97, 1, 'IT411', 'Capstone Project 1', 3, 1, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(98, 1, 'IT412', 'IT Governance', 3, 1, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(99, 1, 'IT413', 'IT Elective 2', 3, 1, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(100, 1, 'IT414', 'Emerging Technologies', 3, 1, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(101, 1, 'IT415', 'Internship Preparation', 3, 1, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(102, 1, 'IT421', 'Capstone Project 2', 3, 2, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(103, 1, 'IT422', 'IT Elective 3', 3, 2, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(104, 1, 'IT423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:11:54', NULL, NULL, NULL, NULL, 1),
(217, 1, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(218, 1, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(219, 1, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(220, 1, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(221, 1, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(222, 1, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(223, 1, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(224, 1, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(225, 1, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(226, 1, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(232, 2, 'CS111', 'Introduction to Computer Science', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(233, 2, 'CS112', 'Programming Fundamentals', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(234, 2, 'CS113', 'Discrete Mathematics', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(235, 2, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(236, 2, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(237, 2, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(238, 2, 'CS121', 'Object-Oriented Programming', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(239, 2, 'CS122', 'Data Structures', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(240, 2, 'CS123', 'Computer Organization', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(241, 2, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(242, 2, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(243, 2, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(244, 2, 'CS211', 'Algorithms and Complexity', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(245, 2, 'CS212', 'Database Systems', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(246, 2, 'CS213', 'Computer Architecture', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(247, 2, 'CS214', 'Operating Systems', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(248, 2, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(249, 2, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(250, 2, 'CS221', 'Software Engineering', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(251, 2, 'CS222', 'Theory of Computation', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(252, 2, 'CS223', 'Artificial Intelligence', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(253, 2, 'CS224', 'Computer Networks', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(254, 2, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(255, 2, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(256, 2, 'CS311', 'Artificial Intelligence 2', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(257, 2, 'CS312', 'Machine Learning', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(258, 2, 'CS313', 'Web Technologies', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(259, 2, 'CS314', 'Information Security', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(260, 2, 'CS315', 'Research Methods', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(261, 2, 'CS316', 'CS Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(262, 2, 'CS321', 'Data Mining', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(263, 2, 'CS322', 'Compiler Design', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(264, 2, 'CS323', 'Distributed Computing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(265, 2, 'CS324', 'CS Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(266, 2, 'CS325', 'Mobile Computing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(267, 2, 'CS326', 'Software Project Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(268, 2, 'CS411', 'Thesis 1', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(269, 2, 'CS412', 'Advanced Algorithms', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(270, 2, 'CS413', 'CS Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(271, 2, 'CS414', 'Emerging Computing Technologies', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(272, 2, 'CS415', 'Professional Practice', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(273, 2, 'CS421', 'Thesis 2', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(274, 2, 'CS422', 'CS Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(275, 2, 'CS423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(295, 3, 'IS111', 'Information Systems Fundamentals', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(296, 3, 'IS112', 'Introduction to Programming', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(297, 3, 'IS113', 'Business Mathematics', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(298, 3, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(299, 3, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(300, 3, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(301, 3, 'IS121', 'Programming for Information Systems', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(302, 3, 'IS122', 'Database Management', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(303, 3, 'IS123', 'Business Process Management', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(304, 3, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(305, 3, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(306, 3, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(307, 3, 'IS211', 'Systems Analysis and Design', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(308, 3, 'IS212', 'Data Structures', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(309, 3, 'IS213', 'Enterprise Architecture', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(310, 3, 'IS214', 'IT Infrastructure', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(311, 3, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(312, 3, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(313, 3, 'IS221', 'Web Information Systems', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(314, 3, 'IS222', 'Information Security', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(315, 3, 'IS223', 'Systems Integration', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(316, 3, 'IS224', 'IT Project Management', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(317, 3, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(318, 3, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(319, 3, 'IS311', 'Business Intelligence', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(320, 3, 'IS312', 'Data Analytics', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(321, 3, 'IS313', 'Information Assurance', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(322, 3, 'IS314', 'Research Methods', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(323, 3, 'IS315', 'IS Project Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(324, 3, 'IS316', 'IS Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(325, 3, 'IS321', 'Enterprise Systems', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(326, 3, 'IS322', 'Cloud Information Systems', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(327, 3, 'IS323', 'IT Governance', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(328, 3, 'IS324', 'IS Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(329, 3, 'IS325', 'Digital Transformation', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(330, 3, 'IS326', 'Professional Practice', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(331, 3, 'IS411', 'Capstone Project 1', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(332, 3, 'IS412', 'Strategic Information Systems', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(333, 3, 'IS413', 'IS Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(334, 3, 'IS414', 'Emerging Technologies', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(335, 3, 'IS415', 'Information Systems Audit', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(336, 3, 'IS421', 'Capstone Project 2', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(337, 3, 'IS422', 'IS Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(338, 3, 'IS423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(358, 5, 'BA111', 'Principles of Management', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(359, 5, 'BA112', 'Business Organization', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(360, 5, 'BA113', 'Financial Accounting', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(361, 5, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(362, 5, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(363, 5, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(364, 5, 'BA121', 'Marketing Management', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(365, 5, 'BA122', 'Business Statistics', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(366, 5, 'BA123', 'Microeconomics', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(367, 5, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(368, 5, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(369, 5, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(370, 5, 'BA211', 'Human Resource Management', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(371, 5, 'BA212', 'Operations Management', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(372, 5, 'BA213', 'Business Finance', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(373, 5, 'BA214', 'Business Law', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(374, 5, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(375, 5, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(376, 5, 'BA221', 'Entrepreneurship', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(377, 5, 'BA222', 'Consumer Behavior', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(378, 5, 'BA223', 'Management Information Systems', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(379, 5, 'BA224', 'Strategic Management', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(380, 5, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(381, 5, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(382, 5, 'BA311', 'Business Research', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(383, 5, 'BA312', 'Investment Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(384, 5, 'BA313', 'International Business', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(385, 5, 'BA314', 'Organizational Behavior', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(386, 5, 'BA315', 'Business Analytics', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(387, 5, 'BA316', 'Business Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(388, 5, 'BA321', 'Strategic Marketing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(389, 5, 'BA322', 'Financial Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(390, 5, 'BA323', 'Supply Chain Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(391, 5, 'BA324', 'Business Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(392, 5, 'BA325', 'Corporate Governance', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(393, 5, 'BA326', 'Professional Development', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(394, 5, 'BA411', 'Business Strategy', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(395, 5, 'BA412', 'Management Consulting', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(396, 5, 'BA413', 'Business Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(397, 5, 'BA414', 'Research Project 1', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(398, 5, 'BA415', 'Business Ethics', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(399, 5, 'BA421', 'Research Project 2', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(400, 5, 'BA422', 'Business Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(401, 5, 'BA423', 'Practicum / Internship', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(421, 6, 'AC111', 'Fundamentals of Accounting', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(422, 6, 'AC112', 'Accounting Principles', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(423, 6, 'AC113', 'Business Mathematics', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(424, 6, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(425, 6, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(426, 6, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(427, 6, 'AC121', 'Financial Accounting', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(428, 6, 'AC122', 'Managerial Accounting', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(429, 6, 'AC123', 'Business Law', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(430, 6, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(431, 6, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(432, 6, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(433, 6, 'AC211', 'Intermediate Accounting 1', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(434, 6, 'AC212', 'Cost Accounting', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(435, 6, 'AC213', 'Taxation', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(436, 6, 'AC214', 'Accounting Information Systems', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(437, 6, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(438, 6, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(439, 6, 'AC221', 'Intermediate Accounting 2', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(440, 6, 'AC222', 'Auditing Principles', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(441, 6, 'AC223', 'Advanced Accounting', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(442, 6, 'AC224', 'Financial Management', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(443, 6, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(444, 6, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(445, 6, 'AC311', 'Intermediate Accounting 3', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(446, 6, 'AC312', 'Auditing Theory', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(447, 6, 'AC313', 'Government Accounting', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(448, 6, 'AC314', 'Accounting Research', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(449, 6, 'AC315', 'Financial Reporting', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(450, 6, 'AC316', 'Accounting Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(451, 6, 'AC321', 'Advanced Auditing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(452, 6, 'AC322', 'Strategic Cost Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(453, 6, 'AC323', 'Corporate Accounting', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(454, 6, 'AC324', 'Accounting Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(455, 6, 'AC325', 'Professional Accounting Practice', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(456, 6, 'AC326', 'Accounting Ethics', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(457, 6, 'AC411', 'Advanced Financial Accounting', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(458, 6, 'AC412', 'Advanced Taxation', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(459, 6, 'AC413', 'Accounting Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(460, 6, 'AC414', 'Auditing Applications', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(461, 6, 'AC415', 'Accounting Research Project', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(462, 6, 'AC421', 'Accounting Practicum', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(463, 6, 'AC422', 'Accounting Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(464, 6, 'AC423', 'Professional Practice', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(484, 7, 'HM111', 'Introduction to Hospitality Management', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(485, 7, 'HM112', 'Food and Beverage Service', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(486, 7, 'HM113', 'Kitchen Fundamentals', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(487, 7, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(488, 7, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(489, 7, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(490, 7, 'HM121', 'Housekeeping Operations', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(491, 7, 'HM122', 'Front Office Operations', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(492, 7, 'HM123', 'Hospitality Accounting', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(493, 7, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(494, 7, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(495, 7, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(496, 7, 'HM211', 'Culinary Arts', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(497, 7, 'HM212', 'Beverage Management', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(498, 7, 'HM213', 'Hotel Operations', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(499, 7, 'HM214', 'Hospitality Marketing', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(500, 7, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(501, 7, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(502, 7, 'HM221', 'Event Management', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(503, 7, 'HM222', 'Resort Management', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(504, 7, 'HM223', 'Hospitality Technology', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(505, 7, 'HM224', 'Food Safety and Sanitation', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(506, 7, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(507, 7, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(508, 7, 'HM311', 'Hospitality Research', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(509, 7, 'HM312', 'Restaurant Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(510, 7, 'HM313', 'Rooms Division Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(511, 7, 'HM314', 'Hospitality Entrepreneurship', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(512, 7, 'HM315', 'Revenue Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(513, 7, 'HM316', 'HM Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(514, 7, 'HM321', 'International Hospitality', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(515, 7, 'HM322', 'Quality Management in Hospitality', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(516, 7, 'HM323', 'Sustainable Hospitality', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(517, 7, 'HM324', 'HM Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(518, 7, 'HM325', 'Hospitality Leadership', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(519, 7, 'HM326', 'Professional Development', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(520, 7, 'HM411', 'Hospitality Strategic Management', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(521, 7, 'HM412', 'Hospitality Research Project', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(522, 7, 'HM413', 'HM Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(523, 7, 'HM414', 'Advanced Culinary Management', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(524, 7, 'HM415', 'Hospitality Law', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(525, 7, 'HM421', 'HM Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(526, 7, 'HM422', 'Hospitality Practicum', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(527, 7, 'HM423', 'Professional Practice', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(547, 8, 'TM111', 'Introduction to Tourism', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(548, 8, 'TM112', 'Tourism Industry', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(549, 8, 'TM113', 'Travel Geography', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(550, 8, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(551, 8, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(552, 8, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(553, 8, 'TM121', 'Tour Operations', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(554, 8, 'TM122', 'Travel Agency Management', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(555, 8, 'TM123', 'Tourism Marketing', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(556, 8, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(557, 8, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(558, 8, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(559, 8, 'TM211', 'Destination Management', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(560, 8, 'TM212', 'Tourism Planning', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(561, 8, 'TM213', 'Tourism Economics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(562, 8, 'TM214', 'Transportation Management', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(563, 8, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(564, 8, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(565, 8, 'TM221', 'Event Tourism', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(566, 8, 'TM222', 'Cultural Heritage Tourism', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(567, 8, 'TM223', 'Sustainable Tourism', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(568, 8, 'TM224', 'Tourism Technology', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(569, 8, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(570, 8, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(571, 8, 'TM311', 'Tourism Research', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(572, 8, 'TM312', 'Ecotourism', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(573, 8, 'TM313', 'Hospitality and Tourism Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(574, 8, 'TM314', 'Tourism Entrepreneurship', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(575, 8, 'TM315', 'Tourism Policy and Planning', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(576, 8, 'TM316', 'Tourism Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(577, 8, 'TM321', 'International Tourism', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(578, 8, 'TM322', 'Cruise Tourism', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(579, 8, 'TM323', 'Adventure Tourism', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(580, 8, 'TM324', 'Tourism Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(581, 8, 'TM325', 'Tourism Event Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(582, 8, 'TM326', 'Professional Development', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(583, 8, 'TM411', 'Tourism Strategic Management', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(584, 8, 'TM412', 'Tourism Research Project', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(585, 8, 'TM413', 'Tourism Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(586, 8, 'TM414', 'Destination Marketing', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(587, 8, 'TM415', 'Tourism Law', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(588, 8, 'TM421', 'Tourism Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(589, 8, 'TM422', 'Tourism Practicum', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(590, 8, 'TM423', 'Professional Practice', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(610, 9, 'CR111', 'Introduction to Criminology', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(611, 9, 'CR112', 'Criminal Law', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(612, 9, 'CR113', 'Philippine Criminal Justice System', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(613, 9, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(614, 9, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(615, 9, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(616, 9, 'CR121', 'Criminal Investigation', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(617, 9, 'CR122', 'Forensic Science', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(618, 9, 'CR123', 'Police Organization', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(619, 9, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(620, 9, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(621, 9, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(622, 9, 'CR211', 'Criminal Procedure', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(623, 9, 'CR212', 'Correctional Administration', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(624, 9, 'CR213', 'Criminal Sociology', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(625, 9, 'CR214', 'Juvenile Delinquency', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(626, 9, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(627, 9, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(628, 9, 'CR221', 'Crime Detection', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(629, 9, 'CR222', 'Criminal Psychology', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(630, 9, 'CR223', 'Victimology', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(631, 9, 'CR224', 'Community-Based Corrections', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(632, 9, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(633, 9, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(634, 9, 'CR311', 'Criminalistics', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(635, 9, 'CR312', 'Questioned Documents', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(636, 9, 'CR313', 'Forensic Photography', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(637, 9, 'CR314', 'Criminological Research', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(638, 9, 'CR315', 'Crime Prevention', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(639, 9, 'CR316', 'Criminology Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(640, 9, 'CR321', 'Advanced Criminal Investigation', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(641, 9, 'CR322', 'Cybercrime Investigation', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(642, 9, 'CR323', 'Organized Crime', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(643, 9, 'CR324', 'Criminology Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(644, 9, 'CR325', 'Security Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(645, 9, 'CR326', 'Professional Practice', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(646, 9, 'CR411', 'Criminological Research Project 1', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(647, 9, 'CR412', 'Advanced Forensic Science', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(648, 9, 'CR413', 'Criminology Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(649, 9, 'CR414', 'Criminal Justice Administration', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(650, 9, 'CR415', 'Professional Ethics', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(651, 9, 'CR421', 'Criminological Research Project 2', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(652, 9, 'CR422', 'Criminology Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(653, 9, 'CR423', 'Criminology Practicum', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(673, 10, 'NURS111', 'Fundamentals of Nursing', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(674, 10, 'NURS112', 'Health Assessment', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(675, 10, 'NURS113', 'Anatomy and Physiology', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(676, 10, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(677, 10, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(678, 10, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(679, 10, 'NURS121', 'Community Health Nursing', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(680, 10, 'NURS122', 'Nutrition and Diet Therapy', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(681, 10, 'NURS123', 'Pharmacology', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(682, 10, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(683, 10, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(684, 10, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(685, 10, 'NURS211', 'Medical Surgical Nursing 1', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(686, 10, 'NURS212', 'Maternal and Child Nursing', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(687, 10, 'NURS213', 'Pathophysiology', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(688, 10, 'NURS214', 'Nursing Informatics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(689, 10, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(690, 10, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(691, 10, 'NURS221', 'Medical Surgical Nursing 2', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(692, 10, 'NURS222', 'Mental Health Nursing', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(693, 10, 'NURS223', 'Pediatric Nursing', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(694, 10, 'NURS224', 'Nursing Research', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(695, 10, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(696, 10, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(697, 10, 'NURS311', 'Medical Surgical Nursing 3', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(698, 10, 'NURS312', 'Critical Care Nursing', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(699, 10, 'NURS313', 'Community Health Nursing 2', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(700, 10, 'NURS314', 'Nursing Leadership', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(701, 10, 'NURS315', 'Nursing Research 2', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(702, 10, 'NURS316', 'Nursing Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(703, 10, 'NURS321', 'Emergency Nursing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(704, 10, 'NURS322', 'Gerontological Nursing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(705, 10, 'NURS323', 'Oncology Nursing', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(706, 10, 'NURS324', 'Nursing Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(707, 10, 'NURS325', 'Nursing Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(708, 10, 'NURS326', 'Professional Nursing Practice', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(709, 10, 'NURS411', 'Advanced Nursing Practice', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(710, 10, 'NURS412', 'Nursing Research Project', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(711, 10, 'NURS413', 'Nursing Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(712, 10, 'NURS414', 'Health Policy and Administration', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(713, 10, 'NURS415', 'Professional Nursing Ethics', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(714, 10, 'NURS421', 'Nursing Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(715, 10, 'NURS422', 'Clinical Practicum', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(716, 10, 'NURS423', 'Professional Practice', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(736, 15, 'CE111', 'Engineering Mathematics 1', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(737, 15, 'CE112', 'Engineering Drawing', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(738, 15, 'CE113', 'Engineering Mechanics', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(739, 15, 'GE111', 'Purposive Communication', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(740, 15, 'GE112', 'Mathematics in the Modern World', 3, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(741, 15, 'PE111', 'Physical Education 1', 2, 1, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(742, 15, 'CE121', 'Engineering Mathematics 2', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(743, 15, 'CE122', 'Computer Aided Design', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(744, 15, 'CE123', 'Surveying', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(745, 15, 'GE113', 'Understanding the Self', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(746, 15, 'GE114', 'Readings in Philippine History', 3, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(747, 15, 'PE112', 'Physical Education 2', 2, 2, 1, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(748, 15, 'CE211', 'Structural Theory 1', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(749, 15, 'CE212', 'Construction Materials', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(750, 15, 'CE213', 'Fluid Mechanics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(751, 15, 'CE214', 'Engineering Statistics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(752, 15, 'GE211', 'Ethics', 3, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(753, 15, 'PE211', 'Physical Education 3', 2, 1, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(754, 15, 'CE221', 'Structural Theory 2', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(755, 15, 'CE222', 'Soil Mechanics', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(756, 15, 'CE223', 'Hydraulics', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(757, 15, 'CE224', 'Highway Engineering', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1);
INSERT INTO `subjects` (`id`, `course_id`, `subject_code`, `subject_name`, `units`, `sem`, `year_level`, `created`, `section_id`, `schedule_day`, `schedule_time`, `room_number`, `is_available`) VALUES
(758, 15, 'GE212', 'Science, Technology and Society', 3, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(759, 15, 'PE212', 'Physical Education 4', 2, 2, 2, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(760, 15, 'CE311', 'Reinforced Concrete Design', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(761, 15, 'CE312', 'Steel Design', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(762, 15, 'CE313', 'Foundation Engineering', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(763, 15, 'CE314', 'Construction Management', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(764, 15, 'CE315', 'Engineering Research', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(765, 15, 'CE316', 'Civil Engineering Elective 1', 3, 1, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(766, 15, 'CE321', 'Transportation Engineering', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(767, 15, 'CE322', 'Water Resources Engineering', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(768, 15, 'CE323', 'Environmental Engineering', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(769, 15, 'CE324', 'Civil Engineering Elective 2', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(770, 15, 'CE325', 'Project Management', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(771, 15, 'CE326', 'Professional Practice', 3, 2, 3, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(772, 15, 'CE411', 'Advanced Structural Design', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(773, 15, 'CE412', 'Advanced Foundation Engineering', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(774, 15, 'CE413', 'Civil Engineering Elective 3', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(775, 15, 'CE414', 'Engineering Economics', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(776, 15, 'CE415', 'Civil Engineering Research', 3, 1, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(777, 15, 'CE421', 'Civil Engineering Elective 4', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(778, 15, 'CE422', 'Civil Engineering Practicum', 6, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1),
(779, 15, 'CE423', 'Professional Practice', 3, 2, 4, '2026-08-21 05:20:23', NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin','cashier','student') DEFAULT 'student',
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `curriculum`
--
ALTER TABLE `curriculum`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_curriculum_subject` (`course_id`,`subject_id`,`year_level`,`semester`),
  ADD KEY `idx_curriculum_lookup` (`course_id`,`year_level`,`semester`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `enrollment_details`
--
ALTER TABLE `enrollment_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `enrollment_id` (`enrollment_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `fk_students_section` (`section_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `curriculum`
--
ALTER TABLE `curriculum`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `enrollment_details`
--
ALTER TABLE `enrollment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=799;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `enrollment_details`
--
ALTER TABLE `enrollment_details`
  ADD CONSTRAINT `enrollment_details_ibfk_1` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`id`),
  ADD CONSTRAINT `enrollment_details_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `sections_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
