<?php
require_once __DIR__ . '/session_security.php';
require_once __DIR__ . '/enrollment_setup.php';
start_secure_session();
require __DIR__ . '/../db/dbconn.php';

ensure_account_security_schema($conn);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../auth/login.php', true, 303);
    exit;
}

$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');

if ($email === '' || $password === '') {
    header('Location: ../auth/login.php?error=empty', true, 303);
    exit;
}

$stmt = mysqli_prepare(
    $conn,
    "SELECT user_id, full_name, email, password_hash, role_id
     FROM users
     WHERE email = ?
     LIMIT 1"
);

if (!$stmt) {
    header('Location: ../auth/login.php?error=invalid', true, 303);
    exit;
}

mysqli_stmt_bind_param($stmt, 's', $email);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$user || !password_verify($password, (string)$user['password_hash'])) {
    header('Location: ../auth/login.php?error=invalid', true, 303);
    exit;
}

$roleId = (int)($user['role_id'] ?? 0);
$roleMap = [1 => 'admin', 2 => 'teacher', 3 => 'student', 4 => 'cashier'];
$role = $roleMap[$roleId] ?? '';
if ($role === '') {
    header('Location: ../auth/login.php?error=invalid', true, 303);
    exit;
}

session_regenerate_id(true);
$_SESSION['user_id'] = (int)$user['user_id'];
$_SESSION['role_id'] = $roleId;
$_SESSION['fullname'] = (string)$user['full_name'];
$_SESSION['email'] = (string)$user['email'];
$_SESSION['role'] = $role;
session_write_close();

if ($roleId === 1) {
    header('Location: ../admin/admin_dashboard.php', true, 303);
    exit;
}
if ($roleId === 2) {
    header('Location: ../teacher/teacher_dashboard.php', true, 303);
    exit;
}
if ($roleId === 4) {
    header('Location: ../cashier/index.php', true, 303);
    exit;
}
header('Location: ../student/student_dashboard.php', true, 303);
exit;
