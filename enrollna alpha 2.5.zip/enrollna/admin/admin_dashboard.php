<?php

require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();

include '../db/dbconn.php';


/* =========================================================
   DASHBOARD COUNTS
========================================================= */

$students = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        'SELECT COUNT(*) total FROM students'
    )
)['total'];


$courses = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        'SELECT COUNT(*) total FROM courses'
    )
)['total'];


$subjects = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        'SELECT COUNT(*) total FROM subjects'
    )
)['total'];


$enrollments = (int) mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        'SELECT COUNT(*) total FROM enrollments'
    )
)['total'];


/* =========================================================
   PAYMENT / ENROLLMENT COUNTS
========================================================= */

$pendingPayments = (int) (
    mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "SELECT COUNT(*) total
             FROM enrollments
             WHERE payment_status='pending'"
        )
    )['total'] ?? 0
);


$approved = (int) (
    mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "SELECT COUNT(*) total
             FROM enrollments
             WHERE STATUS='approved'"
        )
    )['total'] ?? 0
);


$paid = (int) (
    mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "SELECT COUNT(*) total
             FROM enrollments
             WHERE payment_status='paid'"
        )
    )['total'] ?? 0
);


$sections = (int) (
    mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            'SELECT COUNT(*) total FROM sections'
        )
    )['total'] ?? 0
);


/* =========================================================
   MONTHLY ENROLLMENT DATA — LAST 6 MONTHS
========================================================= */

$monthlyData = [];
$monthLabels = [];

for ($i = 5; $i >= 0; $i--) {

    $ts = strtotime("-$i months");

    $monthLabels[] = date('M Y', $ts);

    $y = date('Y', $ts);
    $m = date('m', $ts);

    $r = mysqli_fetch_assoc(
        mysqli_query(
            $conn,
            "SELECT COUNT(*) total
             FROM enrollments
             WHERE YEAR(created)='$y'
             AND MONTH(created)='$m'"
        )
    );

    $monthlyData[] = (int) ($r['total'] ?? 0);
}


/* =========================================================
   ADMIN NAME
========================================================= */

$adminName = htmlspecialchars(
    $_SESSION['admin_name'] ?? 'Admin'
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard – EYYSAT</title>

    <link
        rel="stylesheet"
        href="../css/admin_dashboard.css">

    <script
        src="https://cdn.jsdelivr.net/npm/chart.js">
    </script>

</head>


<body>


    <!-- =====================================================
     SIDEBAR
===================================================== -->

    <aside
        class="admin-sidebar"
        id="adminSidebar">


        <!-- BRAND -->

        <div class="sidebar-brand">

            <div class="sidebar-logo">

                <img
                    src="../img/eyysat.png"
                    alt="EYYSAT Logo">

            </div>


            <div class="sidebar-brand-text">

                <strong>
                    EYYSAT
                </strong>

                <span>
                    ADMIN PANEL
                </span>

            </div>

        </div>


        <!-- NAVIGATION -->

        <nav class="sidebar-nav">


            <p class="sidebar-label">
                MAIN MENU
            </p>


            <a
                href="admin_dashboard.php"
                class="sidebar-link active">

                <span class="sidebar-icon">
                    &#127968;
                </span>

                <span class="sidebar-text">
                    Dashboard
                </span>

            </a>


            <a
                href="students.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#127891;
                </span>

                <span class="sidebar-text">
                    Students
                </span>

            </a>


            <a
                href="courses.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128218;
                </span>

                <span class="sidebar-text">
                    Courses
                </span>

            </a>


            <a
                href="enrollments.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128214;
                </span>

                <span class="sidebar-text">
                    Enrollments
                </span>

            </a>


            <a
                href="cashier.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128176;
                </span>

                <span class="sidebar-text">
                    Cashier
                </span>

            </a>


            <a
                href="reports.php"
                class="sidebar-link">

                <span class="sidebar-icon">
                    &#128202;
                </span>

                <span class="sidebar-text">
                    Reports
                </span>

            </a>


            <p class="sidebar-label sidebar-label-bottom">
                ACCOUNT
            </p>


            <a
                href="../auth/admin_logout.php"
                class="sidebar-link sidebar-logout">

                <span class="sidebar-icon">
                    &#128682;
                </span>

                <span class="sidebar-text">
                    Logout
                </span>

            </a>

        </nav>


        <!-- PROFILE -->

        <div class="sidebar-profile">

            <div class="profile-avatar">

                <?= strtoupper(
                    substr($adminName, 0, 1)
                ) ?>

            </div>


            <div class="profile-info">

                <strong>
                    <?= $adminName ?>
                </strong>

                <span>
                    Administrator
                </span>

            </div>

        </div>

    </aside>


    <!-- =====================================================
     MOBILE OVERLAY
===================================================== -->

    <div
        class="sidebar-overlay"
        id="sidebarOverlay">
    </div>


    <!-- =====================================================
     MAIN
===================================================== -->

    <main
        class="dashboard-main"
        id="dashboardMain">


        <!-- =================================================
         SIDEBAR TOGGLE
    ================================================== -->

        <button
            class="sidebar-toggle"
            id="sidebarToggle"
            type="button"
            aria-label="Toggle sidebar">
        </button>


        <!-- =================================================
         TOP HEADER
    ================================================== -->

        <header class="dashboard-topbar">

            <div>

                <span class="topbar-label">
                    ADMINISTRATION
                </span>

                <h2>
                    Dashboard
                </h2>

            </div>

        </header>


        <!-- =================================================
         HERO
    ================================================== -->

        <section class="hero">


            <div class="welcome">

                <span class="hero-badge">
                    📊 Dashboard Overview
                </span>


                <h1>

                    Welcome back,

                    <span class="accent">
                        <?= $adminName ?>
                    </span>

                </h1>


                <p>
                    Enrollment Management System —
                    real-time overview of all activity.
                </p>


                <div class="hero-big-stat">

                    <h2
                        class="count-up"
                        data-target="<?= $students ?>">
                        0
                    </h2>

                    <span>
                        Total Students Registered
                    </span>

                </div>

            </div>


            <!-- MINI STATS -->

            <div class="hero-stats">


                <div class="mini-stat">

                    <h3>
                        Courses
                    </h3>

                    <span
                        class="count-up"
                        data-target="<?= $courses ?>">

                        <?= $courses ?>

                    </span>

                </div>


                <div class="mini-stat">

                    <h3>
                        Subjects
                    </h3>

                    <span
                        class="count-up"
                        data-target="<?= $subjects ?>">

                        <?= $subjects ?>

                    </span>

                </div>


                <div class="mini-stat">

                    <h3>
                        Enrollments
                    </h3>

                    <span
                        class="count-up"
                        data-target="<?= $enrollments ?>">

                        <?= $enrollments ?>

                    </span>

                </div>

            </div>

        </section>


        <!-- =================================================
         QUICK STATS
    ================================================== -->

        <section class="stats-row">


            <div class="stat-card stat-warning">

                <div class="stat-icon">
                    ⏳
                </div>

                <h3>
                    Pending Payments
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $pendingPayments ?>">

                    <?= $pendingPayments ?>

                </span>

            </div>


            <div class="stat-card stat-success">

                <div class="stat-icon">
                    ✅
                </div>

                <h3>
                    Approved Enrollments
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $approved ?>">

                    <?= $approved ?>

                </span>

            </div>


            <div class="stat-card stat-paid">

                <div class="stat-icon">
                    💰
                </div>

                <h3>
                    Fully Paid
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $paid ?>">

                    <?= $paid ?>

                </span>

            </div>


            <div class="stat-card stat-section">

                <div class="stat-icon">
                    🏫
                </div>

                <h3>
                    Sections
                </h3>

                <span
                    class="count-up"
                    data-target="<?= $sections ?>">

                    <?= $sections ?>

                </span>

            </div>

        </section>


        <!-- =================================================
         ANALYTICS
    ================================================== -->

        <section class="analytics-grid">


            <!-- SYSTEM OVERVIEW -->

            <div class="card chart-card">

                <h3>
                    System Overview
                </h3>

                <canvas
                    id="enrollmentChart">
                </canvas>

            </div>


            <!-- MONTHLY ENROLLMENTS -->

            <div class="card chart-card">

                <h3>
                    Monthly Enrollments
                </h3>

                <canvas
                    id="monthlyChart">
                </canvas>

            </div>


            <!-- RECENT ENROLLMENTS -->

            <div class="card recent-card">

                <h3>
                    Recent Enrollments
                </h3>


                <div class="table-wrapper">

                    <table>

                        <thead>

                            <tr>

                                <th>
                                    Student No.
                                </th>

                                <th>
                                    Name
                                </th>

                                <th>
                                    Course
                                </th>

                                <th>
                                    Payment
                                </th>

                                <th>
                                    Status
                                </th>

                            </tr>

                        </thead>


                        <tbody>

                            <?php

                            $recentQuery = mysqli_query(
                                $conn,
                                "
                                SELECT
                                    students.student_number,
                                    students.first_name,
                                    students.last_name,
                                    courses.course_code,
                                    enrollments.payment_status,
                                    enrollments.amount_paid,
                                    enrollments.STATUS

                                FROM enrollments

                                INNER JOIN students
                                    ON enrollments.student_id = students.id

                                LEFT JOIN courses
                                    ON students.course_id = courses.id

                                ORDER BY enrollments.id DESC

                                LIMIT 10
                                "
                            );


                            while (
                                $row =
                                mysqli_fetch_assoc(
                                    $recentQuery
                                )
                            ) {


                                $hasPayment =
                                    (float) (
                                        $row['amount_paid']
                                        ?? 0
                                    ) > 0;


                                $payClass =
                                    (
                                        strtolower(
                                            $row['payment_status']
                                        ) === 'paid'
                                        || $hasPayment
                                    )
                                    ? 'status-paid'
                                    : 'status-pending';


                                $envClass =
                                    strtolower(
                                        $row['STATUS']
                                    ) === 'approved'
                                    ? 'status-approved'
                                    : (
                                        strtolower(
                                            $row['STATUS']
                                        ) === 'rejected'
                                        ? 'status-rejected'
                                        : 'status-pending'
                                    );


                                $enrollmentLabel =
                                    (
                                        strtolower(
                                            $row['STATUS']
                                        ) === 'approved'
                                        &&
                                        (
                                            strtolower(
                                                $row['payment_status']
                                            ) === 'paid'
                                            || $hasPayment
                                        )
                                    )
                                    ? 'Enrolled'
                                    : ucfirst(
                                        $row['STATUS']
                                    );


                                $paymentLabel =
                                    strtolower(
                                        $row['payment_status']
                                    ) === 'paid'
                                    ? 'Fully Paid'
                                    : (
                                        $hasPayment
                                        ? 'Paid'
                                        : ucfirst(
                                            $row['payment_status']
                                        )
                                    );

                            ?>

                                <tr>

                                    <td>

                                        <?= htmlspecialchars(
                                            $row['student_number']
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $row['first_name']
                                                . ' '
                                                . $row['last_name']
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $row['course_code']
                                        ) ?>

                                    </td>


                                    <td>

                                        <span
                                            class="<?= $payClass ?>">

                                            <?= htmlspecialchars(
                                                $paymentLabel
                                            ) ?>

                                        </span>

                                    </td>


                                    <td>

                                        <span
                                            class="<?= $envClass ?>">

                                            <?= htmlspecialchars(
                                                $enrollmentLabel
                                            ) ?>

                                        </span>

                                    </td>

                                </tr>


                            <?php

                            }

                            ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </section>

    </main>


    <!-- =====================================================
     SCROLL TO TOP BUTTON
===================================================== -->

    <button
        class="scroll-top"
        id="scrollTop"
        type="button"
        aria-label="Scroll to top">

        ↑

    </button>


    <!-- =====================================================
     JAVASCRIPT
===================================================== -->

    <script>
        /* =========================================================
           SIDEBAR ELEMENTS
        ========================================================= */

        const sidebar =
            document.getElementById(
                'adminSidebar'
            );

        const sidebarToggle =
            document.getElementById(
                'sidebarToggle'
            );

        const sidebarOverlay =
            document.getElementById(
                'sidebarOverlay'
            );

        const dashboardMain =
            document.getElementById(
                'dashboardMain'
            );


        let sidebarCollapsed = false;


        /* =========================================================
           UPDATE SIDEBAR TOGGLE POSITION
        ========================================================= */

        function updateTogglePosition() {

            if (window.innerWidth <= 768) {

                sidebarToggle.style.left =
                    '18px';

                return;
            }


            if (sidebarCollapsed) {

                sidebarToggle.style.left =
                    '68px';

            } else {

                sidebarToggle.style.left =
                    '246px';

            }

        }


        /* =========================================================
           SIDEBAR TOGGLE
        ========================================================= */

        sidebarToggle.addEventListener(
            'click',
            function() {

                /* MOBILE */

                if (
                    window.innerWidth <= 768
                ) {

                    sidebar.classList.toggle(
                        'mobile-open'
                    );

                    sidebarOverlay.classList.toggle(
                        'show'
                    );

                    return;
                }


                /* DESKTOP */

                sidebarCollapsed = !sidebarCollapsed;


                sidebar.classList.toggle(
                    'collapsed',
                    sidebarCollapsed
                );


                dashboardMain.classList.toggle(
                    'sidebar-collapsed',
                    sidebarCollapsed
                );


                /* CHANGE ARROW */

                sidebarToggle.classList.toggle(
                    'collapsed',
                    sidebarCollapsed
                );


                updateTogglePosition();

            }
        );


        /* =========================================================
           MOBILE OVERLAY
        ========================================================= */

        sidebarOverlay.addEventListener(
            'click',
            function() {

                sidebar.classList.remove(
                    'mobile-open'
                );

                sidebarOverlay.classList.remove(
                    'show'
                );

            }
        );


        /* =========================================================
           MOBILE NAVIGATION
        ========================================================= */

        document
            .querySelectorAll(
                '.sidebar-link'
            )
            .forEach(
                function(link) {

                    link.addEventListener(
                        'click',
                        function() {

                            if (
                                window.innerWidth <= 768
                            ) {

                                sidebar.classList.remove(
                                    'mobile-open'
                                );

                                sidebarOverlay.classList.remove(
                                    'show'
                                );

                            }

                        }
                    );

                }
            );


        /* =========================================================
           RESPONSIVE
        ========================================================= */

        window.addEventListener(
            'resize',
            function() {

                updateTogglePosition();

            }
        );


        updateTogglePosition();


        /* =========================================================
           COUNT UP
        ========================================================= */

        document
            .querySelectorAll(
                '.count-up'
            )
            .forEach(
                function(el) {

                    const target =
                        Number(
                            el.dataset.target
                        );

                    const duration = 1200;

                    const step =
                        target /
                        (duration / 16);

                    let current = 0;


                    const timer =
                        setInterval(
                            function() {

                                current =
                                    Math.min(
                                        current + step,
                                        target
                                    );


                                el.textContent =
                                    Math.floor(
                                        current
                                    ).toLocaleString();


                                if (
                                    current >= target
                                ) {

                                    clearInterval(
                                        timer
                                    );

                                }

                            },
                            16
                        );

                }
            );


        /* =========================================================
           SCROLL TO TOP
        ========================================================= */

        const scrollTopButton =
            document.getElementById(
                'scrollTop'
            );


        window.addEventListener(
            'scroll',
            function() {

                if (
                    window.scrollY > 300
                ) {

                    scrollTopButton.classList.add(
                        'show'
                    );

                } else {

                    scrollTopButton.classList.remove(
                        'show'
                    );

                }

            }
        );


        /* =========================================================
           SCROLL TO TOP CLICK
        ========================================================= */

        scrollTopButton.addEventListener(
            'click',
            function() {

                window.scrollTo({

                    top: 0,

                    behavior: 'smooth'

                });

            }
        );


        /* =========================================================
           DOUGHNUT CHART
        ========================================================= */

        new Chart(
            document.getElementById(
                'enrollmentChart'
            ), {

                type: 'doughnut',

                data: {

                    labels: [
                        'Students',
                        'Courses',
                        'Subjects',
                        'Enrollments'
                    ],

                    datasets: [{

                        data: [

                            <?= $students ?>,
                            <?= $courses ?>,
                            <?= $subjects ?>,
                            <?= $enrollments ?>

                        ],

                        backgroundColor: [

                            '#f4d35e',
                            '#1e5a96',
                            '#3b82f6',
                            '#f39c12'

                        ],

                        borderWidth: 0,

                        hoverOffset: 10

                    }]

                },

                options: {

                    responsive: true,

                    cutout: '65%',

                    plugins: {

                        legend: {

                            labels: {

                                color: 'white',

                                font: {
                                    size: 13
                                }

                            }

                        }

                    }

                }

            }
        );


        /* =========================================================
           MONTHLY BAR CHART
        ========================================================= */

        new Chart(
            document.getElementById(
                'monthlyChart'
            ), {

                type: 'bar',

                data: {

                    labels: <?= json_encode(
                                $monthLabels
                            ) ?>,

                    datasets: [{

                        label: 'Enrollments',

                        data: <?= json_encode(
                                    $monthlyData
                                ) ?>,

                        backgroundColor: 'rgba(244, 211, 94, 0.75)',

                        borderColor: '#f4d35e',

                        borderWidth: 1,

                        borderRadius: 6

                    }]

                },

                options: {

                    responsive: true,

                    plugins: {

                        legend: {

                            labels: {
                                color: 'white'
                            }

                        }

                    },

                    scales: {

                        x: {

                            ticks: {
                                color: '#a1a1aa'
                            },

                            grid: {
                                color: 'rgba(255,255,255,0.05)'
                            }

                        },

                        y: {

                            ticks: {

                                color: '#a1a1aa',

                                stepSize: 1

                            },

                            grid: {

                                color: 'rgba(255,255,255,0.05)'

                            },

                            beginAtZero: true

                        }

                    }

                }

            }
        );


        /* =========================================================
           PREVENT CACHED PAGE AFTER LOGOUT
        ========================================================= */

        window.addEventListener(
            'pageshow',
            function(e) {

                if (e.persisted) {

                    window.location.reload();

                }

            }
        );
    </script>


</body>

</html>
