<?php
require_once __DIR__ . '/../functions/student_auth.php';
start_student_session();
require __DIR__ . '/../db/dbconn.php';

if (($_SESSION['role'] ?? '') !== 'student' || empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php?loginredirect=1', true, 303);
    exit;
}

$enrollmentId = (int) ($_GET['enrollment_id'] ?? 0);
$stmt = mysqli_prepare($conn, '
    SELECT e.id, e.payment_method, e.payment_reference, e.payment_account,
           e.cash_amount_requested, e.amount_paid, e.payment_status,
           e.status, e.created, s.first_name, s.last_name, s.student_number,
           s.email, c.course_code, c.course_name
    FROM enrollments e
    INNER JOIN students s ON s.id = e.student_id
    LEFT JOIN courses c ON c.id = e.course_id
    WHERE e.id = ? AND s.user_id = ?
    LIMIT 1
');
$userId = (int) $_SESSION['user_id'];
mysqli_stmt_bind_param($stmt, 'ii', $enrollmentId, $userId);
mysqli_stmt_execute($stmt);
$receipt = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$receipt) {
    http_response_code(404);
    exit('Payment receipt not found.');
}

function payment_receipt_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$method = strtolower((string) ($receipt['payment_method'] ?? ''));
$methodLabel = $method === 'gcash' ? 'GCash' : 'Cash / Over-the-counter';
$amountSubmitted = (float) ($receipt['cash_amount_requested'] ?? 0);
$amountPaid = (float) ($receipt['amount_paid'] ?? 0);
$isPaid = strtolower((string) ($receipt['payment_status'] ?? '')) === 'paid';
$receiptNumber = 'PAY-' . str_pad((string) $receipt['id'], 8, '0', STR_PAD_LEFT);
$dateSubmitted = !empty($receipt['created']) ? date('M d, Y • h:i A', strtotime($receipt['created'])) : '—';
$amount = $isPaid && $amountPaid > 0 ? $amountPaid : $amountSubmitted;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Payment Receipt | EYYSAT</title>
<link href="../css/bootstrap.css" rel="stylesheet">
<style>
:root{--blue:#3b82f6;--blue-dark:#2563eb;--navy:#0f172a;--text:#1e293b;--muted:#64748b;--line:#e2e8f0;--soft:#f8fafc;--pending:#d97706;--pending-bg:#fffbeb;--paid:#15803d;--paid-bg:#ecfdf3}
*{box-sizing:border-box}
html,body{min-height:100%;margin:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background:#0f172a;color:var(--text);padding:20px;display:flex;justify-content:center;align-items:center}
.page{width:100%;max-width:700px}
.receipt-modal{background:#fff;border-radius:12px;width:100%;box-shadow:0 25px 50px -12px rgba(0,0,0,.5);overflow:hidden}
.modal-header{padding:24px 30px;border-bottom:1px solid var(--line);position:relative;padding-right:70px}
.modal-header h2{margin:0 0 5px;font-size:22px;color:var(--navy)}
.modal-header p{margin:0;color:var(--muted);font-size:14px}
.close-btn{position:absolute;top:20px;right:20px;background:#f1f5f9;border:0;border-radius:6px;width:32px;height:32px;font-size:20px;line-height:1;cursor:pointer;color:var(--muted);display:grid;place-items:center;text-decoration:none}
.close-btn:hover{background:#e2e8f0;color:var(--navy)}
.receipt-body{padding:30px}
.brand-bar{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid var(--line);padding-bottom:20px;margin-bottom:20px}
.brand-logo{display:flex;align-items:center;gap:10px;font-weight:700;color:var(--navy);font-size:18px;min-width:0}
.brand-logo img{width:48px;height:48px;object-fit:cover;border-radius:50%;background:#0f172a;border:3px solid #f4d35e;padding:0;flex:0 0 auto;display:block}
.brand-sub{font-size:12px;color:var(--muted);font-weight:400;margin-top:2px}
.receipt-title-row{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:20px}
.receipt-title h3{margin:0;font-size:18px;color:var(--text)}
.receipt-title p{margin:4px 0 0;font-size:14px;color:var(--muted)}
.receipt-no{text-align:right;flex:0 0 auto}.receipt-no label{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:600;display:block}.receipt-no span{font-size:15px;font-weight:700;color:var(--blue)}
.status-alert{background:<?= $isPaid ? '#ecfdf3' : '#fffbeb' ?>;border:1px solid <?= $isPaid ? '#bbf7d0' : '#fde68a' ?>;border-left:4px solid <?= $isPaid ? '#22c55e' : '#f59e0b' ?>;padding:16px;border-radius:6px;margin-bottom:24px}
.status-alert h4{margin:0 0 5px;color:<?= $isPaid ? '#166534' : '#92400e' ?>;font-size:14px;display:flex;align-items:center;gap:8px}.status-alert p{margin:0;color:<?= $isPaid ? '#15803d' : '#b45309' ?>;font-size:13px}
.amount-section{margin-bottom:30px}.amount-section label{font-size:12px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;display:block;margin-bottom:4px}.amount-value{font-size:32px;font-weight:800;color:var(--navy);overflow-wrap:anywhere}
.section-title{font-size:13px;font-weight:700;color:var(--navy);border-bottom:1px solid var(--line);padding-bottom:8px;margin:10px 0 20px;text-transform:uppercase}
.details-list{display:flex;flex-direction:column;gap:12px;margin-bottom:30px}.detail-row{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;border-bottom:1px dashed var(--line);padding-bottom:8px}.detail-row:last-child{border-bottom:0}.detail-label{font-size:14px;color:var(--muted);font-weight:500;flex:0 0 40%}.detail-value{font-size:14px;color:var(--navy);font-weight:600;text-align:right;overflow-wrap:anywhere;min-width:0}
.receipt-footer{text-align:center;font-size:12px;color:#94a3b8;margin-top:10px;line-height:1.6}
.modal-footer{padding:20px 30px;background:var(--soft);border-top:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap}.buttons{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-left:auto}.btn{padding:10px 16px;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer;border:1px solid transparent;transition:all .2s;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;min-height:42px}.btn-secondary{background:#fff;border-color:#cbd5e1;color:#334155}.btn-secondary:hover{background:#f1f5f9}.btn-primary{background:var(--blue);color:#fff;box-shadow:0 2px 4px rgba(59,130,246,.2)}.btn-primary:hover{background:var(--blue-dark)}
@media(max-width:600px){body{padding:10px;align-items:flex-start}.page{max-width:100%}.modal-header{padding:20px 55px 18px 20px}.modal-header h2{font-size:19px}.modal-header p{font-size:13px;line-height:1.45}.receipt-body{padding:20px}.brand-bar{margin-bottom:18px;padding-bottom:16px}.brand-logo{font-size:16px}.brand-logo img{width:42px;height:42px;border-width:2px}.receipt-title-row{flex-direction:column;align-items:flex-start;gap:12px}.receipt-no{text-align:left}.amount-value{font-size:28px}.detail-row{flex-direction:column;gap:4px}.detail-label{flex-basis:auto}.detail-value{text-align:left;width:100%}.modal-footer{padding:16px 20px;flex-direction:column;align-items:stretch}.buttons{width:100%;margin:0;display:grid;grid-template-columns:1fr 1fr}.buttons .btn{width:100%}}
@media(max-width:380px){.buttons{grid-template-columns:1fr}.receipt-body{padding:16px}.brand-logo{align-items:flex-start}.status-alert{padding:13px}.amount-value{font-size:25px}}
@media print{body{background:#fff;padding:0;display:block}.page{max-width:none}.receipt-modal{box-shadow:none;border-radius:0}.modal-header,.modal-footer,.close-btn{display:none}.receipt-body{padding:25px}.status-alert{break-inside:avoid}}
</style>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>
<body>
<div class="page">
  <main class="receipt-modal" role="document">
    <header class="modal-header">
      <h2>Provisional Payment Receipt</h2>
      <p>A complete record of the payment submitted for this enrollment.</p>
      <a href="../webhome.php" class="close-btn" aria-label="Close receipt">&times;</a>
    </header>
    <div class="receipt-body">
      <div class="brand-bar">
        <div class="brand-logo"><img src="../img/eyysat-circle.png" alt="EYYSAT Logo"><div>EYYSAT<div class="brand-sub">Enrollment &amp; Registration Portal</div></div></div>
      </div>
      <div class="receipt-title-row">
        <div class="receipt-title"><h3>Enrollment Payment</h3><p>Payment Receipt</p></div>
        <div class="receipt-no"><label>Receipt No.</label><span><?= payment_receipt_escape($receiptNumber) ?></span></div>
      </div>
      <div class="status-alert">
        <h4><?= $isPaid ? '✓ PAYMENT VERIFIED' : '⚠️ PENDING VERIFICATION' ?></h4>
        <p><?= $isPaid ? 'The cashier has confirmed this payment and it is considered final.' : 'Cashier verification is still required before this payment is considered final.' ?></p>
      </div>
      <div class="amount-section"><label><?= $isPaid ? 'Amount Paid' : 'Amount Submitted' ?></label><div class="amount-value">₱<?= number_format($amount,2) ?></div></div>
      <div class="section-title">Student Information</div>
      <div class="details-list">
        <div class="detail-row"><div class="detail-label">Student Name</div><div class="detail-value"><?= payment_receipt_escape($receipt['first_name'].' '.$receipt['last_name']) ?></div></div>
        <div class="detail-row"><div class="detail-label">Student Number</div><div class="detail-value"><?= payment_receipt_escape($receipt['student_number'] ?? '—') ?></div></div>
        <div class="detail-row"><div class="detail-label">Course</div><div class="detail-value"><?= payment_receipt_escape($receipt['course_code'] ?? '—') ?><?= !empty($receipt['course_name']) ? ' — '.payment_receipt_escape($receipt['course_name']) : '' ?></div></div>
        <div class="detail-row"><div class="detail-label">Email</div><div class="detail-value"><?= payment_receipt_escape($receipt['email'] ?? '—') ?></div></div>
      </div>
      <div class="section-title">Payment Information</div>
      <div class="details-list">
        <div class="detail-row"><div class="detail-label">Payment Method</div><div class="detail-value"><?= payment_receipt_escape($methodLabel) ?></div></div>
        <div class="detail-row"><div class="detail-label">Payer / Account</div><div class="detail-value"><?= payment_receipt_escape($receipt['payment_account'] ?: 'School Cashier / Over-the-counter') ?></div></div>
        <div class="detail-row"><div class="detail-label">Transaction Reference</div><div class="detail-value"><?= payment_receipt_escape($receipt['payment_reference'] ?: 'Not applicable — cash payment') ?></div></div>
        <div class="detail-row"><div class="detail-label">Date Submitted</div><div class="detail-value"><?= payment_receipt_escape($dateSubmitted) ?></div></div>
        <div class="detail-row"><div class="detail-label">Payment Status</div><div class="detail-value"><?= payment_receipt_escape(ucfirst($receipt['payment_status'] ?? 'Pending')) ?></div></div>
        <div class="detail-row"><div class="detail-label">Enrollment Status</div><div class="detail-value"><?= payment_receipt_escape(ucfirst($receipt['status'] ?? 'Pending')) ?></div></div>
      </div>
      <div class="receipt-footer">Thank you for using EYYSAT Enrollment Portal.<br>Enrollment #<?= (int)$receipt['id'] ?></div>
    </div>
    <footer class="modal-footer">
      <div></div>
      <div class="buttons"><button type="button" class="btn btn-secondary" onclick="window.print()">🖨️ Print Receipt</button><a href="../webhome.php" class="btn btn-primary">Back to Dashboard</a></div>
    </footer>
  </main>
</div>
</body>
</html>
