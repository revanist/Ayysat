<?php require __DIR__ . '/teacher_bootstrap.php';
$mid = (int) ($_GET['id'] ?? 0);
$q = mysqli_prepare($conn, "SELECT m.*,a.teacher_id,a.section_id FROM lms_materials m JOIN teaching_assignments a ON a.id=m.assignment_id WHERE m.id=? LIMIT 1");
mysqli_stmt_bind_param($q, 'i', $mid);
mysqli_stmt_execute($q);
$m = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
if (!$m) {
    http_response_code(404);
    exit('File not found.');
}
$allowed = false;
if ((int) $m['teacher_id'] === $teacherId) {
    $allowed = true;
} else {
    $q = mysqli_prepare($conn, "SELECT 1 FROM students WHERE user_id=? AND section_id=? AND enrollment_status='Enrolled' LIMIT 1");
    mysqli_stmt_bind_param($q, 'ii', $teacherId, $m['section_id']);/* teacherId is never a student; student download uses student/lms_download.php */
    mysqli_stmt_execute($q);
}
if (!$allowed) {
    http_response_code(403);
    exit('Access denied.');
}
$path = __DIR__ . '/' . $m['file_path'];
if (!is_file($path)) {
    http_response_code(404);
    exit('File is no longer available.');
}
header('Content-Type: ' . ($m['mime_type'] ?: 'application/octet-stream'));
header('Content-Length: ' . filesize($path));
header('Content-Disposition: attachment; filename="' . str_replace('"', '', $m['file_name']) . '"');
readfile($path);
exit;