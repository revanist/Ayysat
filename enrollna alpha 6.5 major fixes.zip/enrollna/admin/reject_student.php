<?php
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();
require_admin_csrf();
require __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: pending_enrollments.php', true, 303);
    exit;
}

$studentId = (int) ($_POST['student_id'] ?? 0);
if ($studentId < 1) {
    $_SESSION['error'] = 'Invalid student.';
    header('Location: pending_enrollments.php', true, 303);
    exit;
}

$stmt = mysqli_prepare($conn, "UPDATE enrollments SET status = 'Rejected' WHERE student_id = ? AND LOWER(status) IN ('pending','approved')");
mysqli_stmt_bind_param($stmt, 'i', $studentId);
$ok = mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

$_SESSION[$ok ? 'success' : 'error'] = $ok ? 'Enrollment application rejected successfully.' : 'Unable to reject the enrollment application.';
header('Location: pending_enrollments.php', true, 303);
exit;
