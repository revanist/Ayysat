<?php
require_once __DIR__ . '/../functions/teacher_auth.php';

$teacherCurrentPage = basename($_SERVER['PHP_SELF']);
$teacherName = htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['teacher_name'] ?? 'Instructor');

function teacher_sidebar_active(string $file, string $current): string
{
    return $current === $file ? ' active' : '';
}
?>
<aside class="admin-sidebar" id="teacherSidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo"><img src="../img/eyysat-circle.png" alt="EYYSAT Logo"></div>
        <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>INSTRUCTOR PANEL</span></div>
    </div>

    <nav class="sidebar-nav" aria-label="Instructor navigation">
        <p class="sidebar-label">MAIN MENU</p>
        <a href="teacher_dashboard.php" class="sidebar-link<?= teacher_sidebar_active('teacher_dashboard.php', $teacherCurrentPage) ?>">
            <span class="sidebar-icon">&#127968;</span><span class="sidebar-text">Dashboard</span>
        </a>
        <a href="classes.php" class="sidebar-link<?= teacher_sidebar_active('classes.php', $teacherCurrentPage) ?>">
            <span class="sidebar-icon">&#127891;</span><span class="sidebar-text">My Classes</span>
        </a>
        <a href="schedule.php" class="sidebar-link<?= teacher_sidebar_active('schedule.php', $teacherCurrentPage) ?>">
            <span class="sidebar-icon">&#128336;</span><span class="sidebar-text">Schedule</span>
        </a>
        <a href="announcements.php" class="sidebar-link<?= teacher_sidebar_active('announcements.php', $teacherCurrentPage) ?>">
            <span class="sidebar-icon">&#128276;</span><span class="sidebar-text">Announcements</span>
        </a>

        <p class="sidebar-label sidebar-label-bottom">ACADEMIC</p>
        <a href="curriculum.php" class="sidebar-link<?= teacher_sidebar_active('curriculum.php', $teacherCurrentPage) ?>">
            <span class="sidebar-icon">&#128218;</span><span class="sidebar-text">Curriculum</span>
        </a>
        <a href="teacher_profile.php" class="sidebar-link<?= teacher_sidebar_active('teacher_profile.php', $teacherCurrentPage) ?>">
            <span class="sidebar-icon">&#128100;</span><span class="sidebar-text">My Profile</span>
        </a>

        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="../auth/logout.php" class="sidebar-link sidebar-logout">
            <span class="sidebar-icon">&#128682;</span><span class="sidebar-text">Logout</span>
        </a>
    </nav>

    <div class="sidebar-profile">
        <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? $_SESSION['teacher_name'] ?? 'I', 0, 1))) ?></div>
        <div class="profile-info"><strong><?= $teacherName ?></strong><span>Instructor / Professor</span></div>
    </div>
</aside>

<div class="sidebar-overlay" id="teacherSidebarOverlay"></div>
<button class="sidebar-toggle" id="teacherSidebarToggle" type="button" aria-label="Toggle instructor sidebar"></button>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('teacherSidebar');
    const toggle = document.getElementById('teacherSidebarToggle');
    const overlay = document.getElementById('teacherSidebarOverlay');
    const main = document.querySelector('.dashboard-main');
    if (!sidebar || !toggle || !overlay) return;

    function updateTogglePosition() {
        toggle.style.left = window.innerWidth <= 768
            ? '18px'
            : (sidebar.classList.contains('collapsed') ? '68px' : '246px');
    }

    toggle.addEventListener('click', function () {
        if (window.innerWidth <= 768) {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('show');
            return;
        }
        const collapsed = sidebar.classList.toggle('collapsed');
        if (main) main.classList.toggle('sidebar-collapsed', collapsed);
        toggle.classList.toggle('collapsed', collapsed);
        updateTogglePosition();
    });

    overlay.addEventListener('click', function () {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('show');
    });

    document.querySelectorAll('#teacherSidebar .sidebar-link').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('show');
            }
        });
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 768) {
            sidebar.classList.remove('mobile-open');
            overlay.classList.remove('show');
        }
        updateTogglePosition();
    });

    updateTogglePosition();
});
</script>
