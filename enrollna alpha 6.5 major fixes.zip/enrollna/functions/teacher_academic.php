<?php
declare(strict_types=1);
require_once __DIR__.'/teacher_auth.php';
function teacher_class_assignment(mysqli $conn,int $assignmentId,int $teacherId): ?array {
 $q=mysqli_prepare($conn,"SELECT a.*,sub.subject_code,sub.subject_name,sub.units,sub.schedule_day,sub.schedule_time,sub.room_number,sec.section_name,c.course_code,c.course_name FROM teaching_assignments a JOIN subjects sub ON sub.id=a.subject_id JOIN sections sec ON sec.id=a.section_id JOIN courses c ON c.id=sec.course_id WHERE a.id=? AND a.teacher_id=? AND a.status='Active' LIMIT 1");
 mysqli_stmt_bind_param($q,'ii',$assignmentId,$teacherId); mysqli_stmt_execute($q); $r=mysqli_fetch_assoc(mysqli_stmt_get_result($q)); mysqli_stmt_close($q); return $r?:null;
}
function teacher_roster(mysqli $conn,array $class): mysqli_result {
 $q=mysqli_prepare($conn,"SELECT s.id,s.student_number,s.first_name,s.middle_name,s.last_name,s.email,e.STATUS AS enrollment_status FROM students s JOIN enrollments e ON e.student_id=s.id WHERE e.section_id=? AND e.school_year=? AND e.sem=? AND e.STATUS IN ('Approved','Enrolled') ORDER BY s.last_name,s.first_name");
 mysqli_stmt_bind_param($q,'isi',$class['section_id'],$class['school_year'],$class['semester']); mysqli_stmt_execute($q); return mysqli_stmt_get_result($q);
}
function teacher_fullname(array $r): string { return trim($r['first_name'].' '.($r['middle_name']??'').' '.$r['last_name']); }
