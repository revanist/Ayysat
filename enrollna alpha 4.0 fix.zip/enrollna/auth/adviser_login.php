<?php
require_once __DIR__ . '/../functions/teacher_auth.php';
start_teacher_session();
require_once '../db/dbconn.php';
require_once '../functions/teacher_setup.php';
ensure_teacher_schema($conn);

if (!empty($_SESSION['teacher_id'])) {
    header('Location: ../teacher/teacher_dashboard.php', true, 303);
    exit;
}

$error = '';
$success = '';
if (isset($_GET['success']) && $_GET['success'] === 'registered') {
    $success = 'Adviser account created successfully. You may now sign in.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $stmt = mysqli_prepare($conn, 'SELECT id, fullname, email, password FROM teachers WHERE email = ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $teacher = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);

        if ($teacher && password_verify($password, $teacher['password'])) {
            session_regenerate_id(true);
            $_SESSION['teacher_id'] = (int)$teacher['id'];
            $_SESSION['teacher_name'] = $teacher['fullname'];
            $_SESSION['teacher_email'] = $teacher['email'];
            $_SESSION['teacher_csrf_token'] = bin2hex(random_bytes(32));
            header('Location: ../teacher/teacher_dashboard.php', true, 303);
            exit;
        }
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adviser Login | EYYSAT</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/auth.css">
    <script src="../js/sweetalert2.all.min.js"></script>
</head>
<body>
<div class="auth-page">
    <div class="auth-hero">
        <div class="hero-content">
            <span class="hero-badge">Adviser Portal 2026–27</span>
            <h2>Welcome to the EYYSAT Adviser Portal</h2>
            <p>Manage your assigned sections, keep track of students, and share important announcements from one responsive dashboard.</p>
            <div class="hero-points"><span>Section management</span><span>Student monitoring</span><span>Announcements</span></div>
        </div>
    </div>

    <div class="portal-container">
        <div class="portal-header">
            <a href="../webhome.php"><img src="../img/eyysat.png" alt="EYYSAT Logo" class="portal-logo"></a>
            <h1>EYYSAT PORTAL</h1>
            <p>Adviser / Professor Login</p>
        </div>
        <div class="portal-body">
            <form method="POST" action="">
                <div class="form-group"><label>Email Address</label><input type="email" name="email" placeholder="professor@eyysat.edu" autocomplete="email" required></div>
                <div class="form-group"><label>Password</label><input type="password" name="password" placeholder="Enter your password" autocomplete="current-password" required></div>
                <button type="submit" class="btn">Sign In as Adviser</button>
            </form>
            <div class="link">Don't have an adviser account? <a href="adviser_register.php">Register Here</a></div>
            <div class="link" style="margin-top:8px;"><a href="login.php">Student Login</a> &nbsp;·&nbsp; <a href="admin_login.php">Admin Login</a></div>
        </div>
    </div>
</div>
<script>
<?php if ($error !== ''): ?>Swal.fire({icon:'error',text:<?=json_encode($error)?>,confirmButtonText:'Try Again'});<?php endif; ?>
<?php if ($success !== ''): ?>Swal.fire({icon:'success',text:<?=json_encode($success)?>,confirmButtonText:'Continue'});<?php endif; ?>
</script>
</body>
</html>
