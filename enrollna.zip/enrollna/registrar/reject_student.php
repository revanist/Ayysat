<?php
require_once __DIR__ . '/../functions/academic_auth.php';
require_academic_login();
require_academic_csrf();
require __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);
require_once __DIR__ . '/../functions/admin_enrollment.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: pending_enrollments.php', true, 303);
    exit;
}

$studentId = (int)($_POST['student_id'] ?? 0);
try {
    if ($studentId < 1) throw new InvalidArgumentException('Invalid student.');

    $stmt = mysqli_prepare($conn, "SELECT id FROM enrollments WHERE student_id = ? AND STATUS = 'Pending' ORDER BY id DESC LIMIT 1");
    if (!$stmt) throw new RuntimeException('Unable to find pending enrollment.');
    mysqli_stmt_bind_param($stmt, 'i', $studentId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$row) throw new RuntimeException('This student has no pending enrollment.');
    admin_reject_enrollment($conn, (int)$row['id']);
    $_SESSION['success'] = 'Enrollment application rejected successfully.';
} catch (Throwable $e) {
    $_SESSION['error'] = $e->getMessage();
}

header('Location: pending_enrollments.php', true, 303);
exit;
