/* Safe UX helpers: validation feedback + submit protection only. */
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('form').forEach(function(form){
    form.querySelectorAll('input,select,textarea').forEach(function(field){
      if(field.type==='hidden'||field.disabled) return;
      field.addEventListener('input',function(){
        if(field.checkValidity()) field.classList.remove('field-error');
      });
      field.addEventListener('change',function(){
        if(field.checkValidity()) field.classList.remove('field-error');
      });
    });
    form.addEventListener('submit',function(e){
      if(!form.checkValidity()){
        form.querySelectorAll('input,select,textarea').forEach(function(field){
          if(field.type!=='hidden' && !field.checkValidity()) field.classList.add('field-error');
        });
        var first=form.querySelector('.field-error');
        if(first) first.scrollIntoView({behavior:'smooth',block:'center'});
        return;
      }
      if(form.dataset.uxSubmitting==='1'){
        e.preventDefault();
        return;
      }
      form.dataset.uxSubmitting='1';
      var submit=form.querySelector('button[type="submit"],input[type="submit"]');
      if(submit && !submit.dataset.keepText){
        submit.dataset.originalText=submit.innerHTML||submit.value;
        if(submit.tagName==='BUTTON') submit.innerHTML='<span class="spinner-border spinner-border-sm me-1" aria-hidden="true"></span> Processing...';
        submit.disabled=true;
        submit.classList.add('ux-submit-loading');
      }
    });
  });
});
