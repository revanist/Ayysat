<?php
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();

// Admin is intentionally read-only for payment verification. Cashier is the only role
// allowed to confirm payments. Keep this legacy route as a safe compatibility redirect.
$target = 'notifications.php';
if (isset($_GET['review']) || isset($_GET['receipt']) || isset($_GET['confirmed'])) {
    $id = (int)($_GET['review'] ?? $_GET['receipt'] ?? $_GET['confirmed'] ?? 0);
    if ($id > 0) {
        $target = 'payment_transaction.php?id=' . $id;
    }
}
header('Location: ' . $target, true, 303);
exit;
