<?php
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();

require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/student_data.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);
require_once __DIR__ . '/../functions/teacher_setup.php';
ensure_teacher_schema($conn);

$userId = (int) ($_SESSION['user_id'] ?? 0);
$student = get_student_profile($conn, $userId);

if (!$student) {
    http_response_code(404);
    exit('Student profile not found.');
}

$studentId = (int) $student['id'];
$enrollment = get_student_latest_enrollment($conn, $studentId) ?: null;

$subjects = [];
if ($enrollment) {
    $enrollmentId = (int) $enrollment['id'];
    $subjectStmt = mysqli_prepare($conn, "
        SELECT DISTINCT
            sub.id,
            sub.subject_code,
            sub.subject_name,
            COALESCE(cur.units, sub.units) AS units,
            t.full_name AS teacher_name,
            sub.schedule_day,
            sub.schedule_time,
            sub.room_number,
            COALESCE(sec.section_name, ?) AS subject_section
        FROM enrollment_details ed
        INNER JOIN subjects sub ON sub.id = ed.subject_id
        LEFT JOIN curriculum cur
               ON cur.subject_id = sub.id
              AND cur.course_id = ?
        LEFT JOIN sections sec ON sec.id = COALESCE(sub.section_id, ?)
        LEFT JOIN teacher_sections ts ON ts.section_id = COALESCE(sub.section_id, ?)
        LEFT JOIN users t ON t.user_id = ts.teacher_id AND t.role_id = 2
        WHERE ed.enrollment_id = ?
        ORDER BY sub.subject_code ASC
    ");
    $fallbackSection = $student['section_name'] ?? 'Not assigned';
    $courseId = (int) $student['course_id'];
    $sectionId = (int) ($student['section_id'] ?? 0);
    mysqli_stmt_bind_param($subjectStmt, 'siiii', $fallbackSection, $courseId, $sectionId, $sectionId, $enrollmentId);
    mysqli_stmt_execute($subjectStmt);
    $result = mysqli_stmt_get_result($subjectStmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $subjects[] = $row;
    }
    mysqli_stmt_close($subjectStmt);
}

// If no enrollment details were stored yet, show the student's curriculum for the current year/semester.
if (!$subjects && !empty($student['course_id'])) {
    $courseId = (int) $student['course_id'];
    $yearLevel = max(1, (int) ($student['year_level'] ?? 1));
    $semester = max(1, (int) ($enrollment['sem'] ?? 1));
    $sectionId = (int) ($student['section_id'] ?? 0);
    $fallbackSection = $student['section_name'] ?? 'Not assigned';

    $currStmt = mysqli_prepare($conn, "
        SELECT
            sub.id,
            sub.subject_code,
            sub.subject_name,
            cur.units,
            t.full_name AS teacher_name,
            sub.schedule_day,
            sub.schedule_time,
            sub.room_number,
            COALESCE(sec.section_name, ?) AS subject_section
        FROM curriculum cur
        INNER JOIN subjects sub ON sub.id = cur.subject_id
        LEFT JOIN sections sec ON sec.id = COALESCE(sub.section_id, ?)
        LEFT JOIN teacher_sections ts ON ts.section_id = COALESCE(sub.section_id, ?)
        LEFT JOIN users t ON t.user_id = ts.teacher_id AND t.role_id = 2
        WHERE cur.course_id = ?
          AND cur.year_level = ?
          AND cur.semester = ?
          AND sub.is_available = 1
        ORDER BY sub.subject_code ASC
    ");
    mysqli_stmt_bind_param($currStmt, 'siiiii', $fallbackSection, $sectionId, $sectionId, $courseId, $yearLevel, $semester);
    mysqli_stmt_execute($currStmt);
    $result = mysqli_stmt_get_result($currStmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $subjects[] = $row;
    }
    mysqli_stmt_close($currStmt);
}

$totalUnits = 0.0;
foreach ($subjects as $subject) {
    $totalUnits += (float) ($subject['units'] ?? 0);
}

$studentName = htmlspecialchars($_SESSION['fullname'] ?? 'Student');
$schoolYear = $enrollment['school_year'] ?? 'N/A';
$semesterLabel = isset($enrollment['sem']) ? 'Semester ' . (int) $enrollment['sem'] : 'Semester N/A';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Curriculum – EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/student_profile.css">
    <link rel="stylesheet" href="../css/student_dashboard.css">
    <link rel="stylesheet" href="../css/ux-polish.css">
    <script src="../js/ux-polish.js" defer></script>
</head>
<body class="profile-page">
<?php include 'sidebar_layout.php'; ?>
<main class="dashboard-main">
    <header class="dashboard-topbar">
        <div>
            <span class="topbar-label">STUDENT PORTAL</span>
            <h2>My Curriculum</h2>
        </div>
    </header>

    <section class="hero curriculum-hero">
        <div class="welcome">
            <span class="hero-badge">&#128218; Academic Schedule</span>
            <h1><?= htmlspecialchars($student['course_code'] ?? 'Program') ?> <span class="accent">Curriculum</span></h1>
            <p>View your enrolled subjects, faculty assignment, section, class schedule, and room assignments.</p>
        </div>
        <div class="hero-stats">
            <div class="mini-stat"><h3>School Year</h3><span><?= htmlspecialchars($schoolYear) ?></span></div>
            <div class="mini-stat"><h3>Term</h3><span><?= htmlspecialchars($semesterLabel) ?></span></div>
            <div class="mini-stat"><h3>Section</h3><span><?= htmlspecialchars($student['section_name'] ?? 'Pending') ?></span></div>
        </div>
    </section>

    <section class="stats-row curriculum-summary">
        <div class="stat-card stat-success"><div class="stat-icon">&#128214;</div><h3>Subjects</h3><span><?= count($subjects) ?></span></div>
        <div class="stat-card stat-paid"><div class="stat-icon">&#9201;</div><h3>Total Units</h3><span><?= number_format($totalUnits, 1) ?></span></div>
        <div class="stat-card stat-section"><div class="stat-icon">&#127891;</div><h3>Year Level</h3><span><?= htmlspecialchars((string) ($student['year_level'] ?? 'N/A')) ?></span></div>
    </section>

    <section class="card curriculum-card">
        <div class="curriculum-card-header">
            <div>
                <span class="topbar-label">CLASS LIST</span>
                <h3>Subjects and Schedule</h3>
            </div>
            <span class="curriculum-student-no"><?= htmlspecialchars($student['student_number'] ?? 'Student No. Pending') ?></span>
        </div>

        <?php if ($subjects): ?>
            <div class="curriculum-table-wrap">
                <table class="curriculum-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Subject</th>
                            <th>Faculty</th>
                            <th>Section</th>
                            <th>Day</th>
                            <th>Time</th>
                            <th>Room</th>
                            <th>Units</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($subjects as $subject): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($subject['subject_code'] ?? '—') ?></strong></td>
                            <td><?= htmlspecialchars($subject['subject_name'] ?? '—') ?></td>
                            <td><?= htmlspecialchars($subject['teacher_name'] ?: 'Faculty') ?></td>
                            <td><?= htmlspecialchars($subject['subject_section'] ?: ($student['section_name'] ?? 'TBA')) ?></td>
                            <td><?= htmlspecialchars($subject['schedule_day'] ?: 'TBA') ?></td>
                            <td><?= htmlspecialchars($subject['schedule_time'] ?: 'TBA') ?></td>
                            <td><?= htmlspecialchars($subject['room_number'] ?: 'TBA') ?></td>
                            <td><?= number_format((float) ($subject['units'] ?? 0), 1) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="curriculum-empty">
                <div class="curriculum-empty-icon">&#128214;</div>
                <h3>No subjects available yet</h3>
                <p>Your curriculum will appear here once subjects are assigned to your course, year level, and semester.</p>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
