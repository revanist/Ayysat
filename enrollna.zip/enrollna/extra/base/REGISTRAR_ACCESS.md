# Registrar / Academic Affairs implementation

## New role
- Role ID: `5`
- Display name: `Registrar / Academic Affairs`
- Login redirect: `registrar/registrar_dashboard.php`

## How to create a Registrar account
1. Sign in as Super Admin.
2. Open **Admin > User Management** (`admin/users.php`).
3. In Create Staff Account, choose **Registrar / Academic Affairs**.
4. Enter the registrar's name/email and either provide a password or let the system generate one.
5. Give the initial password directly to the registrar.

## Registrar portal
After logging in, the Registrar sees:
- Dashboard
- Students
- Courses
- Curriculum
- Sections
- Pending Enrollment
- Enrollment Records
- Instructor Assignments
- Logout

The Registrar can manage the academic/SIS side. The Registrar does not receive Admin User Management, Cashier, or Instructor teaching tools.

## Existing system roles
- `1` Super Admin: system/admin management and full access
- `2` Instructor / Professor: LMS teaching functions
- `3` Student: student portal/LMS functions
- `4` Cashier: payment and finance functions
- `5` Registrar / Academic Affairs: academic/SIS functions

## Academic workflow
Admissions/enrollment -> course/program -> curriculum -> section -> instructor assignment -> student enrollment -> LMS class.

## Database
The existing `curriculum`, `courses`, `sections`, `students`, `enrollments`, and `teaching_assignments` tables are reused. No duplicate curriculum or section tables were added.

For a fresh database import, use `extra/enrollna_clean.sql`.
For an already-running v10 database, run `extra/add_registrar_role.sql` once.
