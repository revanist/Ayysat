<?php
require_once __DIR__ . '/../functions/student_auth.php';
start_student_session();
require __DIR__ . '/../db/dbconn.php';

if (($_SESSION['role'] ?? '') !== 'student' || empty($_SESSION['user_id'])) {
    header('Location: ../auth/login.php?loginredirect=1', true, 303);
    exit;
}

$enrollmentId = (int) ($_GET['enrollment_id'] ?? 0);
$stmt = mysqli_prepare($conn, '
    SELECT e.id, e.payment_method, e.payment_reference, e.payment_account,
           e.cash_amount_requested, e.payment_status, s.first_name, s.last_name
    FROM enrollments e
    INNER JOIN students s ON s.id = e.student_id
    WHERE e.id = ? AND s.user_id = ?
    LIMIT 1
');
$userId = (int) $_SESSION['user_id'];
mysqli_stmt_bind_param($stmt, 'ii', $enrollmentId, $userId);
mysqli_stmt_execute($stmt);
$receipt = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$receipt) {
    http_response_code(404);
    exit('Payment receipt not found.');
}

function payment_receipt_escape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment Receipt | EYYSAT</title>
    <link href="../css/bootstrap.css" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            display: grid;
            place-items: center;
            margin: 0;
            background: #eef5fb;
            color: #172033;
            font-family: Arial, sans-serif;
        }

        .receipt {
            width: min(560px, 92%);
            padding: 36px;
            background: #fff;
            border: 1px solid #d8e3ee;
            border-radius: 18px;
            box-shadow: 0 18px 50px rgba(13, 59, 102, .12);
        }

        .success {
            color: #15803d;
            font-size: 3rem;
        }

        h1 {
            color: #0d3b66;
        }

        dl {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin: 24px 0;
        }

        dt {
            color: #64748b;
        }

        dd {
            margin: 0;
            font-weight: 700;
            text-align: right;
        }
    </style>
</head>

<body>
    <main class="receipt">
        <div class="success">✓</div>
        <h1>Payment submitted</h1>
        <p>Your payment details were received successfully and are waiting for cashier confirmation.</p>
        <dl>
            <dt>Student</dt>
            <dd><?= payment_receipt_escape($receipt['first_name'] . ' ' . $receipt['last_name']) ?></dd>
            <dt>Method</dt>
            <dd><?= payment_receipt_escape(ucfirst($receipt['payment_method'])) ?></dd>
            <dt>Account/reference</dt>
            <dd><?= payment_receipt_escape($receipt['payment_account']) ?></dd>
            <dt>Transaction reference</dt>
            <dd><?= payment_receipt_escape($receipt['payment_reference']) ?></dd>
            <dt>Amount</dt>
            <dd>₱<?= number_format((float) $receipt['cash_amount_requested'], 2) ?></dd>
            <dt>Status</dt>
            <dd><?= payment_receipt_escape(ucfirst($receipt['payment_status'])) ?></dd>
        </dl>
        <a class="btn btn-primary" href="profile.php">Go to student profile</a>
    </main>
</body>

</html>