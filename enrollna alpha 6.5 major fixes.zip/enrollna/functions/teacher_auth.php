<?php
require_once __DIR__ . '/session_security.php';

/**
 * Compatibility teacher authorization.
 *
 * All instructors/professors authenticate through users.role_id = 2.
 * All teacher sessions use the unified users.user_id directly; no separate teacher account table is required.
 */
function start_teacher_session(): void
{
    start_secure_session();
}

function require_teacher_login(): void
{
    start_teacher_session();

    $modernTeacher = !empty($_SESSION['user_id']) && (int)($_SESSION['role_id'] ?? 0) === 2;

    if (!$modernTeacher) {
        header('Location: ../auth/login.php', true, 303);
        exit;
    }

}

function teacher_csrf_token(): string
{
    if (empty($_SESSION['teacher_csrf_token'])) {
        $_SESSION['teacher_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['teacher_csrf_token'];
}

function require_teacher_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || empty($_SESSION['teacher_csrf_token']) ||
        !hash_equals($_SESSION['teacher_csrf_token'], $token)) {
        http_response_code(403);
        exit('Invalid form request. Please return to the teacher portal and try again.');
    }
}
