<?php
require_once __DIR__ . '/academic_auth.php';
require_academic_login();
require_academic_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $target = '../registrar/enrollments.php';
header('Location: ' . $target, true, 303);
    exit;
}

require __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/admin_enrollment.php';

$enrollmentId = (int)($_POST['enrollment_id'] ?? 0);
$status = strtolower(trim((string)($_POST['status'] ?? '')));

try {
    if ($status === 'approved') {
        $studentNumber = admin_approve_enrollment($conn, $enrollmentId);
        $_SESSION['success'] = 'Enrollment approved. Student Number: ' . $studentNumber;
    } elseif ($status === 'rejected') {
        admin_reject_enrollment($conn, $enrollmentId);
        $_SESSION['success'] = 'Enrollment rejected.';
    } else {
        throw new InvalidArgumentException('Invalid enrollment status.');
    }
} catch (Throwable $e) {
    $_SESSION['error'] = $e->getMessage();
}

$target = '../registrar/enrollments.php';
header('Location: ' . $target, true, 303);
exit;
