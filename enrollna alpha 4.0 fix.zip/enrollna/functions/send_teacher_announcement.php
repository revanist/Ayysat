<?php
require_once __DIR__ . '/teacher_auth.php'; require_teacher_login(); require_once '../db/dbconn.php'; require_once __DIR__ . '/teacher_setup.php'; ensure_teacher_schema($conn);
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: ../teacher/announcements.php');exit;} require_teacher_csrf();
$teacherId=(int)$_SESSION['teacher_id'];$sectionId=(int)($_POST['section_id']??0);$title=trim((string)($_POST['title']??''));$message=trim((string)($_POST['message']??''));
if($title===''||$message===''){header('Location: ../teacher/announcements.php?error=empty');exit;}
if($sectionId>0){$chk=mysqli_prepare($conn,'SELECT id FROM teacher_sections WHERE teacher_id=? AND section_id=? LIMIT 1');mysqli_stmt_bind_param($chk,'ii',$teacherId,$sectionId);mysqli_stmt_execute($chk);$ok=mysqli_num_rows(mysqli_stmt_get_result($chk))===1;mysqli_stmt_close($chk);if(!$ok){http_response_code(403);exit('You cannot announce to a section you do not handle.');}}
else{$sectionId=null;}
$stmt=mysqli_prepare($conn,'INSERT INTO teacher_announcements (teacher_id,section_id,title,message) VALUES (?,?,?,?)');mysqli_stmt_bind_param($stmt,'iiss',$teacherId,$sectionId,$title,$message);mysqli_stmt_execute($stmt);mysqli_stmt_close($stmt);
header('Location: ../teacher/announcements.php?sent=1');exit;
