<?php

require_once __DIR__ . '/student_auth.php';
start_student_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header(
        'Location: ../enrollment.php',
        true,
        303
    );

    exit;
}

require_student_csrf();

require '../db/dbconn.php';
require_once __DIR__ . '/enrollment_setup.php';

ensure_enrollment_schema($conn);
seed_course_data($conn);


/**
 * Redirect with an enrollment error.
 */
function enrollment_error(string $message): void
{
    $_SESSION['enrollment_error'] = $message;

    header(
        'Location: ../enrollment.php',
        true,
        303
    );

    exit;
}


/*
 * Student information.
 */
$first_name =
    trim((string) ($_POST['first_name'] ?? ''));

$middle_name =
    trim((string) ($_POST['middle_name'] ?? ''));

$last_name =
    trim((string) ($_POST['last_name'] ?? ''));

$sex =
    (string) ($_POST['sex'] ?? '');

$birthdate =
    (string) ($_POST['birthdate'] ?? '');

$address =
    trim((string) ($_POST['address'] ?? ''));

$contact =
    trim((string) ($_POST['contact'] ?? ''));

$email =
    trim((string) ($_POST['email'] ?? ''));

$guardian =
    trim((string) ($_POST['guardian'] ?? ''));

$guardian_contact =
    trim((string) ($_POST['guardian_contact'] ?? ''));


/*
 * Enrollment selection.
 */
$course_id =
    (int) ($_POST['course_id'] ?? 0);

$section_id =
    (int) ($_POST['section_id'] ?? 0);

$year_level =
    (int) ($_POST['year_level'] ?? 0);

$semester =
    (string) ($_POST['semester'] ?? '');

$subject_ids =
    array_values(
        array_unique(
            array_filter(
                array_map(
                    'intval',
                    (array) (
                        $_POST['subject_ids']
                        ?? []
                    )
                )
            )
        )
    );


$school_year = '2026-2027';


/*
 * Server-controlled payment values.
 *
 * DO NOT read the payment amount from POST.
 */
$payment_option = '';
$payment_method = '';
$payment_reference = '';
$payment_account = '';
$payment_proof = null;
$payment_amount = 0.00;


/*
 * Validate birthdate.
 */
$birthdateValue =
    DateTimeImmutable::createFromFormat(
        '!Y-m-d',
        $birthdate
    );

$isAdult =
    $birthdateValue !== false
    &&
    $birthdateValue->format('Y-m-d') === $birthdate
    &&
    $birthdateValue <=
    (
        new DateTimeImmutable('today')
    )->modify('-18 years');


/*
 * Middle name must be initials only.
 */
$validMiddleInitials =
    $middle_name === ''
    ||
    (
        (bool) preg_match(
            '/^[A-Za-z. ]{1,5}$/',
            $middle_name
        )
    );


/*
 * Basic validation.
 */
if (
    $first_name === ''
    ||
    $last_name === ''
    ||
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
    ||
    $address === ''
    ||
    $contact === ''
    ||
    $guardian === ''
    ||
    $guardian_contact === ''
    ||
    !in_array(
        $sex,
        ['Male', 'Female'],
        true
    )
    ||
    !$isAdult
    ||
    !$validMiddleInitials
    ||
    !in_array(
        $year_level,
        [1, 2, 3, 4],
        true
    )
    ||
    !in_array(
        $semester,
        ['1', '2'],
        true
    )
    ||
    $course_id < 1
    ||
    $section_id < 1
    ||
    $subject_ids === []
) {

    enrollment_error(
        'Please complete all required details. Applicants must be at least 18 years old and select a valid curriculum.'
    );
}

if (!defined('ENROLLMENT_PAYMENT_AMOUNT')) {
    define('ENROLLMENT_PAYMENT_AMOUNT', 2500.00);
}

if (!defined('ENROLLMENT_TOTAL_AMOUNT')) {
    define('ENROLLMENT_TOTAL_AMOUNT', 20000.00);
}

$payment_method = strtolower(trim((string) ($_POST['payment_method'] ?? '')));
$payment_account = trim((string) ($_POST['payment_account'] ?? ''));
$payment_reference = trim((string) ($_POST['payment_reference'] ?? ''));
$posted_payment_amount = (float) ($_POST['payment_amount'] ?? 0);

if (!in_array($payment_method, ['gcash', 'maya', 'card'], true)) {
    enrollment_error('Please select a valid payment method.');
}

if ($posted_payment_amount < (float) ENROLLMENT_PAYMENT_AMOUNT) {
    enrollment_error('The minimum down payment is ₱' . number_format(ENROLLMENT_PAYMENT_AMOUNT, 2) . '.');
}

if ($payment_account === '') {
    enrollment_error('Please provide the payment account details.');
}

if ($payment_method === 'card' && $payment_reference === '') {
    enrollment_error('Please provide a custom card transaction reference.');
}

$payment_requested_amount = $posted_payment_amount;


/*
 * Current logged-in student.
 */
$user_id = null;

if (
    ($_SESSION['role'] ?? '') === 'student'
    &&
    !empty($_SESSION['user_id'])
) {

    $user_id =
        (int) $_SESSION['user_id'];
}


/*
 * Find existing student by user ID.
 */
$existing_student_id = null;

if ($user_id !== null) {

    $chk_user = mysqli_prepare(
        $conn,
        "
        SELECT id
        FROM students
        WHERE user_id = ?
        LIMIT 1
        "
    );

    mysqli_stmt_bind_param(
        $chk_user,
        'i',
        $user_id
    );

    mysqli_stmt_execute($chk_user);

    $res_u =
        mysqli_stmt_get_result(
            $chk_user
        );

    if ($row = mysqli_fetch_assoc($res_u)) {

        $existing_student_id =
            (int) $row['id'];
    }

    mysqli_stmt_close($chk_user);
}


/*
 * If not found by user ID, check email.
 */
if ($existing_student_id === null) {

    $chk_email = mysqli_prepare(
        $conn,
        "
        SELECT id
        FROM students
        WHERE email = ?
        LIMIT 1
        "
    );

    mysqli_stmt_bind_param(
        $chk_email,
        's',
        $email
    );

    mysqli_stmt_execute($chk_email);

    $res_e =
        mysqli_stmt_get_result(
            $chk_email
        );

    if ($row = mysqli_fetch_assoc($res_e)) {

        $existing_student_id =
            (int) $row['id'];
    }

    mysqli_stmt_close($chk_email);
}


/*
 * Guest users cannot create duplicate applications.
 */
if (
    $user_id === null
    &&
    $existing_student_id !== null
) {

    enrollment_error(
        'An application already exists for this email. Please sign in to view your profile.'
    );
}


/*
 * Check whether a user account already exists.
 */
if ($user_id === null) {

    $account = mysqli_prepare(
        $conn,
        "
        SELECT id
        FROM users
        WHERE username = ?
        LIMIT 1
        "
    );

    mysqli_stmt_bind_param(
        $account,
        's',
        $email
    );

    mysqli_stmt_execute($account);

    mysqli_stmt_store_result($account);

    if (
        mysqli_stmt_num_rows($account)
        > 0
    ) {

        mysqli_stmt_close($account);

        enrollment_error(
            'An account already exists for this email. Please sign in before submitting enrollment.'
        );
    }

    mysqli_stmt_close($account);
}


/*
 * Server-controlled enrollment payment.
 *
 * Amount is defined on the server and is NEVER
 * taken from POST data.
 *
 * Change 2500.00 if your enrollment fee is different.
 */
$total_tuition = (float) ENROLLMENT_TOTAL_AMOUNT;

/*
 * No payment has happened yet.
 */
$payment_amount = 0.00;

$remaining_balance =
    $total_tuition;

$payment_status = 'Pending';


mysqli_begin_transaction($conn);

try {

    /*
     * Validate course.
     */
    $courseCheck = mysqli_prepare(
        $conn,
        "
        SELECT id
        FROM courses
        WHERE id = ?
        LIMIT 1
        "
    );

    mysqli_stmt_bind_param(
        $courseCheck,
        'i',
        $course_id
    );

    mysqli_stmt_execute($courseCheck);

    mysqli_stmt_store_result(
        $courseCheck
    );

    if (
        mysqli_stmt_num_rows($courseCheck)
        === 0
    ) {

        mysqli_stmt_close($courseCheck);

        throw new RuntimeException(
            'The selected course is invalid.'
        );
    }

    mysqli_stmt_close($courseCheck);


    /*
     * Validate section belongs to course.
     */
    $section_check = mysqli_prepare(
        $conn,
        "
        SELECT id
        FROM sections
        WHERE id = ?
        AND course_id = ?
        LIMIT 1
        "
    );

    mysqli_stmt_bind_param(
        $section_check,
        'ii',
        $section_id,
        $course_id
    );

    mysqli_stmt_execute(
        $section_check
    );

    mysqli_stmt_store_result(
        $section_check
    );

    if (
        mysqli_stmt_num_rows($section_check)
        === 0
    ) {

        mysqli_stmt_close(
            $section_check
        );

        throw new RuntimeException(
            'The selected section is invalid.'
        );
    }

    mysqli_stmt_close(
        $section_check
    );


    /*
     * Validate every selected subject against
     * the actual curriculum.
     *
     * This prevents someone from manually posting
     * a subject ID that isn't part of the selected
     * course/year/semester curriculum.
     */
    $subject_check = mysqli_prepare(
        $conn,
        "
        SELECT
            cu.subject_id
        FROM curriculum cu
        INNER JOIN subjects s
            ON s.id = cu.subject_id
        WHERE cu.course_id = ?
        AND cu.subject_id = ?
        AND cu.year_level = ?
        AND cu.semester = ?
        AND s.course_id = ?
        AND s.is_available = 1
        LIMIT 1
        "
    );

    foreach ($subject_ids as $subject_id) {

        mysqli_stmt_bind_param(
            $subject_check,
            'iiiii',
            $course_id,
            $subject_id,
            $year_level,
            $semester,
            $course_id
        );

        mysqli_stmt_execute(
            $subject_check
        );

        mysqli_stmt_store_result(
            $subject_check
        );

        if (
            mysqli_stmt_num_rows(
                $subject_check
            ) === 0
        ) {

            mysqli_stmt_close(
                $subject_check
            );

            throw new RuntimeException(
                'One of the selected subjects is not part of the selected curriculum.'
            );
        }

        mysqli_stmt_free_result(
            $subject_check
        );
    }

    mysqli_stmt_close(
        $subject_check
    );


    /*
     * Existing student.
     */
    if ($existing_student_id !== null) {

        $student_id =
            $existing_student_id;


        $upd_student = mysqli_prepare(
            $conn,
            "
            UPDATE students
            SET
                user_id = ?,
                first_name = ?,
                middle_name = ?,
                last_name = ?,
                sex = ?,
                birthdate = ?,
                address = ?,
                contact = ?,
                email = ?,
                guardian = ?,
                guardian_contact = ?,
                course_id = ?,
                section_id = ?,
                year_level = ?,
                payment_status = 'Pending',
                enrollment_status = 'Pending',
                remaining_balance = ?
            WHERE id = ?
            "
        );

        mysqli_stmt_bind_param(
            $upd_student,
            'issssssssssiiidi',
            $user_id,
            $first_name,
            $middle_name,
            $last_name,
            $sex,
            $birthdate,
            $address,
            $contact,
            $email,
            $guardian,
            $guardian_contact,
            $course_id,
            $section_id,
            $year_level,
            $remaining_balance,
            $student_id
        );

        if (
            !mysqli_stmt_execute(
                $upd_student
            )
        ) {

            mysqli_stmt_close(
                $upd_student
            );

            throw new RuntimeException(
                'Unable to update student record.'
            );
        }

        mysqli_stmt_close(
            $upd_student
        );
    } else {

        /*
         * New student.
         */
        $student_number =
            generate_student_number(
                $conn,
                $course_id
            );

        $student_stmt = mysqli_prepare(
            $conn,
            "
            INSERT INTO students
            (
                user_id,
                student_number,
                first_name,
                middle_name,
                last_name,
                sex,
                birthdate,
                address,
                contact,
                email,
                guardian,
                guardian_contact,
                course_id,
                section_id,
                year_level,
                payment_status,
                enrollment_status,
                remaining_balance
            )
            VALUES
            (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, 'Pending', 'Pending', ?
            )
            "
        );

        mysqli_stmt_bind_param(
            $student_stmt,
            'isssssssssssiiid',
            $user_id,
            $student_number,
            $first_name,
            $middle_name,
            $last_name,
            $sex,
            $birthdate,
            $address,
            $contact,
            $email,
            $guardian,
            $guardian_contact,
            $course_id,
            $section_id,
            $year_level,
            $remaining_balance
        );

        if (
            !mysqli_stmt_execute(
                $student_stmt
            )
        ) {

            mysqli_stmt_close(
                $student_stmt
            );

            throw new RuntimeException(
                'Unable to create student record.'
            );
        }

        $student_id =
            mysqli_insert_id($conn);

        mysqli_stmt_close(
            $student_stmt
        );
    }


    /*
     * Create the enrollment.
     *
     * Notice that course_id, section_id,
     * year_level and semester are saved.
     */
    $enrollment_stmt = mysqli_prepare(
        $conn,
        "
        INSERT INTO enrollments
        (
            student_id,
            course_id,
            section_id,
            year_level,
            school_year,
            sem,
            status,
            payment_status,
            payment_method,
            payment_option,
            payment_reference,
            amount_paid,
            payment_account,
            payment_proof,
            cash_amount_requested
        )
        VALUES
        (
            ?, ?, ?, ?, ?, ?,
            'Pending',
            'Pending',
            ?, ?, ?, ?, ?, ?, ?
        )
        "
    );

    mysqli_stmt_bind_param(
        $enrollment_stmt,
        'iiiisssssdssd',
        $student_id,
        $course_id,
        $section_id,
        $year_level,
        $school_year,
        $semester,
        $payment_method,
        $payment_option,
        $payment_reference,
        $payment_amount,
        $payment_account,
        $payment_proof,
        $payment_requested_amount
    );

    if (
        !mysqli_stmt_execute(
            $enrollment_stmt
        )
    ) {

        mysqli_stmt_close(
            $enrollment_stmt
        );

        throw new RuntimeException(
            'Unable to create enrollment record.'
        );
    }

    $enrollment_id =
        mysqli_insert_id($conn);

    mysqli_stmt_close(
        $enrollment_stmt
    );

    /* Queue a durable cashier alert for this submitted payment. */
    $notificationMessage = sprintf(
        '%s %s submitted a %s payment of ₱%s.',
        $first_name,
        $last_name,
        strtoupper($payment_method),
        number_format($payment_requested_amount, 2)
    );
    $notificationStmt = mysqli_prepare(
        $conn,
        'INSERT INTO admin_notifications (enrollment_id, message) VALUES (?, ?)'
    );
    mysqli_stmt_bind_param($notificationStmt, 'is', $enrollment_id, $notificationMessage);
    if (!mysqli_stmt_execute($notificationStmt)) {
        mysqli_stmt_close($notificationStmt);
        throw new RuntimeException('Unable to notify the cashier.');
    }
    mysqli_stmt_close($notificationStmt);


    /*
     * Save the selected curriculum subjects.
     */
    $subject_insert = mysqli_prepare(
        $conn,
        "
        INSERT INTO enrollment_details
        (
            enrollment_id,
            subject_id
        )
        VALUES (?, ?)
        "
    );

    foreach ($subject_ids as $subject_id) {

        mysqli_stmt_bind_param(
            $subject_insert,
            'ii',
            $enrollment_id,
            $subject_id
        );

        if (
            !mysqli_stmt_execute(
                $subject_insert
            )
        ) {

            mysqli_stmt_close(
                $subject_insert
            );

            throw new RuntimeException(
                'Unable to save selected subjects.'
            );
        }
    }

    mysqli_stmt_close(
        $subject_insert
    );


    mysqli_commit($conn);
} catch (Throwable $exception) {

    mysqli_rollback($conn);

    enrollment_error(
        'Unable to submit the application. Please review your details and try again.'
    );
}


/*
 * Prevent re-submission.
 */
unset(
    $_SESSION['student_csrf_token']
);


/*
 * Guest:
 * send them to registration first.
 */
if ($user_id === null) {

    $_SESSION['enrollment_success'] =
        'Application submitted. Create an account with the same email to continue with payment.';

    header(
        'Location: ../auth/register.php?from=enrollment',
        true,
        303
    );

    exit;
}


/* The payment receipt is available immediately; the cashier confirms it. */
$_SESSION['enrollment_success'] =
    'Enrollment created. Payment is waiting for cashier review.';

header(
    'Location: ../student/payment_receipt.php?enrollment_id=' .
        (int) $enrollment_id,
    true,
    303
);

exit;
