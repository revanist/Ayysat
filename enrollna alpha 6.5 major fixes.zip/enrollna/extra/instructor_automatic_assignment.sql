-- EYYSAT Instructor automatic section/class assignment
-- Run after the main database/LMS schema if you do not use enrollment_setup.php.
-- The application also creates/synchronizes these records automatically.

-- Instructor section access remains the source assignment.
-- teaching_assignments links that instructor to every available subject in the section.

CREATE TABLE IF NOT EXISTS teaching_assignments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    teacher_id INT NOT NULL,
    subject_id INT NOT NULL,
    section_id INT NOT NULL,
    school_year VARCHAR(20) NOT NULL,
    semester TINYINT UNSIGNED NOT NULL DEFAULT 1,
    status ENUM('Active','Archived') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_teaching_assignment(teacher_id,subject_id,section_id,school_year,semester),
    KEY idx_assignment_teacher(teacher_id,status),
    KEY idx_assignment_section_subject(section_id,subject_id,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
