<?php
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();
header('Location: users.php', true, 303);
exit;
