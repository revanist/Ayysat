<?php
declare(strict_types=1);

/**
 * Enrollment data access. The form view receives one normalized catalog
 * instead of performing SQL queries itself.
 */
function enrollment_load_course_catalog(mysqli $conn): array
{
    $catalog = [];

    $courses = mysqli_query(
        $conn,
        "SELECT id, course_code, course_name
         FROM courses
         ORDER BY course_code ASC"
    );

    if (!$courses) {
        return $catalog;
    }

    while ($course = mysqli_fetch_assoc($courses)) {
        $courseId = (int) $course['id'];

        $sections = enrollment_fetch_all(
            $conn,
            "SELECT id, section_name
             FROM sections
             WHERE course_id = ?
             ORDER BY section_name ASC",
            'i',
            [$courseId]
        );

        // Normalize section metadata once on the server. The browser should
        // not have to guess year/semester from the display name.
        foreach ($sections as &$section) {
            $name = strtoupper(trim((string) ($section['section_name'] ?? '')));
            if (preg_match('/^(.+)-(1|2|3|4)([A-D])(1|2)$/', $name, $match)) {
                $section['year_level'] = (int) $match[2];
                $section['section_letter'] = $match[3];
                $section['semester'] = (int) $match[4];
            } else {
                $section['year_level'] = 0;
                $section['section_letter'] = '';
                $section['semester'] = 0;
            }
            $section['id'] = (int) $section['id'];
            $section['section_name'] = (string) $section['section_name'];
        }
        unset($section);

        $subjects = enrollment_fetch_all(
            $conn,
            "SELECT id, subject_code, subject_name, schedule_day, schedule_time, room_number
             FROM subjects
             WHERE course_id = ?
             ORDER BY subject_code ASC",
            'i',
            [$courseId]
        );

        $curriculum = enrollment_fetch_all(
            $conn,
            "SELECT
                s.id,
                s.subject_code,
                s.subject_name,
                c.units,
                c.year_level,
                c.semester,
                s.schedule_day,
                s.schedule_time,
                s.room_number
             FROM curriculum c
             INNER JOIN subjects s ON s.id = c.subject_id
             WHERE c.course_id = ?
               AND s.course_id = ?
             ORDER BY c.year_level ASC, c.semester ASC, s.subject_code ASC",
            'ii',
            [$courseId, $courseId]
        );

        $catalog[] = [
            'course' => [
                'id' => $courseId,
                'course_code' => (string) $course['course_code'],
                'course_name' => (string) $course['course_name'],
            ],
            'sections' => $sections,
            'subjects' => $subjects,
            'curriculum' => $curriculum,
        ];
    }

    mysqli_free_result($courses);

    return $catalog;
}

function enrollment_fetch_all(mysqli $conn, string $sql, string $types, array $values): array
{
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return [];
    }

    if (count($values) === 1) {
        mysqli_stmt_bind_param($stmt, $types, $values[0]);
    } elseif (count($values) === 2) {
        mysqli_stmt_bind_param($stmt, $types, $values[0], $values[1]);
    } else {
        mysqli_stmt_close($stmt);
        return [];
    }
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return [];
    }

    $result = mysqli_stmt_get_result($stmt);
    $rows = [];

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        mysqli_free_result($result);
    }

    mysqli_stmt_close($stmt);
    return $rows;
}

function enrollment_catalog_for_js(array $catalog): array
{
    return array_map(
        static function (array $entry): array {
            return [
                'id' => (int) $entry['course']['id'],
                'course_code' => $entry['course']['course_code'],
                'course_name' => $entry['course']['course_name'],
                'sections' => $entry['sections'],
                'subjects' => $entry['subjects'],
                'curriculum' => $entry['curriculum'],
            ];
        },
        $catalog
    );
}
