<?php
/** Shared dashboard-style admin sidebar. */
$currentPage = basename($_SERVER['PHP_SELF']);
$adminName = htmlspecialchars($_SESSION['admin_name'] ?? 'Admin');
if (isset($conn)) {
    $notificationCountResult = mysqli_query($conn, "SELECT COUNT(*) AS total FROM admin_notifications WHERE is_read = 0");
    $unreadNotificationCount = $notificationCountResult ? (int) mysqli_fetch_assoc($notificationCountResult)['total'] : 0;
} else {
    $unreadNotificationCount = 0;
}

$activePage = match ($currentPage) {
    'edit_student.php' => 'students.php',
    'student_info.php' => 'enrollments.php',
    default => $currentPage,
};

function sidebar_active(string $file, string $current): string {
    return $current === $file ? ' active' : '';
}
?>

<aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <div class="sidebar-logo"><img src="../img/eyysat.png" alt="EYYSAT Logo"></div>
        <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>ADMIN PANEL</span></div>
    </div>

    <nav class="sidebar-nav" aria-label="Admin navigation">
        <p class="sidebar-label">MAIN MENU</p>
        <a href="admin_dashboard.php" class="sidebar-link<?= sidebar_active('admin_dashboard.php', $activePage) ?>"><span class="sidebar-icon">&#127968;</span><span class="sidebar-text">Dashboard</span></a>
        <a href="students.php" class="sidebar-link<?= sidebar_active('students.php', $activePage) ?>"><span class="sidebar-icon">&#127891;</span><span class="sidebar-text">Students</span></a>
        <a href="courses.php" class="sidebar-link<?= sidebar_active('courses.php', $activePage) ?>"><span class="sidebar-icon">&#128218;</span><span class="sidebar-text">Courses</span></a>
        <a href="enrollments.php" class="sidebar-link<?= sidebar_active('enrollments.php', $activePage) ?>"><span class="sidebar-icon">&#128214;</span><span class="sidebar-text">Enrollments</span></a>
        <a href="cashier.php" class="sidebar-link<?= sidebar_active('cashier.php', $activePage) ?>"><span class="sidebar-icon">&#128176;</span><span class="sidebar-text">Cashier</span></a>
        <a href="notifications.php" class="sidebar-link<?= sidebar_active('notifications.php', $activePage) ?>"><span class="sidebar-icon">&#128276;</span><span class="sidebar-text">Notifications</span><?php if ($unreadNotificationCount > 0): ?><span class="sidebar-notification-badge"><?= $unreadNotificationCount > 99 ? '99+' : $unreadNotificationCount ?></span><?php endif; ?></a>
        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="../auth/admin_logout.php" class="sidebar-link sidebar-logout"><span class="sidebar-icon">&#128682;</span><span class="sidebar-text">Logout</span></a>
    </nav>

    <div class="sidebar-profile">
        <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['admin_name'] ?? 'Admin', 0, 1))) ?></div>
        <div class="profile-info"><strong><?= $adminName ?></strong><span>Administrator</span></div>
    </div>
</aside>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
<button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Toggle sidebar"></button>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('adminSidebar');
    const toggle = document.getElementById('sidebarToggle');
    const overlay = document.getElementById('sidebarOverlay');
    const main = document.querySelector('.dashboard-main');
    if (!sidebar || !toggle || !overlay) return;
    function updateTogglePosition() {
        toggle.style.left = window.innerWidth <= 768 ? '18px' : (sidebar.classList.contains('collapsed') ? '68px' : '246px');
    }
    toggle.addEventListener('click', function () {
        if (window.innerWidth <= 768) {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('show');
            return;
        }
        const collapsed = sidebar.classList.toggle('collapsed');
        if (main) main.classList.toggle('sidebar-collapsed', collapsed);
        toggle.classList.toggle('collapsed', collapsed);
        updateTogglePosition();
    });
    overlay.addEventListener('click', function () {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('show');
    });
    document.querySelectorAll('.sidebar-link').forEach(function (link) {
        link.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('mobile-open');
                overlay.classList.remove('show');
            }
        });
    });
    window.addEventListener('resize', updateTogglePosition);
    updateTogglePosition();
});
</script>
