<?php
require_once __DIR__ . '/../functions/academic_auth.php';
require_academic_login();
require_academic_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $target = '../registrar/students.php';
    header('Location: ' . $target, true, 303);
    exit;
}

include '../db/dbconn.php';

$id          = (int) ($_POST['id'] ?? 0);
$first_name  = trim((string) ($_POST['first_name'] ?? ''));
$middle_name = trim((string) ($_POST['middle_name'] ?? ''));
$last_name   = trim((string) ($_POST['last_name'] ?? ''));
$email       = trim((string) ($_POST['email'] ?? ''));
$address     = trim((string) ($_POST['address'] ?? ''));
$contact     = trim((string) ($_POST['contact'] ?? ''));

if ($id < 1 || $first_name === '' || $last_name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^\d{11}$/', $contact) || ($middle_name !== '' && !preg_match("/^[\p{L} .'-]+$/u", $middle_name))) {
    http_response_code(400);
    exit('Invalid student update parameters. Contact number must contain exactly 11 digits, and middle name must contain letters only.');
}

$exists = mysqli_prepare($conn, 'SELECT id, user_id FROM students WHERE id = ? LIMIT 1');
if (!$exists) { http_response_code(500); exit('Unable to validate student.'); }
mysqli_stmt_bind_param($exists, 'i', $id);
mysqli_stmt_execute($exists);
$studentRow = mysqli_fetch_assoc(mysqli_stmt_get_result($exists));
mysqli_stmt_close($exists);

if (!$studentRow) {
    http_response_code(404);
    exit('Student not found.');
}

$userId = (int) ($studentRow['user_id'] ?? 0);

if ($userId > 0) {
    $emailCheck = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE LOWER(email) = LOWER(?) AND user_id <> ? LIMIT 1');
    if (!$emailCheck) { http_response_code(500); exit('Unable to validate email.'); }
    mysqli_stmt_bind_param($emailCheck, 'si', $email, $userId);
    mysqli_stmt_execute($emailCheck);
    $duplicate = mysqli_fetch_assoc(mysqli_stmt_get_result($emailCheck));
    mysqli_stmt_close($emailCheck);

    if ($duplicate) {
        http_response_code(409);
        exit('That email address is already used by another account.');
    }
}

mysqli_begin_transaction($conn);

try {
    $stmt = mysqli_prepare($conn, '
        UPDATE students SET
            first_name = ?,
            middle_name = ?,
            last_name = ?,
            email = ?,
            address = ?,
            contact = ?
        WHERE id = ?
    ');
    if (!$stmt) {
        throw new RuntimeException('Unable to prepare student update.');
    }

    mysqli_stmt_bind_param($stmt, 'ssssssi', $first_name, $middle_name, $last_name, $email, $address, $contact, $id);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to update student record.');
    }
    mysqli_stmt_close($stmt);

    if ($userId > 0) {
        $fullName = trim($first_name . ' ' . ($middle_name !== '' ? $middle_name . ' ' : '') . $last_name);
        $userStmt = mysqli_prepare($conn, 'UPDATE users SET full_name = ?, email = ? WHERE user_id = ? AND role_id = 3');
        if (!$userStmt) {
            throw new RuntimeException('Unable to prepare account update.');
        }

        mysqli_stmt_bind_param($userStmt, 'ssi', $fullName, $email, $userId);
        if (!mysqli_stmt_execute($userStmt)) {
            mysqli_stmt_close($userStmt);
            throw new RuntimeException('Unable to update linked account.');
        }
        mysqli_stmt_close($userStmt);
    }

    mysqli_commit($conn);
    header('Location: ../registrar/students.php', true, 303);
    exit;
} catch (Throwable $exception) {
    mysqli_rollback($conn);
    http_response_code(500);
    exit('Update failed. Please try again.');
}
