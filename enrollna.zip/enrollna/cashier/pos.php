<?php
require_once __DIR__ . "/../functions/cashier_auth.php";
require_cashier_login();

require_once __DIR__ . "/../db/dbconn.php";
require_once __DIR__ . "/../functions/enrollment_setup.php";
ensure_enrollment_schema($conn);
ensure_account_security_schema($conn);

function cashier_payment_method(?string $method): string
{
    return match (strtolower(trim((string)$method))) {
        "gcash" => "GCash",
        "cash" => "Cash",
        "card" => "Card",
        "bank", "bank transfer" => "Bank Transfer",
        "maya" => "Maya",
        default => "—",
    };
}

$cashierName = htmlspecialchars($_SESSION["fullname"] ?? "Cashier");
$csrf = cashier_csrf_token();

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "pos_payment") {
    $posStudentId = (int) $_POST["student_id"];
    $posAmount = (float) $_POST["amount"];
    
    if ($posStudentId > 0 && $posAmount > 0) {
        $stmt = mysqli_prepare($conn, "SELECT remaining_balance FROM students WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $posStudentId);
        mysqli_stmt_execute($stmt);
        $s = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);

        if ($s) {
            $enrollStmt = mysqli_prepare($conn, "SELECT id FROM enrollments WHERE student_id = ? ORDER BY id DESC LIMIT 1");
            mysqli_stmt_bind_param($enrollStmt, "i", $posStudentId);
            mysqli_stmt_execute($enrollStmt);
            $e = mysqli_fetch_assoc(mysqli_stmt_get_result($enrollStmt));
            mysqli_stmt_close($enrollStmt);

            if ($e) {
                $enrollmentId = $e["id"];
                $paymentRef = "POS-" . time();
                $rem = (float)$s["remaining_balance"];
                
                $updateEnroll = mysqli_prepare($conn, "
                    UPDATE enrollments 
                    SET amount_paid = amount_paid + ?, 
                        payment_method = 'Cash', 
                        payment_reference = ?, 
                        payment_status = CASE WHEN amount_paid + ? >= ? THEN 'Paid' ELSE 'Partial' END, 
                        status = 'Enrolled' 
                    WHERE id = ?
                ");
                mysqli_stmt_bind_param($updateEnroll, "dsddi", $posAmount, $paymentRef, $posAmount, $rem, $enrollmentId);
                mysqli_stmt_execute($updateEnroll);
                mysqli_stmt_close($updateEnroll);

                mysqli_query($conn, "UPDATE students SET remaining_balance = GREATEST(0, remaining_balance - {$posAmount}), payment_status = CASE WHEN remaining_balance - {$posAmount} <= 0 THEN 'Paid' ELSE 'Partial' END WHERE id = {$posStudentId}");
                
                header("Location: index.php?receipt=" . $enrollmentId);
                exit;
            }
        }
    }
}

$studentsQuery = mysqli_query($conn, "
    SELECT s.id, s.student_number, s.first_name, s.last_name, s.remaining_balance, e.status as enrollment_status 
    FROM students s
    LEFT JOIN enrollments e ON s.id = e.student_id
    ORDER BY s.last_name, s.first_name
");
$allStudents = [];
while ($row = mysqli_fetch_assoc($studentsQuery)) {
    $allStudents[] = $row;
}

$selectedStudentId = (int)($_GET["pos_student"] ?? 0);
$selectedStudent = null;
if ($selectedStudentId > 0) {
    foreach($allStudents as $stu) {
        if((int)$stu["id"] === $selectedStudentId) {
            $selectedStudent = $stu;
            break;
        }
    }
}

$recentQuery = mysqli_query($conn, "
    SELECT e.id, s.student_number, s.first_name, s.last_name,
           c.course_code, e.payment_status, e.payment_method,
           e.amount_paid, e.cash_amount_requested, e.created
    FROM enrollments e
    INNER JOIN students s ON s.id=e.student_id
    LEFT JOIN courses c ON c.id=e.course_id
    WHERE COALESCE(e.amount_paid,0) > 0 OR COALESCE(e.cash_amount_requested,0) > 0
    ORDER BY e.created DESC
    LIMIT 6
");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Point of Sale — EYYSAT Cashier</title>
<link rel="stylesheet" href="../css/admin_dashboard.css">
<link rel="stylesheet" href="../css/cashier_dashboard.css">
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/sweetalert2.all.min.js"></script>
<script src="../js/ux-polish.js" defer></script>
<style>
.pos-grid {
    display: grid;
    grid-template-columns: 1fr 1.6fr 1fr;
    gap: 20px;
    margin-bottom: 24px;
}
.pos-card {
    background: var(--bg-card);
    border: 1px solid var(--border-light);
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
}
.pos-card h2 {
    font-size: 1rem;
    font-weight: 700;
    color: var(--text-primary);
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 16px;
    border-bottom: 2px solid var(--border-light);
    padding-bottom: 10px;
}
.pos-card h2 .pill {
    font-size: 0.65rem;
    background: rgba(255,255,255,0.1);
    color: var(--text-secondary);
    padding: 4px 10px;
    border-radius: 40px;
    font-weight: 800;
    text-transform: uppercase;
}
.verify-list { display: flex; flex-direction: column; gap: 10px; }
.verify-item {
    display: flex; align-items: center; gap: 10px;
    padding: 12px; border-radius: 12px;
    background: rgba(0,0,0,0.15); border: 1px solid var(--border-light);
    font-size: 0.85rem;
}
.verify-item .dot {
    width: 24px; height: 24px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 0.75rem; flex-shrink: 0; font-weight: bold;
}
.verify-item .dot.ok { background: #dcfce7; color: #166534; }
.verify-item .dot.no { background: #fee2e2; color: #991b1b; }
.verify-item .dot.wait { background: #fef3c7; color: #92400e; }
.verify-item .label { flex: 1; font-weight: 600; color: var(--text-primary); }
.verify-item .value { font-size: 0.75rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; }
.summary-row {
    display: flex; justify-content: space-between; padding: 10px 0;
    font-size: 0.85rem; border-bottom: 1px dashed var(--border-light);
}
.summary-row:last-child { border-bottom: none; }
.summary-row .k { color: var(--text-muted); font-weight: 600; }
.summary-row .v { font-weight: 700; color: var(--text-primary); }
.summary-row.total { background: rgba(0,0,0,0.2); padding: 14px; border-radius: 8px; margin-top: 10px; border: 1px solid var(--border-light); }
.summary-row.total .k { color: var(--text-primary); }
.summary-row.total .v { font-size: 1.25rem; color: var(--eyysat-gold); }
.pos-input { width: 100%; padding: 12px; border: 2px solid var(--border-light); background: rgba(0,0,0,0.1); color: var(--text-primary); border-radius: 8px; font-size: 1.2rem; font-weight: 700; font-family: "JetBrains Mono", monospace; outline: none; margin-bottom: 14px; box-sizing: border-box; }
.pos-input:focus { border-color: var(--eyysat-gold); }
.pos-btn { width: 100%; padding: 14px; border-radius: 8px; font-size: 1rem; font-weight: 700; cursor: pointer; border: none; background: #1e5a96; color: white; transition: 0.2s; }
.pos-btn:hover { background: #102a43; }
.pos-btn:disabled { background: #94a3b8; cursor: not-allowed; }
.student-select { width: 100%; padding: 10px; border-radius: 8px; border: 1px solid var(--border-light); background: rgba(0,0,0,0.1); color: var(--text-primary); font-size: 0.9rem; font-weight: 600; margin-bottom: 15px; outline: none; }
.student-select option { background: var(--bg-card); color: var(--text-primary); }
@media (max-width: 1100px) { .pos-grid { grid-template-columns: 1fr 1fr; } .pos-grid .pos-card:nth-child(2) { grid-column: span 2; } }
@media (max-width: 768px) { .pos-grid { grid-template-columns: 1fr; } .pos-grid .pos-card:nth-child(2) { grid-column: span 1; } }
</style>
</head>
<body>

<?php include __DIR__ . "/../sidebar/sidebar.php"; ?>

<main class="dashboard-main cashier-main">
    <header class="dashboard-topbar">
        <div class="cashier-topbar-copy">
            <span class="topbar-label">POINT OF SALE</span>
            <h2>Checkout Terminal</h2>
        </div>
    </header>

    <div class="pos-grid" style="margin-top:20px;">
        <!-- STEP 1: Prerequisite Check -->
        <div class="pos-card">
            <h2>Prerequisite Check <span class="pill">step 1</span></h2>
            
            <label style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); margin-bottom: 5px; display:block;">Find Student</label>
            <select class="student-select" onchange="if(this.value) window.location.href='pos.php?pos_student='+this.value">
                <option value="">-- Select Student --</option>
                <?php foreach($allStudents as $stu): ?>
                    <option value="<?= $stu["id"] ?>" <?= $selectedStudentId === (int)$stu["id"] ? "selected" : "" ?>>
                        <?= htmlspecialchars($stu["first_name"]." ".$stu["last_name"]." (".$stu["student_number"].")") ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <?php if ($selectedStudent): 
                $isApproved = in_array(strtolower($selectedStudent["enrollment_status"] ?? ""), ["approved", "enrolled"]);
                $hasBalance = (float)$selectedStudent["remaining_balance"] > 0;
            ?>
            <div class="verify-list">
                <div class="verify-item">
                    <div class="dot ok">✓</div>
                    <span class="label">Student Identified</span>
                    <span class="value">Verified</span>
                </div>
                <div class="verify-item">
                    <div class="dot <?= $isApproved ? "ok" : "wait" ?>"><?= $isApproved ? "✓" : "⏳" ?></div>
                    <span class="label">Enrollment Status</span>
                    <span class="value"><?= $isApproved ? "Approved" : "Pending" ?></span>
                </div>
                <div class="verify-item">
                    <div class="dot <?= $hasBalance ? "ok" : "no" ?>"><?= $hasBalance ? "✓" : "✕" ?></div>
                    <span class="label">Balance Due</span>
                    <span class="value"><?= $hasBalance ? "Active" : "Cleared" ?></span>
                </div>
            </div>
            <?php else: ?>
            <div class="empty-state" style="padding: 20px;">
                <span style="font-size: 2rem; display:block; margin-bottom:10px;">🔍</span>
                <strong style="color: var(--text-primary);">No student selected</strong>
                <span style="font-size: 0.8rem; color: var(--text-dim);">Select a student above to begin.</span>
            </div>
            <?php endif; ?>
        </div>

        <!-- STEP 2: Transactions -->
        <div class="pos-card" style="display:flex; flex-direction:column;">
            <h2>Recent Terminal Activity <span class="pill">step 2</span></h2>
            <div class="table-wrapper cashier-table-wrap" style="flex:1;">
                <table class="modern-table" style="min-width: 100%;">
                    <thead><tr><th>Student</th><th>Amount</th><th>Method</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php if (!$recentQuery || mysqli_num_rows($recentQuery)===0): ?>
                        <tr><td colspan="4" class="empty-state" style="padding: 20px;"><strong style="color: var(--text-primary);">No transactions yet</strong></td></tr>
                    <?php else: while($row=mysqli_fetch_assoc($recentQuery)): ?>
                        <?php $displayAmount=(float)($row["amount_paid"] ?? 0); if($displayAmount<=0) $displayAmount=(float)($row["cash_amount_requested"] ?? 0); ?>
                        <tr>
                            <td><?= htmlspecialchars($row["last_name"].", ".$row["first_name"][0]) ?></td>
                            <td><strong>₱<?= number_format($displayAmount,2) ?></strong></td>
                            <td><span class="cashier-method <?= strtolower($row["payment_method"] ?? "")==="cash"?"cash":"gcash" ?>"><?= htmlspecialchars(cashier_payment_method($row["payment_method"])) ?></span></td>
                            <td><span class="status-<?= strtolower($row["payment_status"])==="paid"?"approved":"pending" ?>"><?= htmlspecialchars(ucfirst($row["payment_status"])) ?></span></td>
                        </tr>
                    <?php endwhile; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- STEP 3: POS Summary -->
        <div class="pos-card">
            <h2>Payment POS <span class="pill">step 3</span></h2>
            <?php if ($selectedStudent && $isApproved && $hasBalance): ?>
            
            <div class="summary-row">
                <span class="k">Student</span>
                <span class="v"><?= htmlspecialchars($selectedStudent["last_name"]) ?></span>
            </div>
            <div class="summary-row total">
                <span class="k">Balance Due</span>
                <span class="v">₱ <?= number_format($selectedStudent["remaining_balance"], 2) ?></span>
            </div>

            <form method="POST" style="margin-top: 20px;">
                <input type="hidden" name="action" value="pos_payment">
                <input type="hidden" name="student_id" value="<?= $selectedStudent["id"] ?>">
                
                <label style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted); margin-bottom: 5px; display:block;">Amount to Pay (Cash)</label>
                <input type="number" name="amount" class="pos-input" min="1" max="<?= $selectedStudent["remaining_balance"] ?>" step="0.01" value="<?= $selectedStudent["remaining_balance"] ?>" required>
                
                <button type="submit" class="pos-btn">Process Payment</button>
            </form>

            <?php elseif ($selectedStudent && !$isApproved): ?>
            <div class="review-action-alert" style="margin-top:10px; padding:12px; background: #fff7e6; border: 1px solid #fed7aa; border-left: 4px solid #f59e0b;">
                <span class="review-alert-icon" style="font-size: 1rem;">🔒</span>
                <div><strong style="margin-bottom:2px; display:block; color: #92400e;">Blocked</strong><span style="font-size: 0.8rem; color: #b45309;">Enrollment not approved.</span></div>
            </div>
            <?php elseif ($selectedStudent && !$hasBalance): ?>
            <div class="review-action-alert" style="margin-top:10px; padding:12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-left: 4px solid #22c55e;">
                <span class="review-alert-icon" style="font-size: 1rem;">✓</span>
                <div><strong style="margin-bottom:2px; display:block; color: #166534;">Cleared</strong><span style="font-size: 0.8rem; color: #15803d;">No remaining balance.</span></div>
            </div>
            <?php else: ?>
            <div class="empty-state" style="padding: 20px;">
                <span style="font-size: 2rem; display:block; margin-bottom:10px;">💵</span>
                <strong style="color: var(--text-primary);">Select Student</strong>
                <span style="font-size: 0.8rem; color: var(--text-dim);">To open POS terminal.</span>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>
</body>
</html>
