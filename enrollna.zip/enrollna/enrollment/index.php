<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$enrollmentError = (string) ($_SESSION['enrollment_error'] ?? '');
$enrollmentSuccess = (string) ($_SESSION['enrollment_success'] ?? '');
$newStudentAccount = is_array($_SESSION['new_student_account'] ?? null)
    ? $_SESSION['new_student_account']
    : null;

unset(
    $_SESSION['enrollment_error'],
    $_SESSION['enrollment_success'],
    $_SESSION['new_student_account']
);

$catalogForJs = enrollment_catalog_for_js($courseCatalog);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment & Registration Portal</title>

    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="assets/enrollment.css">
    <link rel="stylesheet" href="../css/ux-polish.css">
</head>
<body>
<?php require __DIR__ . '/views/form.php'; ?>

<script>
    window.ENROLLMENT_CATALOG = <?= json_encode(
        $catalogForJs,
        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT
    ); ?>;
    window.ENROLLMENT_ERROR = <?= json_encode($enrollmentError); ?>;
    window.ENROLLMENT_SUCCESS = <?= json_encode($enrollmentSuccess); ?>;
    window.NEW_STUDENT_ACCOUNT = <?= json_encode($newStudentAccount); ?>;
    window.ENROLLMENT_DRAFT = <?= json_encode($_SESSION['enrollment_draft'] ?? []); ?>;
</script>

<script src="../js/bootstrap.bundle.js"></script>
<script src="../js/sweetalert2.all.min.js"></script>
<script src="../js/ux-polish.js" defer></script>
<script src="assets/enrollment.js" defer></script>
</body>
</html>
