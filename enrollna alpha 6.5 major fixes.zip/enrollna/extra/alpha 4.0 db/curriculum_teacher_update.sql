-- Run this only if you want to update an existing database manually.
-- The PHP application also adds this column automatically through ensure_enrollment_schema().
ALTER TABLE subjects
    ADD COLUMN IF NOT EXISTS teacher_name VARCHAR(120) NULL DEFAULT NULL AFTER room_number;
