-- EYYSAT Instructor Academic Management
-- Safe to import after the main enrollna database.
CREATE TABLE IF NOT EXISTS teacher_attendance (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, assignment_id INT UNSIGNED NOT NULL, student_id INT NOT NULL,
 attendance_date DATE NOT NULL, status ENUM('Present','Absent','Late','Excused') NOT NULL DEFAULT 'Present',
 remarks VARCHAR(255) DEFAULT NULL, marked_by INT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY(id),
 UNIQUE KEY uq_teacher_attendance(assignment_id,student_id,attendance_date), KEY idx_attendance_assignment_date(assignment_id,attendance_date), KEY idx_attendance_student(student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS teacher_grades (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, assignment_id INT UNSIGNED NOT NULL, student_id INT NOT NULL,
 grading_period VARCHAR(40) NOT NULL DEFAULT 'Final', score DECIMAL(5,2) DEFAULT NULL, remarks VARCHAR(255) DEFAULT NULL,
 updated_by INT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, PRIMARY KEY(id),
 UNIQUE KEY uq_teacher_grade(assignment_id,student_id,grading_period), KEY idx_grade_assignment_period(assignment_id,grading_period), KEY idx_grade_student(student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
