-- EYYSAT Teacher/LMS integration migration
-- Run after the curriculum/faculty database.
-- Safe for existing enrollment data: no DROP statements.

-- EYYSAT LMS / TEACHER PORTAL migration
-- Safe for existing data: no DROP statements.
-- The application also runs equivalent CREATE/ALTER checks automatically.

ALTER TABLE users MODIFY COLUMN role ENUM('admin','cashier','student','teacher') NOT NULL DEFAULT 'student';

CREATE TABLE IF NOT EXISTS teacher_profiles (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 user_id INT NOT NULL,
 employee_number VARCHAR(40) DEFAULT NULL,
 department VARCHAR(120) DEFAULT NULL,
 title VARCHAR(80) DEFAULT 'Instructor',
 contact VARCHAR(30) DEFAULT NULL,
 bio TEXT DEFAULT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (id), UNIQUE KEY uq_teacher_user(user_id), UNIQUE KEY uq_teacher_employee(employee_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS teaching_assignments (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 teacher_id INT NOT NULL,
 subject_id INT NOT NULL,
 section_id INT NOT NULL,
 school_year VARCHAR(20) NOT NULL,
 semester TINYINT UNSIGNED NOT NULL DEFAULT 1,
 status ENUM('Active','Archived') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (id),
 UNIQUE KEY uq_teaching_assignment(teacher_id,subject_id,section_id,school_year,semester),
 KEY idx_assignment_teacher(teacher_id,status),
 KEY idx_assignment_section_subject(section_id,subject_id,status),
 CONSTRAINT fk_assignment_teacher FOREIGN KEY(teacher_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_assignment_subject FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
 CONSTRAINT fk_assignment_section FOREIGN KEY(section_id) REFERENCES sections(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS lms_announcements (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 assignment_id INT UNSIGNED DEFAULT NULL,
 teacher_id INT NOT NULL,
 title VARCHAR(180) NOT NULL,
 body TEXT NOT NULL,
 publish_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 expires_at DATETIME DEFAULT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY(id), KEY idx_lms_announcement_assignment(assignment_id,publish_at), KEY idx_lms_announcement_teacher(teacher_id),
 CONSTRAINT fk_announcement_assignment FOREIGN KEY(assignment_id) REFERENCES teaching_assignments(id) ON DELETE SET NULL,
 CONSTRAINT fk_announcement_teacher FOREIGN KEY(teacher_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS lms_materials (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 assignment_id INT UNSIGNED NOT NULL,
 teacher_id INT NOT NULL,
 title VARCHAR(180) NOT NULL,
 description TEXT DEFAULT NULL,
 file_name VARCHAR(255) NOT NULL,
 file_path VARCHAR(500) NOT NULL,
 mime_type VARCHAR(120) DEFAULT NULL,
 file_size BIGINT UNSIGNED DEFAULT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(id), KEY idx_lms_material_assignment(assignment_id,created_at),
 CONSTRAINT fk_material_assignment FOREIGN KEY(assignment_id) REFERENCES teaching_assignments(id) ON DELETE CASCADE,
 CONSTRAINT fk_material_teacher FOREIGN KEY(teacher_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Account security fields used by temporary teacher accounts.
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS password_expires_at DATETIME NULL DEFAULT NULL;

ALTER TABLE users
  MODIFY COLUMN role ENUM('admin','cashier','student','teacher') NOT NULL DEFAULT 'student';

-- Normalize LMS tables to the same collation used by the legacy enrollment database.
ALTER TABLE teacher_profiles CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
ALTER TABLE teaching_assignments CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
ALTER TABLE lms_announcements CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
ALTER TABLE lms_materials CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
