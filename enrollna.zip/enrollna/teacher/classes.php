<?php
require __DIR__.'/teacher_bootstrap.php';
require_once __DIR__.'/../functions/teacher_academic.php';

$rows = teacher_active_assignments($conn, $teacherId, $schoolYear, $semester);
$sections = [];
while ($r = mysqli_fetch_assoc($rows)) {
    $secId = (int)$r['section_id'];
    if (!isset($sections[$secId])) {
        $sections[$secId] = [
            'section_name' => $r['section_name'],
            'course_code' => $r['course_code'],
            'course_name' => $r['course_name'],
            'students' => []
        ];
    }
}

if (!empty($sections)) {
    $secIds = implode(',', array_keys($sections));
    $q = "SELECT e.section_id, s.student_number, s.first_name, s.middle_name, s.last_name, s.email 
          FROM enrollments e 
          JOIN students s ON s.id = e.student_id 
          WHERE e.section_id IN ($secIds) 
          AND e.school_year = ? 
          AND e.sem = ? 
          AND e.STATUS IN ('Approved','Enrolled')
          ORDER BY s.last_name, s.first_name";
    
    if ($stmt = mysqli_prepare($conn, $q)) {
        mysqli_stmt_bind_param($stmt, 'si', $schoolYear, $semester);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($s = mysqli_fetch_assoc($res)) {
            $sections[(int)$s['section_id']]['students'][] = $s;
        }
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Classes | EYYSAT</title><link rel="stylesheet" href="../css/admin_dashboard.css"><link rel="stylesheet" href="../css/teacher.css"></head>
<body><?php include __DIR__.'/../sidebar/sidebar.php';?><main class="dashboard-main">
<section class="teacher-hero"><div><div class="teacher-eyebrow">Teaching workspace</div><h1>My Classes</h1><p>Your active sections and enrolled students for SY <?=htmlspecialchars($schoolYear)?> · <?=$semester===1?'1st':'2nd'?> Semester.</p></div></section>

<?php if(empty($sections)):?>
<section class="teacher-panel"><div class="teacher-empty">No assignments for the current semester.</div></section>
<?php else: foreach($sections as $secId => $sec): ?>
<section class="teacher-panel" style="margin-bottom: 24px;">
    <div class="teacher-panel-head">
        <div>
            <span class="teacher-class-code" style="color: var(--teacher-gold); font-weight: 800; font-size: 0.9rem; letter-spacing: 0.05em;"><?=htmlspecialchars($sec['course_code'])?></span>
            <h2 style="font-size: 1.5rem; margin: 4px 0 0 0;"><?=htmlspecialchars($sec['section_name'])?></h2>
            <div class="teacher-panel-sub"><?=htmlspecialchars($sec['course_name'])?> · <?=count($sec['students'])?> student(s) enrolled</div>
        </div>
    </div>
    
    <div class="teacher-table-wrap">
        <table class="teacher-table">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Student Number</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($sec['students'])): ?>
                <tr><td colspan="3" class="teacher-empty" style="padding: 30px;">No students enrolled yet.</td></tr>
                <?php else: foreach($sec['students'] as $st): ?>
                <tr>
                    <td><strong><?=htmlspecialchars(trim($st['last_name'].', '.$st['first_name'].' '.$st['middle_name']))?></strong></td>
                    <td><?=htmlspecialchars($st['student_number'])?></td>
                    <td style="color: var(--teacher-muted);"><?=htmlspecialchars($st['email'])?></td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php endforeach; endif; ?>
</main></body></html>
