-- EYYSAT Curriculum Setup
-- Run this in phpMyAdmin after your existing enrollment database/tables are ready.

CREATE TABLE IF NOT EXISTS curriculum (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    course_id INT NOT NULL,
    subject_id INT NOT NULL,
    year_level TINYINT UNSIGNED NOT NULL,
    semester TINYINT UNSIGNED NOT NULL,
    units DECIMAL(4,1) NOT NULL DEFAULT 3.0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_curriculum_subject (course_id, subject_id, year_level, semester),
    KEY idx_curriculum_lookup (course_id, year_level, semester),
    CONSTRAINT chk_curriculum_year CHECK (year_level BETWEEN 1 AND 4),
    CONSTRAINT chk_curriculum_semester CHECK (semester IN (1, 2)),
    CONSTRAINT chk_curriculum_units CHECK (units > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- EXAMPLE DATA
-- Replace the subject codes below with the subjects that already
-- exist in your subjects table.
--
-- Example: put IT123 in BSIT 1st Year / 1st Semester.
-- The course_id and subject_id are looked up automatically.
-- ------------------------------------------------------------

-- INSERT INTO curriculum (course_id, subject_id, year_level, semester, units)
-- SELECT c.id, s.id, 1, 1, 3
-- FROM courses c
-- JOIN subjects s ON s.course_id = c.id
-- WHERE c.course_code = 'BSIT'
--   AND s.subject_code = 'IT123'
-- LIMIT 1;

-- Add more subjects using the same pattern.

-- Example for a complete first semester:
-- INSERT INTO curriculum (course_id, subject_id, year_level, semester, units)
-- SELECT c.id, s.id, 1, 1, 3
-- FROM courses c
-- JOIN subjects s ON s.course_id = c.id
-- WHERE c.course_code = 'BSIT'
--   AND s.subject_code IN ('IT123', 'IT124', 'GE101', 'GE102');

-- Verify the curriculum:
-- SELECT
--     c.course_code,
--     cu.year_level,
--     cu.semester,
--     s.subject_code,
--     s.subject_name,
--     cu.units
-- FROM curriculum cu
-- JOIN courses c ON c.id = cu.course_id
-- JOIN subjects s ON s.id = cu.subject_id
-- ORDER BY c.course_code, cu.year_level, cu.semester, s.subject_code;
