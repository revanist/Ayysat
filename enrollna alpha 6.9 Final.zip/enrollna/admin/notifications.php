<?php
require_once __DIR__ . '/../functions/admin_auth.php';
require_admin_login();
require __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
ensure_enrollment_schema($conn);

// Opening the Admin notification center acknowledges all Admin notifications.
// Cashier notifications remain unread because their read state is independent.
mysqli_query($conn, "UPDATE admin_notifications SET admin_is_read = 1 WHERE admin_is_read = 0");

$notifications = [];
$result = mysqli_query($conn, "
    SELECT n.id, n.enrollment_id, n.message, n.admin_is_read AS is_read, n.created_at,
           CONCAT(COALESCE(s.first_name,''), ' ', COALESCE(s.last_name,'')) AS student_name,
           e.payment_method, e.payment_reference, e.cash_amount_requested, e.payment_status, e.status
    FROM admin_notifications n
    LEFT JOIN enrollments e ON e.id = n.enrollment_id
    LEFT JOIN students s ON s.id = e.student_id
    ORDER BY n.created_at DESC, n.id DESC
    LIMIT 100
");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) $notifications[] = $row;
}

$unread = 0;
foreach ($notifications as $n) if ((int)$n['is_read'] === 0) $unread++;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Notifications – EYYSAT</title>
<link rel="stylesheet" href="../css/admin_dashboard.css">
<style>
.notifications-main{padding:clamp(16px,3vw,32px);max-width:none;margin:0;width:100%;box-sizing:border-box}
.notification-header,.notification-card,.notification-empty{width:100%;max-width:1200px;margin-left:auto;margin-right:auto;box-sizing:border-box}
.notification-header{margin-bottom:22px}
.notification-card{margin-bottom:12px}
.notification-empty{margin-top:0}
.notification-header{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}
.notification-header h1{margin:0;font-size:clamp(22px,3vw,28px)}
.notification-count{font-size:13px;padding:7px 12px;border-radius:999px;background:#eef5fb;color:#1e5a96;font-weight:700;white-space:nowrap}
.notification-card{background:#fff;border:1px solid #e5eaf0;border-radius:16px;padding:18px 20px;margin-bottom:12px;box-shadow:0 4px 16px rgba(13,59,102,.05);transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease;overflow:hidden}
.notification-card.unread{border-left:4px solid #1e5a96;background:#f8fbff}
.notification-card:hover{transform:translateY(-1px);box-shadow:0 7px 20px rgba(13,59,102,.08)}
.notification-top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px}
.notification-message{font-weight:700;color:#18344e;line-height:1.45;overflow-wrap:anywhere}
.notification-top small{flex:0 0 auto;white-space:nowrap}
.notification-meta{margin-top:8px;color:#6b7785;font-size:13px;line-height:1.6;overflow-wrap:anywhere}
.notification-actions{margin-top:12px;display:flex;gap:8px;flex-wrap:wrap}
.notification-actions a{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border-radius:9px;padding:9px 12px;background:#1e5a96;color:#fff;font-size:13px;font-weight:700;min-height:38px;box-sizing:border-box}
.notification-actions a:hover{filter:brightness(.95)}
.notification-empty{padding:50px 20px;text-align:center;background:#fff;border:1px dashed #ccd7e2;border-radius:16px;color:#718096}
.sidebar-notification-badge{margin-left:auto;min-width:22px;height:22px;padding:0 6px;border-radius:999px;background:#dc3545;color:#fff;font-size:11px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}
@media(max-width:768px){
  .notifications-main{padding:16px 12px}
  .notification-header{align-items:flex-start;margin-bottom:16px}
  .notification-header>div{min-width:0;flex:1 1 100%}
  .notification-top{display:block}
  .notification-top small{display:block;margin-top:7px;font-size:12px}
  .notification-card{padding:15px;border-radius:13px;margin-bottom:10px}
  .notification-card.unread{border-left-width:3px}
  .notification-actions{display:grid;grid-template-columns:1fr;gap:7px}
  .notification-actions a{width:100%}
}
@media(max-width:420px){
  .notification-header h1{font-size:22px}
  .notification-count{font-size:12px;padding:6px 10px}
  .notification-message{font-size:14px}
  .notification-meta{font-size:12px}
}
</style>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/navbar_layout.php'; ?>
<main class="dashboard-main notifications-main">
  <div class="notification-header"><div><h1>Notifications</h1><p class="text-muted mb-0">Enrollment and payment activity received by the administration.</p></div><span class="notification-count"><?= $unread ?> unread</span></div>
  <?php if (!$notifications): ?>
    <div class="notification-empty"><h3>No notifications yet</h3><p>New enrollment payment submissions will appear here automatically.</p></div>
  <?php else: foreach ($notifications as $n): ?>
    <article class="notification-card<?= (int)$n['is_read'] === 0 ? ' unread' : '' ?>">
      <div class="notification-top"><div class="notification-message"><?= htmlspecialchars($n['message']) ?></div><small class="text-muted"><?= htmlspecialchars(date('M d, Y h:i A', strtotime($n['created_at']))) ?></small></div>
      <div class="notification-meta">Student: <strong><?= htmlspecialchars(trim($n['student_name'])) ?></strong> · Enrollment #<?= (int)$n['enrollment_id'] ?> · Payment: <?= htmlspecialchars(ucfirst((string)$n['payment_status'])) ?> · Enrollment: <?= htmlspecialchars(ucfirst((string)$n['status'])) ?></div>
      <div class="notification-actions"><a href="student_info.php?id=<?= (int)$n['enrollment_id'] ?>">View Record</a></div>
    </article>
  <?php endforeach; endif; ?>
</main>
<script src="../js/bootstrap.bundle.js"></script>
</body>
</html>
