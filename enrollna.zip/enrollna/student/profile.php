<?php
require_once __DIR__ . '/../functions/student_auth.php';
require_student_login();

include '../db/dbconn.php';
require_once '../functions/student_data.php';
require_once '../functions/enrollment_setup.php';

ensure_enrollment_schema($conn);
seed_course_data($conn);

$user_id = (int) $_SESSION['user_id'];
$student = get_student_profile($conn, $user_id);

if (!$student) {
    http_response_code(404);
    exit('Student profile not found.');
}

$enrollment = get_student_latest_enrollment($conn, (int) $student['id']) ?: [];


$subject_query = mysqli_query($conn, "
    SELECT
        subjects.subject_code,
        subjects.subject_name,
        subjects.schedule_day,
        subjects.schedule_time,
        subjects.room_number
    FROM enrollment_details
    LEFT JOIN enrollments ON enrollments.id = enrollment_details.enrollment_id
    LEFT JOIN subjects    ON subjects.id    = enrollment_details.subject_id
    WHERE enrollments.student_id = " . (int) $student['id'] . "
    ORDER BY subjects.subject_code ASC
");

$selected_subjects = [];
while ($subject = mysqli_fetch_assoc($subject_query)) {
    $selected_subjects[] = $subject;
}

// Determine if Pay Now button should show.
// Students may submit payment only after the Registrar approves the enrollment.
// request_payment.php also enforces the same rule server-side.
// Hide payment when there is no approved enrollment, the balance is settled,
// or the latest payment is already fully paid.
$enrollmentStatus = strtolower(trim((string) ($enrollment['STATUS'] ?? $enrollment['status'] ?? '')));
$paymentStatus = strtolower(trim((string) ($enrollment['payment_status'] ?? $student['payment_status'] ?? '')));
$canPay = (
    !empty($enrollment['id']) &&
    in_array($enrollmentStatus, ['approved', 'enrolled'], true) &&
    $paymentStatus !== 'paid' &&
    ((float) ($student['remaining_balance'] ?? 0)) > 0
);
$storedEnrollmentStatus = trim((string) ($enrollment['STATUS'] ?? $enrollment['status'] ?? ''));
$displayEnrollmentStatus = (
    in_array(strtolower($enrollment['STATUS'] ?? $enrollment['status'] ?? ''), ['approved', 'enrolled'], true) &&
    strtolower($enrollment['payment_status'] ?? '') === 'paid'
) ? 'Enrolled' : ($storedEnrollmentStatus !== '' ? $storedEnrollmentStatus : ($student['enrollment_status'] ?? 'Not Submitted'));

$csrf = student_csrf_token();

$remainingBalance = (float) ($student['remaining_balance'] ?? 0);
$isPending = strtolower($enrollmentStatus) === 'pending';
$isFullyPaid = !$isPending && ($remainingBalance <= 0 || strtolower($enrollment['payment_status'] ?? '') === 'paid');

if (!$isFullyPaid && $canPay) {
    if (empty($_SESSION['student_payment_reference'])) {
        $_SESSION['student_payment_reference'] = generate_payment_reference($conn);
    }
    $studentPaymentReference = (string) $_SESSION['student_payment_reference'];
} else {
    $studentPaymentReference = '';
}

// Payment notification from redirect
$paymentMsg = '';
if (isset($_GET['payment'])) {
    if ($_GET['payment'] === 'success') {
        $paymentMsg = 'success';
    } elseif ($_GET['payment'] === 'failed') {
        $paymentMsg = 'failed';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>My Profile – Eyysat</title>
    <link rel="stylesheet" href="../css/all.min.css">
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/student_profile.css">
    <script src="../js/sweetalert2.all.min.js"></script>
    <style>
        /* Profile payment UI */
        .pay-balance-btn, .btn-payment {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 18px;
            border-radius: 10px;
            background: var(--academy-blue, #0d3b66);
            color: #fff !important;
            text-decoration: none;
            font-weight: 700;
            font-size: .9rem;
            border: 0;
            cursor: pointer;
            transition: transform .18s ease, opacity .18s ease, box-shadow .18s ease;
        }
        .pay-balance-btn:hover, .btn-payment:hover { opacity: .92; transform: translateY(-1px); }
        .fully-paid-label { color: #16803c; font-weight: 800; }
        .payment-card-content { display:flex; align-items:center; justify-content:space-between; gap:24px; flex-wrap:wrap; }
        .payment-card-content p { margin: 5px 0 0; color:#667085; }
        .payment-help { display:block; margin-top:6px; color:#667085; }

        /* Improved student payment window */
        .payment-window {
            width: min(500px, calc(100% - 24px));
            margin: 24px auto 12px;
            background: #fff;
            border: 1px solid #d1d5db;
            border-radius: 12px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,.10), 0 10px 10px -5px rgba(0,0,0,.04);
            overflow: hidden;
            box-sizing: border-box;
        }
        .payment-window[hidden] { display:none !important; }
        .payment-window-form {
            width:100%; box-sizing:border-box; padding:0;
            color:#111827 !important; background:#fff !important;
            font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif !important;
            font-size:15px; line-height:1.5;
        }
        .payment-window-form * { box-sizing:border-box; }
        .payment-modal-header {
            padding:24px 30px;
            border-bottom:1px solid #d1d5db;
            position:relative;
            background:#fff;
        }
        .payment-modal-header .payment-kicker {
            display:block; font-size:12px; font-weight:700; color:#1d4ed8 !important;
            text-transform:uppercase; letter-spacing:.5px; margin-bottom:4px;
        }
        .payment-modal-header h3 {
            margin:0 42px 8px 0; font-size:22px; color:#111827 !important; line-height:1.25;
        }
        .payment-modal-header p { margin:0; font-size:14px; color:#6b7280 !important; }
        .payment-modal-header p strong { color:#111827 !important; }
        .payment-close {
            position:absolute; top:24px; right:24px; width:32px; height:32px;
            background:#f3f4f6; border:0; border-radius:6px; font-size:20px;
            cursor:pointer; color:#6b7280 !important; display:flex; align-items:center; justify-content:center;
            transition:background .2s,color .2s;
        }
        .payment-close:hover { background:#e5e7eb; color:#111827 !important; }
        .payment-modal-body { padding:24px 30px; display:flex; flex-direction:column; gap:20px; }
        .payment-method-grid { display:grid; grid-template-columns:1fr; gap:10px; margin:0; }
        .payment-method {
            border:2px solid #1d4ed8; background:#eff6ff; border-radius:8px; padding:16px;
            display:flex; align-items:center; gap:12px; cursor:default; position:relative;
        }
        .payment-method .method-icon {
            width:32px; height:32px; margin:0; background:#1d4ed8; color:#fff; border-radius:6px;
            display:flex; align-items:center; justify-content:center; font-weight:700; font-size:13px;
        }
        .payment-method .method-details strong { display:block; font-size:15px; color:#111827 !important; }
        .payment-method .method-details span { display:block; font-size:13px; color:#6b7280 !important; }
        .payment-method .method-check { position:absolute; right:16px; top:50%; transform:translateY(-50%); color:#1d4ed8; font-weight:800; }
        .payment-field { margin:0; display:flex; flex-direction:column; gap:6px; }
        .payment-field label { font-size:14px; font-weight:600; color:#111827 !important; margin:0; }
        .payment-field .helper-text, .payment-field small { font-size:12px; color:#6b7280 !important; margin:0; }
        .payment-input-wrap { position:relative; display:flex; align-items:center; width:100%; }
        .payment-input-wrap .currency-symbol {
            position:absolute; left:16px; color:#111827; font-weight:600; font-size:16px; z-index:1;
        }
        .payment-field input {
            display:block; width:100% !important; min-height:46px; padding:12px 16px;
            border:1px solid #d1d5db !important; border-radius:8px !important; font-size:16px;
            color:#111827 !important; background:#fff !important; outline:none; transition:border-color .2s,box-shadow .2s;
            box-shadow:none !important; font-weight:400; -webkit-text-fill-color:#111827 !important; opacity:1 !important;
        }
        .payment-input-wrap input.has-currency { padding-left:40px; }
        .payment-field input:focus { border-color:#1d4ed8 !important; box-shadow:0 0 0 3px rgba(29,78,216,.10) !important; }
        .payment-field input:hover { border-color:#9ca3af !important; }
        .payment-field input::placeholder { color:#6b7280 !important; opacity:1 !important; -webkit-text-fill-color:#6b7280 !important; }
        .payment-field input[readonly] { background:#f3f4f6 !important; font-family:monospace !important; font-size:14px; font-weight:600; }
        .quick-amounts { display:flex; gap:8px; margin-top:2px; flex-wrap:wrap; }
        .quick-amounts button {
            background:#f3f4f6; border:1px solid #d1d5db; border-radius:4px; padding:5px 9px;
            font-size:12px; color:#111827; cursor:pointer; transition:all .2s;
        }
        .quick-amounts button:hover { background:#fff; border-color:#1d4ed8; color:#1d4ed8; }
        .reference-box {
            display:flex; align-items:center; justify-content:space-between; gap:10px;
            background:#f3f4f6; border:1px solid #d1d5db; border-radius:8px; padding:12px 16px;
        }
        .reference-box code { font-family:monospace; font-size:14px; color:#111827; background:transparent; font-weight:600; overflow-wrap:anywhere; }
        .copy-btn {
            flex:0 0 auto; background:#fff; border:1px solid #d1d5db; border-radius:4px; padding:5px 10px;
            font-size:12px; font-weight:600; color:#111827; cursor:pointer; transition:all .2s;
        }
        .copy-btn:hover { background:#1d4ed8; color:#fff; border-color:#1d4ed8; }
        .payment-modal-actions {
            padding:20px 30px; background:#f9fafb; border-top:1px solid #d1d5db;
            display:flex; justify-content:flex-end; gap:12px;
        }
        .payment-modal-actions .btn {
            padding:10px 20px; min-height:42px; border-radius:8px; font-size:14px; font-weight:600;
            cursor:pointer; transition:all .2s; border:none;
        }
        .payment-modal-actions .btn-secondary { background:#fff; border:1px solid #d1d5db; color:#111827 !important; }
        .payment-modal-actions .btn-secondary:hover { background:#f3f4f6; }
        .payment-modal-actions .btn-payment { background:#1d4ed8 !important; color:#fff !important; box-shadow:0 2px 4px rgba(29,78,216,.2); border:0 !important; }
        .payment-modal-actions .btn-payment:hover { background:#1e40af !important; }
        @media (max-width:700px) {
            .payment-window { width:calc(100% - 16px); margin-top:16px; }
            .payment-modal-header { padding:20px 20px; }
            .payment-modal-body { padding:20px; }
            .payment-modal-actions { padding:18px 20px; flex-direction:column-reverse; }
            .payment-modal-actions .btn { width:100%; }
        }
        @media (max-width:420px) {
            .payment-window { width:calc(100% - 8px); border-radius:10px; }
            .payment-modal-header { padding:18px 16px; }
            .payment-modal-header h3 { font-size:20px; }
            .payment-modal-body { padding:18px 16px; gap:18px; }
            .payment-modal-actions { padding:16px; }
            .reference-box { align-items:flex-start; }
            .reference-box code { min-width:0; }
        }
    </style>
<link rel="stylesheet" href="../css/ux-polish.css">
<script src="../js/ux-polish.js" defer></script>
</head>

<body class="profile-page">

    <?php include __DIR__ . '/../sidebar/sidebar.php'; ?>

    <main class="dashboard-main">

        <!-- HERO -->
        <div class="hero">
            <div class="welcome">
                <span class="eyebrow">🎓 Student Portal</span>
                <h1>Student Profile</h1>
                <p>Your complete student record, enrollment progress, and account details.</p>

                <div class="student-id">
                    <?php if (!empty($student['profile_picture'])): ?>
                        <div class="student-avatar">
                            <img src="../uploads/<?= htmlspecialchars($student['profile_picture']) ?>"
                                alt="Profile Picture">
                        </div>
                    <?php else: ?>
                        <div class="student-avatar">
                            <i class="fa-solid fa-user"></i>
                        </div>
                    <?php endif; ?>
                    <div>
                        <strong><?= htmlspecialchars($student['student_number'] ?? 'Pending') ?></strong>
                        <span>Student Number</span>
                    </div>
                </div>
            </div>

            <div class="hero-stats">
                <div class="mini-stat">
                    <h3>Course</h3>
                    <span><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></span>
                </div>

                <div class="mini-stat balance-mini-stat">
                    <h3><?= $isPending ? 'Payment Status' : ($isFullyPaid ? 'Payment Status' : 'Balance') ?></h3>
                    <?php if ($isPending): ?>
                        <span class="fully-paid-label" style="color:#f59e0b;">Awaiting Assessment</span>
                    <?php elseif ($isFullyPaid): ?>
                        <span class="fully-paid-label">Fully Paid</span>
                    <?php else: ?>
                        <span>₱<?= number_format($remainingBalance, 2) ?></span>
                    <?php endif; ?>
                </div>

                <div class="mini-stat">
                    <h3>Status</h3>
                    <span><?= htmlspecialchars($displayEnrollmentStatus) ?></span>
                </div>
            </div>
        </div>

        <!-- PAYMENT NOTIFICATION -->
        <?php if ($paymentMsg === 'success'): ?>
            <div class="alert-banner alert-success">
                🎉 <strong>Payment successful!</strong> Your enrollment fee has been received.
                Your account will be updated shortly.
            </div>
        <?php elseif ($paymentMsg === 'failed'): ?>
            <div class="alert-banner alert-danger">
                ⚠️ <strong>Payment was not completed.</strong> Please try again or contact the cashier.
            </div>
        <?php endif; ?>

        <!-- CARDS GRID -->
        <div class="analytics-grid">

            <!-- Academic Information -->
            <div class="card">
                <h3>Academic Information</h3>

                <dl class="info-list">
                    <div>
                        <dt>Student No.</dt>
                        <dd><?= htmlspecialchars($student['student_number'] ?? 'Pending') ?></dd>
                    </div>
                    <div>
                        <dt>Course</dt>
                        <dd><?= htmlspecialchars($student['course_name'] ?? 'Not selected') ?></dd>
                    </div>
                    <div>
                        <dt>Course Code</dt>
                        <dd><?= htmlspecialchars($student['course_code'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Year Level</dt>
                        <dd><?= htmlspecialchars($student['year_level'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Birthdate</dt>
                        <dd><?= htmlspecialchars($student['birthdate'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Sex</dt>
                        <dd><?= htmlspecialchars($student['sex'] ?? 'N/A') ?></dd>
                    </div>
                    <div>
                        <dt>Section</dt>
                        <dd><?= htmlspecialchars($student['section_name'] ?? 'Not assigned yet') ?></dd>
                    </div>
                </dl>

                <div style="margin-top:1.5rem;">
                    <h3>Registration Form</h3>
                    <p style="color:#666;margin-bottom:.75rem;">View your official submitted registration details.</p>
                    <a id="viewRegistrationFormBtn" href="registration_form_view.php" class="btn btn-doc">
                        📄 View Registration Form
                    </a>
                </div>
            </div>

            <!-- Payment -->
            <div class="card payment-card" id="payment" style="grid-column: 1 / -1;">
                <div class="payment-card-content">
                    <div>
                        <h3>Payment</h3>
                        <?php if ($isPending): ?>
                            <p>Your enrollment is <strong>awaiting assessment</strong>. You can make a payment once it's approved.</p>
                        <?php elseif ($isFullyPaid): ?>
                            <p>You have <strong>no pending balance</strong>. Your account is fully paid.</p>
                        <?php else: ?>
                            <p>Your remaining balance is <strong>₱<?= number_format($remainingBalance, 2) ?></strong>.</p>
                            <small class="payment-help">Choose Maya Checkout and enter the amount you want to pay.</small>
                        <?php endif; ?>
                    </div>
                    <?php if (!$isFullyPaid && !$isPending && $canPay): ?>
                        <a href="../payment/index.php" class="btn btn-payment" style="text-decoration:none; display:inline-block; text-align:center;">💳 Pay Now</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Enrollment Status -->
            <div class="card" id="enrollment" style="grid-column: 1 / -1;">
                <h3>Enrollment Status</h3>

                <div class="status-summary">
                    <div class="status-item">
                        <span>Application</span>
                        <strong class="<?= in_array(strtolower($displayEnrollmentStatus), ['approved', 'enrolled'], true) ? 'text-success' : (strtolower($displayEnrollmentStatus) === 'rejected' ? 'text-danger' : 'text-warning') ?>">
                            <?= htmlspecialchars($displayEnrollmentStatus) ?>
                        </strong>
                    </div>
                    <div class="status-item">
                        <span>Payment</span>
                        <strong class="<?= strtolower($enrollment['payment_status'] ?? '') === 'paid' ? 'text-success' : 'text-warning' ?>">
                            <?= htmlspecialchars($enrollment['payment_status'] ?? $student['payment_status'] ?? 'Pending') ?>
                        </strong>
                    </div>
                    <div class="status-item">
                        <span>School Year</span>
                        <strong><?= htmlspecialchars($enrollment['school_year'] ?? 'N/A') ?></strong>
                    </div>
                    <div class="status-item">
                        <span>Semester</span>
                        <strong><?= htmlspecialchars($enrollment['sem'] ?? 'N/A') ?></strong>
                    </div>
                </div>

            </div>

        </div>

    </main>

    <!-- PAYMENT ERROR TOAST -->
    <div id="payErrorToast" style="
        display:none; position:fixed; bottom:24px; right:24px;
        background:#ef4444; color:#fff; padding:14px 20px;
        border-radius:12px; box-shadow:0 4px 20px rgba(0,0,0,.25);
        font-weight:600; z-index:9999; max-width:340px;">
    </div>

    <script>
        /* ── Back-button / tab security ─────────────────────────── */
        window.addEventListener('pageshow', function(e) {
            if (e.persisted) window.location.reload();
        });

        document.querySelectorAll('#viewRegistrationFormBtn').forEach(function(link) {
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const url = link.href;
                Swal.fire({
                    title: 'Preparing registration form',
                    text: 'Please wait a moment…',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    didOpen: function() {
                        Swal.showLoading();
                    }
                });
                window.setTimeout(function() {
                    window.location.href = url;
                }, 900);
            });
        });

        /* ── Student payment form helpers ───────────────────────── */
        function showPayError(msg) {
            const toast = document.getElementById('payErrorToast');
            toast.textContent = msg;
            toast.style.display = 'block';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 5000);
        }

        function openPaymentModal() {
            const windowEl = document.getElementById('paymentWindow');
            const amount = document.getElementById('paymentAmount');
            const reference = document.getElementById('paymentReference');
            const max = <?= json_encode($remainingBalance) ?>;

            if (!windowEl) return;
            if (amount) {
                amount.max = max.toFixed(2);
                if (!amount.value || Number(amount.value) > max) amount.value = '0';
            }
            if (reference) reference.value = '<?= htmlspecialchars($studentPaymentReference, ENT_QUOTES) ?>';
            windowEl.hidden = false;
            windowEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        function closePaymentModal() {
            const windowEl = document.getElementById('paymentWindow');
            if (windowEl) windowEl.hidden = true;
        }

        const paymentAmountInput = document.getElementById('paymentAmount');
        paymentAmountInput?.addEventListener('focus', function() {
            if (this.value === '0') this.value = '';
        });
        paymentAmountInput?.addEventListener('blur', function() {
            if (this.value.trim() === '') this.value = '0';
        });

        document.querySelectorAll('[data-quick-amount]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                const input = document.getElementById('paymentAmount');
                if (!input) return;
                const max = Number(input.max || 0);
                const choice = this.getAttribute('data-quick-amount');
                input.value = (choice === 'full' ? max : Math.min(Number(choice), max)).toFixed(2);
                input.focus();
            });
        });

        document.getElementById('copyPaymentReference')?.addEventListener('click', async function() {
            const ref = document.getElementById('paymentReference')?.value || '';
            if (!ref) return;
            try {
                await navigator.clipboard.writeText(ref);
                const original = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => this.textContent = original, 1400);
            } catch (e) {
                const fallback = document.createElement('textarea');
                fallback.value = ref; document.body.appendChild(fallback); fallback.select();
                document.execCommand('copy'); fallback.remove();
                this.textContent = 'Copied!';
                setTimeout(() => this.textContent = 'Copy', 1400);
            }
        });

        document.getElementById('customPaymentForm')?.addEventListener('submit', function(event) {
            const amountInput = document.getElementById('paymentAmount');
            const amount = Number(amountInput?.value || 0);
            const max = Number(amountInput?.max || 0);
            if (!Number.isFinite(amount) || amount <= 0) {
                event.preventDefault();
                showPayError('Enter a valid payment amount.');
                return;
            }
            if (amount > max + 0.00001) {
                event.preventDefault();
                amountInput.value = max.toFixed(2);
                showPayError('Payment cannot exceed your remaining balance of ₱' + max.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2}) + '.');
                return;
            }
            if (reference) reference.readOnly = true;
        });

        /* ── Profile Image Preview ──────────────────────────────── */
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('pic_preview');
                    const placeholder = document.getElementById('pic_placeholder');
                    if (preview) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    }
                    if (placeholder) {
                        placeholder.style.display = 'none';
                    }
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script>
        <?php if (isset($_GET['error'])): ?>
            let errMsg = '';
            switch('<?= htmlspecialchars($_GET['error']) ?>') {
                case 'email_taken': errMsg = 'That email address is already in use by another account.'; break;
                case 'invalid_current_password': errMsg = 'The current password you entered is incorrect.'; break;
                case 'password_mismatch': errMsg = 'New password and confirm password do not match.'; break;
                case 'short_password': errMsg = 'Your new password must be at least 8 characters long.'; break;
                case 'incomplete_password': errMsg = 'Please fill out all password fields to change your password.'; break;
                default: errMsg = 'An error occurred while updating your profile.';
            }
            Swal.fire({
                icon: 'error',
                title: 'Update Failed',
                text: errMsg,
                confirmButtonColor: '#0d3b66'
            });
        <?php elseif (isset($_GET['success'])): ?>
            Swal.fire({
                icon: 'success',
                title: 'Profile Updated',
                text: 'Your profile has been updated successfully.',
                confirmButtonColor: '#16803c'
            });
            // Clean URL
            window.history.replaceState({}, document.title, window.location.pathname);
        <?php endif; ?>
    </script>
</body>

</html>
