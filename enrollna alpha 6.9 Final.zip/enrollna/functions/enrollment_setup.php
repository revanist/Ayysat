<?php
require_once __DIR__ . '/session_security.php';


/**
 * EYYSAT ENROLLMENT SETUP
 *
 * This file makes sure the additional enrollment-related
 * columns exist and provides the initial course/section/subject
 * seed data.
 */

function ensure_enrollment_schema(mysqli $conn): void
{
    $tables = [];

    $tables['students'] = [
        [
            'name' => 'section_id',
            'definition' => 'INT NULL DEFAULT NULL'
        ],
        [
            'name' => 'profile_picture',
            'definition' => 'VARCHAR(255) NULL DEFAULT NULL'
        ],
        [
            'name' => 'remaining_balance',
            'definition' => 'DECIMAL(10,2) NULL DEFAULT 0.00'
        ],
    ];

    $tables['subjects'] = [
        [
            'name' => 'section_id',
            'definition' => 'INT NULL DEFAULT NULL'
        ],
        [
            'name' => 'schedule_day',
            'definition' => 'VARCHAR(20) NULL DEFAULT NULL'
        ],
        [
            'name' => 'schedule_time',
            'definition' => 'VARCHAR(50) NULL DEFAULT NULL'
        ],
        [
            'name' => 'room_number',
            'definition' => 'VARCHAR(20) NULL DEFAULT NULL'
        ],
        [
            'name' => 'teacher_name',
            'definition' => 'VARCHAR(120) NULL DEFAULT NULL'
        ],
        [
            'name' => 'is_available',
            'definition' => 'TINYINT(1) NOT NULL DEFAULT 1'
        ],
    ];

    $tables['enrollments'] = [
        [
            'name' => 'paymongo_link_id',
            'definition' => 'VARCHAR(100) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_method',
            'definition' => 'VARCHAR(50) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_option',
            'definition' => 'VARCHAR(50) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_reference',
            'definition' => 'VARCHAR(100) NULL DEFAULT NULL'
        ],
        [
            'name' => 'amount_paid',
            'definition' => 'DECIMAL(10,2) NULL DEFAULT 0.00'
        ],
        [
            'name' => 'cash_amount_requested',
            'definition' => 'DECIMAL(10,2) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_account',
            'definition' => 'VARCHAR(100) NULL DEFAULT NULL'
        ],
        [
            'name' => 'payment_proof',
            'definition' => 'VARCHAR(255) NULL DEFAULT NULL'
        ],
    ];

    foreach ($tables as $table => $columns) {

        $result = mysqli_query($conn, "SHOW COLUMNS FROM `$table`");

        if (!$result) {
            continue;
        }

        $existing = [];

        while ($row = mysqli_fetch_assoc($result)) {
            $existing[] = $row['Field'];
        }

        foreach ($columns as $column) {

            if (!in_array($column['name'], $existing, true)) {

                mysqli_query(
                    $conn,
                    "ALTER TABLE `$table`
                     ADD COLUMN `{$column['name']}`
                     {$column['definition']}"
                );
            }
        }
    }

    /*
     * Older installations use restrictive ENUM columns.  Cashier-confirmed
     * enrollments and down payments need explicit Enrolled and Partial states.
     */
    mysqli_query(
        $conn,
        "ALTER TABLE enrollments
         MODIFY COLUMN STATUS ENUM('Pending', 'Approved', 'Rejected', 'Enrolled')
         NOT NULL DEFAULT 'Pending'"
    );
    mysqli_query(
        $conn,
        "ALTER TABLE enrollments
         MODIFY COLUMN payment_status ENUM('Paid', 'Pending', 'Unpaid', 'Partial')
         NOT NULL DEFAULT 'Pending'"
    );
    mysqli_query(
        $conn,
        "ALTER TABLE students
         MODIFY COLUMN payment_status ENUM('Paid', 'Pending', 'Unpaid', 'Partial')
         NOT NULL DEFAULT 'Pending'"
    );

    /* Repair empty ENUM values written before the expanded status migration. */
    mysqli_query(
        $conn,
        "UPDATE enrollments
         SET STATUS = 'Enrolled'
         WHERE STATUS = ''
           AND COALESCE(amount_paid, 0) > 0
           AND cash_amount_requested IS NULL"
    );
    mysqli_query(
        $conn,
        "UPDATE students s
         INNER JOIN enrollments e ON e.student_id = s.id
         SET s.payment_status = CASE
                 WHEN COALESCE(e.amount_paid, 0) >= 20000 THEN 'Paid'
                 ELSE 'Partial'
             END,
             s.enrollment_status = 'Enrolled'
         WHERE s.payment_status = ''
           AND e.STATUS = 'Enrolled'
           AND COALESCE(e.amount_paid, 0) > 0
           AND e.cash_amount_requested IS NULL"
    );
    mysqli_query(
        $conn,
        "UPDATE enrollments
         SET payment_status = CASE
             WHEN COALESCE(amount_paid, 0) >= 20000 THEN 'Paid'
             ELSE 'Partial'
         END
         WHERE payment_status = ''
           AND COALESCE(amount_paid, 0) > 0
           AND cash_amount_requested IS NULL"
    );

    /*
     * Cashier alerts are persisted so a payment submitted while no admin is
     * online is still shown the next time the cashier page is opened.
     */
    mysqli_query(
        $conn,
        "
        CREATE TABLE IF NOT EXISTS admin_notifications (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            enrollment_id INT NOT NULL,
            message VARCHAR(255) NOT NULL,
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_admin_notifications_unread (is_read, created_at),
            KEY idx_admin_notifications_enrollment (enrollment_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        "
    );

    /*
     * Notifications have separate read states for Admin and Cashier.
     * The legacy is_read column is retained for backward compatibility,
     * while these columns prevent one portal from clearing the other's badge.
     */
    foreach ([
        'admin_is_read' => "ALTER TABLE admin_notifications ADD COLUMN admin_is_read TINYINT(1) NOT NULL DEFAULT 0 AFTER is_read",
        'cashier_is_read' => "ALTER TABLE admin_notifications ADD COLUMN cashier_is_read TINYINT(1) NOT NULL DEFAULT 0 AFTER admin_is_read"
    ] as $column => $alterSql) {
        $columnEscaped = mysqli_real_escape_string($conn, $column);
        $check = mysqli_query($conn, "SHOW COLUMNS FROM admin_notifications LIKE '$columnEscaped'");
        if ($check && mysqli_num_rows($check) === 0) {
            mysqli_query($conn, $alterSql);
        }
        if ($check) mysqli_free_result($check);
    }
    mysqli_query($conn, "UPDATE admin_notifications SET admin_is_read = CASE WHEN is_read = 1 THEN 1 ELSE admin_is_read END, cashier_is_read = CASE WHEN is_read = 1 THEN 1 ELSE cashier_is_read END");

    /*
     * Make sure the curriculum table exists.
     *
     * Your database already contains this table, but this makes
     * the application safe if it is installed on a fresh database.
     */
    mysqli_query(
        $conn,
        "
        CREATE TABLE IF NOT EXISTS curriculum (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            course_id INT NOT NULL,
            subject_id INT NOT NULL,
            year_level TINYINT UNSIGNED NOT NULL,
            semester TINYINT UNSIGNED NOT NULL,
            units DECIMAL(4,1) NOT NULL DEFAULT 3.0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

            PRIMARY KEY (id),

            UNIQUE KEY uq_curriculum_subject
                (course_id, subject_id, year_level, semester),

            KEY idx_curriculum_lookup
                (course_id, year_level, semester)
        )
        ENGINE=InnoDB
        DEFAULT CHARSET=utf8mb4
        COLLATE=utf8mb4_unicode_ci
        "
    );
}


/**
 * Seed courses, sections and subjects only when necessary.
 *
 * Existing records are preserved.
 */
function seed_course_data(mysqli $conn): void
{
    $courseCountResult = mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total FROM courses"
    );

    if (!$courseCountResult) {
        return;
    }

    $courseCount = (int) mysqli_fetch_assoc($courseCountResult)['total'];

    if ($courseCount === 0) {

        $courses = [
            [
                'course_code' => 'BSIT',
                'course_name' => 'Bachelor of Science in Information Technology'
            ],
            [
                'course_code' => 'BEED',
                'course_name' => 'Bachelor of Elementary Education'
            ],
            [
                'course_code' => 'BSED',
                'course_name' => 'Bachelor of Secondary Education'
            ],
        ];

        foreach ($courses as $course) {

            $stmt = mysqli_prepare(
                $conn,
                "
                INSERT INTO courses
                (
                    course_code,
                    course_name
                )
                VALUES (?, ?)
                "
            );

            mysqli_stmt_bind_param(
                $stmt,
                'ss',
                $course['course_code'],
                $course['course_name']
            );

            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }

    $courses = mysqli_query(
        $conn,
        "SELECT id, course_code FROM courses ORDER BY id ASC"
    );

    if (!$courses) {
        return;
    }

    while ($course = mysqli_fetch_assoc($courses)) {

        $courseId = (int) $course['id'];
        $courseCode = (string) $course['course_code'];

        /*
         * SECTIONS
         */
        $sectionStmt = mysqli_prepare(
            $conn,
            "
            SELECT COUNT(*) AS total
            FROM sections
            WHERE course_id = ?
            "
        );

        mysqli_stmt_bind_param(
            $sectionStmt,
            'i',
            $courseId
        );

        mysqli_stmt_execute($sectionStmt);

        $sectionResult = mysqli_stmt_get_result($sectionStmt);
        $sectionCount = (int) mysqli_fetch_assoc($sectionResult)['total'];

        mysqli_stmt_close($sectionStmt);

        if ($sectionCount === 0) {

            $sectionNames = [
                'Section A',
                'Section B'
            ];

            foreach ($sectionNames as $sectionName) {

                $stmt = mysqli_prepare(
                    $conn,
                    "
                    INSERT INTO sections
                    (
                        course_id,
                        section_name,
                        max_slots
                    )
                    VALUES (?, ?, 40)
                    "
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    'is',
                    $courseId,
                    $sectionName
                );

                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
        }

        /*
         * SUBJECTS
         */
        $subjectStmt = mysqli_prepare(
            $conn,
            "
            SELECT COUNT(*) AS total
            FROM subjects
            WHERE course_id = ?
            "
        );

        mysqli_stmt_bind_param(
            $subjectStmt,
            'i',
            $courseId
        );

        mysqli_stmt_execute($subjectStmt);

        $subjectResult = mysqli_stmt_get_result($subjectStmt);
        $subjectCount = (int) mysqli_fetch_assoc($subjectResult)['total'];

        mysqli_stmt_close($subjectStmt);

        if ($subjectCount === 0) {

            $sections = mysqli_prepare(
                $conn,
                "
                SELECT id
                FROM sections
                WHERE course_id = ?
                ORDER BY id ASC
                "
            );

            mysqli_stmt_bind_param(
                $sections,
                'i',
                $courseId
            );

            mysqli_stmt_execute($sections);

            $sectionResult = mysqli_stmt_get_result($sections);

            $sectionIds = [];

            while ($section = mysqli_fetch_assoc($sectionResult)) {
                $sectionIds[] = (int) $section['id'];
            }

            mysqli_stmt_close($sections);

            if ($sectionIds === []) {
                continue;
            }

            $subjectTemplates = [

                'BSIT' => [
                    ['code' => 'IT101', 'name' => 'Programming I', 'day' => 'Mon', 'time' => '8:00 AM', 'room' => 'LAB 1'],
                    ['code' => 'IT102', 'name' => 'Database Systems', 'day' => 'Tue', 'time' => '10:00 AM', 'room' => 'LAB 2'],
                    ['code' => 'IT103', 'name' => 'Networking', 'day' => 'Wed', 'time' => '1:00 PM', 'room' => 'LAB 3'],
                    ['code' => 'IT104', 'name' => 'Web Development', 'day' => 'Thu', 'time' => '3:00 PM', 'room' => 'LAB 4'],
                    ['code' => 'IT105', 'name' => 'Systems Analysis', 'day' => 'Fri', 'time' => '9:00 AM', 'room' => 'RM 101'],
                    ['code' => 'IT106', 'name' => 'Ethics in Computing', 'day' => 'Mon', 'time' => '2:00 PM', 'room' => 'RM 102'],
                ],

                'BEED' => [
                    ['code' => 'ED101', 'name' => 'Child Development', 'day' => 'Mon', 'time' => '8:00 AM', 'room' => 'RM 201'],
                    ['code' => 'ED102', 'name' => 'Teaching Methods', 'day' => 'Tue', 'time' => '10:00 AM', 'room' => 'RM 202'],
                    ['code' => 'ED103', 'name' => 'Educational Psychology', 'day' => 'Wed', 'time' => '1:00 PM', 'room' => 'RM 203'],
                    ['code' => 'ED104', 'name' => 'Assessment in Learning', 'day' => 'Thu', 'time' => '3:00 PM', 'room' => 'RM 204'],
                    ['code' => 'ED105', 'name' => 'Reading Instruction', 'day' => 'Fri', 'time' => '9:00 AM', 'room' => 'RM 205'],
                    ['code' => 'ED106', 'name' => 'Curriculum Planning', 'day' => 'Mon', 'time' => '2:00 PM', 'room' => 'RM 206'],
                ],

                'BSED' => [
                    ['code' => 'SED101', 'name' => 'Principles of Teaching', 'day' => 'Mon', 'time' => '8:00 AM', 'room' => 'RM 301'],
                    ['code' => 'SED102', 'name' => 'Educational Research', 'day' => 'Tue', 'time' => '10:00 AM', 'room' => 'RM 302'],
                    ['code' => 'SED103', 'name' => 'Curriculum Development', 'day' => 'Wed', 'time' => '1:00 PM', 'room' => 'RM 303'],
                    ['code' => 'SED104', 'name' => 'Literature Studies', 'day' => 'Thu', 'time' => '3:00 PM', 'room' => 'RM 304'],
                    ['code' => 'SED105', 'name' => 'Classroom Management', 'day' => 'Fri', 'time' => '9:00 AM', 'room' => 'RM 305'],
                    ['code' => 'SED106', 'name' => 'Special Topics', 'day' => 'Mon', 'time' => '2:00 PM', 'room' => 'RM 306'],
                ],
            ];

            $templates =
                $subjectTemplates[$courseCode]
                ?? $subjectTemplates['BSIT'];

            $index = 0;

            foreach ($templates as $subject) {

                $sectionId =
                    $sectionIds[$index % count($sectionIds)];

                $stmt = mysqli_prepare(
                    $conn,
                    "
                    INSERT INTO subjects
                    (
                        course_id,
                        section_id,
                        subject_code,
                        subject_name,
                        units,
                        sem,
                        year_level,
                        schedule_day,
                        schedule_time,
                        room_number
                    )
                    VALUES (?, ?, ?, ?, 3, 1, 1, ?, ?, ?)
                    "
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    'iisssss',
                    $courseId,
                    $sectionId,
                    $subject['code'],
                    $subject['name'],
                    $subject['day'],
                    $subject['time'],
                    $subject['room']
                );

                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);

                $index++;
            }
        }
    }
}



/**
 * Generate a unique payment transaction reference for the current enrollment.
 * The reference is created by the server and is never supplied by the student.
 */
function generate_payment_reference(mysqli $conn): string
{
    for ($attempt = 0; $attempt < 10; $attempt++) {
        $reference = 'EYYSAT-GC-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(6)));

        $stmt = mysqli_prepare(
            $conn,
            'SELECT id FROM enrollments WHERE payment_reference = ? LIMIT 1'
        );
        mysqli_stmt_bind_param($stmt, 's', $reference);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $exists = mysqli_stmt_num_rows($stmt) > 0;
        mysqli_stmt_close($stmt);

        if (!$exists) {
            return $reference;
        }
    }

    throw new RuntimeException('Unable to generate a unique payment reference.');
}

/**
 * Generate a student number.
 */
function generate_student_number(mysqli $conn, int $course_id): string
{
    $year = date('Y');

    $stmt = mysqli_prepare(
        $conn,
        "
        SELECT MAX(
            CAST(
                SUBSTRING(student_number, 6)
                AS UNSIGNED
            )
        ) AS max_num
        FROM students
        WHERE student_number IS NOT NULL
        AND student_number LIKE ?
        "
    );

    $prefix = $year . '-%';

    mysqli_stmt_bind_param(
        $stmt,
        's',
        $prefix
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    mysqli_stmt_close($stmt);

    $next =
        ((int) ($row['max_num'] ?? 0))
        + 1;

    return
        $year .
        '-' .
        str_pad(
            (string) $next,
            5,
            '0',
            STR_PAD_LEFT
        );
}

/* ============================================================
   Teacher/LMS compatibility layer integrated from the modern teacher portal.
   ============================================================ */
function lms_table_exists(mysqli $conn, string $table): bool
{
    $table = mysqli_real_escape_string($conn, $table);
    $r = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    return $r && mysqli_num_rows($r) > 0;
}

function lms_column_exists(mysqli $conn, string $table, string $column): bool
{
    $cols = lms_columns($conn, $table);
    return isset($cols[$column]);
}

function lms_columns(mysqli $conn, string $table): array
{
    if (!lms_table_exists($conn, $table)) return [];
    $table = str_replace('`', '``', $table);
    $r = mysqli_query($conn, "SHOW COLUMNS FROM `$table`");
    $out=[];
    if ($r) while($row=mysqli_fetch_assoc($r)) $out[$row['Field']]=$row;
    return $out;
}

function lms_add_column(mysqli $conn, string $table, string $column, string $definition): void
{
    $cols=lms_columns($conn,$table);
    if (!isset($cols[$column])) {
        mysqli_query($conn,"ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    }
}

function lms_make_id_key(mysqli $conn, string $table): void
{
    $cols=lms_columns($conn,$table);
    if (!$cols || isset($cols['id'])) {
        if (isset($cols['id'])) {
            $r=mysqli_query($conn,"SHOW INDEX FROM `$table` WHERE Key_name='PRIMARY'");
            $hasPk=$r && mysqli_num_rows($r)>0;
            if (!$hasPk) mysqli_query($conn,"ALTER TABLE `$table` ADD PRIMARY KEY (`id`)");
            mysqli_query($conn,"ALTER TABLE `$table` MODIFY COLUMN `id` INT UNSIGNED NOT NULL AUTO_INCREMENT");
        }
        return;
    }
    // Legacy tables sometimes already have an auto-increment key with another name.
    $auto=null;
    foreach($cols as $name=>$row) if (($row['Extra']??'')==='auto_increment') {$auto=$name;break;}
    if ($auto !== null) {
        mysqli_query($conn,"ALTER TABLE `$table` CHANGE COLUMN `$auto` `id` INT UNSIGNED NOT NULL AUTO_INCREMENT");
        $r=mysqli_query($conn,"SHOW INDEX FROM `$table` WHERE Key_name='PRIMARY'");
        if (!$r || mysqli_num_rows($r)===0) mysqli_query($conn,"ALTER TABLE `$table` ADD PRIMARY KEY (`id`)");
        return;
    }
    // No generated key exists: add a nullable id, fill it uniquely, then promote it to AUTO_INCREMENT.
    mysqli_query($conn,"ALTER TABLE `$table` ADD COLUMN `id` INT UNSIGNED NULL");
    mysqli_query($conn,"SET @lms_id := 0");
    mysqli_query($conn,"UPDATE `$table` SET `id` = (@lms_id := @lms_id + 1) WHERE `id` IS NULL");
    mysqli_query($conn,"ALTER TABLE `$table` MODIFY COLUMN `id` INT UNSIGNED NOT NULL AUTO_INCREMENT");
    mysqli_query($conn,"ALTER TABLE `$table` ADD PRIMARY KEY (`id`)");
}

function ensure_account_security_schema(mysqli $conn): void
{
    if (!lms_table_exists($conn, 'users')) return;

    $cols = lms_columns($conn, 'users');

    // Normalize the unified account table to the canonical schema used by the application.
    // Passwords are never stored in plaintext; password_hash/password_verify are used by the app.
    if (isset($cols['id']) && !isset($cols['user_id'])) {
        @mysqli_query($conn, "ALTER TABLE users CHANGE COLUMN id user_id INT NOT NULL AUTO_INCREMENT");
    }
    if (isset($cols['fullname']) && !isset($cols['full_name'])) {
        @mysqli_query($conn, "ALTER TABLE users CHANGE COLUMN fullname full_name VARCHAR(120) NOT NULL");
    }
    if (isset($cols['password']) && !isset($cols['password_hash'])) {
        @mysqli_query($conn, "ALTER TABLE users CHANGE COLUMN password password_hash VARCHAR(255) NOT NULL");
    }
    if (isset($cols['created']) && !isset($cols['created_at'])) {
        @mysqli_query($conn, "ALTER TABLE users CHANGE COLUMN created created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
    }

    $cols = lms_columns($conn, 'users');
    if (!isset($cols['user_id'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN user_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST");
    if (!isset($cols['full_name'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN full_name VARCHAR(120) NOT NULL AFTER user_id");
    if (!isset($cols['email'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN email VARCHAR(150) NOT NULL AFTER full_name");
    if (!isset($cols['password_hash'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN password_hash VARCHAR(255) NOT NULL AFTER email");
    if (!isset($cols['role_id'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN role_id INT NOT NULL DEFAULT 3 AFTER password_hash");
    if (!isset($cols['role'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN role VARCHAR(20) GENERATED ALWAYS AS (CASE role_id WHEN 1 THEN 'admin' WHEN 2 THEN 'teacher' WHEN 3 THEN 'student' WHEN 4 THEN 'cashier' ELSE 'unknown' END) STORED AFTER role_id");
    if (!isset($cols['created_at'])) @mysqli_query($conn, "ALTER TABLE users ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER role");

    // Remove obsolete account-security columns from the previous version.
    $cols = lms_columns($conn, 'users');
    if (isset($cols['must_change_password'])) @mysqli_query($conn, "ALTER TABLE users DROP COLUMN must_change_password");
    if (isset($cols['password_expires_at'])) @mysqli_query($conn, "ALTER TABLE users DROP COLUMN password_expires_at");

    mysqli_query($conn, "ALTER TABLE users MODIFY COLUMN role_id INT NOT NULL DEFAULT 3");

    // Role 4 is the dedicated cashier role. Keep the generated role label in sync.
    if (lms_table_exists($conn, 'roles')) {
        mysqli_query($conn, "INSERT INTO roles (id, name, description) VALUES (4, 'Cashier', 'Payment verification, collection and receipt access') ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description)");
    }
    if (isset($cols['role'])) {
        @mysqli_query($conn, "ALTER TABLE users MODIFY COLUMN role VARCHAR(20) GENERATED ALWAYS AS (CASE role_id WHEN 1 THEN 'admin' WHEN 2 THEN 'teacher' WHEN 3 THEN 'student' WHEN 4 THEN 'cashier' ELSE 'unknown' END) STORED");
    }

    // Add the email uniqueness constraint only when it does not already exist.
    // This function runs on every request, so an unconditional ADD UNIQUE KEY
    // causes a fatal "Duplicate key name" error after the first run.
    $emailKeyExists = false;
    $emailUniqueExists = false;
    $indexResult = mysqli_query($conn, "SHOW INDEX FROM users");
    if ($indexResult) {
        while ($index = mysqli_fetch_assoc($indexResult)) {
            if (($index['Key_name'] ?? '') === 'uq_users_email') {
                $emailKeyExists = true;
            }
            if (($index['Column_name'] ?? '') === 'email' && (int)($index['Non_unique'] ?? 1) === 0) {
                $emailUniqueExists = true;
            }
        }
        mysqli_free_result($indexResult);
    }

    if (!$emailKeyExists && !$emailUniqueExists) {
        mysqli_query($conn, "ALTER TABLE users ADD UNIQUE KEY uq_users_email (email)");
    }
}

/**
 * Upgrade-safe LMS schema. Existing tables are inspected before ALTER operations;
 * this avoids duplicate AUTO_INCREMENT columns and repairs legacy table layouts.
 */
function ensure_lms_schema(mysqli $conn): void
{
    ensure_account_security_schema($conn);
    if (lms_table_exists($conn,'users')) {
        // Role hierarchy is defined by users.role_id: 1 Super Admin, 2 Instructor/Professor, 3 Student, 4 Cashier.
        if (lms_column_exists($conn,'users','role_id')) {
            mysqli_query($conn,"ALTER TABLE users MODIFY COLUMN role_id INT NOT NULL DEFAULT 3");
        }
    }

    // Keep LMS text columns compatible with the legacy enrollment database.
    // The original schema uses utf8mb4_general_ci while the first LMS migration
    // used utf8mb4_unicode_ci. Mixed collations break school-year comparisons.
    foreach (['teacher_profiles','teaching_assignments','lms_announcements','lms_materials'] as $lmsTable) {
        if (lms_table_exists($conn, $lmsTable)) {
            @mysqli_query($conn, "ALTER TABLE `$lmsTable` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        }
    }

    if (!lms_table_exists($conn,'teacher_profiles')) {
        mysqli_query($conn,"CREATE TABLE teacher_profiles (id INT UNSIGNED NOT NULL AUTO_INCREMENT,user_id INT NOT NULL,employee_number VARCHAR(40) DEFAULT NULL,department VARCHAR(120) DEFAULT NULL,title VARCHAR(80) DEFAULT 'Instructor',contact VARCHAR(30) DEFAULT NULL,bio TEXT DEFAULT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_teacher_user(user_id),UNIQUE KEY uq_teacher_employee(employee_number)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        lms_make_id_key($conn,'teacher_profiles');
        lms_add_column($conn,'teacher_profiles','user_id','INT NOT NULL');
        lms_add_column($conn,'teacher_profiles','employee_number','VARCHAR(40) DEFAULT NULL');
        lms_add_column($conn,'teacher_profiles','department','VARCHAR(120) DEFAULT NULL');
        lms_add_column($conn,'teacher_profiles','title',"VARCHAR(80) DEFAULT 'Instructor'");
        lms_add_column($conn,'teacher_profiles','contact','VARCHAR(30) DEFAULT NULL');
        lms_add_column($conn,'teacher_profiles','bio','TEXT DEFAULT NULL');
        lms_add_column($conn,'teacher_profiles','created_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
        lms_add_column($conn,'teacher_profiles','updated_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
    }

    if (!lms_table_exists($conn,'teaching_assignments')) {
        mysqli_query($conn,"CREATE TABLE teaching_assignments (id INT UNSIGNED NOT NULL AUTO_INCREMENT,teacher_id INT NOT NULL,subject_id INT NOT NULL,section_id INT NOT NULL,school_year VARCHAR(20) NOT NULL,semester TINYINT UNSIGNED NOT NULL DEFAULT 1,status ENUM('Active','Archived') NOT NULL DEFAULT 'Active',created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_teaching_assignment(teacher_id,subject_id,section_id,school_year,semester),KEY idx_assignment_teacher(teacher_id,status),KEY idx_assignment_section_subject(section_id,subject_id,status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        lms_make_id_key($conn,'teaching_assignments');
        lms_add_column($conn,'teaching_assignments','teacher_id','INT NOT NULL');
        lms_add_column($conn,'teaching_assignments','subject_id','INT NOT NULL');
        lms_add_column($conn,'teaching_assignments','section_id','INT NOT NULL');
        lms_add_column($conn,'teaching_assignments','school_year','VARCHAR(20) NOT NULL DEFAULT \'2026-2027\'');
        lms_add_column($conn,'teaching_assignments','semester','TINYINT UNSIGNED NOT NULL DEFAULT 1');
        lms_add_column($conn,'teaching_assignments','status',"ENUM('Active','Archived') NOT NULL DEFAULT 'Active'");
        lms_add_column($conn,'teaching_assignments','created_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
        lms_add_column($conn,'teaching_assignments','updated_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
    }

    if (!lms_table_exists($conn,'lms_announcements')) {
        mysqli_query($conn,"CREATE TABLE lms_announcements (id INT UNSIGNED NOT NULL AUTO_INCREMENT,assignment_id INT UNSIGNED DEFAULT NULL,teacher_id INT NOT NULL,title VARCHAR(180) NOT NULL,body TEXT NOT NULL,publish_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,expires_at DATETIME DEFAULT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_lms_announcement_assignment(assignment_id,publish_at),KEY idx_lms_announcement_teacher(teacher_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        lms_make_id_key($conn,'lms_announcements');
        lms_add_column($conn,'lms_announcements','assignment_id','INT UNSIGNED DEFAULT NULL');
        lms_add_column($conn,'lms_announcements','teacher_id','INT NOT NULL DEFAULT 0');
        lms_add_column($conn,'lms_announcements','title','VARCHAR(180) NOT NULL DEFAULT \'Announcement\'');
        lms_add_column($conn,'lms_announcements','body','TEXT NOT NULL');
        lms_add_column($conn,'lms_announcements','publish_at','DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP');
        lms_add_column($conn,'lms_announcements','expires_at','DATETIME DEFAULT NULL');
        lms_add_column($conn,'lms_announcements','created_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
        lms_add_column($conn,'lms_announcements','updated_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP');
    }

    if (!lms_table_exists($conn,'lms_materials')) {
        mysqli_query($conn,"CREATE TABLE lms_materials (id INT UNSIGNED NOT NULL AUTO_INCREMENT,assignment_id INT UNSIGNED NOT NULL,teacher_id INT NOT NULL,title VARCHAR(180) NOT NULL,description TEXT DEFAULT NULL,file_name VARCHAR(255) NOT NULL,file_path VARCHAR(500) NOT NULL,mime_type VARCHAR(120) DEFAULT NULL,file_size BIGINT UNSIGNED DEFAULT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_lms_material_assignment(assignment_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        lms_make_id_key($conn,'lms_materials');
        lms_add_column($conn,'lms_materials','assignment_id','INT UNSIGNED NOT NULL DEFAULT 0');
        lms_add_column($conn,'lms_materials','teacher_id','INT NOT NULL DEFAULT 0');
        lms_add_column($conn,'lms_materials','title',"VARCHAR(180) NOT NULL DEFAULT 'Learning Material'");
        lms_add_column($conn,'lms_materials','description','TEXT DEFAULT NULL');
        lms_add_column($conn,'lms_materials','file_name',"VARCHAR(255) NOT NULL DEFAULT ''");
        lms_add_column($conn,'lms_materials','file_path',"VARCHAR(500) NOT NULL DEFAULT ''");
        lms_add_column($conn,'lms_materials','mime_type','VARCHAR(120) DEFAULT NULL');
        lms_add_column($conn,'lms_materials','file_size','BIGINT UNSIGNED DEFAULT NULL');
        lms_add_column($conn,'lms_materials','created_at','TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
    }

    // Instructor academic management schema: attendance and gradebook.
    if (!lms_table_exists($conn,'teacher_attendance')) {
        mysqli_query($conn,"CREATE TABLE teacher_attendance (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,assignment_id INT UNSIGNED NOT NULL,student_id INT NOT NULL,attendance_date DATE NOT NULL,status ENUM('Present','Absent','Late','Excused') NOT NULL DEFAULT 'Present',remarks VARCHAR(255) DEFAULT NULL,marked_by INT NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_teacher_attendance(assignment_id,student_id,attendance_date),KEY idx_attendance_assignment_date(assignment_id,attendance_date),KEY idx_attendance_student(student_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    }
    if (!lms_table_exists($conn,'teacher_grades')) {
        mysqli_query($conn,"CREATE TABLE teacher_grades (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,assignment_id INT UNSIGNED NOT NULL,student_id INT NOT NULL,grading_period VARCHAR(40) NOT NULL DEFAULT 'Final',score DECIMAL(5,2) DEFAULT NULL,remarks VARCHAR(255) DEFAULT NULL,updated_by INT NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_teacher_grade(assignment_id,student_id,grading_period),KEY idx_grade_assignment_period(assignment_id,grading_period),KEY idx_grade_student(student_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    }
    if (!lms_table_exists($conn,'teacher_profiles')) {
        // kept for compatibility with older databases; profile table is normally created above.
    }

    // Final collation normalization after CREATE/ALTER operations above.
    foreach (['teacher_profiles','teaching_assignments','lms_announcements','lms_materials'] as $lmsTable) {
        if (lms_table_exists($conn, $lmsTable)) {
            @mysqli_query($conn, "ALTER TABLE `$lmsTable` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
        }
    }

    // Repair only orphaned legacy section links; never overwrite valid section assignments.
    if (lms_table_exists($conn,'subjects') && lms_table_exists($conn,'sections')) {
        mysqli_query($conn,"UPDATE subjects sub INNER JOIN sections sec ON sec.course_id=sub.course_id SET sub.section_id=sec.id WHERE sub.section_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM sections real_sec WHERE real_sec.id=sub.section_id) AND sec.section_name=CASE WHEN MOD(sub.section_id,2)=1 THEN 'Section A' ELSE 'Section B' END");
    }
}
