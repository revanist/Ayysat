<?php
require_once __DIR__ . '/admin_auth.php';
require_admin_login();
require_admin_csrf();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/enrollment_setup.php';
require_once __DIR__ . '/teacher_setup.php';
ensure_enrollment_schema($conn);
ensure_teacher_schema($conn);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/courses.php', true, 303);
    exit;
}

$subjectId = (int) ($_POST['subject_id'] ?? 0);
$courseId = (int) ($_POST['course_id'] ?? 0);
$sectionId = (int) ($_POST['section_id'] ?? 0);
$teacherId = (int) ($_POST['teacher_id'] ?? 0);
$day = trim((string) ($_POST['schedule_day'] ?? ''));
$time = trim((string) ($_POST['schedule_time'] ?? ''));
$room = trim((string) ($_POST['room_number'] ?? ''));

if ($subjectId <= 0 || $courseId <= 0) {
    header('Location: ../admin/courses.php?course=' . $courseId, true, 303);
    exit;
}

$day = mb_substr($day, 0, 20);
$time = mb_substr($time, 0, 50);
$room = mb_substr($room, 0, 20);

// Confirm the subject belongs to the selected course and obtain its section/semester.
$subjectStmt = mysqli_prepare($conn, 'SELECT id, section_id, sem FROM subjects WHERE id=? AND course_id=? LIMIT 1');
mysqli_stmt_bind_param($subjectStmt, 'ii', $subjectId, $courseId);
mysqli_stmt_execute($subjectStmt);
$subject = mysqli_fetch_assoc(mysqli_stmt_get_result($subjectStmt));
mysqli_stmt_close($subjectStmt);

if (!$subject) {
    header('Location: ../admin/courses.php?course=' . $courseId, true, 303);
    exit;
}

$actualSectionId = (int) ($subject['section_id'] ?? 0);
if ($actualSectionId <= 0 && $sectionId > 0) {
    // Keep compatibility with installations where section_id is supplied by the form.
    $actualSectionId = $sectionId;
}

// Only an actual Instructor account (users.role_id = 2) can be assigned.
$validTeacher = false;
if ($teacherId > 0) {
    $teacherStmt = mysqli_prepare($conn, 'SELECT user_id FROM users WHERE user_id=? AND role_id=2 AND TRIM(full_name) <> \'\' LIMIT 1');
    mysqli_stmt_bind_param($teacherStmt, 'i', $teacherId);
    mysqli_stmt_execute($teacherStmt);
    $validTeacher = mysqli_num_rows(mysqli_stmt_get_result($teacherStmt)) === 1;
    mysqli_stmt_close($teacherStmt);
    if (!$validTeacher) {
        $teacherId = 0;
    }
}

// Save schedule/room details. Faculty is no longer manually typed; it is taken from the account dropdown.
$teacherName = '';
if ($teacherId > 0) {
    $nameStmt = mysqli_prepare($conn, 'SELECT full_name FROM users WHERE user_id=? AND role_id=2 LIMIT 1');
    mysqli_stmt_bind_param($nameStmt, 'i', $teacherId);
    mysqli_stmt_execute($nameStmt);
    $teacherRow = mysqli_fetch_assoc(mysqli_stmt_get_result($nameStmt));
    mysqli_stmt_close($nameStmt);
    $teacherName = trim((string) ($teacherRow['full_name'] ?? ''));
}

$stmt = mysqli_prepare($conn, "
    UPDATE subjects
    SET teacher_name = NULLIF(?, ''),
        schedule_day = NULLIF(?, ''),
        schedule_time = NULLIF(?, ''),
        room_number = NULLIF(?, '')
    WHERE id = ? AND course_id = ?
");
mysqli_stmt_bind_param($stmt, 'ssssii', $teacherName, $day, $time, $room, $subjectId, $courseId);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

// Maintain the authoritative subject-to-professor assignments.
// College model: a professor is assigned to a specific subject and section.
// When a legacy subject has no section_id, selecting a professor applies that
// subject to each section of the course so existing students can resolve it.
$schoolYear = '2026-2027';
$semester = max(1, (int) ($subject['sem'] ?? 1));

// First archive any currently-active assignment for this subject in this school year.
// This also makes selecting "Faculty" a true reset instead of leaving an old
// instructor assignment hidden behind the dropdown.
$archive = mysqli_prepare($conn, "UPDATE teaching_assignments SET status='Archived' WHERE subject_id=? AND school_year=? AND status='Active'");
if ($archive) {
    mysqli_stmt_bind_param($archive, 'is', $subjectId, $schoolYear);
    mysqli_stmt_execute($archive);
    mysqli_stmt_close($archive);
}

if ($teacherId > 0) {
    $targetSections = [];

    if ($actualSectionId > 0) {
        $targetSections[] = $actualSectionId;
    } else {
        // Legacy data often has subjects.section_id = NULL. In that case,
        // assign the selected professor to every section of this course.
        $sectionStmt = mysqli_prepare($conn, 'SELECT id FROM sections WHERE course_id=? ORDER BY id');
        if ($sectionStmt) {
            mysqli_stmt_bind_param($sectionStmt, 'i', $courseId);
            mysqli_stmt_execute($sectionStmt);
            $sectionResult = mysqli_stmt_get_result($sectionStmt);
            while ($sectionRow = mysqli_fetch_assoc($sectionResult)) {
                $targetSections[] = (int) $sectionRow['id'];
            }
            mysqli_stmt_close($sectionStmt);
        }
    }

    foreach ($targetSections as $targetSectionId) {
        $assign = mysqli_prepare($conn, "
            INSERT INTO teaching_assignments
                (teacher_id, subject_id, section_id, school_year, semester, status, assignment_source)
            VALUES (?, ?, ?, ?, ?, 'Active', 'Manual')
            ON DUPLICATE KEY UPDATE
                teacher_id=VALUES(teacher_id),
                status='Active',
                assignment_source='Manual',
                updated_at=CURRENT_TIMESTAMP
        ");
        if ($assign) {
            mysqli_stmt_bind_param($assign, 'iiisi', $teacherId, $subjectId, $targetSectionId, $schoolYear, $semester);
            mysqli_stmt_execute($assign);
            mysqli_stmt_close($assign);
        }
    }
}

header('Location: ../admin/courses.php?course=' . $courseId . '&saved=1', true, 303);
exit;
