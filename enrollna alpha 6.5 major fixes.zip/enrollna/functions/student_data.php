<?php
/**
 * Shared functions for fetching student profile and enrollment data.
 */

/**
 * Fetch the complete student profile, including course and section details.
 *
 * @param mysqli $conn The database connection
 * @param int $user_id The user ID of the student
 * @return array|null The student associative array, or null if not found
 */
function get_student_profile(mysqli $conn, int $user_id): ?array {
    $stmt = mysqli_prepare($conn, "
        SELECT 
            s.*, 
            c.course_name, 
            c.course_code, 
            sec.section_name
        FROM students s
        LEFT JOIN courses c  ON s.course_id  = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.user_id = ?
        LIMIT 1
    ");
    
    if (!$stmt) return null;
    
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $student = mysqli_fetch_assoc($result) ?: null;
    mysqli_stmt_close($stmt);
    
    return $student;
}

/**
 * Fetch the latest enrollment record for a given student ID.
 *
 * @param mysqli $conn The database connection
 * @param int $student_id The student's primary ID (students.id)
 * @return array|null The enrollment associative array, or null if not found
 */
function get_student_latest_enrollment(mysqli $conn, int $student_id): ?array {
    $stmt = mysqli_prepare($conn, "
        SELECT *
        FROM enrollments
        WHERE student_id = ?
        ORDER BY id DESC
        LIMIT 1
    ");
    
    if (!$stmt) return null;
    
    mysqli_stmt_bind_param($stmt, 'i', $student_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $enrollment = mysqli_fetch_assoc($result) ?: null;
    mysqli_stmt_close($stmt);
    
    return $enrollment;
}
