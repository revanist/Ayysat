-- EYYSAT Adviser / Professor Portal
-- Run this after importing the main enrollna.sql dump if you prefer SQL setup.

CREATE TABLE IF NOT EXISTS teachers (
  id int(11) NOT NULL AUTO_INCREMENT,
  fullname varchar(120) NOT NULL,
  email varchar(100) NOT NULL,
  password varchar(255) NOT NULL,
  created timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_teachers_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS teacher_sections (
  id int(11) NOT NULL AUTO_INCREMENT,
  teacher_id int(11) NOT NULL,
  section_id int(11) NOT NULL,
  created timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uq_teacher_sections_section (section_id),
  KEY idx_teacher_sections_teacher (teacher_id),
  KEY idx_teacher_sections_section (section_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS teacher_announcements (
  id int(11) NOT NULL AUTO_INCREMENT,
  teacher_id int(11) NOT NULL,
  section_id int(11) DEFAULT NULL,
  title varchar(150) NOT NULL,
  message text NOT NULL,
  created_at timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  KEY idx_teacher_announcements_teacher (teacher_id),
  KEY idx_teacher_announcements_section (section_id),
  KEY idx_teacher_announcements_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
