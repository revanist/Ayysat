<?php

require_once __DIR__ . '/student_auth.php';
start_student_session();

require '../db/dbconn.php';


$enrollment_id =
    (int) ($_GET['enrollment_id'] ?? 0);


if ($enrollment_id < 1) {

    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}


$user_id =
    (int) ($_SESSION['user_id'] ?? 0);


if ($user_id < 1) {

    header(
        'Location: ../auth/login.php?loginredirect=1',
        true,
        303
    );

    exit;
}


/*
 * Verify ownership.
 */
$stmt = mysqli_prepare(
    $conn,
    "
    SELECT e.id
    FROM enrollments e
    INNER JOIN students s
        ON s.id = e.student_id
    WHERE e.id = ?
    AND s.user_id = ?
    LIMIT 1
    "
);

mysqli_stmt_bind_param(
    $stmt,
    'ii',
    $enrollment_id,
    $user_id
);

mysqli_stmt_execute($stmt);

mysqli_stmt_store_result($stmt);

$exists =
    mysqli_stmt_num_rows($stmt) > 0;

mysqli_stmt_close($stmt);


if (!$exists) {

    header(
        'Location: ../student/profile.php',
        true,
        303
    );

    exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>Payment Cancelled | EYYSAT</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #f5f7fb;
            font-family:
                Arial,
                Helvetica,
                sans-serif;
        }

        .card {
            width: min(520px, 92%);
            padding: 40px;
            background: #fff;
            border-radius: 20px;
            text-align: center;
            box-shadow:
                0 15px 45px rgba(0, 0, 0, .10);
        }

        .icon {
            width: 65px;
            height: 65px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: #fff4e5;
            color: #c56a00;
            font-size: 30px;
        }

        h1 {
            margin-bottom: 12px;
        }

        p {
            color: #64748b;
            line-height: 1.6;
        }

        .actions {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 25px;
        }

        a {
            padding: 12px 18px;
            border-radius: 10px;
            text-decoration: none;
        }

        .primary {
            background: #0d3b66;
            color: #fff;
        }

        .secondary {
            background: #eef2f7;
            color: #182230;
        }
    </style>

</head>

<body>

    <div class="card">

        <div class="icon">
            !
        </div>

        <h1>Payment Cancelled</h1>

        <p>
            Your enrollment has been saved, but the
            PayMongo payment was not completed.
        </p>

        <p>
            You can return to your enrollment and
            try the payment again.
        </p>

        <div class="actions">

            <a
                class="primary"
                href="create_checkout.php?enrollment_id=<?= (int) $enrollment_id ?>">
                Try Payment Again
            </a>

            <a
                class="secondary"
                href="../student/profile.php">
                Back to Profile
            </a>

        </div>

    </div>

</body>

</html>