<?php
/**
 * EYYSAT unified dashboard sidebar.
 * All protected dashboard pages include this one file.
 * The visible panel is selected from the authenticated role_id:
 * 1 = admin, 2 = teacher, 3 = student, 4 = cashier, 5 = registrar.
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$sidebarRoleId = (int) ($_SESSION['role_id'] ?? 0);
if ($sidebarRoleId === 0) {
    $section = basename(dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    $sidebarRoleId = match ($section) {
        'admin' => 1,
        'teacher' => 2,
        'student' => 3,
        'cashier' => 4,
        'registrar' => 5,
        default => (!empty($_SESSION['admin_id']) ? 1 : 0),
    };
}
if (!isset($conn)) {
    require_once __DIR__ . '/../db/dbconn.php';
}

$appBase = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');

$sidebarRoles = [
    1 => 'admin',
    2 => 'teacher',
    3 => 'student',
    4 => 'cashier',
    5 => 'registrar',
];
$sidebarRole = $sidebarRoles[$sidebarRoleId] ?? '';

function sidebar_url(string $path): string
{
    global $appBase;
    return $appBase . '/' . ltrim($path, '/');
}

function sidebar_active(string $file, string $current): string
{
    return $current === $file ? ' active' : '';
}

if ($sidebarRole === 'student') {
    $studentName = htmlspecialchars($_SESSION['fullname'] ?? 'Student');
    $studentSidebarProfile = [
        'first_name' => '', 'middle_name' => '', 'last_name' => '',
        'email' => '', 'contact' => '', 'address' => '',
    ];
    $userSidebarId = (int) ($_SESSION['user_id'] ?? 0);
    if ($userSidebarId > 0 && isset($conn)) {
        $result = mysqli_query($conn, "SELECT first_name, middle_name, last_name, email, contact, address FROM students WHERE user_id = $userSidebarId LIMIT 1");
        if ($result && mysqli_num_rows($result) > 0) {
            $studentSidebarProfile = mysqli_fetch_assoc($result) ?: $studentSidebarProfile;
        }
    }
    ?>
    <aside class="admin-sidebar student-sidebar" id="studentSidebar">
        <div class="sidebar-brand">
            <div class="sidebar-logo"><img src="<?= htmlspecialchars(sidebar_url('img/eyysat.png')) ?>" alt="EYYSAT Logo"></div>
            <div class="sidebar-brand-text"><strong>EYYSAT</strong><span>STUDENT PORTAL</span></div>
        </div>
        <nav class="sidebar-nav" aria-label="Student navigation">
            <p class="sidebar-label">MY PORTAL</p>
            <a href="<?= htmlspecialchars(sidebar_url('student/student_dashboard.php')) ?>" class="sidebar-link<?= sidebar_active('student_dashboard.php', $currentPage) ?>"><i data-lucide="layout-dashboard" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Dashboard</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('student/profile.php#enrollment')) ?>" class="sidebar-link"><i data-lucide="clipboard-check" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Enrollment & Status</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('student/profile.php#payment')) ?>" class="sidebar-link"><i data-lucide="credit-card" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Payments</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('student/profile.php')) ?>" class="sidebar-link<?= sidebar_active('profile.php', $currentPage) ?>"><i data-lucide="user" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">My Profile</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('student/curriculum.php')) ?>" class="sidebar-link<?= sidebar_active('curriculum.php', $currentPage) ?>"><i data-lucide="book-open" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Curriculum</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('student/activities.php')) ?>" class="sidebar-link<?= sidebar_active('activities.php', $currentPage) ?>"><i data-lucide="clipboard-list" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Activities</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('student/notifications.php')) ?>" class="sidebar-link<?= sidebar_active('notifications.php', $currentPage) ?>"><i data-lucide="bell" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Notifications</span></a>
            <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
            <a href="<?= htmlspecialchars(sidebar_url('auth/logout.php')) ?>" class="sidebar-link sidebar-logout"><i data-lucide="log-out" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Logout</span></a>
        </nav>
        <button type="button" class="sidebar-profile-trigger" id="studentProfileTrigger" aria-label="Open student account settings">
            <div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'Student', 0, 1))) ?></div>
            <div class="profile-info"><strong><?= $studentName ?></strong><span>Student</span></div>
        </button>
    </aside>
    <div class="sidebar-overlay" id="studentSidebarOverlay"></div>
    <button class="sidebar-toggle" id="studentSidebarToggle" type="button" aria-label="Toggle student sidebar"></button>
    <script src="<?= htmlspecialchars(sidebar_url('js/sweetalert2.all.min.js')) ?>"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const sidebar = document.getElementById('studentSidebar'), toggle = document.getElementById('studentSidebarToggle'), overlay = document.getElementById('studentSidebarOverlay'), main = document.querySelector('.dashboard-main'), profileTrigger = document.getElementById('studentProfileTrigger');
        if (!sidebar || !toggle || !overlay) return;
        function positionToggle() { toggle.style.left = window.innerWidth <= 768 ? '18px' : (sidebar.classList.contains('collapsed') ? '68px' : '246px'); }
        toggle.addEventListener('click', function () { if (window.innerWidth <= 768) { sidebar.classList.toggle('mobile-open'); overlay.classList.toggle('show'); return; } const collapsed = sidebar.classList.toggle('collapsed'); if (main) main.classList.toggle('sidebar-collapsed', collapsed); toggle.classList.toggle('collapsed', collapsed); positionToggle(); });
        overlay.addEventListener('click', function () { sidebar.classList.remove('mobile-open'); overlay.classList.remove('show'); });
        document.querySelectorAll('#studentSidebar .sidebar-link').forEach(function (link) { link.addEventListener('click', function () { if (window.innerWidth <= 768) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('show'); } }); });
        if (profileTrigger && typeof Swal !== 'undefined') {
            profileTrigger.addEventListener('click', function () {
                Swal.fire({ title: 'Loading account settings', text: 'Preparing your information...', allowOutsideClick: false, allowEscapeKey: false, showConfirmButton: false, didOpen: function () { Swal.showLoading(); } });
                window.setTimeout(function () {
                    Swal.close();
                    Swal.fire({
                        title: 'Student Account Settings',
                        html: `<form method="POST" action="<?= htmlspecialchars(sidebar_url('functions/student_update_profile.php')) ?>" class="student-settings-form">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(function_exists('student_csrf_token') ? student_csrf_token() : '') ?>">
                            <div class="student-settings-grid">
                                <div class="student-settings-panel"><h4>Personal Information</h4>
                                    <div class="student-settings-row"><label>First Name</label><input type="text" name="first_name" value="<?= htmlspecialchars($studentSidebarProfile['first_name'] ?? '') ?>" required></div>
                                    <div class="student-settings-row"><label>Middle Name</label><input type="text" name="middle_name" value="<?= htmlspecialchars($studentSidebarProfile['middle_name'] ?? '') ?>"></div>
                                    <div class="student-settings-row"><label>Last Name</label><input type="text" name="last_name" value="<?= htmlspecialchars($studentSidebarProfile['last_name'] ?? '') ?>" required></div>
                                    <div class="student-settings-row"><label>Email</label><input type="email" name="email" value="<?= htmlspecialchars($studentSidebarProfile['email'] ?? '') ?>" required></div>
                                    <div class="student-settings-row"><label>Contact Number</label><input type="text" name="contact" value="<?= htmlspecialchars($studentSidebarProfile['contact'] ?? '') ?>" required></div>
                                    <div class="student-settings-row"><label>Address</label><textarea name="address" rows="3" required><?= htmlspecialchars($studentSidebarProfile['address'] ?? '') ?></textarea></div>
                                </div>
                                <div class="student-settings-panel"><h4>Change Password</h4>
                                    <div class="student-settings-row"><label>Current Password</label><input type="password" name="current_password" placeholder="Enter current password"></div>
                                    <div class="student-settings-row"><label>New Password</label><input type="password" name="new_password" placeholder="At least 8 characters"></div>
                                    <div class="student-settings-row"><label>Confirm New Password</label><input type="password" name="confirm_password" placeholder="Re-enter new password"></div>
                                </div>
                            </div><div class="student-settings-actions"><button type="submit" class="btn student-settings-submit">Save Changes</button></div>
                        </form>`, width: '900px', customClass: { popup: 'student-settings-modal', title: 'student-settings-title' }, showCloseButton: true, showConfirmButton: false, allowOutsideClick: true, focusConfirm: false, padding: '1.5rem'
                    });
                }, 450);
            });
        }
        window.addEventListener('resize', positionToggle); positionToggle();
    });
    </script>
    <?php
} elseif ($sidebarRole === 'registrar') {
    $registrarName = htmlspecialchars($_SESSION['fullname'] ?? 'Registrar');
    $activePage = $currentPage;
    ?>
    <aside class="admin-sidebar" id="registrarSidebar">
      <div class="sidebar-brand"><div class="sidebar-logo"><img src="<?= htmlspecialchars(sidebar_url('img/eyysat.png')) ?>" alt="EYYSAT Logo"></div><div class="sidebar-brand-text"><strong>EYYSAT</strong><span>REGISTRAR / ACADEMIC</span></div></div>
      <nav class="sidebar-nav" aria-label="Registrar navigation">
        <p class="sidebar-label">ACADEMIC MANAGEMENT</p>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/registrar_dashboard.php')) ?>" class="sidebar-link<?= sidebar_active('registrar_dashboard.php',$activePage) ?>"><i data-lucide="layout-dashboard" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Dashboard</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/students.php')) ?>" class="sidebar-link<?= sidebar_active('students.php',$activePage) ?>"><i data-lucide="graduation-cap" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Students</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/courses.php')) ?>" class="sidebar-link<?= sidebar_active('courses.php',$activePage) ?>"><i data-lucide="book-open" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Courses</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/curriculum.php')) ?>" class="sidebar-link<?= sidebar_active('curriculum.php',$activePage) ?>"><i data-lucide="library" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Curriculum</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/sections.php')) ?>" class="sidebar-link<?= sidebar_active('sections.php',$activePage) ?>"><i data-lucide="layers" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Sections</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/pending_enrollments.php')) ?>" class="sidebar-link<?= sidebar_active('pending_enrollments.php',$activePage) ?>"><i data-lucide="clipboard-check" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Pending Enrollment</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/enrollments.php')) ?>" class="sidebar-link<?= sidebar_active('enrollments.php',$activePage) ?>"><i data-lucide="file-text" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Enrollment Records</span></a>
        <a href="<?= htmlspecialchars(sidebar_url('registrar/assign_subjects.php')) ?>" class="sidebar-link<?= sidebar_active('assign_subjects.php',$activePage) ?>"><i data-lucide="user-check" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Instructor Assignments</span></a>
        <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
        <a href="<?= htmlspecialchars(sidebar_url('auth/logout.php')) ?>" class="sidebar-link sidebar-logout"><i data-lucide="log-out" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Logout</span></a>
      </nav>
      <div class="sidebar-profile"><div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'R',0,1))) ?></div><div class="profile-info"><strong><?= $registrarName ?></strong><span>Registrar / Academic Affairs</span></div></div>
    </aside>
    <div class="sidebar-overlay" id="sidebarOverlay"></div><button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Toggle registrar sidebar"></button>
    <?php
} elseif ($sidebarRole === 'admin') {
    $adminName = htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['admin_name'] ?? 'Admin');
    $activePage = $currentPage;
    ?>
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="sidebar-brand"><div class="sidebar-logo"><img src="<?= htmlspecialchars(sidebar_url('img/eyysat.png')) ?>" alt="EYYSAT Logo"></div><div class="sidebar-brand-text"><strong>EYYSAT</strong><span>SYSTEM ADMIN</span></div></div>
        <nav class="sidebar-nav" aria-label="System administration navigation">
            <p class="sidebar-label">SYSTEM MANAGEMENT</p>
            <a href="<?= htmlspecialchars(sidebar_url('admin/admin_dashboard.php')) ?>" class="sidebar-link<?= sidebar_active('admin_dashboard.php', $activePage) ?>"><i data-lucide="layout-dashboard" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">System Dashboard</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('admin/users.php')) ?>" class="sidebar-link<?= sidebar_active('users.php', $activePage) ?>"><i data-lucide="users" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">User Management</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('admin/system_settings.php')) ?>" class="sidebar-link<?= sidebar_active('system_settings.php', $activePage) ?>"><i data-lucide="settings" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">System Settings</span></a>
            <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
            <a href="<?= htmlspecialchars(sidebar_url('auth/logout.php')) ?>" class="sidebar-link sidebar-logout"><i data-lucide="log-out" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Logout</span></a>
        </nav>
        <div class="sidebar-profile"><div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'Admin', 0, 1))) ?></div><div class="profile-info"><strong><?= $adminName ?></strong><span>System Administrator</span></div></div>
    </aside>
    <div class="sidebar-overlay" id="sidebarOverlay"></div><button class="sidebar-toggle" id="sidebarToggle" type="button" aria-label="Toggle admin sidebar"></button>
    <?php
} elseif ($sidebarRole === 'teacher') {
    $teacherName = htmlspecialchars($_SESSION['fullname'] ?? $_SESSION['teacher_name'] ?? 'Instructor');
    ?>
    <aside class="admin-sidebar" id="teacherSidebar">
        <div class="sidebar-brand"><div class="sidebar-logo"><img src="<?= htmlspecialchars(sidebar_url('img/eyysat-circle.png')) ?>" alt="EYYSAT Logo"></div><div class="sidebar-brand-text"><strong>EYYSAT</strong><span>INSTRUCTOR PANEL</span></div></div>
        <nav class="sidebar-nav" aria-label="Instructor navigation">
            <p class="sidebar-label">MAIN MENU</p>
            <a href="<?= htmlspecialchars(sidebar_url('teacher/teacher_dashboard.php')) ?>" class="sidebar-link<?= sidebar_active('teacher_dashboard.php', $currentPage) ?>"><i data-lucide="layout-dashboard" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Dashboard</span></a>

            <a href="<?= htmlspecialchars(sidebar_url('teacher/schedule.php')) ?>" class="sidebar-link<?= sidebar_active('schedule.php', $currentPage) ?>"><i data-lucide="calendar" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Schedule</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('teacher/announcements.php')) ?>" class="sidebar-link<?= sidebar_active('announcements.php', $currentPage) ?>"><i data-lucide="megaphone" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Announcements</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('teacher/notifications.php')) ?>" class="sidebar-link<?= sidebar_active('notifications.php', $currentPage) ?>"><i data-lucide="bell" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Notifications</span></a>

            <p class="sidebar-label sidebar-label-bottom">ACADEMIC</p>
            <a href="<?= htmlspecialchars(sidebar_url('teacher/curriculum.php')) ?>" class="sidebar-link<?= sidebar_active('curriculum.php', $currentPage) ?>"><i data-lucide="book-open" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Curriculum</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('teacher/teacher_profile.php')) ?>" class="sidebar-link<?= sidebar_active('teacher_profile.php', $currentPage) ?>"><i data-lucide="user" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">My Profile</span></a>
            <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
            <a href="<?= htmlspecialchars(sidebar_url('auth/logout.php')) ?>" class="sidebar-link sidebar-logout"><i data-lucide="log-out" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Logout</span></a>
        </nav>
        <div class="sidebar-profile"><div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? $_SESSION['teacher_name'] ?? 'I', 0, 1))) ?></div><div class="profile-info"><strong><?= $teacherName ?></strong><span>Instructor / Professor</span></div></div>
    </aside>
    <div class="sidebar-overlay" id="teacherSidebarOverlay"></div><button class="sidebar-toggle" id="teacherSidebarToggle" type="button" aria-label="Toggle instructor sidebar"></button>
    <?php
} elseif ($sidebarRole === 'cashier') {
    $cashierName = htmlspecialchars($_SESSION['fullname'] ?? 'Cashier');
    $unreadPaymentCount = 0;
    if (isset($conn)) {
        $result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM admin_notifications WHERE cashier_is_read = 0");
        $unreadPaymentCount = $result ? (int) (mysqli_fetch_assoc($result)['total'] ?? 0) : 0;
    }
    ?>
    <aside class="admin-sidebar cashier-sidebar" id="cashierSidebar">
        <div class="sidebar-brand"><div class="sidebar-logo"><img src="<?= htmlspecialchars(sidebar_url('img/eyysat.png')) ?>" alt="EYYSAT Logo"></div><div class="sidebar-brand-text"><strong>EYYSAT</strong><span>CASHIER PANEL</span></div></div>
        <nav class="sidebar-nav" aria-label="Cashier navigation">
            <p class="sidebar-label">MAIN MENU</p>
            <a href="<?= htmlspecialchars(sidebar_url('cashier/index.php')) ?>" class="sidebar-link<?= sidebar_active('index.php', $currentPage) ?>"><i data-lucide="layout-dashboard" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Dashboard</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('cashier/pos.php')) ?>" class="sidebar-link<?= sidebar_active('pos.php', $currentPage) ?>"><i data-lucide="calculator" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Point of Sale (POS)</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('cashier/index.php#pending-payments')) ?>" class="sidebar-link"><i data-lucide="banknote" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Payment Verification</span><?php if ($unreadPaymentCount > 0): ?><span class="sidebar-notification-badge"><?= $unreadPaymentCount > 99 ? '99+' : $unreadPaymentCount ?></span><?php endif; ?></a>
            <a href="<?= htmlspecialchars(sidebar_url('cashier/index.php#transactions')) ?>" class="sidebar-link"><i data-lucide="receipt" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Transactions</span></a>
            <a href="<?= htmlspecialchars(sidebar_url('cashier/index.php#receipts')) ?>" class="sidebar-link"><i data-lucide="scroll-text" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Receipts</span></a>
            <p class="sidebar-label sidebar-label-bottom">ACCOUNT</p>
            <a href="<?= htmlspecialchars(sidebar_url('auth/logout.php')) ?>" class="sidebar-link sidebar-logout"><i data-lucide="log-out" class="sidebar-icon" width="16" height="16"></i><span class="sidebar-text">Logout</span></a>
        </nav>
        <div class="sidebar-profile"><div class="profile-avatar"><?= htmlspecialchars(strtoupper(substr($_SESSION['fullname'] ?? 'C', 0, 1))) ?></div><div class="profile-info"><strong><?= $cashierName ?></strong><span>Cashier</span></div></div>
    </aside>
    <div class="sidebar-overlay" id="cashierSidebarOverlay"></div><button class="sidebar-toggle" id="cashierSidebarToggle" type="button" aria-label="Toggle cashier sidebar"></button>
    <?php
}
?>

<?php if ($sidebarRole !== 'student'): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.querySelector('.admin-sidebar');
    const toggle = document.querySelector('.sidebar-toggle');
    const overlay = document.querySelector('.sidebar-overlay');
    const main = document.querySelector('.dashboard-main');
    if (!sidebar || !toggle || !overlay) return;
    function updateTogglePosition() { toggle.style.left = window.innerWidth <= 768 ? '18px' : (sidebar.classList.contains('collapsed') ? '68px' : '246px'); }
    toggle.addEventListener('click', function () { if (window.innerWidth <= 768) { sidebar.classList.toggle('mobile-open'); overlay.classList.toggle('show'); return; } const collapsed = sidebar.classList.toggle('collapsed'); if (main) main.classList.toggle('sidebar-collapsed', collapsed); toggle.classList.toggle('collapsed', collapsed); updateTogglePosition(); });
    overlay.addEventListener('click', function () { sidebar.classList.remove('mobile-open'); overlay.classList.remove('show'); });
    sidebar.querySelectorAll('.sidebar-link').forEach(function (link) { link.addEventListener('click', function () { if (window.innerWidth <= 768) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('show'); } }); });
    window.addEventListener('resize', function () { if (window.innerWidth > 768) { sidebar.classList.remove('mobile-open'); overlay.classList.remove('show'); } updateTogglePosition(); });
    updateTogglePosition();
});
</script>
<?php endif; ?>

<script src="<?= htmlspecialchars(sidebar_url('js/lucide.min.js')) ?>"></script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
      if (typeof lucide !== 'undefined') {
          lucide.createIcons();
      }
  });
</script>
