<?php
require_once __DIR__ . '/teacher_auth.php';
start_teacher_session();
require_once '../db/dbconn.php';
require_once __DIR__ . '/teacher_setup.php';
ensure_teacher_schema($conn);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ../auth/adviser_register.php'); exit; }

$fullname = trim((string)($_POST['fullname'] ?? ''));
$email = trim((string)($_POST['email'] ?? ''));
$password = (string)($_POST['password'] ?? '');
$confirm = (string)($_POST['confirm_password'] ?? '');

if ($fullname === '' || $email === '' || $password === '' || $confirm === '') { header('Location: ../auth/adviser_register.php?error=empty'); exit; }
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { header('Location: ../auth/adviser_register.php?error=email'); exit; }
if ($password !== $confirm) { header('Location: ../auth/adviser_register.php?error=password'); exit; }
if (strlen($password) < 8) { header('Location: ../auth/adviser_register.php?error=shortpassword'); exit; }

$check = mysqli_prepare($conn, 'SELECT id FROM teachers WHERE email = ? LIMIT 1');
mysqli_stmt_bind_param($check, 's', $email); mysqli_stmt_execute($check); mysqli_stmt_store_result($check);
if (mysqli_stmt_num_rows($check) > 0) { mysqli_stmt_close($check); header('Location: ../auth/adviser_register.php?error=exists'); exit; }
mysqli_stmt_close($check);

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = mysqli_prepare($conn, 'INSERT INTO teachers (fullname, email, password) VALUES (?, ?, ?)');
mysqli_stmt_bind_param($stmt, 'sss', $fullname, $email, $hash); mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
header('Location: ../auth/adviser_login.php?success=registered', true, 303); exit;
