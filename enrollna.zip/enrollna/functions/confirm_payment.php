<?php
require_once __DIR__ . '/cashier_auth.php';
require_cashier_login();
require_cashier_csrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../cashier/index.php', true, 303);
    exit;
}

require __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/enrollment_setup.php';
require_once __DIR__ . '/system_settings.php';

ensure_enrollment_schema($conn);
$enrollmentFee = system_enrollment_fee($conn);

$enrollmentId = (int) ($_POST['enrollment_id'] ?? 0);
if ($enrollmentId < 1) {
    http_response_code(400);
    exit('Invalid enrollment ID.');
}

mysqli_begin_transaction($conn);

try {
    $lookup = mysqli_prepare($conn, '
        SELECT e.student_id, e.status, e.amount_paid, e.cash_amount_requested, e.payment_status
        FROM enrollments e
        WHERE e.id = ?
        FOR UPDATE
    ');
    mysqli_stmt_bind_param($lookup, 'i', $enrollmentId);
    mysqli_stmt_execute($lookup);
    $payment = mysqli_fetch_assoc(mysqli_stmt_get_result($lookup));
    mysqli_stmt_close($lookup);

    if (!$payment) {
        throw new RuntimeException('Payment not found.');
    }
    if (!in_array(strtolower((string)$payment['status']), ['approved', 'enrolled'], true)) {
        throw new RuntimeException('Payment cannot be confirmed before the enrollment is approved.');
    }

    $studentId = (int) $payment['student_id'];
    $receivedAmount = (float) ($payment['cash_amount_requested'] ?? 0);
    if ($receivedAmount <= 0) {
        throw new RuntimeException('Payment has already been confirmed or is missing.');
    }

    $totalPaid = (float) ($payment['amount_paid'] ?? 0) + $receivedAmount;
    $remainingBalance = max(0, $enrollmentFee - $totalPaid);
    $isFullyPaid = $remainingBalance <= 0;
    $paymentStatus = $isFullyPaid ? 'Paid' : 'Partial';
    /* Cashier acceptance enrolls the student; payment can remain partial. */
    $enrollmentStatus = 'Enrolled';
    $studentStatus = 'Enrolled';

    $enrollment = mysqli_prepare($conn, '
        UPDATE enrollments
        SET payment_status = ?, status = ?,
            amount_paid = ?, cash_amount_requested = NULL
        WHERE id = ? AND cash_amount_requested IS NOT NULL
    ');
    mysqli_stmt_bind_param($enrollment, 'ssdi', $paymentStatus, $enrollmentStatus, $totalPaid, $enrollmentId);
    mysqli_stmt_execute($enrollment);
    mysqli_stmt_close($enrollment);

    $student = mysqli_prepare($conn, '
        UPDATE students
        SET payment_status = ?, enrollment_status = ?, remaining_balance = ?
        WHERE id = ?
    ');
    mysqli_stmt_bind_param($student, 'ssdi', $paymentStatus, $studentStatus, $remainingBalance, $studentId);
    mysqli_stmt_execute($student);
    mysqli_stmt_close($student);

    mysqli_commit($conn);
    header('Location: ../cashier/index.php?confirmed=' . $enrollmentId, true, 303);
    exit;
} catch (Throwable $exception) {
    mysqli_rollback($conn);
    http_response_code(500);
    exit('Payment confirmation failed.');
}
