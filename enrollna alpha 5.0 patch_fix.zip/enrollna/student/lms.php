<?php
require_once '../functions/student_auth.php';
require_student_login();
require '../db/dbconn.php';
require_once '../functions/enrollment_setup.php';
require_once '../functions/student_data.php';
ensure_lms_schema($conn);
$uid = (int) $_SESSION['user_id'];

$studentProfile = get_student_profile($conn, $uid);
$enrollment = $studentProfile ? get_student_latest_enrollment($conn, (int) $studentProfile['id']) : null;

$sectionId = (int) ($studentProfile['section_id'] ?? 0);
$schoolYear = '2026-2027';
$semester = 1;

if ($enrollment && in_array(ucfirst(strtolower($enrollment['status'])), ['Approved', 'Enrolled'])) {
    if (!empty($enrollment['section_id'])) {
        $sectionId = (int) $enrollment['section_id'];
    }
    $schoolYear = $enrollment['school_year'] ?? $schoolYear;
    $semester = (int) ($enrollment['sem'] ?? $semester);
}
$ann = $mat = null;
if ($sectionId) {
    $q = mysqli_prepare($conn, "SELECT a.title,a.body,a.publish_at,u.full_name teacher_name,sub.subject_code FROM lms_announcements a JOIN teaching_assignments ta ON ta.id=a.assignment_id AND ta.section_id=? AND ta.school_year=? AND ta.semester=? AND ta.status='Active' JOIN users u ON u.user_id=a.teacher_id JOIN subjects sub ON sub.id=ta.subject_id WHERE a.publish_at<=NOW() AND (a.expires_at IS NULL OR a.expires_at>NOW()) ORDER BY a.publish_at DESC");
    mysqli_stmt_bind_param($q, 'isi', $sectionId, $schoolYear, $semester);
    mysqli_stmt_execute($q);
    $ann = mysqli_stmt_get_result($q);
    $q = mysqli_prepare($conn, "SELECT m.id,m.title,m.description,m.file_name,m.created_at,u.full_name teacher_name,sub.subject_code FROM lms_materials m JOIN teaching_assignments ta ON ta.id=m.assignment_id AND ta.section_id=? AND ta.school_year=? AND ta.semester=? AND ta.status='Active' JOIN users u ON u.user_id=m.teacher_id JOIN subjects sub ON sub.id=ta.subject_id ORDER BY m.created_at DESC");
    mysqli_stmt_bind_param($q, 'isi', $sectionId, $schoolYear, $semester);
    mysqli_stmt_execute($q);
    $mat = mysqli_stmt_get_result($q);
}
?>
<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>My LMS | EYYSAT</title>
    <link rel="stylesheet" href="../css/admin_dashboard.css">
    <link rel="stylesheet" href="../css/teacher.css">
    <style>
        .student-lms {
            max-width: 1050px
        }

        .lms-item {
            padding: 18px 0;
            border-bottom: 1px solid var(--border-light)
        }

        .lms-item:last-child {
            border-bottom: 0
        }
    </style>
</head>

<body><?php include 'sidebar_layout.php'; ?>
    <main class="dashboard-main student-lms">
        <div class="hero">
            <div class="welcome"><span class="hero-badge">Learning Management System</span>
                <h1>My LMS</h1>
                <p><?= htmlspecialchars($_SESSION['fullname'] ?? 'Student') ?> · <?= htmlspecialchars($schoolYear) ?> ·
                    <?= $semester == 1 ? '1st' : '2nd' ?> Semester</p>
            </div>
        </div><?php if (!$sectionId): ?>
            <div class="teacher-card empty">Your enrollment is not linked to a section yet. Once the registrar assigns your
                section, your classes and learning materials will appear here.</div><?php else: ?>
            <div class="teacher-card">
                <h3>Class announcements</h3><?php if (!$ann || mysqli_num_rows($ann) === 0): ?>
                    <div class="empty">No announcements for your section.</div><?php else:
                    while ($a = mysqli_fetch_assoc($ann)): ?>
                        <div class="lms-item"><span class="badge"><?= htmlspecialchars($a['subject_code']) ?></span>
                            <h3><?= htmlspecialchars($a['title']) ?></h3>
                            <p><?= nl2br(htmlspecialchars($a['body'])) ?></p><small class="muted">Posted by
                                <?= htmlspecialchars($a['teacher_name']) ?> ·
                                <?= htmlspecialchars(date('M d, Y g:i A', strtotime($a['publish_at']))) ?></small>
                        </div><?php endwhile; endif; ?>
            </div>
            <div class="teacher-card" style="margin-top:18px">
                <h3>Learning materials</h3><?php if (!$mat || mysqli_num_rows($mat) === 0): ?>
                    <div class="empty">No learning materials uploaded yet.</div><?php else: ?>
                    <div class="table-wrap">
                        <table class="teacher-table">
                            <thead>
                                <tr>
                                    <th>Subject</th>
                                    <th>Material</th>
                                    <th>Teacher</th>
                                    <th>Uploaded</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody><?php while ($m = mysqli_fetch_assoc($mat)): ?>
                                    <tr>
                                        <td><span class="badge"><?= htmlspecialchars($m['subject_code']) ?></span></td>
                                        <td><strong><?= htmlspecialchars($m['title']) ?></strong><br><span
                                                class="muted"><?= htmlspecialchars($m['description'] ?? '') ?></span></td>
                                        <td><?= htmlspecialchars($m['teacher_name']) ?></td>
                                        <td><?= htmlspecialchars(date('M d, Y', strtotime($m['created_at']))) ?></td>
                                        <td><a class="teacher-btn secondary" href="lms_download.php?id=<?= $m['id'] ?>">Download</a>
                                        </td>
                                    </tr><?php endwhile; ?>
                            </tbody>
                        </table>
                    </div><?php endif; ?>
            </div><?php endif; ?>
    </main>
</body>

</html>