<?php
declare(strict_types=1);

/**
 * Teacher LMS bootstrap.
 *
 * Loads the shared enrollment setup and the canonical teacher authorization
 * helpers. The authorization helper supports both the modern LMS teacher
 * account/session and the unified instructor account/session.
 */

require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
require_once __DIR__ . '/../functions/teacher_auth.php';
require_once __DIR__ . '/../functions/teacher_setup.php';

require_teacher_login();

/* Canonical teacher context shared by all modern LMS pages. */
$teacherId = (int) ($_SESSION['user_id'] ?? 0);
require_once __DIR__ . '/../functions/system_settings.php';
$schoolYear = (string) ($_SESSION['school_year'] ?? system_school_year($conn));
$semester = (int) ($_SESSION['semester'] ?? 1);


/* Ensure the modern teacher/LMS tables exist before any LMS query runs. */
if (function_exists('ensure_lms_schema')) {
    ensure_lms_schema($conn);
}

ensure_teacher_schema($conn);
