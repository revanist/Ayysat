<?php
require_once __DIR__ . '/session_security.php';

/** Shared session and access controls for cashier-only pages and actions. */
function start_cashier_session(): void
{
    start_secure_session();
}

function require_cashier_login(): void
{
    start_cashier_session();

    if (empty($_SESSION['user_id']) || (int)($_SESSION['role_id'] ?? 0) !== 4) {
        header('Location: ../auth/login.php', true, 303);
        exit;
    }
}

function cashier_csrf_token(): string
{
    if (empty($_SESSION['cashier_csrf_token'])) {
        $_SESSION['cashier_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['cashier_csrf_token'];
}

function require_cashier_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || empty($_SESSION['cashier_csrf_token']) ||
        !hash_equals($_SESSION['cashier_csrf_token'], $token)) {
        http_response_code(403);
        exit('Invalid form request. Please return to the cashier portal and try again.');
    }
}
