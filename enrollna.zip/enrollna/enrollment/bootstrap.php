<?php
declare(strict_types=1);

require_once __DIR__ . '/../functions/student_auth.php';
require_once __DIR__ . '/../functions/enrollment_setup.php';
require_once __DIR__ . '/data.php';

// Public application: applicants may submit without being logged in; existing students may also reuse this form.
start_student_session();
require __DIR__ . '/../db/dbconn.php';

ensure_enrollment_schema($conn);
seed_course_data($conn);

$courseCatalog = enrollment_load_course_catalog($conn);
