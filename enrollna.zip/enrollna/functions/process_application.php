<?php
// Backwards-compatible endpoint. Enrollment processing now lives in /enrollment/process.php.
require __DIR__ . '/../enrollment/process.php';
