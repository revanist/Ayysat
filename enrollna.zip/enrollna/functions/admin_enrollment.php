<?php
require_once __DIR__ . '/system_settings.php';
/**
 * Centralized admin enrollment state transitions.
 *
 * Enrollment state is mirrored between enrollments.STATUS and
 * students.enrollment_status so both records describe the same application.
 */

function admin_lock_section(mysqli $conn, int $sectionId): int
{
    $stmt = mysqli_prepare($conn, 'SELECT max_slots FROM sections WHERE id = ? FOR UPDATE');
    if (!$stmt) {
        throw new RuntimeException('Unable to lock the selected section.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $sectionId);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to lock the selected section.');
    }
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$row) {
        throw new RuntimeException('The selected section no longer exists.');
    }

    return (int)$row['max_slots'];
}

function admin_validate_section_capacity(mysqli $conn, int $sectionId, int $currentEnrollmentId, int $maxSlots): void
{
    if ($maxSlots <= 0) {
        return;
    }

    $stmt = mysqli_prepare(
        $conn,
        "SELECT COUNT(*) AS active_count
         FROM enrollments
         WHERE section_id = ?
           AND id <> ?
           AND STATUS IN ('Approved', 'Enrolled')"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to check section capacity.');
    }
    mysqli_stmt_bind_param($stmt, 'ii', $sectionId, $currentEnrollmentId);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new RuntimeException('Unable to check section capacity.');
    }
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if ((int)($row['active_count'] ?? 0) >= $maxSlots) {
        throw new RuntimeException('The selected section is already full. Approval cannot continue.');
    }
}

function admin_validate_no_duplicate_active_enrollment(
    mysqli $conn,
    int $studentId,
    string $schoolYear,
    int $semester,
    int $currentEnrollmentId
): void {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id
         FROM enrollments
         WHERE student_id = ?
           AND school_year = ?
           AND sem = ?
           AND id <> ?
           AND STATUS IN ('Pending', 'Approved', 'Enrolled')
         LIMIT 1"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to check duplicate enrollment.');
    }
    mysqli_stmt_bind_param($stmt, 'isii', $studentId, $schoolYear, $semester, $currentEnrollmentId);
    mysqli_stmt_execute($stmt);
    $duplicate = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if ($duplicate) {
        throw new RuntimeException('This student already has another active enrollment for the selected school year and semester.');
    }
}

function admin_validate_enrollment_curriculum(
    mysqli $conn,
    int $enrollmentId,
    int $courseId,
    int $yearLevel,
    int $semester
): void {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT COUNT(*) AS total
         FROM enrollment_details ed
         INNER JOIN curriculum cu ON cu.subject_id = ed.subject_id
             AND cu.course_id = ?
             AND cu.year_level = ?
             AND cu.semester = ?
         INNER JOIN subjects s ON s.id = ed.subject_id
             AND s.course_id = ?
         WHERE ed.enrollment_id = ?"
    );
    if (!$stmt) {
        throw new RuntimeException('Unable to validate the selected curriculum.');
    }
    mysqli_stmt_bind_param($stmt, 'iiiii', $courseId, $yearLevel, $semester, $courseId, $enrollmentId);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    $selectedStmt = mysqli_prepare($conn, 'SELECT COUNT(*) AS total FROM enrollment_details WHERE enrollment_id = ?');
    if (!$selectedStmt) {
        throw new RuntimeException('Unable to validate enrollment subjects.');
    }
    mysqli_stmt_bind_param($selectedStmt, 'i', $enrollmentId);
    mysqli_stmt_execute($selectedStmt);
    $selected = mysqli_fetch_assoc(mysqli_stmt_get_result($selectedStmt));
    mysqli_stmt_close($selectedStmt);

    $selectedCount = (int)($selected['total'] ?? 0);
    $validCount = (int)($row['total'] ?? 0);

    if ($selectedCount < 1 || $validCount !== $selectedCount) {
        throw new RuntimeException('The selected curriculum no longer matches the student\'s course, year level, or semester.');
    }
}

function admin_approve_enrollment(mysqli $conn, int $enrollmentId): string
{
    if ($enrollmentId < 1) {
        throw new InvalidArgumentException('Invalid enrollment.');
    }

    mysqli_begin_transaction($conn);
    $studentNumberLock = null;
    ensure_system_settings_schema($conn);
    $enrollmentFee = system_enrollment_fee($conn);

    try {
        $lookup = mysqli_prepare($conn, '
            SELECT e.id, e.student_id, e.course_id, e.section_id, e.year_level, e.school_year, e.sem,
                   e.STATUS AS enrollment_status, s.student_number
            FROM enrollments e
            INNER JOIN students s ON s.id = e.student_id
            WHERE e.id = ?
            FOR UPDATE
        ');
        if (!$lookup) {
            throw new RuntimeException('Unable to prepare enrollment lookup.');
        }
        mysqli_stmt_bind_param($lookup, 'i', $enrollmentId);
        if (!mysqli_stmt_execute($lookup)) {
            mysqli_stmt_close($lookup);
            throw new RuntimeException('Unable to read enrollment.');
        }
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($lookup));
        mysqli_stmt_close($lookup);

        if (!$row) {
            throw new RuntimeException('Enrollment not found.');
        }
        if (strcasecmp((string)$row['enrollment_status'], 'Pending') !== 0) {
            throw new RuntimeException('Only pending enrollments can be approved.');
        }

        $studentId = (int)$row['student_id'];
        $courseId = (int)$row['course_id'];
        $sectionId = (int)$row['section_id'];
        $yearLevel = (int)$row['year_level'];
        $semester = (int)$row['sem'];
        $schoolYear = (string)$row['school_year'];

        $sectionCourse = mysqli_prepare(
            $conn,
            'SELECT s.section_name, c.course_code
             FROM sections s
             INNER JOIN courses c ON c.id = s.course_id
             WHERE s.id = ? AND s.course_id = ?
             LIMIT 1'
        );
        if (!$sectionCourse) {
            throw new RuntimeException('Unable to validate the selected section.');
        }

        mysqli_stmt_bind_param($sectionCourse, 'ii', $sectionId, $courseId);
        mysqli_stmt_execute($sectionCourse);
        $sectionRow = mysqli_fetch_assoc(mysqli_stmt_get_result($sectionCourse));
        mysqli_stmt_close($sectionCourse);

        if (!$sectionRow) {
            throw new RuntimeException("The selected section no longer belongs to the student's course.");
        }

        $courseCode = strtoupper(trim((string) $sectionRow['course_code']));
        $sectionName = strtoupper(trim((string) $sectionRow['section_name']));
        $sectionPattern = '/^' . preg_quote($courseCode, '/') . '-'
            . $yearLevel . '[A-D]' . $semester . '$/';

        if (!preg_match($sectionPattern, $sectionName)) {
            throw new RuntimeException(
                "The selected section no longer matches the student's course, year level, and semester."
            );
        }

        admin_validate_enrollment_curriculum($conn, $enrollmentId, $courseId, $yearLevel, $semester);
        admin_validate_no_duplicate_active_enrollment($conn, $studentId, $schoolYear, $semester, $enrollmentId);

        // Lock the section and perform the final seat check immediately before approval.
        $maxSlots = admin_lock_section($conn, $sectionId);
        admin_validate_section_capacity($conn, $sectionId, $enrollmentId, $maxSlots);

        $studentNumber = trim((string)($row['student_number'] ?? ''));

        if ($studentNumber === '') {
            $schoolYearConfig = system_school_year($conn);
            $year = substr($schoolYearConfig, 0, 4);
            $studentNumberLock = 'eyysat_student_number_' . $year;

            $lockStmt = mysqli_prepare($conn, 'SELECT GET_LOCK(?, 10) AS lock_acquired');
            if (!$lockStmt) {
                throw new RuntimeException('Unable to prepare student number lock.');
            }
            mysqli_stmt_bind_param($lockStmt, 's', $studentNumberLock);
            if (!mysqli_stmt_execute($lockStmt)) {
                mysqli_stmt_close($lockStmt);
                throw new RuntimeException('Unable to lock student number generation.');
            }
            $lockRow = mysqli_fetch_assoc(mysqli_stmt_get_result($lockStmt));
            mysqli_stmt_close($lockStmt);

            if ((int)($lockRow['lock_acquired'] ?? 0) !== 1) {
                throw new RuntimeException('Student number generation is busy. Please try again.');
            }

            $seqStmt = mysqli_prepare($conn, "
                SELECT student_number
                FROM students
                WHERE student_number LIKE CONCAT(?, '-%')
                ORDER BY CAST(SUBSTRING_INDEX(student_number, '-', -1) AS UNSIGNED) DESC
                LIMIT 1
            ");
            if (!$seqStmt) {
                throw new RuntimeException('Unable to prepare student number generator.');
            }
            mysqli_stmt_bind_param($seqStmt, 's', $year);
            if (!mysqli_stmt_execute($seqStmt)) {
                mysqli_stmt_close($seqStmt);
                throw new RuntimeException('Unable to generate student number.');
            }
            $last = mysqli_fetch_assoc(mysqli_stmt_get_result($seqStmt));
            mysqli_stmt_close($seqStmt);

            $next = 1;
            if ($last && preg_match('/^' . preg_quote($year, '/') . '-(\d+)$/', (string)$last['student_number'], $matches)) {
                $next = (int)$matches[1] + 1;
            }
            $studentNumber = $year . '-' . str_pad((string)$next, 3, '0', STR_PAD_LEFT);
        }

        $student = mysqli_prepare($conn, "
            UPDATE students
            SET student_number = ?, enrollment_status = 'Approved',
                payment_status = CASE WHEN COALESCE(remaining_balance, 0) > 0 THEN payment_status ELSE 'Pending' END,
                remaining_balance = CASE WHEN COALESCE(remaining_balance, 0) > 0 THEN remaining_balance ELSE ? END
            WHERE id = ?
        ");
        if (!$student) {
            throw new RuntimeException('Unable to prepare student approval update.');
        }
        mysqli_stmt_bind_param($student, 'sdi', $studentNumber, $enrollmentFee, $studentId);
        if (!mysqli_stmt_execute($student) || mysqli_stmt_affected_rows($student) !== 1) {
            mysqli_stmt_close($student);
            throw new RuntimeException('Unable to update student approval state.');
        }
        mysqli_stmt_close($student);

        $enrollment = mysqli_prepare($conn, "UPDATE enrollments SET STATUS = 'Approved' WHERE id = ? AND STATUS = 'Pending'");
        if (!$enrollment) {
            throw new RuntimeException('Unable to prepare enrollment approval update.');
        }
        mysqli_stmt_bind_param($enrollment, 'i', $enrollmentId);
        if (!mysqli_stmt_execute($enrollment) || mysqli_stmt_affected_rows($enrollment) !== 1) {
            mysqli_stmt_close($enrollment);
            throw new RuntimeException('Enrollment was changed by another request.');
        }
        mysqli_stmt_close($enrollment);

        mysqli_commit($conn);

        if ($studentNumberLock !== null) {
            admin_release_student_number_lock($conn, $studentNumberLock);
        }

        return $studentNumber;
    } catch (Throwable $e) {
        mysqli_rollback($conn);

        if ($studentNumberLock !== null) {
            admin_release_student_number_lock($conn, $studentNumberLock);
        }

        throw $e;
    }
}

function admin_release_student_number_lock(mysqli $conn, string $lockName): void
{
    $release = mysqli_prepare($conn, 'SELECT RELEASE_LOCK(?)');
    if ($release) {
        mysqli_stmt_bind_param($release, 's', $lockName);
        mysqli_stmt_execute($release);
        mysqli_stmt_close($release);
    }
}

function admin_reject_enrollment(mysqli $conn, int $enrollmentId): void
{
    if ($enrollmentId < 1) {
        throw new InvalidArgumentException('Invalid enrollment.');
    }

    mysqli_begin_transaction($conn);

    try {
        $lookup = mysqli_prepare($conn, '
            SELECT student_id, STATUS
            FROM enrollments
            WHERE id = ?
            FOR UPDATE
        ');
        if (!$lookup) {
            throw new RuntimeException('Unable to prepare enrollment lookup.');
        }
        mysqli_stmt_bind_param($lookup, 'i', $enrollmentId);
        mysqli_stmt_execute($lookup);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($lookup));
        mysqli_stmt_close($lookup);

        if (!$row) {
            throw new RuntimeException('Enrollment not found.');
        }
        if (strcasecmp((string)$row['STATUS'], 'Pending') !== 0) {
            throw new RuntimeException('Only pending enrollments can be rejected.');
        }

        $studentId = (int)$row['student_id'];

        $enrollment = mysqli_prepare($conn, "UPDATE enrollments SET STATUS = 'Rejected' WHERE id = ? AND STATUS = 'Pending'");
        if (!$enrollment) {
            throw new RuntimeException('Unable to prepare enrollment rejection.');
        }
        mysqli_stmt_bind_param($enrollment, 'i', $enrollmentId);
        if (!mysqli_stmt_execute($enrollment) || mysqli_stmt_affected_rows($enrollment) !== 1) {
            mysqli_stmt_close($enrollment);
            throw new RuntimeException('Enrollment was changed by another request.');
        }
        mysqli_stmt_close($enrollment);

        $student = mysqli_prepare($conn, "UPDATE students SET enrollment_status = 'Rejected', student_number = NULL WHERE id = ?");
        if (!$student) {
            throw new RuntimeException('Unable to prepare student rejection update.');
        }
        mysqli_stmt_bind_param($student, 'i', $studentId);
        if (!mysqli_stmt_execute($student) || mysqli_stmt_affected_rows($student) !== 1) {
            mysqli_stmt_close($student);
            throw new RuntimeException('Unable to update student rejection state.');
        }
        mysqli_stmt_close($student);

        mysqli_commit($conn);
    } catch (Throwable $e) {
        mysqli_rollback($conn);
        throw $e;
    }
}
