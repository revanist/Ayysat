# EYYSAT Role Structure

## 1. System Admin

**Purpose:** Technical/system administration only.

### Access
- `admin/admin_dashboard.php` — System Dashboard
- `admin/users.php` — User Management
- `admin/system_settings.php` — System Settings

### Responsibilities
- Create/manage staff accounts
- Reset staff passwords
- Manage roles
- Configure current school year
- Configure default enrollment fee
- Monitor system/account information

**Does not normally:** approve enrollment, manage curriculum/sections, verify payments, or teach classes.

---

## 2. Registrar / Academic Affairs

**Purpose:** Owns the school's academic/SIS operations.

### Access
- `registrar/registrar_dashboard.php`
- Students
- Courses / Programs
- Curriculum
- Sections
- Pending Enrollment
- Enrollment Records
- Instructor Assignments

### Responsibilities
- Review student applications
- Approve/reject enrollment
- Generate student numbers after approval
- Maintain student academic records
- Maintain programs/courses and subjects
- Maintain official curriculum
- Create/manage sections and capacity
- Assign instructors to section subjects
- Maintain enrollment records

---

## 3. Cashier

**Purpose:** Owns payment operations.

### Access
- `cashier/index.php`
- Payment Verification
- Transactions
- Receipts

### Responsibilities
- Review payment requests
- Verify payments
- Record collected amounts
- Track balances
- Provide payment receipts

**Does not approve academic enrollment.**

---

## 4. Instructor / Professor

**Purpose:** Owns teaching/LMS work for assigned classes.

### Access
- My Classes
- Schedule
- Materials
- Announcements
- Activities
- Assignments
- Attendance
- Gradebook
- Performance
- Class Students

### Responsibilities
- Teach assigned subjects/sections
- Upload learning materials
- Create and publish activities
- Manage assignments
- Record attendance
- Grade submissions
- Communicate with students
- Review class performance

**Does not create official curriculum or sections.**

---

## 5. Student

**Purpose:** Uses the SIS and LMS as the learner.

### Access
- Dashboard
- Enrollment & Status
- Payments
- Profile
- Curriculum
- Activities
- Notifications

### Responsibilities
- Submit admission/enrollment application
- Select course, section and curriculum subjects
- Pay/submit payment requests
- View enrollment status
- View official curriculum
- Access assigned LMS activities
- Submit assignments/activities
- View grades and attendance
- Receive instructor announcements

---

## Main System Flow

```text
Student submits application
        ↓
Registrar reviews application
        ↓
Registrar approves/rejects
        ↓
Student number generated on approval
        ↓
Registrar maintains section + instructor assignment
        ↓
Student is enrolled in the academic structure
        ↓
Student submits payment request
        ↓
Cashier verifies payment
        ↓
Student accesses LMS class/activity
        ↓
Instructor manages materials, activities, attendance and grades
```

## Ownership Rule

```text
Admin       → System
Registrar   → School / Academic / SIS
Cashier     → Money / Payments
Instructor  → Teaching / LMS
Student     → Enrollment / Learning
```

## Configuration

The System Admin can change the current school year and default enrollment fee from **System Settings**. The Registrar and Cashier use these settings automatically; they should not edit PHP files for normal term changes.
