<?php
session_start();
require_once __DIR__ . '/../db/dbconn.php';
require_once __DIR__ . '/../functions/student_data.php';

$ref = isset($_GET['ref']) ? $_GET['ref'] : '';
$gmail_username = '19rainier@gmail.com'; 
$gmail_app_password = 'jiuu rmqn nrmj hqpa'; 

function send_smtp_email($to, $subject, $message, $smtp_user, $smtp_pass)
{
    $host = 'ssl://smtp.gmail.com';
    $port = 465;
    $socket = @fsockopen($host, $port, $errno, $errstr, 15);
    if (!$socket) return false;
    fread($socket, 515);
    fwrite($socket, "EHLO localhost\r\n"); fread($socket, 515);
    fwrite($socket, "AUTH LOGIN\r\n"); fread($socket, 515);
    fwrite($socket, base64_encode($smtp_user) . "\r\n"); fread($socket, 515);
    fwrite($socket, base64_encode($smtp_pass) . "\r\n");
    $auth_res = fread($socket, 515);
    if (strpos($auth_res, '235') === false) { fclose($socket); return false; }
    fwrite($socket, "MAIL FROM: <$smtp_user>\r\n"); fread($socket, 515);
    fwrite($socket, "RCPT TO: <$to>\r\n"); fread($socket, 515);
    fwrite($socket, "DATA\r\n"); fread($socket, 515);
    $headers = "From: EYYSAT Payment <$smtp_user>\r\nTo: $to\r\nSubject: $subject\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n";
    fwrite($socket, $headers . "\r\n" . $message . "\r\n.\r\n"); fread($socket, 515);
    fwrite($socket, "QUIT\r\n");
    fclose($socket);
    return true;
}

if ($ref) {
    $q = mysqli_prepare($conn, "SELECT p.*, s.first_name, s.last_name, s.email, s.student_number, s.remaining_balance FROM payments p JOIN students s ON s.id = p.student_id WHERE p.reference_number = ? AND p.status = 'Pending' LIMIT 1");
    mysqli_stmt_bind_param($q, "s", $ref);
    mysqli_stmt_execute($q);
    $payment = mysqli_fetch_assoc(mysqli_stmt_get_result($q));
    
    if ($payment) {
        $paymentAmount = (float)$payment['amount'];
        $enrollmentId = (int)$payment['enrollment_id'];
        $studentName = trim($payment['first_name'] . ' ' . $payment['last_name']);
        
        // 1. Update Payment Status
        mysqli_query($conn, "UPDATE payments SET status = 'Completed' WHERE id = " . (int)$payment['id']);
        
        // 2. Update Enrollment
        $update = mysqli_prepare($conn, "
            UPDATE enrollments 
            SET payment_method = 'Maya', 
                payment_reference = ?, 
                amount_paid = amount_paid + ?, 
                payment_status = CASE WHEN amount_paid + ? >= ? THEN 'Paid' ELSE 'Partial' END,
                STATUS = 'Enrolled'
            WHERE id = ?
        ");
        $targetAmt = (float)$payment['remaining_balance'];
        mysqli_stmt_bind_param($update, "sdddi", $ref, $paymentAmount, $paymentAmount, $targetAmt, $enrollmentId);
        mysqli_stmt_execute($update);
        
        // 3. Insert Notification
        $notifMessage = "Received Maya payment of ₱" . number_format($paymentAmount, 2) . " from {$studentName} ({$payment['student_number']}). Ref: {$ref}";
        $notifStmt = mysqli_prepare($conn, "INSERT INTO admin_notifications (enrollment_id, message, is_read, admin_is_read, cashier_is_read) VALUES (?, ?, 0, 0, 0)");
        mysqli_stmt_bind_param($notifStmt, 'is', $enrollmentId, $notifMessage);
        mysqli_stmt_execute($notifStmt);
        
        // 4. Update Student Balance
        mysqli_query($conn, "UPDATE students SET remaining_balance = GREATEST(0, remaining_balance - {$paymentAmount}), payment_status = CASE WHEN remaining_balance - {$paymentAmount} <= 0 THEN 'Paid' ELSE 'Partial' END WHERE id = " . (int)$payment['student_id']);
        
        // 5. Send Email
        $formattedAmount = number_format($paymentAmount, 2);
        $receiptBody = "
        <div style='font-family: Arial, sans-serif; padding: 20px; max-width: 500px; margin: 0 auto; border: 1px solid #ddd; border-radius: 8px;'>
            <h2 style='color: #10b981; margin-top: 0;'>Payment Successful</h2>
            <p>Hi {$studentName},</p>
            <p>We have successfully received your payment via Maya.</p>
            <table style='width: 100%; text-align: left; margin-top: 20px; border-collapse: collapse;'>
                <tr><td style='padding: 8px 0; border-bottom: 1px solid #eee;'><strong>Reference:</strong></td><td style='padding: 8px 0; border-bottom: 1px solid #eee;'>{$ref}</td></tr>
                <tr><td style='padding: 8px 0; border-bottom: 1px solid #eee;'><strong>Method:</strong></td><td style='padding: 8px 0; border-bottom: 1px solid #eee;'>Maya</td></tr>
                <tr><td style='padding: 8px 0; border-bottom: 1px solid #eee;'><strong>Amount:</strong></td><td style='padding: 8px 0; border-bottom: 1px solid #eee;'>₱{$formattedAmount}</td></tr>
                <tr><td style='padding: 8px 0; border-bottom: 1px solid #eee;'><strong>Status:</strong></td><td style='padding: 8px 0; border-bottom: 1px solid #eee;'>PAID</td></tr>
            </table>
            <p style='margin-top: 20px; color: #6b7280; font-size: 12px;'>This receipt was automatically generated by the EYYSAT System.</p>
        </div>";
        send_smtp_email($payment['email'], "Official Receipt: $ref", $receiptBody, $gmail_username, $gmail_app_password);
        
        // Redirect to student profile
        header("Location: ../student/profile.php?payment=success");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f4f4f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); text-align: center; max-width: 400px; width: 100%; }
        .icon { font-size: 60px; color: #10b981; margin-bottom: 20px; }
        h2 { color: #111827; margin: 0 0 10px; }
        p { color: #4b5563; margin-bottom: 20px; }
        .btn { background: #e5e7eb; color: #374151; text-decoration: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; display: inline-block; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">✓</div>
        <h2>Payment Processed!</h2>
        <p>Your transaction has been recorded.</p>
        <a href="../student/profile.php" class="btn">Return to Profile</a>
    </div>
</body>
</html>
