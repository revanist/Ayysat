<?php
require_once __DIR__.'/../functions/student_auth.php';
require_student_login();
require_once __DIR__.'/../db/dbconn.php';
require_once __DIR__.'/../functions/enrollment_setup.php';
require_once __DIR__.'/../functions/student_data.php';
ensure_enrollment_schema($conn);
$student=get_student_profile($conn,(int)$_SESSION['user_id']);
if(!$student) exit('Student profile not found.');
$id=(int)($_GET['id']??$_POST['activity_id']??0);
$q=mysqli_prepare($conn,"SELECT a.*,ta.section_id,ta.school_year,ta.semester,sub.subject_code,sub.subject_name,sec.section_name FROM lms_activities a JOIN teaching_assignments ta ON ta.id=a.assignment_id JOIN subjects sub ON sub.id=ta.subject_id JOIN sections sec ON sec.id=ta.section_id JOIN enrollments e ON e.section_id=ta.section_id AND e.student_id=? AND e.school_year=ta.school_year AND e.sem=ta.semester AND e.STATUS IN ('Approved','Enrolled') WHERE a.id=? AND a.status IN ('Published','Closed') LIMIT 1");
mysqli_stmt_bind_param($q,'ii',$student['id'],$id);mysqli_stmt_execute($q);$activity=mysqli_fetch_assoc(mysqli_stmt_get_result($q));
if(!$activity){http_response_code(404);exit('Activity not available to you.');}
$q=mysqli_prepare($conn,"SELECT * FROM lms_submissions WHERE activity_id=? AND student_id=?");mysqli_stmt_bind_param($q,'ii',$id,$student['id']);mysqli_stmt_execute($q);$submission=mysqli_fetch_assoc(mysqli_stmt_get_result($q));
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 require_student_csrf();
 if($activity['status']==='Closed'){$err='This activity is closed.';}
 else {
  $text=trim($_POST['submission_text']??'');$file=$_FILES['submission']??null;$relative=null;$mime=null;$size=null;$original=null;
  if($file&&$file['error']===UPLOAD_ERR_OK){
   if($file['size']>20*1024*1024)$err='File is too large.';
   else {
    $allowed=['pdf'=>'application/pdf','doc'=>'application/msword','docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document','pptx'=>'application/vnd.openxmlformats-officedocument.presentationml.presentation','xlsx'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','zip'=>'application/zip','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png'];
    $ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
    if(!isset($allowed[$ext]))$err='File type not allowed.';
    else {
     $dir=__DIR__.'/../teacher/uploads/submissions';if(!is_dir($dir))mkdir($dir,0750,true);$stored=bin2hex(random_bytes(16)).'.'.$ext;$target=$dir.'/'.$stored;
     if(!move_uploaded_file($file['tmp_name'],$target))$err='Could not save submission.';
     else {$mime=(new finfo(FILEINFO_MIME_TYPE))->file($target);if($mime!==$allowed[$ext]){unlink($target);$err='File content does not match its extension.';}else{$relative='uploads/submissions/'.$stored;$size=(int)$file['size'];$original=basename($file['name']);}}
    }
   }
  }
  if($err===''){
   if($text===''&&!$relative)$err='Provide a text response or upload a file.';
   else {
    $q=mysqli_prepare($conn,"INSERT INTO lms_submissions(activity_id,student_id,file_name,file_path,mime_type,file_size,submission_text,status,submitted_at) VALUES(?,?,?,?,?,?,?,'Submitted',NOW()) ON DUPLICATE KEY UPDATE file_name=VALUES(file_name),file_path=VALUES(file_path),mime_type=VALUES(mime_type),file_size=VALUES(file_size),submission_text=VALUES(submission_text),status='Submitted',submitted_at=NOW()");
    mysqli_stmt_bind_param($q,'iisssis',$id,$student['id'],$original,$relative,$mime,$size,$text);mysqli_stmt_execute($q);$msg='Submission saved.';
   }
  }
 }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=htmlspecialchars($activity['title'])?> | EYYSAT</title><link rel="stylesheet" href="../css/admin_dashboard.css"><link rel="stylesheet" href="../css/student_profile.css"><link rel="stylesheet" href="../css/teacher.css"></head><body><?php include __DIR__.'/../sidebar/sidebar.php';?><main class="dashboard-main">
<section class="teacher-hero"><div><div class="teacher-eyebrow"><?=htmlspecialchars($activity['subject_code'].' · '.$activity['section_name'])?></div><h1><?=htmlspecialchars($activity['title'])?></h1><p><?=htmlspecialchars($activity['activity_type'])?> · Max <?=number_format((float)$activity['max_score'],2)?> · <?= $activity['due_at']?htmlspecialchars(date('M d, Y g:i A',strtotime($activity['due_at']))):'No due date'?></p></div></section>
<?php if($msg):?><div class="notice"><?=htmlspecialchars($msg)?></div><?php endif;?><?php if($err):?><div class="notice error"><?=htmlspecialchars($err)?></div><?php endif;?>
<section class="teacher-grid"><div class="teacher-panel"><h2>Instructions</h2><p><?=nl2br(htmlspecialchars($activity['instructions']??'No instructions provided.'))?></p></div><div class="teacher-panel"><h2>Your submission</h2><?php if($submission):?><div class="teacher-notification"><strong><?=htmlspecialchars($submission['status'])?></strong><p>Submitted <?=htmlspecialchars(date('M d, Y g:i A',strtotime($submission['submitted_at'])))?></p><?php if($submission['score']!==null):?><p>Score: <strong><?=number_format((float)$submission['score'],2)?> / <?=number_format((float)$activity['max_score'],2)?></strong></p><?php endif;?><?php if($submission['feedback']):?><p>Feedback: <?=nl2br(htmlspecialchars($submission['feedback']))?></p><?php endif;?></div><?php endif;?><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=htmlspecialchars(student_csrf_token())?>"><input type="hidden" name="activity_id" value="<?=$id?>"><div class="field"><label>Response</label><textarea name="submission_text" rows="7"><?=htmlspecialchars($submission['submission_text']??'')?></textarea></div><div class="field" style="margin-top:12px"><label>File (optional, max 20 MB)</label><input type="file" name="submission"></div><button class="teacher-btn primary" type="submit" style="margin-top:12px">Submit work</button></form></div></section></main></body></html>