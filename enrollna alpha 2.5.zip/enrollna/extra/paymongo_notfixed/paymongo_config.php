<?php

/**
 * EYYSAT PAYMONGO CONFIGURATION
 *
 * TEST MODE ONLY
 *
 * Never put the secret key in JavaScript,
 * HTML, or any publicly accessible frontend file.
 */

const PAYMONGO_SECRET_KEY = 'sk_test_XJJuKEXLPpBRZ19Zc7bWuctU';

/*
 * Copy the webhook signing secret from:
 *
 * PayMongo Dashboard
 * → Developer Tools
 * → Webhooks
 * → Your TEST webhook
 * → Signing Secret
 */
const PAYMONGO_WEBHOOK_SECRET = 'whsk_PASTE_YOUR_TEST_WEBHOOK_SECRET_HERE';


/*
 * Your local project URL.
 *
 * XAMPP example:
 *
 * http://localhost/enrollna
 *
 * CHANGE THIS if your project folder has another name.
 */
const APP_BASE_URL = 'http://localhost/enrollna';


/*
 * Enrollment payment amount.
 *
 * 15000.00 = ₱15,000
 */
const ENROLLMENT_PAYMENT_AMOUNT = 15000.00;


/*
 * PayMongo API.
 *
 * Current Hosted Checkout documentation recommends v2
 * for new integrations.
 */
const PAYMONGO_CHECKOUT_URL =
'https://api.paymongo.com/v2/checkout_sessions';


/*
 * PayMongo test mode.
 */
const PAYMONGO_LIVEMODE = false;


/**
 * Perform a PayMongo API request.
 */
function paymongo_request(
    string $method,
    string $url,
    array $payload = null
): array {

    $ch = curl_init($url);

    $headers = [
        'Accept: application/json',
        'Content-Type: application/json',
        'Authorization: Basic ' .
            base64_encode(
                PAYMONGO_SECRET_KEY . ':'
            ),
    ];

    curl_setopt_array(
        $ch,
        [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
        ]
    );

    if ($payload !== null) {

        curl_setopt(
            $ch,
            CURLOPT_POSTFIELDS,
            json_encode(
                $payload,
                JSON_UNESCAPED_SLASHES
            )
        );
    }

    $response = curl_exec($ch);

    $curlError = curl_error($ch);

    $httpCode =
        (int) curl_getinfo(
            $ch,
            CURLINFO_HTTP_CODE
        );

    curl_close($ch);

    if ($response === false || $curlError !== '') {

        throw new RuntimeException(
            'Unable to connect to PayMongo.'
        );
    }

    $decoded = json_decode(
        $response,
        true
    );

    if (!is_array($decoded)) {

        throw new RuntimeException(
            'PayMongo returned an invalid response.'
        );
    }

    if ($httpCode < 200 || $httpCode >= 300) {

        $message =
            $decoded['errors'][0]['detail']
            ?? 'PayMongo request failed.';

        throw new RuntimeException(
            $message
        );
    }

    return $decoded;
}


/**
 * Get a PayMongo Checkout Session.
 */
function paymongo_get_checkout_session(
    string $sessionId
): array {

    return paymongo_request(
        'GET',
        PAYMONGO_CHECKOUT_URL . '/' .
            rawurlencode($sessionId)
    );
}
