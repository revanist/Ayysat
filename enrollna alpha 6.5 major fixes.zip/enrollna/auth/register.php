<?php
/**
 * Account registration now starts from the enrollment form.
 * Students receive/create their portal account as part of the enrollment flow.
 */
require_once __DIR__ . '/../functions/student_auth.php';
start_student_session();

header('Location: ../enrollment.php', true, 303);
exit;
