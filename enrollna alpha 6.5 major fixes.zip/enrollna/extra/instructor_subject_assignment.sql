-- EYYSAT: manual subject-to-instructor assignment
ALTER TABLE teaching_assignments ADD COLUMN assignment_source ENUM('Manual','Legacy') NOT NULL DEFAULT 'Manual';
UPDATE teaching_assignments SET status='Archived', assignment_source='Legacy';
-- The application creates this table automatically and will use it as a one-time migration marker.
